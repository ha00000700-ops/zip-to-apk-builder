package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.domain.model.AthanNotificationType
import com.example.domain.model.Bookmark
import com.example.domain.model.CalculationMethod
import com.example.domain.model.DailyPrayerRecord
import com.example.domain.model.JuristicMethod
import com.example.domain.model.KhatmahPlan
import com.example.domain.model.LocationData
import com.example.domain.model.MuezzinVoice
import com.example.domain.model.PrayerAdjustments
import com.example.domain.model.PrayerCompletionStatus
import com.example.domain.model.PrayerType
import com.example.domain.model.QuranFont
import org.json.JSONArray
import org.json.JSONObject

class SettingsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("al_noor_preferences", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_CALC_METHOD = "calc_method"
        private const val KEY_JURISTIC_METHOD = "juristic_method"
        private const val KEY_CITY_AR = "city_ar"
        private const val KEY_CITY_EN = "city_en"
        private const val KEY_COUNTRY_AR = "country_ar"
        private const val KEY_COUNTRY_EN = "country_en"
        private const val KEY_LAT = "lat"
        private const val KEY_LNG = "lng"
        private const val KEY_TZ = "tz"
        private const val KEY_AUTO_GPS = "auto_gps"
        private const val KEY_MUEZZIN = "muezzin"
        private const val KEY_DND_MINUTES = "dnd_minutes"
        private const val KEY_FAJR_SMART_ALARM = "fajr_smart_alarm"
        private const val KEY_PRE_ATHAN_MINS = "pre_athan_mins"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_ARABIC_FONT_SIZE = "arabic_font_size"
        private const val KEY_QURAN_FONT = "quran_font"
        private const val KEY_TASBIH_LIFETIME = "tasbih_lifetime"
        private const val KEY_TASBIH_TODAY = "tasbih_today"
        private const val KEY_TASBIH_TODAY_DATE = "tasbih_today_date"
        private const val KEY_BOOKMARKS = "bookmarks"
        private const val KEY_KHATMAH_PAGES = "khatmah_pages"
        private const val KEY_KHATMAH_DAYS = "khatmah_days"
        private const val KEY_LAST_READ_SURAH = "last_read_surah"
        private const val KEY_LAST_READ_AYAH = "last_read_ayah"
    }

    fun getCalculationMethod(): CalculationMethod {
        val id = prefs.getString(KEY_CALC_METHOD, CalculationMethod.UMM_AL_QURA.id)
        return CalculationMethod.values().firstOrNull { it.id == id } ?: CalculationMethod.UMM_AL_QURA
    }

    fun saveCalculationMethod(method: CalculationMethod) {
        prefs.edit().putString(KEY_CALC_METHOD, method.id).apply()
    }

    fun getJuristicMethod(): JuristicMethod {
        val name = prefs.getString(KEY_JURISTIC_METHOD, JuristicMethod.STANDARD.name)
        return try {
            JuristicMethod.valueOf(name ?: JuristicMethod.STANDARD.name)
        } catch (_: Exception) {
            JuristicMethod.STANDARD
        }
    }

    fun saveJuristicMethod(method: JuristicMethod) {
        prefs.edit().putString(KEY_JURISTIC_METHOD, method.name).apply()
    }

    fun getLocation(): LocationData {
        val cityAr = prefs.getString(KEY_CITY_AR, CityLocationsRepository.defaultCity.cityNameAr) ?: CityLocationsRepository.defaultCity.cityNameAr
        val cityEn = prefs.getString(KEY_CITY_EN, CityLocationsRepository.defaultCity.cityNameEn) ?: CityLocationsRepository.defaultCity.cityNameEn
        val countryAr = prefs.getString(KEY_COUNTRY_AR, CityLocationsRepository.defaultCity.countryAr) ?: CityLocationsRepository.defaultCity.countryAr
        val countryEn = prefs.getString(KEY_COUNTRY_EN, CityLocationsRepository.defaultCity.countryEn) ?: CityLocationsRepository.defaultCity.countryEn
        val lat = prefs.getFloat(KEY_LAT, CityLocationsRepository.defaultCity.latitude.toFloat()).toDouble()
        val lng = prefs.getFloat(KEY_LNG, CityLocationsRepository.defaultCity.longitude.toFloat()).toDouble()
        val tz = prefs.getFloat(KEY_TZ, CityLocationsRepository.defaultCity.timeZoneOffsetHours.toFloat()).toDouble()
        val isAutoGps = prefs.getBoolean(KEY_AUTO_GPS, false)

        return LocationData(cityAr, cityEn, countryAr, countryEn, lat, lng, tz, isAutoGps)
    }

    fun saveLocation(loc: LocationData) {
        prefs.edit()
            .putString(KEY_CITY_AR, loc.cityNameAr)
            .putString(KEY_CITY_EN, loc.cityNameEn)
            .putString(KEY_COUNTRY_AR, loc.countryAr)
            .putString(KEY_COUNTRY_EN, loc.countryEn)
            .putFloat(KEY_LAT, loc.latitude.toFloat())
            .putFloat(KEY_LNG, loc.longitude.toFloat())
            .putFloat(KEY_TZ, loc.timeZoneOffsetHours.toFloat())
            .putBoolean(KEY_AUTO_GPS, loc.isAutoGps)
            .apply()
    }

    fun getAdjustments(): PrayerAdjustments {
        return PrayerAdjustments(
            fajr = prefs.getInt("adj_fajr", 0),
            sunrise = prefs.getInt("adj_sunrise", 0),
            dhuhr = prefs.getInt("adj_dhuhr", 0),
            asr = prefs.getInt("adj_asr", 0),
            maghrib = prefs.getInt("adj_maghrib", 0),
            isha = prefs.getInt("adj_isha", 0)
        )
    }

    fun saveAdjustments(adj: PrayerAdjustments) {
        prefs.edit()
            .putInt("adj_fajr", adj.fajr)
            .putInt("adj_sunrise", adj.sunrise)
            .putInt("adj_dhuhr", adj.dhuhr)
            .putInt("adj_asr", adj.asr)
            .putInt("adj_maghrib", adj.maghrib)
            .putInt("adj_isha", adj.isha)
            .apply()
    }

    fun getMuezzinVoice(): MuezzinVoice {
        val name = prefs.getString(KEY_MUEZZIN, MuezzinVoice.MAKKAH.name)
        return try {
            MuezzinVoice.valueOf(name ?: MuezzinVoice.MAKKAH.name)
        } catch (_: Exception) {
            MuezzinVoice.MAKKAH
        }
    }

    fun saveMuezzinVoice(voice: MuezzinVoice) {
        prefs.edit().putString(KEY_MUEZZIN, voice.name).apply()
    }

    fun getAthanNotification(prayer: PrayerType): AthanNotificationType {
        val name = prefs.getString("athan_notif_${prayer.name}", AthanNotificationType.FULL_ATHAN.name)
        return try {
            AthanNotificationType.valueOf(name ?: AthanNotificationType.FULL_ATHAN.name)
        } catch (_: Exception) {
            AthanNotificationType.FULL_ATHAN
        }
    }

    fun saveAthanNotification(prayer: PrayerType, type: AthanNotificationType) {
        prefs.edit().putString("athan_notif_${prayer.name}", type.name).apply()
    }

    fun getDndMinutes(): Int = prefs.getInt(KEY_DND_MINUTES, 20)
    fun saveDndMinutes(minutes: Int) = prefs.edit().putInt(KEY_DND_MINUTES, minutes).apply()

    fun isFajrSmartAlarmEnabled(): Boolean = prefs.getBoolean(KEY_FAJR_SMART_ALARM, true)
    fun saveFajrSmartAlarm(enabled: Boolean) = prefs.edit().putBoolean(KEY_FAJR_SMART_ALARM, enabled).apply()

    fun getPreAthanMinutes(): Int = prefs.getInt(KEY_PRE_ATHAN_MINS, 15)
    fun savePreAthanMinutes(minutes: Int) = prefs.edit().putInt(KEY_PRE_ATHAN_MINS, minutes).apply()

    fun isDarkModeEnabled(): Boolean = prefs.getBoolean(KEY_DARK_THEME, false)
    fun saveDarkMode(enabled: Boolean) = prefs.edit().putBoolean(KEY_DARK_THEME, enabled).apply()

    fun getArabicFontSize(): Float = prefs.getFloat(KEY_ARABIC_FONT_SIZE, 22f)
    fun saveArabicFontSize(size: Float) = prefs.edit().putFloat(KEY_ARABIC_FONT_SIZE, size).apply()

    fun getQuranFont(): QuranFont {
        val id = prefs.getString(KEY_QURAN_FONT, QuranFont.HAFS_UTHMANIC.id)
        return QuranFont.values().firstOrNull { it.id == id } ?: QuranFont.HAFS_UTHMANIC
    }
    fun saveQuranFont(font: QuranFont) = prefs.edit().putString(KEY_QURAN_FONT, font.id).apply()

    // Tasbih
    fun getTasbihLifetimeCount(): Long = prefs.getLong(KEY_TASBIH_LIFETIME, 0L)
    fun incrementTasbih() {
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val savedDate = prefs.getString(KEY_TASBIH_TODAY_DATE, "")
        val todayCount = if (savedDate == todayStr) prefs.getInt(KEY_TASBIH_TODAY, 0) + 1 else 1
        val lifetime = prefs.getLong(KEY_TASBIH_LIFETIME, 0L) + 1

        prefs.edit()
            .putLong(KEY_TASBIH_LIFETIME, lifetime)
            .putInt(KEY_TASBIH_TODAY, todayCount)
            .putString(KEY_TASBIH_TODAY_DATE, todayStr)
            .apply()
    }

    fun getTasbihTodayCount(): Int {
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val savedDate = prefs.getString(KEY_TASBIH_TODAY_DATE, "")
        return if (savedDate == todayStr) prefs.getInt(KEY_TASBIH_TODAY, 0) else 0
    }

    // Prayer tracker for a date
    fun getPrayerRecord(dateKey: String): DailyPrayerRecord {
        val fajr = PrayerCompletionStatus.valueOf(prefs.getString("pt_${dateKey}_fajr", PrayerCompletionStatus.NOT_RECORDED.name) ?: PrayerCompletionStatus.NOT_RECORDED.name)
        val dhuhr = PrayerCompletionStatus.valueOf(prefs.getString("pt_${dateKey}_dhuhr", PrayerCompletionStatus.NOT_RECORDED.name) ?: PrayerCompletionStatus.NOT_RECORDED.name)
        val asr = PrayerCompletionStatus.valueOf(prefs.getString("pt_${dateKey}_asr", PrayerCompletionStatus.NOT_RECORDED.name) ?: PrayerCompletionStatus.NOT_RECORDED.name)
        val maghrib = PrayerCompletionStatus.valueOf(prefs.getString("pt_${dateKey}_maghrib", PrayerCompletionStatus.NOT_RECORDED.name) ?: PrayerCompletionStatus.NOT_RECORDED.name)
        val isha = PrayerCompletionStatus.valueOf(prefs.getString("pt_${dateKey}_isha", PrayerCompletionStatus.NOT_RECORDED.name) ?: PrayerCompletionStatus.NOT_RECORDED.name)
        return DailyPrayerRecord(dateKey, fajr, dhuhr, asr, maghrib, isha)
    }

    fun savePrayerStatus(dateKey: String, prayerType: PrayerType, status: PrayerCompletionStatus) {
        val key = "pt_${dateKey}_${prayerType.name.lowercase()}"
        prefs.edit().putString(key, status.name).apply()
    }

    // Khatmah
    fun getKhatmahPlan(): KhatmahPlan {
        val pagesRead = prefs.getInt(KEY_KHATMAH_PAGES, 0)
        val targetDays = prefs.getInt(KEY_KHATMAH_DAYS, 30)
        return KhatmahPlan(totalPages = 604, targetDays = targetDays, pagesReadSoFar = pagesRead)
    }

    fun updateKhatmahProgress(pagesRead: Int, targetDays: Int) {
        prefs.edit()
            .putInt(KEY_KHATMAH_PAGES, pagesRead)
            .putInt(KEY_KHATMAH_DAYS, targetDays)
            .apply()
    }

    // Bookmarks
    fun getBookmarks(): List<Bookmark> {
        val jsonStr = prefs.getString(KEY_BOOKMARKS, "[]") ?: "[]"
        val list = mutableListOf<Bookmark>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    Bookmark(
                        id = obj.getString("id"),
                        surahNumber = obj.getInt("surahNumber"),
                        surahNameAr = obj.getString("surahNameAr"),
                        ayahNumber = obj.getInt("ayahNumber"),
                        timestamp = obj.getLong("timestamp"),
                        note = obj.optString("note", "")
                    )
                )
            }
        } catch (_: Exception) {}
        return list
    }

    fun saveBookmark(bookmark: Bookmark) {
        val current = getBookmarks().toMutableList()
        current.removeAll { it.surahNumber == bookmark.surahNumber && it.ayahNumber == bookmark.ayahNumber }
        current.add(0, bookmark)
        val arr = JSONArray()
        current.take(50).forEach { b ->
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("surahNumber", b.surahNumber)
            obj.put("surahNameAr", b.surahNameAr)
            obj.put("ayahNumber", b.ayahNumber)
            obj.put("timestamp", b.timestamp)
            obj.put("note", b.note)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    fun removeBookmark(surahNumber: Int, ayahNumber: Int) {
        val current = getBookmarks().filterNot { it.surahNumber == surahNumber && it.ayahNumber == ayahNumber }
        val arr = JSONArray()
        current.forEach { b ->
            val obj = JSONObject()
            obj.put("id", b.id)
            obj.put("surahNumber", b.surahNumber)
            obj.put("surahNameAr", b.surahNameAr)
            obj.put("ayahNumber", b.ayahNumber)
            obj.put("timestamp", b.timestamp)
            obj.put("note", b.note)
            arr.put(obj)
        }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }

    fun saveLastRead(surahNumber: Int, ayahNumber: Int) {
        prefs.edit()
            .putInt(KEY_LAST_READ_SURAH, surahNumber)
            .putInt(KEY_LAST_READ_AYAH, ayahNumber)
            .apply()
    }

    fun getLastRead(): Pair<Int, Int> {
        val s = prefs.getInt(KEY_LAST_READ_SURAH, 1)
        val a = prefs.getInt(KEY_LAST_READ_AYAH, 1)
        return Pair(s, a)
    }
}
