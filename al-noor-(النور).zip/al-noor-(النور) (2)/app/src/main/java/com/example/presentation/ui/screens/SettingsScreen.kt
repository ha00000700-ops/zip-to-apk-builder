package com.example.presentation.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DoNotDisturb
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.CalculationMethod
import com.example.domain.model.JuristicMethod
import com.example.domain.model.MuezzinVoice
import com.example.domain.model.PrayerAdjustments
import com.example.domain.model.QuranFont
import com.example.presentation.ui.components.IslamicCard
import com.example.presentation.ui.components.IslamicMotifHeader
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright

@Composable
fun SettingsScreen(viewModel: AlNoorViewModel) {
    val context = LocalContext.current

    val location by viewModel.currentLocation.collectAsState()
    val isGpsLoading by viewModel.isGpsLoading.collectAsState()
    val isCitySearching by viewModel.isCitySearching.collectAsState()
    val citySearchResults by viewModel.citySearchResults.collectAsState()
    val citySearchQuery by viewModel.citySearchQuery.collectAsState()

    val selectedMethod by viewModel.selectedMethod.collectAsState()
    val selectedJuristic by viewModel.selectedJuristic.collectAsState()
    val adjustments by viewModel.prayerAdjustments.collectAsState()
    val muezzinVoice by viewModel.muezzinVoice.collectAsState()
    val previewingMuezzinVoice by viewModel.previewingMuezzinVoice.collectAsState()
    val isDndEnabled by viewModel.dndMinutes.collectAsState()
    val fajrSmartAlarm by viewModel.fajrSmartAlarm.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val arabicFontSize by viewModel.arabicFontSize.collectAsState()
    val quranFont by viewModel.quranFont.collectAsState()

    var showLocationDialog by remember { mutableStateOf(false) }
    var showMethodDialog by remember { mutableStateOf(false) }
    var showJuristicDialog by remember { mutableStateOf(false) }
    var showAdjustmentsDialog by remember { mutableStateOf(false) }
    var showMuezzinDialog by remember { mutableStateOf(false) }
    var showQuranFontDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 100.dp)
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            IslamicMotifHeader(
                titleAr = "الإعدادات والحساب الفلكي",
                subtitleAr = "تخصيص طرق الحساب الشرعية، أصوات الأذان، والتنبيهات الذكية"
            )
        }

        // Section 1: Calculation Engine Settings
        item {
            SettingsCategoryHeader(title = "الحساب الفلكي والمذهب الفقهي")
        }

        item {
            IslamicCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SettingsNavigationItem(
                        icon = Icons.Default.Place,
                        title = "المدينة والموقع الجغرافي",
                        subtitle = "${location.cityNameAr} • ${location.countryAr}",
                        onClick = { showLocationDialog = true }
                    )
                    SettingsDivider()
                    SettingsNavigationItem(
                        icon = Icons.Default.Tune,
                        title = "طريقة حساب المواقيت",
                        subtitle = selectedMethod.titleAr,
                        onClick = { showMethodDialog = true }
                    )
                    SettingsDivider()
                    SettingsNavigationItem(
                        icon = Icons.Default.Mosque,
                        title = "المذهب الفقهي لصلاة العصر",
                        subtitle = selectedJuristic.titleAr,
                        onClick = { showJuristicDialog = true }
                    )
                    SettingsDivider()
                    SettingsNavigationItem(
                        icon = Icons.Default.Tune,
                        title = "التعديل اليدوي للمواقيت (بالدقائق)",
                        subtitle = "ضبط يدوي دقيق (+/- دقائق) لكل صلاة",
                        onClick = { showAdjustmentsDialog = true }
                    )
                }
            }
        }

        // Section 2: Athan & Notifications
        item {
            SettingsCategoryHeader(title = "الأذان والتنبيهات الذكية")
        }

        item {
            IslamicCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SettingsNavigationItem(
                        icon = Icons.Default.VolumeUp,
                        title = "صوت المؤذن",
                        subtitle = muezzinVoice.titleAr,
                        onClick = { showMuezzinDialog = true }
                    )
                    SettingsDivider()
                    SettingsSwitchItem(
                        icon = Icons.Default.Alarm,
                        title = "منبه الفجر الذكي",
                        subtitle = "إيقاظ تدريجي قبل أذان الفجر بـ 15 دقيقة",
                        checked = fajrSmartAlarm,
                        onCheckedChange = { viewModel.setFajrSmartAlarm(it) }
                    )
                    SettingsDivider()
                    SettingsSwitchItem(
                        icon = Icons.Default.DoNotDisturb,
                        title = "وضع الصامت التلقائي أثناء الصلاة",
                        subtitle = "تفعيل وضع عدم الإزعاج لمدة 20 دقيقة عند رفع الأذان",
                        checked = isDndEnabled > 0,
                        onCheckedChange = { enabled -> viewModel.setDndMinutes(if (enabled) 20 else 0) }
                    )
                }
            }
        }

        // Section 3: Appearance & Display
        item {
            SettingsCategoryHeader(title = "المظهر والخط العربي")
        }

        item {
            IslamicCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    SettingsSwitchItem(
                        icon = if (isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                        title = "الوضع الليلي (Dark Mode)",
                        subtitle = "مظهر داكن مريح للعين في التلاوة الليلية",
                        checked = isDarkMode,
                        onCheckedChange = { viewModel.toggleDarkMode() }
                    )
                    SettingsDivider()
                    SettingsNavigationItem(
                        icon = Icons.Default.FormatSize,
                        title = "خط المصحف الشريف وحجمه",
                        subtitle = "${quranFont.nameAr} • ${arabicFontSize.toInt()} sp",
                        onClick = { showQuranFontDialog = true }
                    )
                }
            }
        }

        // Section 4: About & Precision Info
        item {
            SettingsCategoryHeader(title = "حول التطبيق والمعايير الفلكية")
        }

        item {
            IslamicCard(onClick = { showAboutDialog = true }) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "عن تطبيق النور (Al-Noor)",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = "الإصدار 1.0.0 • خوارزميات فلكية معتمدة شرعاً",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }
                    Text(
                        text = "تفاصيل ↗",
                        style = MaterialTheme.typography.labelMedium.copy(color = RoyalGold)
                    )
                }
            }
        }
    }

    // Location Picker Dialog
    if (showLocationDialog) {
        LocationPickerDialog(
            currentLocation = location,
            isGpsLoading = isGpsLoading,
            isSearching = isCitySearching,
            searchQuery = citySearchQuery,
            searchResults = citySearchResults,
            onSearchQueryChanged = { viewModel.searchCities(it) },
            onDetectGps = {
                viewModel.detectGpsLocation { success, message ->
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    if (success) {
                        showLocationDialog = false
                    }
                }
            },
            onLocationSelected = {
                viewModel.setLocation(it)
                showLocationDialog = false
            },
            onDismiss = {
                viewModel.searchCities("")
                showLocationDialog = false
            }
        )
    }

    // Calculation Method Picker Dialog
    if (showMethodDialog) {
        CalculationMethodPickerDialog(
            currentMethod = selectedMethod,
            onMethodSelected = {
                viewModel.setCalculationMethod(it)
                showMethodDialog = false
            },
            onDismiss = { showMethodDialog = false }
        )
    }

    // Juristic Method Dialog
    if (showJuristicDialog) {
        AlertDialog(
            onDismissRequest = { showJuristicDialog = false },
            title = { Text("المذهب الفقهي لحساب صلاة العصر", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    JuristicMethod.values().forEach { juristic ->
                        val isSelected = juristic == selectedJuristic
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.setJuristicMethod(juristic)
                                    showJuristicDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = isSelected, onClick = null)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = juristic.titleAr,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                )
                                Text(
                                    text = juristic.descriptionAr,
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showJuristicDialog = false }) { Text("إغلاق") }
            }
        )
    }

    // Manual Adjustments Dialog
    if (showAdjustmentsDialog) {
        ManualAdjustmentsDialog(
            currentAdjustments = adjustments,
            onSave = {
                viewModel.updateAdjustments(it)
                showAdjustmentsDialog = false
            },
            onDismiss = { showAdjustmentsDialog = false }
        )
    }

    // Muezzin Selector Dialog with Real-time Preview Controls
    if (showMuezzinDialog) {
        MuezzinPickerDialog(
            currentVoice = muezzinVoice,
            previewingVoice = previewingMuezzinVoice,
            onSelect = { voice ->
                viewModel.setMuezzinVoice(voice)
                viewModel.playMuezzinPreview(voice)
            },
            onTogglePreview = { voice ->
                if (previewingMuezzinVoice == voice) {
                    viewModel.stopAudioPreview()
                } else {
                    viewModel.playMuezzinPreview(voice)
                }
            },
            onDismiss = {
                viewModel.stopAudioPreview()
                showMuezzinDialog = false
            }
        )
    }

    // Quran Font & Size Customizer Dialog
    if (showQuranFontDialog) {
        QuranFontCustomizerDialog(
            currentFont = quranFont,
            currentFontSize = arabicFontSize,
            onFontSelect = { viewModel.setQuranFont(it) },
            onFontSizeChange = { viewModel.setArabicFontSize(it) },
            onDismiss = { showQuranFontDialog = false }
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تطبيق النور (Al-Noor)", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "تطبيق إسلامي شامل ومجاني، بدون إعلانات مزعجة وخالي من المشتتات، يهدف لخدمة المسلم في حياته اليومية.",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Column {
                        Text(
                            text = "تطوير وبرمجة وتصميم:",
                            style = MaterialTheme.typography.labelMedium.copy(color = RoyalGold, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Huossam_07",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.ExtraBold, color = EmeraldPrimary)
                        )
                        Text(
                            text = "حقوق الملكية وتطوير البرمجيات © 2026",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Column {
                        Text(
                            text = "المعايير الفلكية والمؤسسات المعتمدة:",
                            style = MaterialTheme.typography.labelMedium.copy(color = RoyalGold, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "• رابطة العالم الإسلامي (Muslim World League)\n• تقويم أم القرى (مكة المكرمة)\n• الهيئة المصرية العامة للمساحة\n• جامعة العلوم الإسلامية بكراتشي\n• معهد الجيوفيزياء بجامعة طهران",
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                        )
                    }

                    Column {
                        Text(
                            text = "الخوارزميات البرمجية:",
                            style = MaterialTheme.typography.labelMedium.copy(color = RoyalGold, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "تم ضبط وتطوير الخوارزميات الفلكية بواسطة: Huossam_07 لضمان أقصى درجات الدقة في حساب زوايا الفجر والعشاء وانحراف القبلة الجيوديسي.",
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }

                    Text(
                        text = "جميع الحقوق محفوظة للمطور Huossam_07",
                        style = MaterialTheme.typography.labelSmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) { Text("إغلاق") }
            }
        )
    }
}

@Composable
fun SettingsCategoryHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall.copy(
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        ),
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    )
}

@Composable
fun SettingsNavigationItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        }
        Text(text = "تعديل ↗", style = MaterialTheme.typography.labelSmall.copy(color = RoyalGold))
    }
}

@Composable
fun SettingsSwitchItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun SettingsDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    )
}

@Composable
fun ManualAdjustmentsDialog(
    currentAdjustments: PrayerAdjustments,
    onSave: (PrayerAdjustments) -> Unit,
    onDismiss: () -> Unit
) {
    var fajr by remember { mutableStateOf(currentAdjustments.fajr) }
    var sunrise by remember { mutableStateOf(currentAdjustments.sunrise) }
    var dhuhr by remember { mutableStateOf(currentAdjustments.dhuhr) }
    var asr by remember { mutableStateOf(currentAdjustments.asr) }
    var maghrib by remember { mutableStateOf(currentAdjustments.maghrib) }
    var isha by remember { mutableStateOf(currentAdjustments.isha) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("التعديل اليدوي للمواقيت (بالدقائق)", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                AdjustmentRow(name = "الفجر", value = fajr, onValueChange = { fajr = it })
                AdjustmentRow(name = "الشروق", value = sunrise, onValueChange = { sunrise = it })
                AdjustmentRow(name = "الظهر", value = dhuhr, onValueChange = { dhuhr = it })
                AdjustmentRow(name = "العصر", value = asr, onValueChange = { asr = it })
                AdjustmentRow(name = "المغرب", value = maghrib, onValueChange = { maghrib = it })
                AdjustmentRow(name = "العشاء", value = isha, onValueChange = { isha = it })
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(PrayerAdjustments(fajr, sunrise, dhuhr, asr, maghrib, isha))
                }
            ) {
                Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdjustmentRow(name: String, value: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { onValueChange(value - 1) }, modifier = Modifier.size(32.dp)) {
                Text("-", style = MaterialTheme.typography.titleLarge)
            }
            Text(
                text = "${if (value > 0) "+$value" else "$value"} دقيقة",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 6.dp)
            )
            IconButton(onClick = { onValueChange(value + 1) }, modifier = Modifier.size(32.dp)) {
                Text("+", style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
fun MuezzinPickerDialog(
    currentVoice: MuezzinVoice,
    previewingVoice: MuezzinVoice?,
    onSelect: (MuezzinVoice) -> Unit,
    onTogglePreview: (MuezzinVoice) -> Unit,
    onDismiss: () -> Unit
) {
    // Ensure preview audio stops when dialog is disposed
    DisposableEffect(Unit) {
        onDispose {
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VolumeUp, contentDescription = null, tint = RoyalGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("اختر صوت الأذان والتنبيه", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "انقر لتحديد المؤذن أو زر الاستماع للمعاينة الفورية:",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                MuezzinVoice.values().forEach { voice ->
                    val isSelected = voice == currentVoice
                    val isPlaying = previewingVoice == voice

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                            )
                            .clickable { onSelect(voice) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { onSelect(voice) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = voice.titleAr,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Text(
                                    text = voice.style,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        // Play/Stop Audio Preview Button
                        IconButton(
                            onClick = { onTogglePreview(voice) },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isPlaying) RoyalGoldBright
                                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                )
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Stop Preview" else "Play Preview",
                                tint = if (isPlaying) Color.Black else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("تم وحفظ", fontWeight = FontWeight.Bold)
            }
        }
    )
}
