package com.example.presentation.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QuranRepository
import com.example.domain.model.Ayah
import com.example.domain.model.Qari
import com.example.domain.model.QuranFont
import com.example.domain.model.Surah
import com.example.presentation.ui.components.IslamicArabesqueBadge
import com.example.presentation.ui.components.IslamicCard
import com.example.presentation.ui.components.IslamicMotifHeader
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright
import com.example.ui.theme.RoyalGoldLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(viewModel: AlNoorViewModel) {
    val surahs by viewModel.allSurahs.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedSurah by viewModel.selectedSurah.collectAsState()
    val currentAyahs by viewModel.currentAyahs.collectAsState()
    val selectedQari by viewModel.selectedQari.collectAsState()
    val isAudioPlaying by viewModel.isQuranAudioPlaying.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val arabicFontSize by viewModel.arabicFontSize.collectAsState()
    val quranFont by viewModel.quranFont.collectAsState()

    var isReaderModeActive by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) } // 0: Surahs, 1: Bookmarks
    var showQariDialog by remember { mutableStateOf(false) }
    var showFontSizeDialog by remember { mutableStateOf(false) }
    var showTranslation by remember { mutableStateOf(true) }
    var showTafsirInline by remember { mutableStateOf(false) }

    val isQuranLoading by viewModel.isQuranLoading.collectAsState()

    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopQuranAudioPlayback()
        }
    }

    if (isReaderModeActive) {
        // Full Surah Reading View
        SurahReaderView(
            surah = selectedSurah,
            ayahs = currentAyahs,
            isLoading = isQuranLoading,
            arabicFontSize = arabicFontSize,
            quranFont = quranFont,
            showTranslation = showTranslation,
            showTafsir = showTafsirInline,
            isAudioPlaying = isAudioPlaying,
            selectedQari = selectedQari,
            onBack = { isReaderModeActive = false },
            onToggleAudio = { viewModel.toggleQuranAudioPlayback() },
            onStopAudio = { viewModel.stopQuranAudioPlayback() },
            onSelectQari = { showQariDialog = true },
            onToggleTranslation = { showTranslation = !showTranslation },
            onToggleTafsir = { showTafsirInline = !showTafsirInline },
            onAdjustFontSize = { showFontSizeDialog = true },
            onToggleBookmark = { ayahNum -> viewModel.toggleBookmark(ayahNum) },
            isAyahBookmarked = { ayahNum -> viewModel.isAyahBookmarked(ayahNum) }
        )
    } else {
        // Surah Index Catalog & Bookmarks View
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 100.dp)
                .testTag("quran_screen")
        ) {
            IslamicMotifHeader(
                titleAr = "المصحف الشريف",
                subtitleAr = "تلاوة وتدبر مع التفسير الميسر والتلاوات الصوتية"
            )

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.searchQuery.let { _ -> viewModel.searchSurahs(it) } },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                placeholder = { Text("ابحث عن سورة بالاسم أو الرقم...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            // Tabs (Surahs / Bookmarks)
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("فهرس السور (114)", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("العلامات المرجعية (${bookmarks.size})", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Bookmark, contentDescription = null, modifier = Modifier.size(18.dp)) }
                )
            }

            if (selectedTab == 0) {
                // Surahs List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(surahs) { surah ->
                        SurahListItemCard(
                            surah = surah,
                            onClick = {
                                viewModel.selectSurah(surah)
                                isReaderModeActive = true
                            }
                        )
                    }
                }
            } else {
                // Bookmarks List
                if (bookmarks.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.BookmarkBorder,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا توجد علامات مرجعية محفوظة",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "اضغط على أيقونة الإشارة المرجعية داخل القارئ لحفظ أي آية والرجوع إليها لاحقاً.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(bookmarks) { bookmark ->
                            IslamicCard(
                                onClick = {
                                    val s = QuranRepository.surahs.find { it.number == bookmark.surahNumber }
                                    if (s != null) {
                                        viewModel.selectSurah(s)
                                        isReaderModeActive = true
                                    }
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Bookmark,
                                            contentDescription = null,
                                            tint = RoyalGold,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = "سورة ${bookmark.surahNameAr} - الآية ${bookmark.ayahNumber}",
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            )
                                            Text(
                                                text = "انقر للمتابعة والقراءة",
                                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )
                                        }
                                    }
                                    IconButton(onClick = { viewModel.toggleBookmark(bookmark.ayahNumber) }) {
                                        Icon(
                                            imageVector = Icons.Default.Bookmark,
                                            contentDescription = "Remove",
                                            tint = RoyalGold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Reciters Dialog
    if (showQariDialog) {
        AlertDialog(
            onDismissRequest = { showQariDialog = false },
            title = {
                Text(
                    text = "اختر القارئ المفضل",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                LazyColumn(modifier = Modifier.height(300.dp)) {
                    items(QuranRepository.qaris) { qari ->
                        val isSelected = qari.id == selectedQari.id
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable {
                                    viewModel.selectQari(qari)
                                    showQariDialog = false
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = qari.nameAr,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Text(
                                    text = "${qari.nameEn} • ${qari.style}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQariDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Font & Style Customizer Dialog
    if (showFontSizeDialog) {
        QuranFontCustomizerDialog(
            currentFont = quranFont,
            currentFontSize = arabicFontSize,
            onFontSelect = { viewModel.setQuranFont(it) },
            onFontSizeChange = { viewModel.setArabicFontSize(it) },
            onDismiss = { showFontSizeDialog = false }
        )
    }
}

@Composable
fun QuranFontCustomizerDialog(
    currentFont: QuranFont,
    currentFontSize: Float,
    onFontSelect: (QuranFont) -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FormatSize, contentDescription = null, tint = RoyalGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تخصيص خط وقراءة المصحف", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Live preview card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RoyalGold.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "معاينة حية للخط:",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "﴿ إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ ﴾",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = currentFont.fontFamily,
                                fontWeight = currentFont.fontWeight,
                                fontSize = currentFontSize.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Font Family Options
                Text(
                    text = "نوع الخط القرآني:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                )
                Spacer(modifier = Modifier.height(6.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    QuranFont.values().forEach { font ->
                        val isSelected = font == currentFont
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
                                    else MaterialTheme.colorScheme.surface
                                )
                                .clickable { onFontSelect(font) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = font.nameAr,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = font.fontFamily,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else font.fontWeight,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Text(
                                    text = font.descriptionAr,
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            androidx.compose.material3.RadioButton(
                                selected = isSelected,
                                onClick = { onFontSelect(font) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Font Size Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "حجم الخط:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )
                    Text(
                        text = "${currentFontSize.toInt()} sp",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = RoyalGold)
                    )
                }

                Slider(
                    value = currentFontSize,
                    onValueChange = onFontSizeChange,
                    valueRange = 18f..38f,
                    steps = 10,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("حفظ التفضيلات", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun SurahListItemCard(
    surah: Surah,
    onClick: () -> Unit
) {
    IslamicCard(onClick = onClick) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Surah Number Badge
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${surah.number}",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = surah.nameAr,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = "${surah.nameEn} • ${surah.englishTranslation}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${surah.numberOfAyahs} آيات",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = RoyalGold
                    )
                )
                Text(
                    text = "${surah.revelationTypeAr} • الجزء ${surah.juz}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    }
}

@Composable
fun SurahReaderView(
    surah: Surah,
    ayahs: List<Ayah>,
    isLoading: Boolean,
    arabicFontSize: Float,
    quranFont: QuranFont,
    showTranslation: Boolean,
    showTafsir: Boolean,
    isAudioPlaying: Boolean,
    selectedQari: Qari,
    onBack: () -> Unit,
    onToggleAudio: () -> Unit,
    onStopAudio: () -> Unit,
    onSelectQari: () -> Unit,
    onToggleTranslation: () -> Unit,
    onToggleTafsir: () -> Unit,
    onAdjustFontSize: () -> Unit,
    onToggleBookmark: (Int) -> Unit,
    isAyahBookmarked: (Int) -> Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("surah_reader_view")
    ) {
        // Top App Bar Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Column {
                    Text(
                        text = "سورة ${surah.nameAr}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = quranFont.fontFamily,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = "${surah.revelationTypeAr} • ${surah.numberOfAyahs} آيات • الجزء ${surah.juz}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }

            Row {
                IconButton(onClick = onAdjustFontSize) {
                    Icon(Icons.Default.FormatSize, contentDescription = "Font Size", tint = RoyalGold)
                }
                IconButton(onClick = onToggleTranslation) {
                    Icon(
                        Icons.Default.Translate,
                        contentDescription = "Translation",
                        tint = if (showTranslation) RoyalGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleTafsir) {
                    Icon(
                        Icons.Default.MenuBook,
                        contentDescription = "Tafsir",
                        tint = if (showTafsir) EmeraldAccent else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (isLoading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth(),
                color = RoyalGold
            )
        }

        // Floating Audio Toolbar
        AudioPlayerBar(
            isAudioPlaying = isAudioPlaying,
            selectedQari = selectedQari,
            surahName = surah.nameAr,
            onToggleAudio = onToggleAudio,
            onStopAudio = onStopAudio,
            onSelectQari = onSelectQari
        )

        // Surah Content List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Independent Standalone Basmala Header (Except Surah 9: At-Tawbah)
            if (surah.number != 9) {
                item {
                    BasmalaHeaderCard(quranFont = quranFont)
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            items(ayahs, key = { it.numberInQuran }) { ayah ->
                val bookmarked = isAyahBookmarked(ayah.numberInSurah)
                AyahReaderCard(
                    ayah = ayah,
                    arabicFontSize = arabicFontSize,
                    quranFont = quranFont,
                    showTranslation = showTranslation,
                    showTafsir = showTafsir,
                    isBookmarked = bookmarked,
                    onToggleBookmark = { onToggleBookmark(ayah.numberInSurah) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun BasmalaHeaderCard(quranFont: QuranFont) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = RoyalGold.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "أَعُوذُ بِٱللَّهِ مِنَ ٱلشَّيْطَٰنِ ٱلرَّجِيمِ",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = quranFont.fontFamily,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text("✦  ", color = RoyalGold, fontSize = 14.sp)
                Text(
                    text = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = quranFont.fontFamily,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = RoyalGold
                    ),
                    textAlign = TextAlign.Center
                )
                Text("  ✦", color = RoyalGold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun AyahReaderCard(
    ayah: Ayah,
    arabicFontSize: Float,
    quranFont: QuranFont,
    showTranslation: Boolean,
    showTafsir: Boolean,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit
) {
    IslamicCard(
        borderColor = if (isBookmarked) RoyalGoldBright else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Ayah Header with Number & Bookmark Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${ayah.numberInSurah}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                IconButton(
                    onClick = onToggleBookmark,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Bookmark",
                        tint = if (isBookmarked) RoyalGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Text with Custom Quran Font and Dynamic Scaling
            Text(
                text = ayah.textAr,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontFamily = quranFont.fontFamily,
                    fontSize = arabicFontSize.sp,
                    lineHeight = (arabicFontSize * 1.8).sp,
                    fontWeight = quranFont.fontWeight,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            // English Translation
            if (showTranslation && ayah.translationEn.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = ayah.translationEn,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                )
            }

            // Inline Tafsir Al-Muyassar
            if (showTafsir && ayah.tafsirMuyassarAr.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "التفسير الميسر :",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = ayah.tafsirMuyassarAr,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 20.sp
                            ),
                            textAlign = TextAlign.Right
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AudioPlayerBar(
    isAudioPlaying: Boolean,
    selectedQari: Qari,
    surahName: String,
    onToggleAudio: () -> Unit,
    onStopAudio: () -> Unit,
    onSelectQari: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelectQari() }
            ) {
                Icon(
                    imageVector = Icons.Default.Headphones,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "القارئ: ${selectedQari.nameAr}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = if (isAudioPlaying) "جارٍ الاستماع لسورة $surahName..." else "انقر لتغيير القارئ",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onStopAudio,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.error.copy(alpha = 0.8f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onToggleAudio,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(EmeraldPrimary)
                ) {
                    Icon(
                        imageVector = if (isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isAudioPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
