package com.example.data.notification

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.SettingsManager
import com.example.domain.calculator.AstronomicalPrayerCalculator
import com.example.domain.model.AthanNotificationType
import com.example.domain.model.PrayerType
import java.util.Calendar

object AthanSchedulerHelper {

    private const val ACTION_ATHAN = "com.example.ACTION_ATHAN_ALARM"

    @SuppressLint("ScheduleExactAlarm")
    fun scheduleAllPrayerAlarms(context: Context) {
        val settingsManager = SettingsManager(context)
        val location = settingsManager.getLocation()
        val method = settingsManager.getCalculationMethod()
        val juristic = settingsManager.getJuristicMethod()
        val adjustments = settingsManager.getAdjustments()
        val muezzin = settingsManager.getMuezzinVoice()

        val calculator = AstronomicalPrayerCalculator()
        val cal = Calendar.getInstance()
        val schedule = calculator.calculateTimes(
            calendar = cal,
            latitude = location.latitude,
            longitude = location.longitude,
            timeZoneOffsetHours = location.timeZoneOffsetHours,
            method = method,
            juristicMethod = juristic,
            adjustments = adjustments
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val now = System.currentTimeMillis()

        data class PrayerAlarmItem(val type: PrayerType, val timeMillis: Long, val nameAr: String)

        val prayersToSchedule = listOf(
            PrayerAlarmItem(PrayerType.FAJR, schedule.fajrMillis, "الفجر"),
            PrayerAlarmItem(PrayerType.DHUHR, schedule.dhuhrMillis, "الظهر"),
            PrayerAlarmItem(PrayerType.ASR, schedule.asrMillis, "العصر"),
            PrayerAlarmItem(PrayerType.MAGHRIB, schedule.maghribMillis, "المغرب"),
            PrayerAlarmItem(PrayerType.ISHA, schedule.ishaMillis, "العشاء")
        )

        for (item in prayersToSchedule) {
            val notifType = settingsManager.getAthanNotification(item.type)
            if (notifType == AthanNotificationType.SILENT) continue

            // If prayer time has passed today, schedule for next day (+24h approx)
            val triggerAtMillis = if (item.timeMillis > now + 2000) {
                item.timeMillis
            } else {
                item.timeMillis + 24 * 60 * 60 * 1000L
            }

            val requestCode = item.type.ordinal + 100
            val intent = Intent(context, AthanAlarmReceiver::class.java).apply {
                this.action = ACTION_ATHAN
                putExtra(AthanForegroundService.EXTRA_PRAYER_NAME, item.nameAr)
                putExtra(AthanForegroundService.EXTRA_MUEZZIN, muezzin.name)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (alarmManager.canScheduleExactAlarms()) {
                        alarmManager.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMillis,
                            pendingIntent
                        )
                    } else {
                        alarmManager.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            triggerAtMillis,
                            pendingIntent
                        )
                    }
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        triggerAtMillis,
                        pendingIntent
                    )
                }
            } catch (_: Exception) {}
        }
    }
}
