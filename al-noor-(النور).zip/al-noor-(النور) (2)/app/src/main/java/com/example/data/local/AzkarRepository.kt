package com.example.data.local

import com.example.domain.model.AzkarCategory
import com.example.domain.model.DhikrPreset
import com.example.domain.model.ZikrItem

object AzkarRepository {

    val dhikrPresets = listOf(
        DhikrPreset("subhanallah", "سُبْحَانَ اللَّهِ", "SubhanAllah", 33, "غرس نخلة في الجنة ومحو الخطايا"),
        DhikrPreset("alhamdulillah", "الْحَمْدُ لِلَّهِ", "Alhamdulillah", 33, "تملأ الميزان بالخير والبركة"),
        DhikrPreset("la_ilaha_illallah", "لَا إِلَٰهَ إِلَّا اللَّهُ", "La ilaha illallah", 33, "أفضل الذكر وخير ما قال النبيون"),
        DhikrPreset("allahu_akbar", "اللَّهُ أَكْبَرُ", "Allahu Akbar", 34, "أعظم الكلمات وأجلها قدراً"),
        DhikrPreset("astaghfirullah", "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ", "Astaghfirullah wa atubu ilayh", 100, "تفريج الهموم واستجلاب الرزق"),
        DhikrPreset("la_hawla", "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", "La hawla wa la quwwata illa billah", 100, "كنز من كنوز الجنة ودواء لـ 99 داء"),
        DhikrPreset("salawat", "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ", "Allahumma salli 'ala Muhammad", 100, "صلاة الله على العبد عشراً وتكفير السيئات"),
        DhikrPreset("subhan_wa_bihamdihi", "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ ، سُبْحَانَ اللَّهِ الْعَظِيمِ", "SubhanAllahi wa bihamdihi SubhanAllahil Azeem", 100, "كلمتان خفيفتان على اللسان ثقيلتان في الميزان")
    )

    val azkarList: List<ZikrItem> = listOf(
        // Morning Azkar
        ZikrItem(
            id = "m_1",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            countTarget = 1,
            virtueAr = "من قالها حين يصبح أُعطي خير ما في هذا اليوم وخير ما بعده، وحُفظ من شره.",
            referenceAr = "رواه مسلم (2723)"
        ),
        ZikrItem(
            id = "m_2",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوبَ إِلاَّ أَنْتَ.",
            countTarget = 1,
            virtueAr = "سيد الاستغفار: من قاله موقناً به حين يصبح فمات من يومه دخل الجنة.",
            referenceAr = "رواه البخاري (6306)"
        ),
        ZikrItem(
            id = "m_3",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.",
            countTarget = 3,
            virtueAr = "لم يضره شيء ولم تصبه فجأة بلاء حتى يمسي.",
            referenceAr = "رواه أبو داود والترمذي"
        ),
        ZikrItem(
            id = "m_4",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالإِسْلاَمِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا.",
            countTarget = 3,
            virtueAr = "كان حقاً على الله أن يرضيه يوم القيامة.",
            referenceAr = "رواه الترمذي"
        ),
        ZikrItem(
            id = "m_5",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلاَ تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.",
            countTarget = 1,
            virtueAr = "وصية النبي ﷺ لفاطمة رضي الله عنها في الصباح والمساء.",
            referenceAr = "رواه النسائي والحاكم"
        ),
        ZikrItem(
            id = "m_6",
            categoryId = AzkarCategory.MORNING.id,
            textAr = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ.",
            countTarget = 3,
            virtueAr = "تزن جميع ما سبح العبد طول نهاره في الأجر والثواب.",
            referenceAr = "رواه مسلم"
        ),

        // Evening Azkar
        ZikrItem(
            id = "e_1",
            categoryId = AzkarCategory.EVENING.id,
            textAr = "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            countTarget = 1,
            virtueAr = "حفظ العبد في ليلته وسؤاله خير ما فيها والاستعاذة من شرها والكسل وسوء الكبر.",
            referenceAr = "رواه مسلم"
        ),
        ZikrItem(
            id = "e_2",
            categoryId = AzkarCategory.EVENING.id,
            textAr = "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.",
            countTarget = 3,
            virtueAr = "لم يضره شيء في تلك الليلة ولا حمة (لدغة عقرب أو حية).",
            referenceAr = "رواه مسلم"
        ),
        ZikrItem(
            id = "e_3",
            categoryId = AzkarCategory.EVENING.id,
            textAr = "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لاَ إِلَهَ إِلاَّ أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لاَ إِلَهَ إِلاَّ أَنْتَ.",
            countTarget = 3,
            virtueAr = "سؤال العافية التامة في الجسد والسمع والبصر والنجاة من الفقر وعذاب القبر.",
            referenceAr = "رواه أبو داود"
        ),

        // After Prayer Azkar
        ZikrItem(
            id = "ap_1",
            categoryId = AzkarCategory.AFTER_PRAYER.id,
            textAr = "أَسْتَغْفِرُ اللَّهَ (ثَلاَثاً) .. اللَّهُمَّ أَنْتَ السَّلاَمُ وَمِنْكَ السَّلاَمُ، تَبَارَكْتَ يَا ذَا الْجَلاَلِ وَالإِكْرَامِ.",
            countTarget = 1,
            virtueAr = "أول ما يستقبل به المصلي ربه عقب الفريضة.",
            referenceAr = "رواه مسلم"
        ),
        ZikrItem(
            id = "ap_2",
            categoryId = AzkarCategory.AFTER_PRAYER.id,
            textAr = "لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ، وَلاَ نَعْبُدُ إِلاَّ إِيَّاهُ، لَهُ النِّعْمَةُ وَلَهُ الْفَضْلُ وَلَهُ الثَّنَاءُ الْحَسَنُ.",
            countTarget = 1,
            virtueAr = "تهليل وتعظيم لله تعالى دبر كل صلاة مكتوبة.",
            referenceAr = "رواه مسلم"
        ),
        ZikrItem(
            id = "ap_3",
            categoryId = AzkarCategory.AFTER_PRAYER.id,
            textAr = "سُبْحَانَ اللَّهِ (33) ، الْحَمْدُ لِلَّهِ (33) ، اللَّهُ أَكْبَرُ (33) ، تمام المائة: لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
            countTarget = 1,
            virtueAr = "غُفرت خطاياه وإن كانت مثل زبد البحر.",
            referenceAr = "رواه مسلم"
        ),
        ZikrItem(
            id = "ap_4",
            categoryId = AzkarCategory.AFTER_PRAYER.id,
            textAr = "قراءة آية الكرسي: ﴿اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ...﴾",
            countTarget = 1,
            virtueAr = "من قرأها دبر كل صلاة مكتوبة لم يمنعه من دخول الجنة إلا أن يموت.",
            referenceAr = "رواه النسائي وصححه الألباني"
        ),

        // Sleep & Wake
        ZikrItem(
            id = "sw_1",
            categoryId = AzkarCategory.SLEEP_WAKE.id,
            textAr = "بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.",
            countTarget = 1,
            virtueAr = "تفويض الروح والنوم في حفظ الله ورعايته.",
            referenceAr = "رواه البخاري ومسلم"
        ),
        ZikrItem(
            id = "sw_2",
            categoryId = AzkarCategory.SLEEP_WAKE.id,
            textAr = "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.",
            countTarget = 1,
            virtueAr = "دعاء الاستيقاظ وشكر نعمة الحياة وتذكر البعث والنشور.",
            referenceAr = "رواه البخاري"
        ),

        // Hajj & Umrah
        ZikrItem(
            id = "hu_1",
            categoryId = AzkarCategory.HAJJ_UMRAH.id,
            textAr = "لَبَّيْكَ اللَّهُمَّ لَبَّيْكَ، لَبَّيْكَ لاَ شَرِيكَ لَكَ لَبَّيْكَ، إِنَّ الْحَمْدَ وَالنِّعْمَةَ لَكَ وَالْمُلْكَ، لاَ شَرِيكَ لَكَ.",
            countTarget = 33,
            virtueAr = "التلبية شعار الحج والعمرة وإعلان التوحيد الخالص لله.",
            referenceAr = "متفق عليه"
        ),
        ZikrItem(
            id = "hu_2",
            categoryId = AzkarCategory.HAJJ_UMRAH.id,
            textAr = "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ.",
            countTarget = 7,
            virtueAr = "الدعاء المأثور بين الركن اليماني والحجر الأسود في الطواف.",
            referenceAr = "رواه أبو داود"
        ),

        // Fortification
        ZikrItem(
            id = "fort_1",
            categoryId = AzkarCategory.FORTIFICATION.id,
            textAr = "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي وَآمِنْ رَوْعَاتِي.",
            countTarget = 1,
            virtueAr = "دعاء الحفظ الشامل للأهل والمال والدين من كل الجهات.",
            referenceAr = "رواه أبو داود وابن ماجه"
        )
    )

    fun getAzkarByCategory(categoryId: String): List<ZikrItem> {
        return azkarList.filter { it.categoryId == categoryId }
    }
}
