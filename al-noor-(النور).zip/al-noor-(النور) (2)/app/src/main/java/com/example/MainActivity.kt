package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.presentation.ui.screens.AzkarScreen
import com.example.presentation.ui.screens.DashboardScreen
import com.example.presentation.ui.screens.QiblaScreen
import com.example.presentation.ui.screens.QuranScreen
import com.example.presentation.ui.screens.SettingsScreen
import com.example.presentation.ui.screens.TrackerScreen
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.AlNoorTheme
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright

sealed class NavigationTab(
    val route: String,
    val titleAr: String,
    val icon: ImageVector,
    val testTag: String
) {
    object Dashboard : NavigationTab("dashboard", "المواقيت", Icons.Default.AccessTime, "nav_dashboard")
    object Qibla : NavigationTab("qibla", "القبلة", Icons.Default.NearMe, "nav_qibla")
    object Quran : NavigationTab("quran", "المصحف", Icons.Default.MenuBook, "nav_quran")
    object Azkar : NavigationTab("azkar", "الأذكار", Icons.Default.Fingerprint, "nav_azkar")
    object Tracker : NavigationTab("tracker", "الرفيق", Icons.Default.TrendingUp, "nav_tracker")
    object Settings : NavigationTab("settings", "الإعدادات", Icons.Default.Settings, "nav_settings")
}

class MainActivity : ComponentActivity() {

    private val viewModel: AlNoorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            AlNoorTheme(darkTheme = isDarkMode) {
                // RTL layout direction for Arabic typography & UI
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MainAppScaffold(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: AlNoorViewModel) {
    var currentTab by remember { mutableStateOf<NavigationTab>(NavigationTab.Dashboard) }
    val isDarkMode by viewModel.isDarkMode.collectAsState()

    val tabs = listOf(
        NavigationTab.Dashboard,
        NavigationTab.Qibla,
        NavigationTab.Quran,
        NavigationTab.Azkar,
        NavigationTab.Tracker
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_scaffold"),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(RoyalGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "النُّــــور",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Al-Noor",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = RoyalGold
                            )
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleDarkMode() },
                        modifier = Modifier.testTag("toggle_dark_mode_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Theme",
                            tint = if (isDarkMode) RoyalGoldBright else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = { currentTab = NavigationTab.Settings },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = if (currentTab == NavigationTab.Settings) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                tabs.forEach { tab ->
                    val selected = currentTab == tab
                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.titleAr,
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = {
                            Text(
                                text = tab.titleAr,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag(tab.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { targetTab ->
                when (targetTab) {
                    NavigationTab.Dashboard -> DashboardScreen(
                        viewModel = viewModel,
                        onNavigateToSettings = { currentTab = NavigationTab.Settings }
                    )
                    NavigationTab.Qibla -> QiblaScreen(viewModel = viewModel)
                    NavigationTab.Quran -> QuranScreen(viewModel = viewModel)
                    NavigationTab.Azkar -> AzkarScreen(viewModel = viewModel)
                    NavigationTab.Tracker -> TrackerScreen(viewModel = viewModel)
                    NavigationTab.Settings -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}
