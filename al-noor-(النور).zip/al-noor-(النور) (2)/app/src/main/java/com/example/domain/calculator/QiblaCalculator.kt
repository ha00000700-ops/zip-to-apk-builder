package com.example.domain.calculator

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object QiblaCalculator {

    // Holy Kaaba Coordinates in Makkah Al-Mukarramah
    const val KAABA_LATITUDE = 21.422487
    const val KAABA_LONGITUDE = 39.826206
    private const val EARTH_RADIUS_KM = 6371.0

    /**
     * Calculates the forward azimuth bearing (Qibla angle in degrees relative to True North 0-360°)
     * from any given latitude and longitude.
     */
    fun calculateQiblaBearing(userLat: Double, userLng: Double): Double {
        val lat1 = Math.toRadians(userLat)
        val lon1 = Math.toRadians(userLng)
        val lat2 = Math.toRadians(KAABA_LATITUDE)
        val lon2 = Math.toRadians(KAABA_LONGITUDE)

        val deltaLon = lon2 - lon1

        val y = sin(deltaLon)
        val x = cos(lat1) * Math.tan(lat2) - sin(lat1) * cos(deltaLon)

        var qiblaAngle = Math.toDegrees(atan2(y, x))
        qiblaAngle = (qiblaAngle + 360.0) % 360.0

        return qiblaAngle
    }

    /**
     * Calculates great-circle distance in Kilometers from user location to the Holy Kaaba.
     */
    fun calculateDistanceToKaabaKm(userLat: Double, userLng: Double): Double {
        val lat1 = Math.toRadians(userLat)
        val lon1 = Math.toRadians(userLng)
        val lat2 = Math.toRadians(KAABA_LATITUDE)
        val lon2 = Math.toRadians(KAABA_LONGITUDE)

        val dLat = lat2 - lat1
        val dLon = lon2 - lon1

        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return EARTH_RADIUS_KM * c
    }

    /**
     * Returns human readable cardinal direction (e.g. "جنوب شرق - SE")
     */
    fun getDirectionLabel(bearing: Double): Pair<String, String> {
        val normalized = (bearing % 360 + 360) % 360
        return when {
            normalized >= 337.5 || normalized < 22.5 -> Pair("شمال (N)", "North")
            normalized >= 22.5 && normalized < 67.5 -> Pair("شمال شرق (NE)", "North-East")
            normalized >= 67.5 && normalized < 112.5 -> Pair("شرق (E)", "East")
            normalized >= 112.5 && normalized < 157.5 -> Pair("جنوب شرق (SE)", "South-East")
            normalized >= 157.5 && normalized < 202.5 -> Pair("جنوب (S)", "South")
            normalized >= 202.5 && normalized < 247.5 -> Pair("جنوب غرب (SW)", "South-West")
            normalized >= 247.5 && normalized < 292.5 -> Pair("غرب (W)", "West")
            else -> Pair("شمال غرب (NW)", "North-West")
        }
    }
}
