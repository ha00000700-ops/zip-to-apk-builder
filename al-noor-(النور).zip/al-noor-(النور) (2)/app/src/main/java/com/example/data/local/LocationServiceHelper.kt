package com.example.data.local

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.example.domain.model.LocationData
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume

class LocationServiceHelper(private val context: Context) {

    private val fusedLocationClient: FusedLocationProviderClient by lazy {
        LocationServices.getFusedLocationProviderClient(context)
    }

    fun hasLocationPermission(): Boolean {
        val finePermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarsePermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return finePermission || coarsePermission
    }

    @SuppressLint("MissingPermission")
    suspend fun getCurrentGpsLocation(): LocationData? = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            return@withContext null
        }

        try {
            // First attempt with FusedLocationProviderClient high accuracy
            val location: Location? = suspendCancellableCoroutine { continuation ->
                val cts = CancellationTokenSource()
                fusedLocationClient.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY,
                    cts.token
                ).addOnSuccessListener { loc ->
                    continuation.resume(loc)
                }.addOnFailureListener {
                    continuation.resume(null)
                }
                continuation.invokeOnCancellation { cts.cancel() }
            } ?: suspendCancellableCoroutine { continuation ->
                // Fallback to last known location
                fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                    continuation.resume(loc)
                }.addOnFailureListener {
                    continuation.resume(null)
                }
            } ?: getFallbackLocationFromLocationManager()

            if (location != null) {
                return@withContext resolveLocationData(location.latitude, location.longitude)
            }
        } catch (_: Exception) {
            // Fallback gracefully
        }
        null
    }

    @SuppressLint("MissingPermission")
    private fun getFallbackLocationFromLocationManager(): Location? {
        try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                ?: return null
            val providers = locationManager.getProviders(true)
            for (provider in providers) {
                val loc = locationManager.getLastKnownLocation(provider)
                if (loc != null) return loc
            }
        } catch (_: Exception) {}
        return null
    }

    suspend fun resolveLocationData(latitude: Double, longitude: Double): LocationData = withContext(Dispatchers.IO) {
        var cityNameAr = "موقعي الحالي"
        var cityNameEn = "Current Location"
        var countryAr = "تحديد تلقائي (GPS)"
        var countryEn = "Auto GPS"

        try {
            val geocoder = Geocoder(context, Locale("ar"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val addresses = suspendCancellableCoroutine<List<Address>> { cont ->
                    geocoder.getFromLocation(latitude, longitude, 1) { addrs ->
                        cont.resume(addrs)
                    }
                }
                if (addresses.isNotEmpty()) {
                    val addr = addresses[0]
                    addr.locality?.let { cityNameAr = it }
                        ?: addr.subAdminArea?.let { cityNameAr = it }
                        ?: addr.adminArea?.let { cityNameAr = it }
                    addr.countryName?.let { countryAr = it }
                }
            } else {
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(latitude, longitude, 1)
                if (!addresses.isNullOrEmpty()) {
                    val addr = addresses[0]
                    addr.locality?.let { cityNameAr = it }
                        ?: addr.subAdminArea?.let { cityNameAr = it }
                        ?: addr.adminArea?.let { cityNameAr = it }
                    addr.countryName?.let { countryAr = it }
                }
            }
        } catch (_: Exception) {
            // Network or geocoder not available, match nearest known city
            val nearest = CityLocationsRepository.allCities.minByOrNull { city ->
                val dLat = city.latitude - latitude
                val dLon = city.longitude - longitude
                dLat * dLat + dLon * dLon
            }
            if (nearest != null) {
                cityNameAr = nearest.cityNameAr
                cityNameEn = nearest.cityNameEn
                countryAr = nearest.countryAr
                countryEn = nearest.countryEn
            }
        }

        val tz = TimeZone.getDefault()
        val offsetHours = tz.getOffset(System.currentTimeMillis()) / (1000.0 * 60.0 * 60.0)

        LocationData(
            cityNameAr = cityNameAr,
            cityNameEn = cityNameEn,
            countryAr = countryAr,
            countryEn = countryEn,
            latitude = latitude,
            longitude = longitude,
            timeZoneOffsetHours = offsetHours,
            isAutoGps = true
        )
    }
}
