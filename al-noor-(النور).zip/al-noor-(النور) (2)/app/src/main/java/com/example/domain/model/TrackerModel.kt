package com.example.domain.model

enum class PrayerCompletionStatus(val titleAr: String, val titleEn: String, val colorHex: Long) {
    NOT_RECORDED("لم تسجل", "Not Recorded", 0xFF64748B),
    IN_MOSQUE("في المسجد", "In Mosque", 0xFF10B981),
    ON_TIME("في وقتها", "On Time", 0xFF059669),
    LATE("متأخرة", "Late", 0xFFF59E0B),
    QADA("قضاء", "Qada (Missed)", 0xFFEF4444)
}

data class DailyPrayerRecord(
    val dateKey: String, // YYYY-MM-DD
    val fajr: PrayerCompletionStatus = PrayerCompletionStatus.NOT_RECORDED,
    val dhuhr: PrayerCompletionStatus = PrayerCompletionStatus.NOT_RECORDED,
    val asr: PrayerCompletionStatus = PrayerCompletionStatus.NOT_RECORDED,
    val maghrib: PrayerCompletionStatus = PrayerCompletionStatus.NOT_RECORDED,
    val isha: PrayerCompletionStatus = PrayerCompletionStatus.NOT_RECORDED
)

data class KhatmahPlan(
    val totalPages: Int = 604,
    val targetDays: Int = 30,
    val startDateMillis: Long = System.currentTimeMillis(),
    val pagesReadSoFar: Int = 0,
    val isActive: Boolean = true
) {
    val dailyPagesRequired: Int
        get() = kotlin.math.ceil((totalPages - pagesReadSoFar).toDouble() / kotlin.math.max(1, targetDays)).toInt()
    
    val pagesPerPrayer: Int
        get() = kotlin.math.ceil(dailyPagesRequired / 5.0).toInt()
        
    val progressPercent: Float
        get() = (pagesReadSoFar.toFloat() / totalPages).coerceIn(0f, 1f)
}

data class ZakatInput(
    val cashOnHand: Double = 0.0,
    val bankBalance: Double = 0.0,
    val goldGrams24k: Double = 0.0,
    val goldPricePerGram: Double = 75.0, // USD default configurable
    val silverGrams: Double = 0.0,
    val silverPricePerGram: Double = 0.9,
    val tradeGoodsValue: Double = 0.0,
    val debtsOwedToYouRecoverable: Double = 0.0,
    val debtsYouOweDeductible: Double = 0.0,
    val currencySymbol: String = "$"
)

data class ZakatCalculationResult(
    val totalZakatableWealth: Double,
    val nisabThresholdGold: Double,
    val isNisabReached: Boolean,
    val zakatPayableAmount: Double,
    val goldValue: Double,
    val silverValue: Double,
    val liquidCashValue: Double
)
