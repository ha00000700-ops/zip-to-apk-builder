package com.example.domain.calculator

import com.example.domain.model.CalculationMethod
import com.example.domain.model.HighLatitudeRule
import com.example.domain.model.JuristicMethod
import com.example.domain.model.PrayerAdjustments
import com.example.domain.model.PrayerSchedule
import com.example.domain.model.PrayerType
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

class AstronomicalPrayerCalculator {

    companion object {
        private const val DEG_TO_RAD = Math.PI / 180.0
        private const val RAD_TO_DEG = 180.0 / Math.PI

        private fun dSin(d: Double) = sin(d * DEG_TO_RAD)
        private fun dCos(d: Double) = cos(d * DEG_TO_RAD)
        private fun dTan(d: Double) = tan(d * DEG_TO_RAD)
        private fun dAsin(x: Double) = asin(x.coerceIn(-1.0, 1.0)) * RAD_TO_DEG
        private fun dAcos(x: Double) = acos(x.coerceIn(-1.0, 1.0)) * RAD_TO_DEG
        private fun dAtan(x: Double) = atan(x) * RAD_TO_DEG

        private fun fixHour(a: Double): Double {
            var res = a - 24.0 * floor(a / 24.0)
            if (res < 0) res += 24.0
            return res
        }

        private fun fixAngle(a: Double): Double {
            var res = a - 360.0 * floor(a / 360.0)
            if (res < 0) res += 360.0
            return res
        }
    }

    data class SolarCoordinates(val declination: Double, val equationOfTime: Double)

    private fun calculateSolarCoordinates(julianDate: Double): SolarCoordinates {
        val d = julianDate - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dSin(g) + 0.020 * dSin(2 * g))

        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(dAtan(dCos(e) * dSin(l) / dCos(l)) / 15.0)
        
        // Quad adjust
        val lQuad = floor(l / 90.0) * 90.0
        val raQuad = floor(ra * 15.0 / 90.0) * 90.0
        val adjustedRa = (ra * 15.0 + (lQuad - raQuad)) / 15.0

        val declination = dAsin(dSin(e) * dSin(l))
        val equationOfTime = (q / 15.0) - fixHour(adjustedRa)
        return SolarCoordinates(declination, equationOfTime * 60.0) // eq in minutes
    }

    private fun julianDate(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    fun calculateTimes(
        calendar: Calendar,
        latitude: Double,
        longitude: Double,
        timeZoneOffsetHours: Double,
        method: CalculationMethod,
        juristicMethod: JuristicMethod,
        adjustments: PrayerAdjustments = PrayerAdjustments(),
        highLatRule: HighLatitudeRule = HighLatitudeRule.ANGLE_BASED
    ): PrayerSchedule {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val jd = julianDate(year, month, day)
        val solar = calculateSolarCoordinates(jd)

        // Solar Noon (Dhuhr base)
        val noonUtc = 12.0 - (longitude / 15.0) - (solar.equationOfTime / 60.0)
        val dhuhrHour = fixHour(noonUtc + timeZoneOffsetHours)

        // Sunrise & Sunset Angle (-0.833 standard altitude)
        val sunAltitudeRefraction = -0.833
        val sunriseHour = computeHourAngle(sunAltitudeRefraction, latitude, solar.declination)
            ?.let { fixHour(dhuhrHour - it / 15.0) } ?: (dhuhrHour - 6.0)
        val sunsetHour = computeHourAngle(sunAltitudeRefraction, latitude, solar.declination)
            ?.let { fixHour(dhuhrHour + it / 15.0) } ?: (dhuhrHour + 6.0)

        // Fajr
        var fajrHour = computeHourAngle(-method.fajrAngle, latitude, solar.declination)
            ?.let { fixHour(dhuhrHour - it / 15.0) }
            ?: fallbackHighLatitude(sunriseHour, sunsetHour, method.fajrAngle, highLatRule, isFajr = true)

        // Maghrib
        val maghribHour = sunsetHour // Default Maghrib = Sunset

        // Isha
        var ishaHour = if (method.ishaFixedMinutes > 0) {
            fixHour(maghribHour + (method.ishaFixedMinutes / 60.0))
        } else {
            computeHourAngle(-method.ishaAngle, latitude, solar.declination)
                ?.let { fixHour(dhuhrHour + it / 15.0) }
                ?: fallbackHighLatitude(sunriseHour, sunsetHour, method.ishaAngle, highLatRule, isFajr = false)
        }

        // Asr
        val shadowFactor = juristicMethod.shadowFactor
        val asrAltitude = dAtan(1.0 / (shadowFactor + dTan(abs(latitude - solar.declination))))
        val asrHour = computeHourAngle(asrAltitude, latitude, solar.declination)
            ?.let { fixHour(dhuhrHour + it / 15.0) } ?: (dhuhrHour + 3.2)

        // Duha (~20 mins after sunrise)
        val duhaHour = fixHour(sunriseHour + (20.0 / 60.0))

        // Night Span & Last Third Calculation
        var nightDurationHours = (fajrHour + 24.0 - maghribHour) % 24.0
        if (nightDurationHours <= 0) nightDurationHours += 24.0
        val lastThirdStartHour = fixHour(maghribHour + (nightDurationHours * (2.0 / 3.0)))

        // Apply manual adjustments in minutes
        val adjFajr = fixHour(fajrHour + (adjustments.fajr / 60.0))
        val adjSunrise = fixHour(sunriseHour + (adjustments.sunrise / 60.0))
        val adjDhuhr = fixHour(dhuhrHour + (adjustments.dhuhr / 60.0))
        val adjAsr = fixHour(asrHour + (adjustments.asr / 60.0))
        val adjMaghrib = fixHour(maghribHour + (adjustments.maghrib / 60.0))
        val adjIsha = fixHour(ishaHour + (adjustments.isha / 60.0))

        val baseCal = calendar.clone() as Calendar
        baseCal.set(Calendar.SECOND, 0)
        baseCal.set(Calendar.MILLISECOND, 0)

        fun toMillis(hours: Double): Long {
            val c = baseCal.clone() as Calendar
            val h = hours.toInt()
            val m = ((hours - h) * 60.0).toInt()
            c.set(Calendar.HOUR_OF_DAY, h)
            c.set(Calendar.MINUTE, m)
            return c.timeInMillis
        }

        val fajrMillis = toMillis(adjFajr)
        val sunriseMillis = toMillis(adjSunrise)
        val dhuhrMillis = toMillis(adjDhuhr)
        val asrMillis = toMillis(adjAsr)
        val maghribMillis = toMillis(adjMaghrib)
        val ishaMillis = toMillis(adjIsha)

        val now = calendar.timeInMillis
        val prayerList = listOf(
            PrayerType.FAJR to fajrMillis,
            PrayerType.SUNRISE to sunriseMillis,
            PrayerType.DHUHR to dhuhrMillis,
            PrayerType.ASR to asrMillis,
            PrayerType.MAGHRIB to maghribMillis,
            PrayerType.ISHA to ishaMillis
        )

        var nextPrayer = PrayerType.FAJR
        var nextPrayerTime = fajrMillis + 24 * 60 * 60 * 1000L // Next day Fajr fallback
        for ((pType, pTime) in prayerList) {
            if (pTime > now) {
                nextPrayer = pType
                nextPrayerTime = pTime
                break
            }
        }
        val remaining = (nextPrayerTime - now).coerceAtLeast(0L)

        val hijriFormatted = HijriCalendarUtil.getHijriDateString(calendar)
        val gregorianFormatted = String.format(Locale.getDefault(), "%02d/%02d/%04d", day, month, year)

        return PrayerSchedule(
            fajr = formatTime(adjFajr),
            sunrise = formatTime(adjSunrise),
            dhuhr = formatTime(adjDhuhr),
            asr = formatTime(adjAsr),
            maghrib = formatTime(adjMaghrib),
            isha = formatTime(adjIsha),
            duha = formatTime(duhaHour),
            lastThird = formatTime(lastThirdStartHour),
            fajrMillis = fajrMillis,
            sunriseMillis = sunriseMillis,
            dhuhrMillis = dhuhrMillis,
            asrMillis = asrMillis,
            maghribMillis = maghribMillis,
            ishaMillis = ishaMillis,
            nextPrayer = nextPrayer,
            nextPrayerTimeMillis = nextPrayerTime,
            remainingMillis = remaining,
            hijriDateFormatted = hijriFormatted,
            gregorianDateFormatted = gregorianFormatted
        )
    }

    private fun computeHourAngle(altitude: Double, latitude: Double, declination: Double): Double? {
        val cosHA = (dSin(altitude) - (dSin(latitude) * dSin(declination))) / (dCos(latitude) * dCos(declination))
        if (cosHA < -1.0 || cosHA > 1.0) return null
        return dAcos(cosHA)
    }

    private fun fallbackHighLatitude(
        sunriseHour: Double,
        sunsetHour: Double,
        angle: Double,
        rule: HighLatitudeRule,
        isFajr: Boolean
    ): Double {
        val night = (sunriseHour + 24.0 - sunsetHour) % 24.0
        val portion = when (rule) {
            HighLatitudeRule.MIDDLE_OF_NIGHT -> night / 2.0
            HighLatitudeRule.SEVENTH_OF_NIGHT -> night / 7.0
            HighLatitudeRule.ANGLE_BASED -> night * (angle / 60.0)
        }
        return if (isFajr) fixHour(sunriseHour - portion) else fixHour(sunsetHour + portion)
    }

    private fun formatTime(hourDouble: Double): String {
        val normalized = fixHour(hourDouble)
        val h = normalized.toInt()
        val m = ((normalized - h) * 60.0).toInt()
        return String.format(Locale.getDefault(), "%02d:%02d", h, m)
    }
}

object HijriCalendarUtil {
    private val hijriMonthsAr = listOf(
        "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
        "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    fun getHijriDateString(calendar: Calendar): String {
        // Kuwaiti algorithm approx for Islamic Hijri date
        val y = calendar.get(Calendar.YEAR)
        val m = calendar.get(Calendar.MONTH)
        val d = calendar.get(Calendar.DAY_OF_MONTH)

        var jd = if ((y > 1582) || ((y == 1582) && (m > 9)) || ((y == 1582) && (m == 9) && (d > 14))) {
            (1461 * (y + 4800 + (m - 13) / 12)) / 4 +
                    (367 * (m - 1 - 12 * ((m - 13) / 12))) / 12 -
                    (3 * ((y + 4900 + (m - 13) / 12) / 100)) / 4 + d - 32075
        } else {
            367 * y - (7 * (y + 5001 + (m - 8) / 12)) / 4 +
                    (275 * (m + 1)) / 9 + d + 1729777
        }

        val l = jd - 1948440 + 10632
        val n = (l - 1) / 10631
        val lRem = l - 10631 * n + 354
        val j = ((10985 - lRem) / 5316) * ((50 * lRem) / 17719) + (lRem / 5670) * ((43 * lRem) / 15238)
        val l2 = lRem - ((30 - j) / 15) * ((17719 * j) / 50) - (j / 16) * ((15238 * j) / 43) + 29
        val hMonth = ((24 * l2) / 709)
        val hDay = l2 - (709 * hMonth) / 24
        val hYear = 30 * n + j - 30

        val monthName = hijriMonthsAr.getOrElse((hMonth - 1).coerceIn(0, 11)) { "رمضان" }
        return "$hDay $monthName $hYear هـ"
    }
}
