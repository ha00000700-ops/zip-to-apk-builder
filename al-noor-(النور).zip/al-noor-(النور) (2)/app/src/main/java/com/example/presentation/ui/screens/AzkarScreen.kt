package com.example.presentation.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AzkarRepository
import com.example.domain.model.AzkarCategory
import com.example.domain.model.DhikrPreset
import com.example.domain.model.ZikrItem
import com.example.presentation.ui.components.IslamicArabesqueBadge
import com.example.presentation.ui.components.IslamicCard
import com.example.presentation.ui.components.IslamicMotifHeader
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright
import com.example.ui.theme.RoyalGoldLight

@Composable
fun AzkarScreen(viewModel: AlNoorViewModel) {
    val selectedCategory by viewModel.selectedAzkarCategory.collectAsState()
    val azkarList by viewModel.currentAzkarList.collectAsState()
    val progressCounts by viewModel.zikrProgressCounts.collectAsState()

    val currentDhikr by viewModel.currentDhikrPreset.collectAsState()
    val tasbihCount by viewModel.tasbihCount.collectAsState()
    val tasbihTarget by viewModel.tasbihTarget.collectAsState()
    val lifetimeCount by viewModel.tasbihLifetimeCount.collectAsState()
    val todayCount by viewModel.tasbihTodayCount.collectAsState()

    var mainMode by remember { mutableStateOf(0) } // 0: Hisn Al-Muslim (Azkar), 1: Smart Digital Tasbih

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 100.dp)
            .testTag("azkar_screen")
    ) {
        IslamicMotifHeader(
            titleAr = if (mainMode == 0) "حصن المسلم والأذكار" else "المسبحة الرقمية الذكية",
            subtitleAr = if (mainMode == 0) "أذكار الصباح والمساء وأدعية اليوم والليلة" else "تسبيح تفاعلي بالاهتزاز وتتبع الأهداف"
        )

        // Main Tab Switcher (Hisn Al Muslim / Digital Tasbih)
        TabRow(
            selectedTabIndex = mainMode,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp)),
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Tab(
                selected = mainMode == 0,
                onClick = { mainMode = 0 },
                text = { Text("حصن المسلم", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = mainMode == 1,
                onClick = { mainMode = 1 },
                text = { Text("المسبحة الرقمية", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Fingerprint, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        if (mainMode == 0) {
            // Hisn Al Muslim Categories & Cards
            ScrollableTabRow(
                selectedTabIndex = AzkarCategory.values().indexOf(selectedCategory),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                edgePadding = 16.dp,
                containerColor = Color.Transparent
            ) {
                AzkarCategory.values().forEach { cat ->
                    val isSelected = cat == selectedCategory
                    Tab(
                        selected = isSelected,
                        onClick = { viewModel.selectAzkarCategory(cat) },
                        text = {
                            Text(
                                text = cat.titleAr,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }

            // Reset category button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${azkarList.size} أذكار متوفرة",
                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                TextButton(onClick = { viewModel.resetZikrCategoryProgress() }) {
                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إعادة تصفير العدادات", style = MaterialTheme.typography.labelSmall)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(azkarList) { item ->
                    val currentCount = progressCounts[item.id] ?: 0
                    ZikrItemCard(
                        item = item,
                        currentCount = currentCount,
                        onTap = { viewModel.incrementZikr(item) }
                    )
                }
            }
        } else {
            // Smart Digital Tasbih Mode
            DigitalTasbihView(
                currentDhikr = currentDhikr,
                count = tasbihCount,
                target = tasbihTarget,
                lifetimeCount = lifetimeCount,
                todayCount = todayCount,
                onTap = { viewModel.onTasbihTap() },
                onReset = { viewModel.resetTasbihCounter() },
                onSelectPreset = { viewModel.setDhikrPreset(it) },
                onSelectTarget = { viewModel.setTasbihTarget(it) }
            )
        }
    }
}

@Composable
fun ZikrItemCard(
    item: ZikrItem,
    currentCount: Int,
    onTap: () -> Unit
) {
    val isCompleted = currentCount >= item.countTarget
    val progress = (currentCount.toFloat() / item.countTarget).coerceIn(0f, 1f)

    IslamicCard(
        borderColor = if (isCompleted) EmeraldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Arabic Zikr Text
            Text(
                text = item.textAr,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    lineHeight = 28.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )

            // Virtue / Benefit
            if (item.virtueAr.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "فضل الذكر: ${item.virtueAr}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        ),
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Reference Source
            if (item.referenceAr.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = item.referenceAr,
                    style = MaterialTheme.typography.labelSmall.copy(color = RoyalGold),
                    textAlign = TextAlign.Left,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isCompleted) EmeraldPrimaryLight else RoyalGold,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tap Button & Counter
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "التكرار المطلوب : ${item.countTarget} مرات",
                    style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.primaryContainer
                        )
                        .clickable(enabled = !isCompleted) { onTap() }
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.Check else Icons.Default.TouchApp,
                            contentDescription = null,
                            tint = if (isCompleted) Color.White else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isCompleted) "تم الذكر ✓" else "$currentCount / ${item.countTarget}",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isCompleted) Color.White else MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalTasbihView(
    currentDhikr: DhikrPreset,
    count: Int,
    target: Int,
    lifetimeCount: Long,
    todayCount: Int,
    onTap: () -> Unit,
    onReset: () -> Unit,
    onSelectPreset: (DhikrPreset) -> Unit,
    onSelectTarget: (Int) -> Unit
) {
    var isPressed by remember { mutableStateOf(false) }
    val buttonScale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = tween(durationMillis = 100),
        label = "button_scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Dhikr Presets Horizontal Scroll
        Text(
            text = "اختر صيغة الذكر",
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(AzkarRepository.dhikrPresets) { preset ->
                val isSelected = preset.id == currentDhikr.id
                IslamicArabesqueBadge(
                    text = preset.textAr,
                    isHighlighted = isSelected,
                    onClick = { onSelectPreset(preset) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Targets selector row (33, 99, 100, 1000)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الهدف المستهدف:",
                style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(33, 99, 100, 1000).forEach { tgt ->
                    val isSelected = target == tgt
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) RoyalGold else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { onSelectTarget(tgt) }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "$tgt",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Selected Dhikr Title & Virtue
        Text(
            text = currentDhikr.textAr,
            style = MaterialTheme.typography.headlineSmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            ),
            textAlign = TextAlign.Center
        )
        if (currentDhikr.virtue.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = currentDhikr.virtue,
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Big Interactive 3D Tactile Bead / Counter Button
        Box(
            modifier = Modifier
                .size(240.dp)
                .scale(buttonScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(
                            EmeraldPrimaryLight,
                            EmeraldPrimary,
                            Color(0xFF064E3B)
                        )
                    )
                )
                .border(8.dp, RoyalGoldBright, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    onTap()
                }
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$count",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontSize = 52.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                )
                Text(
                    text = "من $target",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = RoyalGoldBright,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Haptic",
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المس للتسبيح",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.9f))
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Reset and Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onReset,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset Counter",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "تسبيحات اليوم",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "$todayCount",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = RoyalGold
                        )
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "المجموع الكلي",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "$lifetimeCount",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    }
}
