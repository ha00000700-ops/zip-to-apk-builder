package com.example.data.local

import com.example.domain.model.LocationData

object CityLocationsRepository {

    val defaultCity = LocationData(
        cityNameAr = "مكة المكرمة",
        cityNameEn = "Makkah",
        countryAr = "المملكة العربية السعودية",
        countryEn = "Saudi Arabia",
        latitude = 21.422487,
        longitude = 39.826206,
        timeZoneOffsetHours = 3.0
    )

    val allCities: List<LocationData> = listOf(
        // السعودية (Saudi Arabia)
        defaultCity,
        LocationData("المدينة المنورة", "Madinah", "المملكة العربية السعودية", "Saudi Arabia", 24.5247, 39.5692, 3.0),
        LocationData("الرياض", "Riyadh", "المملكة العربية السعودية", "Saudi Arabia", 24.7136, 46.6753, 3.0),
        LocationData("جدة", "Jeddah", "المملكة العربية السعودية", "Saudi Arabia", 21.5433, 39.1728, 3.0),
        LocationData("الدمام", "Dammam", "المملكة العربية السعودية", "Saudi Arabia", 26.4207, 50.0888, 3.0),
        LocationData("الخبر", "Khobar", "المملكة العربية السعودية", "Saudi Arabia", 26.2818, 50.1981, 3.0),
        LocationData("الطائف", "Taif", "المملكة العربية السعودية", "Saudi Arabia", 21.2854, 40.4222, 3.0),
        LocationData("تبوك", "Tabuk", "المملكة العربية السعودية", "Saudi Arabia", 28.3835, 36.5662, 3.0),
        LocationData("بريدة", "Buraidah", "المملكة العربية السعودية", "Saudi Arabia", 26.3592, 43.9818, 3.0),
        LocationData("عنيزة", "Unaizah", "المملكة العربية السعودية", "Saudi Arabia", 26.0844, 43.9936, 3.0),
        LocationData("أبها", "Abha", "المملكة العربية السعودية", "Saudi Arabia", 18.2164, 42.5053, 3.0),
        LocationData("خميس مشيط", "Khamis Mushait", "المملكة العربية السعودية", "Saudi Arabia", 18.3000, 42.7333, 3.0),
        LocationData("جازان", "Jazan", "المملكة العربية السعودية", "Saudi Arabia", 16.8892, 42.5511, 3.0),
        LocationData("نجران", "Najran", "المملكة العربية السعودية", "Saudi Arabia", 17.4924, 44.1277, 3.0),
        LocationData("حائل", "Hail", "المملكة العربية السعودية", "Saudi Arabia", 27.5219, 41.6907, 3.0),
        LocationData("الهفوف", "Hofuf", "المملكة العربية السعودية", "Saudi Arabia", 25.3647, 49.5857, 3.0),
        LocationData("الجبيل", "Jubail", "المملكة العربية السعودية", "Saudi Arabia", 27.0046, 49.6606, 3.0),
        LocationData("ينبع", "Yanbu", "المملكة العربية السعودية", "Saudi Arabia", 24.0891, 38.0637, 3.0),
        LocationData("عرعر", "Arar", "المملكة العربية السعودية", "Saudi Arabia", 30.9753, 41.0381, 3.0),
        LocationData("سكاكا", "Sakaka", "المملكة العربية السعودية", "Saudi Arabia", 29.9697, 40.2064, 3.0),

        // فلسطين (Palestine)
        LocationData("القدس الشريف", "Jerusalem", "فلسطين", "Palestine", 31.7683, 35.2137, 2.0),
        LocationData("غزة", "Gaza", "فلسطين", "Palestine", 31.5017, 34.4668, 2.0),
        LocationData("الخليل", "Hebron", "فلسطين", "Palestine", 31.5326, 35.0998, 2.0),
        LocationData("نابلس", "Nablus", "فلسطين", "Palestine", 32.2211, 35.2544, 2.0),
        LocationData("رام الله", "Ramallah", "فلسطين", "Palestine", 31.9038, 35.2034, 2.0),
        LocationData("جنين", "Jenin", "فلسطين", "Palestine", 32.4599, 35.2979, 2.0),
        LocationData("خان يونس", "Khan Yunis", "فلسطين", "Palestine", 31.3462, 34.3063, 2.0),
        LocationData("رفح", "Rafah", "فلسطين", "Palestine", 31.2968, 34.2455, 2.0),
        LocationData("يافا", "Jaffa", "فلسطين", "Palestine", 32.0535, 34.7554, 2.0),
        LocationData("عكا", "Acre", "فلسطين", "Palestine", 32.9278, 35.0818, 2.0),

        // مصر (Egypt)
        LocationData("القاهرة", "Cairo", "جمهورية مصر العربية", "Egypt", 30.0444, 31.2357, 2.0),
        LocationData("الإسكندرية", "Alexandria", "جمهورية مصر العربية", "Egypt", 31.2001, 29.9187, 2.0),
        LocationData("الجيزة", "Giza", "جمهورية مصر العربية", "Egypt", 30.0131, 31.2089, 2.0),
        LocationData("طنطا", "Tanta", "جمهورية مصر العربية", "Egypt", 30.7865, 31.0004, 2.0),
        LocationData("المنصورة", "Mansoura", "جمهورية مصر العربية", "Egypt", 31.0409, 31.3785, 2.0),
        LocationData("الزقازيق", "Zagazig", "جمهورية مصر العربية", "Egypt", 30.5877, 31.5020, 2.0),
        LocationData("بورسعيد", "Port Said", "جمهورية مصر العربية", "Egypt", 31.2653, 32.3019, 2.0),
        LocationData("السويس", "Suez", "جمهورية مصر العربية", "Egypt", 29.9668, 32.5498, 2.0),
        LocationData("الإسماعيلية", "Ismailia", "جمهورية مصر العربية", "Egypt", 30.5965, 32.2715, 2.0),
        LocationData("أسيوط", "Asyut", "جمهورية مصر العربية", "Egypt", 27.1783, 31.1859, 2.0),
        LocationData("سوهاج", "Sohag", "جمهورية مصر العربية", "Egypt", 26.5569, 31.6948, 2.0),
        LocationData("قنا", "Qena", "جمهورية مصر العربية", "Egypt", 26.1551, 32.7160, 2.0),
        LocationData("الأقصر", "Luxor", "جمهورية مصر العربية", "Egypt", 25.6872, 32.6396, 2.0),
        LocationData("أسوان", "Aswan", "جمهورية مصر العربية", "Egypt", 24.0889, 32.8998, 2.0),
        LocationData("شرم الشيخ", "Sharm El Sheikh", "جمهورية مصر العربية", "Egypt", 27.9158, 34.3299, 2.0),
        LocationData("الغردقة", "Hurghada", "جمهورية مصر العربية", "Egypt", 27.2579, 33.8116, 2.0),
        LocationData("الفيوم", "Faiyum", "جمهورية مصر العربية", "Egypt", 29.3084, 30.8428, 2.0),
        LocationData("بني سويف", "Beni Suef", "جمهورية مصر العربية", "Egypt", 29.0661, 31.0994, 2.0),
        LocationData("المنيا", "Minya", "جمهورية مصر العربية", "Egypt", 28.0871, 30.7618, 2.0),
        LocationData("دمياط", "Damietta", "جمهورية مصر العربية", "Egypt", 31.4175, 31.8144, 2.0),

        // الإمارات (UAE)
        LocationData("دبي", "Dubai", "الإمارات العربية المتحدة", "UAE", 25.2048, 55.2708, 4.0),
        LocationData("أبوظبي", "Abu Dhabi", "الإمارات العربية المتحدة", "UAE", 24.4539, 54.3773, 4.0),
        LocationData("الشارقة", "Sharjah", "الإمارات العربية المتحدة", "UAE", 25.3463, 55.4209, 4.0),
        LocationData("عجمان", "Ajman", "الإمارات العربية المتحدة", "UAE", 25.4052, 55.5136, 4.0),
        LocationData("رأس الخيمة", "Ras Al Khaimah", "الإمارات العربية المتحدة", "UAE", 25.7895, 55.9432, 4.0),
        LocationData("الفجيرة", "Fujairah", "الإمارات العربية المتحدة", "UAE", 25.1288, 56.3265, 4.0),
        LocationData("العين", "Al Ain", "الإمارات العربية المتحدة", "UAE", 24.2075, 55.7447, 4.0),

        // الأردن (Jordan)
        LocationData("عمان", "Amman", "المملكة الأردنية الهاشمية", "Jordan", 31.9454, 35.9284, 3.0),
        LocationData("إربد", "Irbid", "المملكة الأردنية الهاشمية", "Jordan", 32.5568, 35.8469, 3.0),
        LocationData("الزرقاء", "Zarqa", "المملكة الأردنية الهاشمية", "Jordan", 32.0608, 36.0942, 3.0),
        LocationData("العقبة", "Aqaba", "المملكة الأردنية الهاشمية", "Jordan", 29.5321, 35.0063, 3.0),
        LocationData("السلط", "Salt", "المملكة الأردنية الهاشمية", "Jordan", 32.0392, 35.7272, 3.0),

        // الكويت وقطر والبحرين وسلطنة عمان
        LocationData("الكويت", "Kuwait City", "دولة الكويت", "Kuwait", 29.3759, 47.9774, 3.0),
        LocationData("الأحمدي", "Ahmadi", "دولة الكويت", "Kuwait", 29.0769, 48.0839, 3.0),
        LocationData("حولي", "Hawalli", "دولة الكويت", "Kuwait", 29.3328, 48.0282, 3.0),
        LocationData("الدوحة", "Doha", "دولة قطر", "Qatar", 25.2854, 51.5310, 3.0),
        LocationData("الوكرة", "Al Wakrah", "دولة قطر", "Qatar", 25.1768, 51.6048, 3.0),
        LocationData("الريان", "Al Rayyan", "دولة قطر", "Qatar", 25.2919, 51.4244, 3.0),
        LocationData("المنامة", "Manama", "مملكة البحرين", "Bahrain", 26.2285, 50.5860, 3.0),
        LocationData("المحرق", "Muharraq", "مملكة البحرين", "Bahrain", 26.2572, 50.6119, 3.0),
        LocationData("مسقط", "Muscat", "سلطنة عمان", "Oman", 23.5880, 58.3829, 4.0),
        LocationData("صلالة", "Salalah", "سلطنة عمان", "Oman", 17.0151, 54.0924, 4.0),
        LocationData("صحار", "Sohar", "سلطنة عمان", "Oman", 24.3639, 56.7468, 4.0),
        LocationData("نزوى", "Nizwa", "سلطنة عمان", "Oman", 22.9333, 57.5333, 4.0),

        // اليمن (Yemen)
        LocationData("صنعاء", "Sanaa", "الجمهورية اليمنية", "Yemen", 15.3694, 44.1910, 3.0),
        LocationData("عدن", "Aden", "الجمهورية اليمنية", "Yemen", 12.7855, 45.0187, 3.0),
        LocationData("تعز", "Taiz", "الجمهورية اليمنية", "Yemen", 13.5795, 44.0209, 3.0),
        LocationData("الحديدة", "Hodeidah", "الجمهورية اليمنية", "Yemen", 14.7978, 42.9545, 3.0),
        LocationData("المكلا", "Mukalla", "الجمهورية اليمنية", "Yemen", 14.5425, 49.1242, 3.0),
        LocationData("إب", "Ibb", "الجمهورية اليمنية", "Yemen", 13.9667, 44.1667, 3.0),

        // العراق (Iraq)
        LocationData("بغداد", "Baghdad", "جمهورية العراق", "Iraq", 33.3152, 44.3661, 3.0),
        LocationData("أربيل", "Erbil", "جمهورية العراق", "Iraq", 36.1911, 44.0092, 3.0),
        LocationData("البصرة", "Basra", "جمهورية العراق", "Iraq", 30.5081, 47.7835, 3.0),
        LocationData("الموصل", "Mosul", "جمهورية العراق", "Iraq", 36.3400, 43.1300, 3.0),
        LocationData("النجف الأشرف", "Najaf", "جمهورية العراق", "Iraq", 32.0259, 44.3462, 3.0),
        LocationData("كربلاء المقدسة", "Karbala", "جمهورية العراق", "Iraq", 32.6160, 44.0249, 3.0),
        LocationData("السليمانية", "Sulaymaniyah", "جمهورية العراق", "Iraq", 35.5669, 45.4161, 3.0),
        LocationData("كركوك", "Kirkuk", "جمهورية العراق", "Iraq", 35.4681, 44.3922, 3.0),

        // سوريا ولبنان (Syria & Lebanon)
        LocationData("دمشق", "Damascus", "الجمهورية العربية السورية", "Syria", 33.5138, 36.2765, 3.0),
        LocationData("حلب", "Aleppo", "الجمهورية العربية السورية", "Syria", 36.2021, 37.1343, 3.0),
        LocationData("حمص", "Homs", "الجمهورية العربية السورية", "Syria", 34.7324, 36.7137, 3.0),
        LocationData("اللاذقية", "Latakia", "الجمهورية العربية السورية", "Syria", 35.5317, 35.7901, 3.0),
        LocationData("حماة", "Hama", "الجمهورية العربية السورية", "Syria", 35.1318, 36.7578, 3.0),
        LocationData("بيروت", "Beirut", "الجمهورية اللبنانية", "Lebanon", 33.8938, 35.5018, 2.0),
        LocationData("طرابلس الشام", "Tripoli (Lebanon)", "الجمهورية اللبنانية", "Lebanon", 34.4367, 35.8497, 2.0),
        LocationData("صيدا", "Sidon", "الجمهورية اللبنانية", "Lebanon", 33.5631, 35.3689, 2.0),

        // المغرب العربي (Maghreb: Morocco, Algeria, Tunisia, Libya, Mauritania)
        LocationData("الرباط", "Rabat", "المملكة المغربية", "Morocco", 34.0209, -6.8416, 1.0),
        LocationData("الدار البيضاء", "Casablanca", "المملكة المغربية", "Morocco", 33.5731, -7.5898, 1.0),
        LocationData("مراكش", "Marrakech", "المملكة المغربية", "Morocco", 31.6295, -7.9811, 1.0),
        LocationData("فاس", "Fes", "المملكة المغربية", "Morocco", 34.0181, -5.0078, 1.0),
        LocationData("طنجة", "Tangier", "المملكة المغربية", "Morocco", 35.7595, -5.8340, 1.0),
        LocationData("أكادير", "Agadir", "المملكة المغربية", "Morocco", 30.4278, -9.5981, 1.0),
        LocationData("مكناس", "Meknes", "المملكة المغربية", "Morocco", 33.8938, -5.5516, 1.0),
        LocationData("وجدة", "Oujda", "المملكة المغربية", "Morocco", 34.6867, -1.9114, 1.0),
        LocationData("الجزائر", "Algiers", "الجمهورية الجزائرية", "Algeria", 36.7538, 3.0588, 1.0),
        LocationData("وهران", "Oran", "الجمهورية الجزائرية", "Algeria", 35.6987, -0.6349, 1.0),
        LocationData("قسنطينة", "Constantine", "الجمهورية الجزائرية", "Algeria", 36.3650, 6.6147, 1.0),
        LocationData("عنابة", "Annaba", "الجمهورية الجزائرية", "Algeria", 36.9000, 7.7667, 1.0),
        LocationData("باتنة", "Batna", "الجمهورية الجزائرية", "Algeria", 35.5559, 6.1741, 1.0),
        LocationData("سطيف", "Setif", "الجمهورية الجزائرية", "Algeria", 36.1911, 5.4137, 1.0),
        LocationData("تونس", "Tunis", "الجمهورية التونسية", "Tunisia", 36.8065, 10.1815, 1.0),
        LocationData("صفاقس", "Sfax", "الجمهورية التونسية", "Tunisia", 34.7406, 10.7603, 1.0),
        LocationData("سوسة", "Sousse", "الجمهورية التونسية", "Tunisia", 35.8254, 10.6369, 1.0),
        LocationData("القيروان", "Kairouan", "الجمهورية التونسية", "Tunisia", 35.6781, 10.0963, 1.0),
        LocationData("بنزرت", "Bizerte", "الجمهورية التونسية", "Tunisia", 37.2744, 9.8739, 1.0),
        LocationData("طرابلس الغرب", "Tripoli", "دولة ليبيا", "Libya", 32.8872, 13.1913, 2.0),
        LocationData("بنغازي", "Benghazi", "دولة ليبيا", "Libya", 32.1167, 20.0667, 2.0),
        LocationData("مصراتة", "Misrata", "دولة ليبيا", "Libya", 32.3754, 15.0925, 2.0),
        LocationData("الزاوية", "Zawiya", "دولة ليبيا", "Libya", 32.7522, 12.7278, 2.0),
        LocationData("نواكشوط", "Nouakchott", "موريتانيا", "Mauritania", 18.0735, -15.9582, 0.0),
        LocationData("نواذيبو", "Nouadhibou", "موريتانيا", "Mauritania", 20.9310, -17.0347, 0.0),

        // السودان والصومال وجيبوتي وجزر القمر
        LocationData("الخرطوم", "Khartoum", "جمهورية السودان", "Sudan", 15.5007, 32.5599, 2.0),
        LocationData("أم درمان", "Omdurman", "جمهورية السودان", "Sudan", 15.6445, 32.4777, 2.0),
        LocationData("بورتسودان", "Port Sudan", "جمهورية السودان", "Sudan", 19.6175, 37.2164, 2.0),
        LocationData("مقديشو", "Mogadishu", "جمهورية الصومال", "Somalia", 2.0469, 45.3182, 3.0),
        LocationData("هرجيسا", "Hargeisa", "الصومال", "Somalia", 9.5600, 44.0650, 3.0),
        LocationData("جيبوتي", "Djibouti City", "جمهورية جيبوتي", "Djibouti", 11.5721, 43.1456, 3.0),
        LocationData("موروني", "Moroni", "جزر القمر", "Comoros", -11.7172, 43.2473, 3.0),

        // العالم الإسلامي والآسيوي (Islamic & Asian World)
        LocationData("إسطنبول", "Istanbul", "تركيا", "Turkey", 41.0082, 28.9784, 3.0),
        LocationData("أنقرة", "Ankara", "تركيا", "Turkey", 39.9334, 32.8597, 3.0),
        LocationData("إزمير", "Izmir", "تركيا", "Turkey", 38.4237, 27.1428, 3.0),
        LocationData("بورصة", "Bursa", "تركيا", "Turkey", 40.1885, 29.0610, 3.0),
        LocationData("قونية", "Konya", "تركيا", "Turkey", 37.8746, 32.4932, 3.0),
        LocationData("غازي عنتاب", "Gaziantep", "تركيا", "Turkey", 37.0662, 37.3833, 3.0),
        LocationData("طهران", "Tehran", "إيران", "Iran", 35.6892, 51.3890, 3.5),
        LocationData("مشهد", "Mashhad", "إيران", "Iran", 36.2605, 59.6168, 3.5),
        LocationData("أصفهان", "Isfahan", "إيران", "Iran", 32.6546, 51.6680, 3.5),
        LocationData("شيراز", "Shiraz", "إيران", "Iran", 29.5918, 52.5837, 3.5),
        LocationData("إسلام آباد", "Islamabad", "باكستان", "Pakistan", 33.6844, 73.0479, 5.0),
        LocationData("كراتشي", "Karachi", "باكستان", "Pakistan", 24.8607, 67.0011, 5.0),
        LocationData("لاهور", "Lahore", "باكستان", "Pakistan", 31.5204, 74.3587, 5.0),
        LocationData("راولبندي", "Rawalpindi", "باكستان", "Pakistan", 33.5651, 73.0169, 5.0),
        LocationData("بيشاور", "Peshawar", "باكستان", "Pakistan", 34.0151, 71.5249, 5.0),
        LocationData("كابل", "Kabul", "أفغانستان", "Afghanistan", 34.5553, 69.2075, 4.5),
        LocationData("جاكرتا", "Jakarta", "إندونيسيا", "Indonesia", -6.2088, 106.8456, 7.0),
        LocationData("سورابايا", "Surabaya", "إندونيسيا", "Indonesia", -7.2575, 112.7521, 7.0),
        LocationData("باندونغ", "Bandung", "إندونيسيا", "Indonesia", -6.9175, 107.6191, 7.0),
        LocationData("ميدان", "Medan", "إندونيسيا", "Indonesia", 3.5952, 98.6722, 7.0),
        LocationData("كوالالمبور", "Kuala Lumpur", "ماليزيا", "Malaysia", 3.1390, 101.6869, 8.0),
        LocationData("بينانغ", "Penang", "ماليزيا", "Malaysia", 5.4141, 100.3288, 8.0),
        LocationData("جوهور بهرو", "Johor Bahru", "ماليزيا", "Malaysia", 1.4927, 103.7414, 8.0),
        LocationData("دكا", "Dhaka", "بنغلاديش", "Bangladesh", 23.8103, 90.4125, 6.0),
        LocationData("شيتاغونغ", "Chittagong", "بنغلاديش", "Bangladesh", 22.3569, 91.7832, 6.0),
        LocationData("طشقند", "Tashkent", "أوزبكستان", "Uzbekistan", 41.2995, 69.2401, 5.0),
        LocationData("سمرقند", "Samarkand", "أوزبكستان", "Uzbekistan", 39.6542, 66.9597, 5.0),
        LocationData("بخارى", "Bukhara", "أوزبكستان", "Uzbekistan", 39.7747, 64.4286, 5.0),
        LocationData("باكو", "Baku", "أذربيجان", "Azerbaijan", 40.4093, 49.8671, 4.0),
        LocationData("أستانا", "Astana", "كازاخستان", "Kazakhstan", 51.1694, 71.4491, 5.0),
        LocationData("ألماتي", "Almaty", "كازاخستان", "Kazakhstan", 43.2220, 76.8512, 5.0),
        LocationData("بشكيك", "Bishkek", "قيرغيزستان", "Kyrgyzstan", 42.8746, 74.5698, 6.0),
        LocationData("دوشنبه", "Dushanbe", "طاجيكستان", "Tajikistan", 38.5598, 68.7870, 5.0),
        LocationData("عشق آباد", "Ashgabat", "تركمانستان", "Turkmenistan", 37.9601, 58.3261, 5.0),
        LocationData("سراييفو", "Sarajevo", "البوسنة والهرسك", "Bosnia and Herzegovina", 43.8563, 18.4131, 1.0),
        LocationData("تيرانا", "Tirana", "ألبانيا", "Albania", 41.3275, 19.8187, 1.0),
        LocationData("برشتينا", "Pristina", "كوسوفو", "Kosovo", 42.6629, 21.1655, 1.0),
        LocationData("سكوبيه", "Skopje", "مقدونيا الشمالية", "North Macedonia", 41.9981, 21.4254, 1.0),
        LocationData("سنغافورة", "Singapore", "سنغافورة", "Singapore", 1.3521, 103.8198, 8.0),
        LocationData("نيودلهي", "New Delhi", "الهند", "India", 28.6139, 77.2090, 5.5),
        LocationData("مومباي", "Mumbai", "الهند", "India", 19.0760, 72.8777, 5.5),
        LocationData("حيدر آباد", "Hyderabad", "الهند", "India", 17.3850, 78.4867, 5.5),

        // العواصم والمدن العالمية الكبرى (International Metropolises)
        LocationData("لندن", "London", "المملكة المتحدة", "United Kingdom", 51.5074, -0.1278, 0.0),
        LocationData("برمنغهام", "Birmingham", "المملكة المتحدة", "United Kingdom", 52.4862, -1.8904, 0.0),
        LocationData("مانشستر", "Manchester", "المملكة المتحدة", "United Kingdom", 53.4808, -2.2426, 0.0),
        LocationData("باريس", "Paris", "فرنسا", "France", 48.8566, 2.3522, 1.0),
        LocationData("مارسيليا", "Marseille", "فرنسا", "France", 43.2965, 5.3698, 1.0),
        LocationData("ليون", "Lyon", "فرنسا", "France", 45.7640, 4.8357, 1.0),
        LocationData("برلين", "Berlin", "ألمانيا", "Germany", 52.5200, 13.4050, 1.0),
        LocationData("فرانكفورت", "Frankfurt", "ألمانيا", "Germany", 50.1109, 8.6821, 1.0),
        LocationData("ميونخ", "Munich", "ألمانيا", "Germany", 48.1351, 11.5820, 1.0),
        LocationData("كولونيا", "Cologne", "ألمانيا", "Germany", 50.9375, 6.9603, 1.0),
        LocationData("مدريد", "Madrid", "إسبانيا", "Spain", 40.4168, -3.7038, 1.0),
        LocationData("برشلونة", "Barcelona", "إسبانيا", "Spain", 41.3851, 2.1734, 1.0),
        LocationData("غرناطة", "Granada", "إسبانيا", "Spain", 37.1773, -3.5986, 1.0),
        LocationData("قرطبة", "Cordoba", "إسبانيا", "Spain", 37.8882, -4.7794, 1.0),
        LocationData("إشبيلية", "Seville", "إسبانيا", "Spain", 37.3891, -5.9845, 1.0),
        LocationData("روما", "Rome", "إيطاليا", "Italy", 41.9028, 12.4964, 1.0),
        LocationData("ميلانو", "Milan", "إيطاليا", "Italy", 45.4642, 9.1900, 1.0),
        LocationData("أمستردام", "Amsterdam", "هولندا", "Netherlands", 52.3676, 4.9041, 1.0),
        LocationData("روتردام", "Rotterdam", "هولندا", "Netherlands", 51.9244, 4.4777, 1.0),
        LocationData("بروكسل", "Brussels", "بلجيكا", "Belgium", 50.8503, 4.3517, 1.0),
        LocationData("فيينا", "Vienna", "النمسا", "Austria", 48.2082, 16.3738, 1.0),
        LocationData("جنيف", "Geneva", "سويسرا", "Switzerland", 46.2044, 6.1432, 1.0),
        LocationData("زيورخ", "Zurich", "سويسرا", "Switzerland", 47.3769, 8.5417, 1.0),
        LocationData("ستوكهولم", "Stockholm", "السويد", "Sweden", 59.3293, 18.0686, 1.0),
        LocationData("أوسلو", "Oslo", "النرويج", "Norway", 59.9139, 10.7522, 1.0),
        LocationData("كوبنهاغن", "Copenhagen", "الدنمارك", "Denmark", 55.6761, 12.5683, 1.0),
        LocationData("موسكو", "Moscow", "روسيا", "Russia", 55.7558, 37.6173, 3.0),
        LocationData("قازان", "Kazan", "روسيا (تتارستان)", "Russia", 55.8304, 49.0661, 3.0),
        LocationData("غروزني", "Grozny", "روسيا (الشيشان)", "Russia", 43.3179, 45.6982, 3.0),
        LocationData("نيويورك", "New York", "الولايات المتحدة", "USA", 40.7128, -74.0060, -5.0),
        LocationData("واشنطن", "Washington D.C.", "الولايات المتحدة", "USA", 38.9072, -77.0369, -5.0),
        LocationData("شيكاغو", "Chicago", "الولايات المتحدة", "USA", 41.8781, -87.6298, -6.0),
        LocationData("لوس أنجلوس", "Los Angeles", "الولايات المتحدة", "USA", 34.0522, -118.2437, -8.0),
        LocationData("هيوستن", "Houston", "الولايات المتحدة", "USA", 29.7604, -95.3698, -6.0),
        LocationData("دالاس", "Dallas", "الولايات المتحدة", "USA", 32.7767, -96.7970, -6.0),
        LocationData("تورونتو", "Toronto", "كندا", "Canada", 43.6532, -79.3832, -5.0),
        LocationData("مونتريال", "Montreal", "كندا", "Canada", 45.5017, -73.5673, -5.0),
        LocationData("فانكوفر", "Vancouver", "كندا", "Canada", 49.2827, -123.1207, -8.0),
        LocationData("سيدني", "Sydney", "أستراليا", "Australia", -33.8688, 151.2093, 10.0),
        LocationData("ملبورن", "Melbourne", "أستراليا", "Australia", -37.8136, 144.9631, 10.0),
        LocationData("طوكيو", "Tokyo", "اليابان", "Japan", 35.6762, 139.6503, 9.0),
        LocationData("بكين", "Beijing", "الصين", "China", 39.9042, 116.4074, 8.0),
        LocationData("سيول", "Seoul", "كوريا الجنوبية", "South Korea", 37.5665, 126.9780, 9.0),
        LocationData("كيب تاون", "Cape Town", "جنوب أفريقيا", "South Africa", -33.9249, 18.4241, 2.0),
        LocationData("جوهانسبرغ", "Johannesburg", "جنوب أفريقيا", "South Africa", -26.2041, 28.0473, 2.0),
        LocationData("دكار", "Dakar", "السنغال", "Senegal", 14.7167, -17.4677, 0.0),
        LocationData("أبوجا", "Abuja", "نيجيريا", "Nigeria", 9.0765, 7.3986, 1.0),
        LocationData("كانو", "Kano", "نيجيريا", "Nigeria", 12.0022, 8.5920, 1.0),
        LocationData("ساو باولو", "Sao Paulo", "البرازيل", "Brazil", -23.5505, -46.6333, -3.0),
        LocationData("بوينس آيرس", "Buenos Aires", "الأرجنتين", "Argentina", -34.6037, -58.3816, -3.0)
    )

    val popularCities = allCities.take(16)

    /**
     * Normalizes Arabic text by unifying Alef variants, Ta Marbuta, Ya/Alef Maqsura, and removing diacritics.
     */
    private fun normalizeArabic(text: String): String {
        return text
            .replace(Regex("[أإآٱ]"), "ا")
            .replace("ة", "ه")
            .replace("ى", "ي")
            .replace(Regex("[\u064B-\u065F\u0670]"), "") // remove tashkeel
            .trim()
            .lowercase()
    }

    /**
     * Fast offline search with normalized matching for Arabic and English strings.
     */
    fun searchCities(query: String): List<LocationData> {
        if (query.isBlank()) return allCities
        val clean = query.trim()
        val normalizedQuery = normalizeArabic(clean)

        return allCities.filter { city ->
            val normArCity = normalizeArabic(city.cityNameAr)
            val normArCountry = normalizeArabic(city.countryAr)
            val normEnCity = city.cityNameEn.lowercase()
            val normEnCountry = city.countryEn.lowercase()
            val lowerClean = clean.lowercase()

            normArCity.contains(normalizedQuery) ||
            normArCountry.contains(normalizedQuery) ||
            normEnCity.contains(lowerClean) ||
            normEnCountry.contains(lowerClean) ||
            normArCity.replace("ال", "").contains(normalizedQuery.replace("ال", ""))
        }
    }
}

