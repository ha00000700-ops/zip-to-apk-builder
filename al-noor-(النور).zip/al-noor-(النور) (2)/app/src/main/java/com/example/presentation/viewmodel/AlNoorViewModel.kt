package com.example.presentation.viewmodel

import android.app.Application
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AudioAndHapticService
import com.example.data.local.AzkarRepository
import com.example.data.local.CityLocationsRepository
import com.example.data.local.InspirationsRepository
import com.example.data.local.LocationServiceHelper
import com.example.data.local.QuranRepository
import com.example.data.local.SettingsManager
import com.example.data.notification.AthanSchedulerHelper
import com.example.data.remote.CityGeocodingService
import com.example.domain.calculator.AstronomicalPrayerCalculator
import com.example.domain.calculator.QiblaCalculator
import com.example.domain.model.AthanNotificationType
import com.example.domain.model.AzkarCategory
import com.example.domain.model.Bookmark
import com.example.domain.model.CalculationMethod
import com.example.domain.model.DailyInspiration
import com.example.domain.model.DailyPrayerRecord
import com.example.domain.model.DhikrPreset
import com.example.domain.model.JuristicMethod
import com.example.domain.model.KhatmahPlan
import com.example.domain.model.LocationData
import com.example.domain.model.MuezzinVoice
import com.example.domain.model.PrayerAdjustments
import com.example.domain.model.PrayerCompletionStatus
import com.example.domain.model.PrayerSchedule
import com.example.domain.model.PrayerType
import com.example.domain.model.Qari
import com.example.domain.model.QuranFont
import com.example.domain.model.Surah
import com.example.domain.model.ZakatCalculationResult
import com.example.domain.model.ZakatInput
import com.example.domain.model.ZikrItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class AlNoorViewModel(application: Application) : AndroidViewModel(application), SensorEventListener {

    private val context: Context = application.applicationContext
    private val settingsManager = SettingsManager(context)
    val audioHapticService = AudioAndHapticService(context)
    private val prayerCalculator = AstronomicalPrayerCalculator()
    val locationHelper = LocationServiceHelper(context)
    private val cityGeocodingService = CityGeocodingService()

    private val _isGpsLoading = MutableStateFlow(false)
    val isGpsLoading: StateFlow<Boolean> = _isGpsLoading.asStateFlow()

    private val _citySearchQuery = MutableStateFlow("")
    val citySearchQuery: StateFlow<String> = _citySearchQuery.asStateFlow()

    private val _isCitySearching = MutableStateFlow(false)
    val isCitySearching: StateFlow<Boolean> = _isCitySearching.asStateFlow()

    private val _citySearchResults = MutableStateFlow(CityLocationsRepository.allCities)
    val citySearchResults: StateFlow<List<LocationData>> = _citySearchResults.asStateFlow()

    private var citySearchJob: Job? = null

    private val _isQuranLoading = MutableStateFlow(false)
    val isQuranLoading: StateFlow<Boolean> = _isQuranLoading.asStateFlow()

    private val sensorManager: SensorManager? =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val rotationVectorSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accelerometerSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val magnetometerSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    private val gravityValues = FloatArray(3)
    private val geomagneticValues = FloatArray(3)
    private var hasGravity = false
    private var hasGeomagnetic = false

    // Dashboard & Prayer Times State
    private val _currentLocation = MutableStateFlow(settingsManager.getLocation())
    val currentLocation: StateFlow<LocationData> = _currentLocation.asStateFlow()

    private val _selectedMethod = MutableStateFlow(settingsManager.getCalculationMethod())
    val selectedMethod: StateFlow<CalculationMethod> = _selectedMethod.asStateFlow()

    private val _selectedJuristic = MutableStateFlow(settingsManager.getJuristicMethod())
    val selectedJuristic: StateFlow<JuristicMethod> = _selectedJuristic.asStateFlow()

    private val _prayerAdjustments = MutableStateFlow(settingsManager.getAdjustments())
    val prayerAdjustments: StateFlow<PrayerAdjustments> = _prayerAdjustments.asStateFlow()

    private val _prayerSchedule = MutableStateFlow(calculateCurrentSchedule())
    val prayerSchedule: StateFlow<PrayerSchedule> = _prayerSchedule.asStateFlow()

    private val _countdownFormatted = MutableStateFlow("00:00:00")
    val countdownFormatted: StateFlow<String> = _countdownFormatted.asStateFlow()

    private val _dailyInspiration = MutableStateFlow(InspirationsRepository.getTodayInspiration())
    val dailyInspiration: StateFlow<DailyInspiration> = _dailyInspiration.asStateFlow()

    // Qibla State
    private val _deviceAzimuth = MutableStateFlow(0f)
    val deviceAzimuth: StateFlow<Float> = _deviceAzimuth.asStateFlow()

    private val _qiblaBearing = MutableStateFlow(
        QiblaCalculator.calculateQiblaBearing(_currentLocation.value.latitude, _currentLocation.value.longitude)
    )
    val qiblaBearing: StateFlow<Double> = _qiblaBearing.asStateFlow()

    private val _distanceToKaabaKm = MutableStateFlow(
        QiblaCalculator.calculateDistanceToKaabaKm(_currentLocation.value.latitude, _currentLocation.value.longitude)
    )
    val distanceToKaabaKm: StateFlow<Double> = _distanceToKaabaKm.asStateFlow()

    private val _isQiblaAligned = MutableStateFlow(false)
    val isQiblaAligned: StateFlow<Boolean> = _isQiblaAligned.asStateFlow()

    private val _accuracyCalibrationNeeded = MutableStateFlow(false)
    val accuracyCalibrationNeeded: StateFlow<Boolean> = _accuracyCalibrationNeeded.asStateFlow()

    // Quran State
    private val _allSurahs = MutableStateFlow(QuranRepository.surahs)
    val allSurahs: StateFlow<List<Surah>> = _allSurahs.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedSurah = MutableStateFlow(QuranRepository.surahs.first())
    val selectedSurah: StateFlow<Surah> = _selectedSurah.asStateFlow()

    private val _currentAyahs = MutableStateFlow(QuranRepository.getAyahsForSurah(1))
    val currentAyahs = _currentAyahs.asStateFlow()

    private val _selectedQari = MutableStateFlow(QuranRepository.qaris.first())
    val selectedQari: StateFlow<Qari> = _selectedQari.asStateFlow()

    private val _isQuranAudioPlaying = MutableStateFlow(false)
    val isQuranAudioPlaying: StateFlow<Boolean> = _isQuranAudioPlaying.asStateFlow()

    private val _bookmarks = MutableStateFlow(settingsManager.getBookmarks())
    val bookmarks: StateFlow<List<Bookmark>> = _bookmarks.asStateFlow()

    private val _lastRead = MutableStateFlow(settingsManager.getLastRead())
    val lastRead: StateFlow<Pair<Int, Int>> = _lastRead.asStateFlow()

    private val _arabicFontSize = MutableStateFlow(settingsManager.getArabicFontSize())
    val arabicFontSize: StateFlow<Float> = _arabicFontSize.asStateFlow()

    private val _quranFont = MutableStateFlow(settingsManager.getQuranFont())
    val quranFont: StateFlow<QuranFont> = _quranFont.asStateFlow()

    // Azkar & Tasbih State
    private val _selectedAzkarCategory = MutableStateFlow(AzkarCategory.MORNING)
    val selectedAzkarCategory: StateFlow<AzkarCategory> = _selectedAzkarCategory.asStateFlow()

    private val _currentAzkarList = MutableStateFlow(AzkarRepository.getAzkarByCategory(AzkarCategory.MORNING.id))
    val currentAzkarList: StateFlow<List<ZikrItem>> = _currentAzkarList.asStateFlow()

    private val _zikrProgressCounts = MutableStateFlow<Map<String, Int>>(emptyMap())
    val zikrProgressCounts: StateFlow<Map<String, Int>> = _zikrProgressCounts.asStateFlow()

    private val _currentDhikrPreset = MutableStateFlow(AzkarRepository.dhikrPresets.first())
    val currentDhikrPreset: StateFlow<DhikrPreset> = _currentDhikrPreset.asStateFlow()

    private val _tasbihCount = MutableStateFlow(0)
    val tasbihCount: StateFlow<Int> = _tasbihCount.asStateFlow()

    private val _tasbihTarget = MutableStateFlow(33)
    val tasbihTarget: StateFlow<Int> = _tasbihTarget.asStateFlow()

    private val _tasbihLifetimeCount = MutableStateFlow(settingsManager.getTasbihLifetimeCount())
    val tasbihLifetimeCount: StateFlow<Long> = _tasbihLifetimeCount.asStateFlow()

    private val _tasbihTodayCount = MutableStateFlow(settingsManager.getTasbihTodayCount())
    val tasbihTodayCount: StateFlow<Int> = _tasbihTodayCount.asStateFlow()

    // Tracker & Planner State
    private val todayKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private val _currentPrayerRecord = MutableStateFlow(settingsManager.getPrayerRecord(todayKey))
    val currentPrayerRecord: StateFlow<DailyPrayerRecord> = _currentPrayerRecord.asStateFlow()

    private val _khatmahPlan = MutableStateFlow(settingsManager.getKhatmahPlan())
    val khatmahPlan: StateFlow<KhatmahPlan> = _khatmahPlan.asStateFlow()

    private val _zakatInput = MutableStateFlow(ZakatInput())
    val zakatInput: StateFlow<ZakatInput> = _zakatInput.asStateFlow()

    private val _zakatResult = MutableStateFlow(calculateZakat(_zakatInput.value))
    val zakatResult: StateFlow<ZakatCalculationResult> = _zakatResult.asStateFlow()

    // Settings & Audio State
    private val _muezzinVoice = MutableStateFlow(settingsManager.getMuezzinVoice())
    val muezzinVoice: StateFlow<MuezzinVoice> = _muezzinVoice.asStateFlow()

    private val _isAudioPreviewPlaying = MutableStateFlow(false)
    val isAudioPreviewPlaying: StateFlow<Boolean> = _isAudioPreviewPlaying.asStateFlow()

    private val _previewingMuezzinVoice = MutableStateFlow<MuezzinVoice?>(null)
    val previewingMuezzinVoice: StateFlow<MuezzinVoice?> = _previewingMuezzinVoice.asStateFlow()

    private val _dndMinutes = MutableStateFlow(settingsManager.getDndMinutes())
    val dndMinutes: StateFlow<Int> = _dndMinutes.asStateFlow()

    private val _fajrSmartAlarm = MutableStateFlow(settingsManager.isFajrSmartAlarmEnabled())
    val fajrSmartAlarm: StateFlow<Boolean> = _fajrSmartAlarm.asStateFlow()

    private val _preAthanMinutes = MutableStateFlow(settingsManager.getPreAthanMinutes())
    val preAthanMinutes: StateFlow<Int> = _preAthanMinutes.asStateFlow()

    private val _isDarkMode = MutableStateFlow(settingsManager.isDarkModeEnabled())
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    init {
        loadLastReadSurah()
        triggerBackgroundAlarmScheduling()
        startCountdownTimer()
    }

    private fun triggerBackgroundAlarmScheduling() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                AthanSchedulerHelper.scheduleAllPrayerAlarms(context)
            } catch (_: Exception) {}
        }
    }

    fun startListeningSensors() {
        try {
            if (rotationVectorSensor != null) {
                sensorManager?.registerListener(this, rotationVectorSensor, SensorManager.SENSOR_DELAY_UI)
            } else {
                accelerometerSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
                magnetometerSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
            }
        } catch (_: Exception) {}
    }

    fun stopListeningSensors() {
        try {
            sensorManager?.unregisterListener(this)
        } catch (_: Exception) {}
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        try {
            var azimuth = 0f

            if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
            } else if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                System.arraycopy(event.values, 0, gravityValues, 0, 3)
                hasGravity = true
            } else if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {
                System.arraycopy(event.values, 0, geomagneticValues, 0, 3)
                hasGeomagnetic = true
            }

            if (hasGravity && hasGeomagnetic && event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) {
                val r = FloatArray(9)
                val i = FloatArray(9)
                if (SensorManager.getRotationMatrix(r, i, gravityValues, geomagneticValues)) {
                    val orientation = FloatArray(3)
                    SensorManager.getOrientation(r, orientation)
                    azimuth = Math.toDegrees(orientation[0].toDouble()).toFloat()
                }
            }

            val normalizedAzimuth = (azimuth + 360f) % 360f
            // Filter small jitters to prevent excessive UI recompositions
            if (abs(normalizedAzimuth - _deviceAzimuth.value) >= 0.5f) {
                _deviceAzimuth.value = normalizedAzimuth

                val targetBearing = _qiblaBearing.value.toFloat()
                val diff = abs(normalizedAzimuth - targetBearing)
                val isAligned = diff <= 4f || diff >= 356f
                if (isAligned && !_isQiblaAligned.value) {
                    audioHapticService.playQiblaAlignedHaptic()
                }
                _isQiblaAligned.value = isAligned
            }
        } catch (_: Exception) {}
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        _accuracyCalibrationNeeded.value = accuracy == SensorManager.SENSOR_STATUS_UNRELIABLE
    }

    private fun startCountdownTimer() {
        viewModelScope.launch(Dispatchers.Default) {
            // Small initial delay
            delay(100)
            var lastCalculatedMinute = -1
            while (true) {
                try {
                    val now = System.currentTimeMillis()
                    val currentCal = Calendar.getInstance()
                    val currentMinute = currentCal.get(Calendar.MINUTE)

                    // Refresh schedule only if minute changed or next prayer has arrived
                    val curSchedule = _prayerSchedule.value
                    val nextPrayerTime = curSchedule.nextPrayerTimeMillis
                    val remMs = (nextPrayerTime - now).coerceAtLeast(0L)
 
                    if (remMs <= 0L || currentMinute != lastCalculatedMinute) {
                        lastCalculatedMinute = currentMinute
                        val updated = calculateCurrentSchedule()
                        _prayerSchedule.value = updated
                    }
 
                    val activeSchedule = _prayerSchedule.value
                    val activeRemMs = (activeSchedule.nextPrayerTimeMillis - now).coerceAtLeast(0L)
                    val hours = activeRemMs / (1000 * 60 * 60)
                    val minutes = (activeRemMs % (1000 * 60 * 60)) / (1000 * 60)
                    val seconds = (activeRemMs % (1000 * 60)) / 1000
                    
                    val countdown = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds)
                    if (_countdownFormatted.value != countdown) {
                        _countdownFormatted.value = countdown
                    }
                } catch (_: Exception) {}
                delay(1000L)
            }
        }
    }

    private fun calculateCurrentSchedule(): PrayerSchedule {
        val cal = Calendar.getInstance()
        val loc = _currentLocation.value
        return prayerCalculator.calculateTimes(
            calendar = cal,
            latitude = loc.latitude,
            longitude = loc.longitude,
            timeZoneOffsetHours = loc.timeZoneOffsetHours,
            method = _selectedMethod.value,
            juristicMethod = _selectedJuristic.value,
            adjustments = _prayerAdjustments.value
        )
    }

    fun searchCities(query: String) {
        _citySearchQuery.value = query
        val clean = query.trim()

        // 1. Instant offline search
        val offlineResults = CityLocationsRepository.searchCities(clean)
        _citySearchResults.value = offlineResults

        // 2. Debounced online search
        citySearchJob?.cancel()
        if (clean.length >= 2) {
            citySearchJob = viewModelScope.launch {
                _isCitySearching.value = true
                delay(300L) // 300ms debounce
                try {
                    val onlineResults = cityGeocodingService.searchOnlineCities(clean)
                    if (onlineResults.isNotEmpty()) {
                        // Merge offline and online results seamlessly, removing duplicates near same lat/lng
                        val merged = (offlineResults + onlineResults).distinctBy {
                            "${String.format(Locale.US, "%.2f", it.latitude)}_${String.format(Locale.US, "%.2f", it.longitude)}"
                        }
                        _citySearchResults.value = merged
                    }
                } catch (_: Exception) {
                    // Silently preserve offline results on network error
                } finally {
                    _isCitySearching.value = false
                }
            }
        } else {
            _isCitySearching.value = false
        }
    }

    fun detectGpsLocation(onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _isGpsLoading.value = true
            val loc = locationHelper.getCurrentGpsLocation()
            _isGpsLoading.value = false
            if (loc != null) {
                setLocation(loc)
                onResult(true, "تم تحديد موقعك بنجاح: ${loc.cityNameAr}")
            } else {
                onResult(false, "تعذر الحصول على إحداثيات GPS. يمكنك اختيار مدينتك من القائمة اليدوية.")
            }
        }
    }

    fun setLocation(location: LocationData) {
        _currentLocation.value = location
        settingsManager.saveLocation(location)
        _qiblaBearing.value = QiblaCalculator.calculateQiblaBearing(location.latitude, location.longitude)
        _distanceToKaabaKm.value = QiblaCalculator.calculateDistanceToKaabaKm(location.latitude, location.longitude)
        _prayerSchedule.value = calculateCurrentSchedule()
        triggerBackgroundAlarmScheduling()
    }

    fun setCalculationMethod(method: CalculationMethod) {
        _selectedMethod.value = method
        settingsManager.saveCalculationMethod(method)
        _prayerSchedule.value = calculateCurrentSchedule()
        triggerBackgroundAlarmScheduling()
    }

    fun setJuristicMethod(method: JuristicMethod) {
        _selectedJuristic.value = method
        settingsManager.saveJuristicMethod(method)
        _prayerSchedule.value = calculateCurrentSchedule()
        triggerBackgroundAlarmScheduling()
    }

    fun updateAdjustments(adjustments: PrayerAdjustments) {
        _prayerAdjustments.value = adjustments
        settingsManager.saveAdjustments(adjustments)
        _prayerSchedule.value = calculateCurrentSchedule()
        triggerBackgroundAlarmScheduling()
    }

    fun setAthanNotification(prayerType: PrayerType, type: AthanNotificationType) {
        settingsManager.saveAthanNotification(prayerType, type)
        triggerBackgroundAlarmScheduling()
    }

    fun getAthanNotification(prayerType: PrayerType): AthanNotificationType {
        return settingsManager.getAthanNotification(prayerType)
    }

    fun setMuezzinVoice(voice: MuezzinVoice) {
        _muezzinVoice.value = voice
        settingsManager.saveMuezzinVoice(voice)
        triggerBackgroundAlarmScheduling()
    }

    fun playMuezzinPreview(voice: MuezzinVoice = _muezzinVoice.value) {
        _previewingMuezzinVoice.value = voice
        audioHapticService.playMuezzinPreview(voice) { isPlaying ->
            _isAudioPreviewPlaying.value = isPlaying
            if (!isPlaying) {
                _previewingMuezzinVoice.value = null
            }
        }
    }

    fun stopAudioPreview() {
        audioHapticService.stopAudio()
        _isAudioPreviewPlaying.value = false
        _previewingMuezzinVoice.value = null
    }

    fun setQuranFont(font: QuranFont) {
        _quranFont.value = font
        settingsManager.saveQuranFont(font)
    }

    fun setDndMinutes(mins: Int) {
        _dndMinutes.value = mins
        settingsManager.saveDndMinutes(mins)
    }

    fun setFajrSmartAlarm(enabled: Boolean) {
        _fajrSmartAlarm.value = enabled
        settingsManager.saveFajrSmartAlarm(enabled)
    }

    fun setPreAthanMinutes(mins: Int) {
        _preAthanMinutes.value = mins
        settingsManager.savePreAthanMinutes(mins)
    }

    fun toggleDarkMode() {
        val newVal = !_isDarkMode.value
        _isDarkMode.value = newVal
        settingsManager.saveDarkMode(newVal)
    }

    fun setArabicFontSize(size: Float) {
        _arabicFontSize.value = size
        settingsManager.saveArabicFontSize(size)
    }

    // Quran actions
    fun searchSurahs(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _allSurahs.value = QuranRepository.surahs
        } else {
            _allSurahs.value = QuranRepository.surahs.filter {
                it.nameAr.contains(query, ignoreCase = true) ||
                        it.nameEn.contains(query, ignoreCase = true) ||
                        it.englishTranslation.contains(query, ignoreCase = true) ||
                        it.number.toString() == query.trim()
            }
        }
    }

    fun selectSurah(surah: Surah) {
        stopQuranAudioPlayback()
        _selectedSurah.value = surah
        _currentAyahs.value = QuranRepository.getAyahsForSurah(surah.number)
        settingsManager.saveLastRead(surah.number, 1)
        _lastRead.value = Pair(surah.number, 1)

        viewModelScope.launch {
            _isQuranLoading.value = true
            val fetched = QuranRepository.loadAyahsForSurah(surah.number)
            if (fetched.isNotEmpty() && _selectedSurah.value.number == surah.number) {
                _currentAyahs.value = fetched
            }
            _isQuranLoading.value = false
        }
    }

    fun selectQari(qari: Qari) {
        stopQuranAudioPlayback()
        _selectedQari.value = qari
    }

    fun toggleQuranAudioPlayback() {
        if (_isQuranAudioPlaying.value) {
            audioHapticService.pauseAudio()
            _isQuranAudioPlaying.value = false
        } else {
            if (audioHapticService.hasPreparedMedia()) {
                audioHapticService.resumeAudio { isPlaying ->
                    _isQuranAudioPlaying.value = isPlaying
                }
            } else {
                val streamUrl = QuranRepository.getAudioStreamUrl(_selectedQari.value, _selectedSurah.value.number)
                audioHapticService.playQuranAudioStream(streamUrl) { isPlaying ->
                    _isQuranAudioPlaying.value = isPlaying
                }
            }
        }
    }

    fun stopQuranAudioPlayback() {
        audioHapticService.stopAudio()
        _isQuranAudioPlaying.value = false
    }

    fun toggleBookmark(ayahNumber: Int) {
        val surah = _selectedSurah.value
        val existing = _bookmarks.value.find { it.surahNumber == surah.number && it.ayahNumber == ayahNumber }
        if (existing != null) {
            settingsManager.removeBookmark(surah.number, ayahNumber)
        } else {
            val b = Bookmark(
                id = "${surah.number}_$ayahNumber",
                surahNumber = surah.number,
                surahNameAr = surah.nameAr,
                ayahNumber = ayahNumber,
                timestamp = System.currentTimeMillis()
            )
            settingsManager.saveBookmark(b)
        }
        _bookmarks.value = settingsManager.getBookmarks()
    }

    fun isAyahBookmarked(ayahNumber: Int): Boolean {
        val sNum = _selectedSurah.value.number
        return _bookmarks.value.any { it.surahNumber == sNum && it.ayahNumber == ayahNumber }
    }

    private fun loadLastReadSurah() {
        val (surahNum, _) = settingsManager.getLastRead()
        val s = QuranRepository.surahs.find { it.number == surahNum } ?: QuranRepository.surahs.first()
        _selectedSurah.value = s
        _currentAyahs.value = QuranRepository.getAyahsForSurah(s.number)
    }

    // Azkar actions
    fun selectAzkarCategory(cat: AzkarCategory) {
        _selectedAzkarCategory.value = cat
        _currentAzkarList.value = AzkarRepository.getAzkarByCategory(cat.id)
    }

    fun incrementZikr(item: ZikrItem) {
        val cur = _zikrProgressCounts.value[item.id] ?: 0
        if (cur < item.countTarget) {
            val next = cur + 1
            _zikrProgressCounts.value = _zikrProgressCounts.value + (item.id to next)
            audioHapticService.playTasbihTapVibration()
            if (next >= item.countTarget) {
                audioHapticService.playMilestoneTargetVibration()
            }
        }
    }

    fun resetZikrCategoryProgress() {
        val list = _currentAzkarList.value
        val mutable = _zikrProgressCounts.value.toMutableMap()
        list.forEach { mutable.remove(it.id) }
        _zikrProgressCounts.value = mutable
    }

    // Tasbih actions
    fun setDhikrPreset(preset: DhikrPreset) {
        _currentDhikrPreset.value = preset
        _tasbihTarget.value = preset.defaultTarget
        _tasbihCount.value = 0
    }

    fun setTasbihTarget(target: Int) {
        _tasbihTarget.value = target
    }

    fun onTasbihTap() {
        val cur = _tasbihCount.value + 1
        val target = _tasbihTarget.value
        _tasbihCount.value = cur
        settingsManager.incrementTasbih()
        _tasbihLifetimeCount.value = settingsManager.getTasbihLifetimeCount()
        _tasbihTodayCount.value = settingsManager.getTasbihTodayCount()

        audioHapticService.playTasbihTapVibration()

        if (target > 0 && cur % target == 0) {
            audioHapticService.playMilestoneTargetVibration()
        }
    }

    fun resetTasbihCounter() {
        _tasbihCount.value = 0
    }

    // Tracker actions
    fun updatePrayerStatus(prayerType: PrayerType, status: PrayerCompletionStatus) {
        settingsManager.savePrayerStatus(todayKey, prayerType, status)
        _currentPrayerRecord.value = settingsManager.getPrayerRecord(todayKey)
    }

    fun updateKhatmahPlan(pagesRead: Int, targetDays: Int) {
        settingsManager.updateKhatmahProgress(pagesRead, targetDays)
        _khatmahPlan.value = settingsManager.getKhatmahPlan()
    }

    fun incrementKhatmahPage(amount: Int = 1) {
        val current = _khatmahPlan.value
        val updated = (current.pagesReadSoFar + amount).coerceIn(0, current.totalPages)
        updateKhatmahPlan(updated, current.targetDays)
    }

    // Zakat actions
    fun updateZakatInput(input: ZakatInput) {
        _zakatInput.value = input
        _zakatResult.value = calculateZakat(input)
    }

    private fun calculateZakat(input: ZakatInput): ZakatCalculationResult {
        val nisabThresholdGold = 85.0 * input.goldPricePerGram
        val goldVal = input.goldGrams24k * input.goldPricePerGram
        val silverVal = input.silverGrams * input.silverPricePerGram
        val liquidCash = input.cashOnHand + input.bankBalance
        val totalAssets = liquidCash + goldVal + silverVal + input.tradeGoodsValue + input.debtsOwedToYouRecoverable
        val zakatableWealth = (totalAssets - input.debtsYouOweDeductible).coerceAtLeast(0.0)
        val isNisab = zakatableWealth >= nisabThresholdGold
        val zakatPayable = if (isNisab) zakatableWealth * 0.025 else 0.0

        return ZakatCalculationResult(
            totalZakatableWealth = zakatableWealth,
            nisabThresholdGold = nisabThresholdGold,
            isNisabReached = isNisab,
            zakatPayableAmount = zakatPayable,
            goldValue = goldVal,
            silverValue = silverVal,
            liquidCashValue = liquidCash
        )
    }

    override fun onCleared() {
        super.onCleared()
        sensorManager?.unregisterListener(this)
        audioHapticService.stopAudio()
    }
}
