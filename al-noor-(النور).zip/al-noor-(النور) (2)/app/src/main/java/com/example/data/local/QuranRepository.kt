package com.example.data.local

import com.example.data.remote.QuranApiService
import com.example.domain.model.Ayah
import com.example.domain.model.Qari
import com.example.domain.model.Surah
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object QuranRepository {

    private val apiService = QuranApiService()
    private val memorySurahCache = mutableMapOf<Int, List<Ayah>>()

    val qaris = listOf(
        Qari(
            id = "yasser_al_dosari",
            nameAr = "الشيخ ياسر الدوسري",
            nameEn = "Sheikh Yasser Al-Dosari",
            style = "إمام الحرم المكي الشريف - ترتيل خاشع",
            serverUrlPrefix = "https://server11.mp3quran.net/yasser/"
        ),
        Qari(
            id = "mishary_alafasy",
            nameAr = "مشاري راشد العفاسي",
            nameEn = "Mishary Rashid Alafasy",
            style = "مرتل عذب ومتقن",
            serverUrlPrefix = "https://server8.mp3quran.net/afs/"
        ),
        Qari(
            id = "abdul_basit",
            nameAr = "عبد الباسط عبد الصمد",
            nameEn = "Abdul Basit Abdul Samad",
            style = "مجود كلاسيكي",
            serverUrlPrefix = "https://server7.mp3quran.net/basit/Almusshaf-Al-Mujawwad/"
        ),
        Qari(
            id = "al_sudais",
            nameAr = "عبد الرحمن السديس",
            nameEn = "Abdur-Rahman as-Sudais",
            style = "حرم مكي خاشع",
            serverUrlPrefix = "https://server11.mp3quran.net/sds/"
        ),
        Qari(
            id = "al_minshawi",
            nameAr = "محمد صديق المنشاوي",
            nameEn = "Mohamed Siddiq El-Minshawi",
            style = "مرتل متقن وحزين",
            serverUrlPrefix = "https://server10.mp3quran.net/minsh/"
        ),
        Qari(
            id = "al_ghamdi",
            nameAr = "سعد الغامدي",
            nameEn = "Saad Al-Ghamdi",
            style = "مرتل هادئ ومؤثر",
            serverUrlPrefix = "https://server7.mp3quran.net/s_gmd/"
        ),
        Qari(
            id = "maher_muaiqly",
            nameAr = "ماهر المعيقلي",
            nameEn = "Maher Al-Muaiqly",
            style = "حرم مكي مؤثر",
            serverUrlPrefix = "https://server12.mp3quran.net/maher/"
        )
    )

    val surahs: List<Surah> = listOf(
        Surah(1, "الفاتحة", "Al-Fatihah", "The Opening", 7, "Meccan", "مكية", 1, 1),
        Surah(2, "البقرة", "Al-Baqarah", "The Cow", 286, "Medinan", "مدنية", 1, 2),
        Surah(3, "آل عمران", "Ali 'Imran", "Family of Imran", 200, "Medinan", "مدنية", 3, 50),
        Surah(4, "النساء", "An-Nisa", "The Women", 176, "Medinan", "مدنية", 4, 77),
        Surah(5, "المائدة", "Al-Ma'idah", "The Table Spread", 120, "Medinan", "مدنية", 6, 106),
        Surah(6, "الأنعام", "Al-An'am", "The Cattle", 165, "Meccan", "مكية", 7, 128),
        Surah(7, "الأعراف", "Al-A'raf", "The Heights", 206, "Meccan", "مكية", 8, 151),
        Surah(8, "الأنفال", "Al-Anfal", "The Spoils of War", 75, "Medinan", "مدنية", 9, 177),
        Surah(9, "التوبة", "At-Tawbah", "The Repentance", 129, "Medinan", "مدنية", 10, 187),
        Surah(10, "يونس", "Yunus", "Jonah", 109, "Meccan", "مكية", 11, 208),
        Surah(11, "هود", "Hud", "Hud", 123, "Meccan", "مكية", 11, 221),
        Surah(12, "يوسف", "Yusuf", "Joseph", 111, "Meccan", "مكية", 12, 235),
        Surah(13, "الرعد", "Ar-Ra'd", "The Thunder", 43, "Medinan", "مدنية", 13, 249),
        Surah(14, "إبراهيم", "Ibrahim", "Abraham", 52, "Meccan", "مكية", 13, 255),
        Surah(15, "الحجر", "Al-Hijr", "The Rocky Tract", 99, "Meccan", "مكية", 14, 262),
        Surah(16, "النحل", "An-Nahl", "The Bee", 128, "Meccan", "مكية", 14, 267),
        Surah(17, "الإسراء", "Al-Isra", "The Night Journey", 111, "Meccan", "مكية", 15, 282),
        Surah(18, "الكهف", "Al-Kahf", "The Cave", 110, "Meccan", "مكية", 15, 293),
        Surah(19, "مريم", "Maryam", "Mary", 98, "Meccan", "مكية", 16, 305),
        Surah(20, "طه", "Ta-Ha", "Ta-Ha", 135, "Meccan", "مكية", 16, 312),
        Surah(21, "الأنبياء", "Al-Anbiya", "The Prophets", 112, "Meccan", "مكية", 17, 322),
        Surah(22, "الحج", "Al-Hajj", "The Pilgrimage", 78, "Medinan", "مدنية", 17, 332),
        Surah(23, "المؤمنون", "Al-Mu'minun", "The Believers", 118, "Meccan", "مكية", 18, 342),
        Surah(24, "النور", "An-Nur", "The Light", 64, "Medinan", "مدنية", 18, 350),
        Surah(25, "الفرقان", "Al-Furqan", "The Criterion", 77, "Meccan", "مكية", 18, 359),
        Surah(26, "الشعراء", "Ash-Shu'ara", "The Poets", 227, "Meccan", "مكية", 19, 367),
        Surah(27, "النمل", "An-Naml", "The Ants", 93, "Meccan", "مكية", 19, 377),
        Surah(28, "القصص", "Al-Qasas", "The Stories", 88, "Meccan", "مكية", 20, 385),
        Surah(29, "العنكبوت", "Al-'Ankabut", "The Spider", 69, "Meccan", "مكية", 20, 396),
        Surah(30, "الروم", "Ar-Rum", "The Romans", 60, "Meccan", "مكية", 21, 404),
        Surah(31, "لقمان", "Luqman", "Luqman", 34, "Meccan", "مكية", 21, 411),
        Surah(32, "السجدة", "As-Sajdah", "The Prostration", 30, "Meccan", "مكية", 21, 415),
        Surah(33, "الأحزاب", "Al-Ahzab", "The Combined Forces", 73, "Medinan", "مدنية", 21, 418),
        Surah(34, "سبأ", "Saba", "Sheba", 54, "Meccan", "مكية", 22, 428),
        Surah(35, "فاطر", "Fatir", "Originator", 45, "Meccan", "مكية", 22, 434),
        Surah(36, "يس", "Ya-Sin", "Ya-Sin", 83, "Meccan", "مكية", 22, 440),
        Surah(37, "الصافات", "As-Saffat", "Those Who Set The Ranks", 182, "Meccan", "مكية", 23, 446),
        Surah(38, "ص", "Sad", "The Letter Sad", 88, "Meccan", "مكية", 23, 453),
        Surah(39, "الزمر", "Az-Zumar", "The Troops", 75, "Meccan", "مكية", 23, 458),
        Surah(40, "غافر", "Ghafir", "The Forgiver", 85, "Meccan", "مكية", 24, 467),
        Surah(41, "فصلت", "Fussilat", "Explained in Detail", 54, "Meccan", "مكية", 24, 477),
        Surah(42, "الشورى", "Ash-Shura", "The Consultation", 53, "Meccan", "مكية", 25, 483),
        Surah(43, "الزخرف", "Az-Zukhruf", "The Ornaments of Gold", 89, "Meccan", "مكية", 25, 489),
        Surah(44, "الدخان", "Ad-Dukhan", "The Smoke", 59, "Meccan", "مكية", 25, 496),
        Surah(45, "الجاثية", "Al-Jathiyah", "The Crouching", 37, "Meccan", "مكية", 25, 499),
        Surah(46, "الأحقاف", "Al-Ahqaf", "The Wind-Curved Sandhills", 35, "Meccan", "مكية", 26, 502),
        Surah(47, "محمد", "Muhammad", "Muhammad", 38, "Medinan", "مدنية", 26, 507),
        Surah(48, "الفتح", "Al-Fath", "The Victory", 29, "Medinan", "مدنية", 26, 511),
        Surah(49, "الحجرات", "Al-Hujurat", "The Rooms", 18, "Medinan", "مدنية", 26, 515),
        Surah(50, "ق", "Qaf", "The Letter Qaf", 45, "Meccan", "مكية", 26, 518),
        Surah(51, "الذاريات", "Adh-Dhariyat", "The Winnowing Winds", 60, "Meccan", "مكية", 26, 520),
        Surah(52, "الطور", "At-Tur", "The Mount", 49, "Meccan", "مكية", 27, 523),
        Surah(53, "النجم", "An-Najm", "The Star", 62, "Meccan", "مكية", 27, 526),
        Surah(54, "القمر", "Al-Qamar", "The Moon", 55, "Meccan", "مكية", 27, 528),
        Surah(55, "الرحمن", "Ar-Rahman", "The Beneficent", 78, "Medinan", "مدنية", 27, 531),
        Surah(56, "الواقعة", "Al-Waqi'ah", "The Inevitable", 96, "Meccan", "مكية", 27, 534),
        Surah(57, "الحديد", "Al-Hadid", "The Iron", 29, "Medinan", "مدنية", 27, 537),
        Surah(58, "المجادلة", "Al-Mujadila", "The Pleading Woman", 22, "Medinan", "مدنية", 28, 542),
        Surah(59, "الحشر", "Al-Hashr", "The Exile", 24, "Medinan", "مدنية", 28, 545),
        Surah(60, "الممتحنة", "Al-Mumtahanah", "She That Is To Be Examined", 13, "Medinan", "مدنية", 28, 549),
        Surah(61, "الصف", "As-Saf", "The Ranks", 14, "Medinan", "مدنية", 28, 551),
        Surah(62, "الجمعة", "Al-Jumu'ah", "Friday", 11, "Medinan", "مدنية", 28, 553),
        Surah(63, "المنافقون", "Al-Munafiqun", "The Hypocrites", 11, "Medinan", "مدنية", 28, 554),
        Surah(64, "التغابن", "At-Taghabun", "Mutual Disillusion", 18, "Medinan", "مدنية", 28, 556),
        Surah(65, "الطلاق", "At-Talaq", "The Divorce", 12, "Medinan", "مدنية", 28, 558),
        Surah(66, "التحريم", "At-Tahrim", "The Prohibition", 12, "Medinan", "مدنية", 28, 560),
        Surah(67, "الملك", "Al-Mulk", "The Sovereignty", 30, "Meccan", "مكية", 29, 562),
        Surah(68, "القلم", "Al-Qalam", "The Pen", 52, "Meccan", "مكية", 29, 564),
        Surah(69, "الحاقة", "Al-Haqqah", "The Inevitable Reality", 52, "Meccan", "مكية", 29, 566),
        Surah(70, "المعارج", "Al-Ma'arij", "The Ascending Stairways", 44, "Meccan", "مكية", 29, 568),
        Surah(71, "نوح", "Nuh", "Noah", 28, "Meccan", "مكية", 29, 570),
        Surah(72, "الجن", "Al-Jinn", "The Jinn", 28, "Meccan", "مكية", 29, 572),
        Surah(73, "المزمل", "Al-Muzzammil", "The Enshrouded One", 20, "Meccan", "مكية", 29, 574),
        Surah(74, "المدثر", "Al-Muddathir", "The Cloaked One", 56, "Meccan", "مكية", 29, 575),
        Surah(75, "القيامة", "Al-Qiyamah", "The Resurrection", 40, "Meccan", "مكية", 29, 577),
        Surah(76, "الإنسان", "Al-Insan", "Man", 31, "Medinan", "مدنية", 29, 578),
        Surah(77, "المرسلات", "Al-Mursalat", "The Emissaries", 50, "Meccan", "مكية", 29, 580),
        Surah(78, "النبأ", "An-Naba", "The Tidings", 40, "Meccan", "مكية", 30, 582),
        Surah(79, "النازعات", "An-Nazi'at", "Those Who Drag Forth", 46, "Meccan", "مكية", 30, 583),
        Surah(80, "عبس", "'Abasa", "He Frowned", 42, "Meccan", "مكية", 30, 585),
        Surah(81, "التكوير", "At-Takwir", "The Overthrowing", 29, "Meccan", "مكية", 30, 586),
        Surah(82, "الانفطار", "Al-Infitar", "The Cleaving", 19, "Meccan", "مكية", 30, 587),
        Surah(83, "المطففين", "Al-Mutaffifin", "Defrauding", 36, "Meccan", "مكية", 30, 587),
        Surah(84, "الانشقاق", "Al-Inshiqaq", "The Splitting Open", 25, "Meccan", "مكية", 30, 589),
        Surah(85, "البروج", "Al-Buruj", "The Constellations", 22, "Meccan", "مكية", 30, 590),
        Surah(86, "الطارق", "At-Tariq", "The Nightcomer", 17, "Meccan", "مكية", 30, 591),
        Surah(87, "الأعلى", "Al-A'la", "The Most High", 19, "Meccan", "مكية", 30, 591),
        Surah(88, "الغاشية", "Al-Ghashiyah", "The Overwhelming", 26, "Meccan", "مكية", 30, 592),
        Surah(89, "الفجر", "Al-Fajr", "The Dawn", 30, "Meccan", "مكية", 30, 593),
        Surah(90, "البلد", "Al-Balad", "The City", 20, "Meccan", "مكية", 30, 594),
        Surah(91, "الشمس", "Ash-Shams", "The Sun", 15, "Meccan", "مكية", 30, 595),
        Surah(92, "الليل", "Al-Layl", "The Night", 21, "Meccan", "مكية", 30, 595),
        Surah(93, "الضحى", "Ad-Duha", "The Morning Brightness", 11, "Meccan", "مكية", 30, 596),
        Surah(94, "الشرح", "Ash-Sharh", "The Relief", 8, "Meccan", "مكية", 30, 596),
        Surah(95, "التين", "At-Tin", "The Fig", 8, "Meccan", "مكية", 30, 597),
        Surah(96, "العلق", "Al-'Alaq", "The Clot", 19, "Meccan", "مكية", 30, 597),
        Surah(97, "القدر", "Al-Qadr", "The Night of Decree", 5, "Meccan", "مكية", 30, 598),
        Surah(98, "البينة", "Al-Bayyinah", "The Clear Proof", 8, "Medinan", "مدنية", 30, 598),
        Surah(99, "الزلزلة", "Az-Zalzalah", "The Earthquake", 8, "Medinan", "مدنية", 30, 599),
        Surah(100, "العاديات", "Al-'Adiyat", "The Courser", 11, "Meccan", "مكية", 30, 599),
        Surah(101, "القارعة", "Al-Qari'ah", "The Calamity", 11, "Meccan", "مكية", 30, 600),
        Surah(102, "التكاثر", "At-Takathur", "Rivalry in World Increase", 8, "Meccan", "مكية", 30, 600),
        Surah(103, "العصر", "Al-'Asr", "The Declining Day", 3, "Meccan", "مكية", 30, 601),
        Surah(104, "الهمزة", "Al-Humazah", "The Traducer", 9, "Meccan", "مكية", 30, 601),
        Surah(105, "الفيل", "Al-Fil", "The Elephant", 5, "Meccan", "مكية", 30, 601),
        Surah(106, "قريش", "Quraysh", "Quraysh", 4, "Meccan", "مكية", 30, 602),
        Surah(107, "الماعون", "Al-Ma'un", "Small Kindness", 7, "Meccan", "مكية", 30, 602),
        Surah(108, "الكوثر", "Al-Kawthar", "Abundance", 3, "Meccan", "مكية", 30, 602),
        Surah(109, "الكافرون", "Al-Kafirun", "The Disbelievers", 6, "Meccan", "مكية", 30, 603),
        Surah(110, "النصر", "An-Nasr", "The Divine Support", 3, "Medinan", "مدنية", 30, 603),
        Surah(111, "المسد", "Al-Masad", "The Palm Fiber", 5, "Meccan", "مكية", 30, 603),
        Surah(112, "الإخلاص", "Al-Ikhlas", "The Sincerity", 4, "Meccan", "مكية", 30, 604),
        Surah(113, "الفلق", "Al-Falaq", "The Daybreak", 5, "Meccan", "مكية", 30, 604),
        Surah(114, "الناس", "An-Nas", "Mankind", 6, "Meccan", "مكية", 30, 604)
    )

    private val detailedAyahsBySurah: Map<Int, List<Ayah>> = mapOf(
        1 to listOf(
            Ayah(1, 1, "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", "In the name of Allah, the Entirely Merciful, the Especially Merciful.", "أبتدئ قراءتي مستعينا باسم الله، مستحضرا صفات رحمته الواسعة بجميع خلقه وخاصتها بعباده المؤمنين.", 1, 1, 1),
            Ayah(2, 2, "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", "[All] praise is [due] to Allah, Lord of the worlds -", "الثناء الكامل والشكر الخالص لله وحده المربي لجميع خلقه بنعمه والمالك لشؤونهم.", 1, 1, 1),
            Ayah(3, 3, "الرَّحْمَٰنِ الرَّحِيمِ", "The Entirely Merciful, the Especially Merciful,", "الرحمن ذو الرحمة العامة الشاملة، والرحيم بالمؤمنين يوم القيامة.", 1, 1, 1),
            Ayah(4, 4, "مَالِكِ يَوْمِ الدِّينِ", "Sovereign of the Day of Recompense.", "المالك المتصرف المطلق في يوم القيامة والجزاء والحساب.", 1, 1, 1),
            Ayah(5, 5, "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", "It is You we worship and You we ask for help.", "نخصك وحدك بالعبادة والتذلل، ونطلب منك وحدك العون على طاعتك وسائر أمورنا.", 1, 1, 1),
            Ayah(6, 6, "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", "Guide us to the straight path -", "وفقنا وأرشدنا وثبتنا على الطريق القويم الواضح وهو دين الإسلام الحق.", 1, 1, 1),
            Ayah(7, 7, "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", "The path of those upon whom You have bestowed favor, not of those who have evoked [Your] anger or of those who are astray.", "طريق من أنعمت عليهم من النبيين والصديقين والشهداء والصالحين، غير طريق المغضوب عليهم وهم الذين عرفوا الحق ولم يتبعوه، ولا طريق الضالين الذين ضلوا عن الحق بجهلهم.", 1, 1, 1)
        ),
        67 to listOf(
            Ayah(1, 5242, "تَبَارَكَ الَّذِي بِيَدِهِ الْمُلْكُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", "Blessed is He in whose hand is dominion, and He is over all things competent -", "تكاثر خير الله وعظم سلطانه، بيده التصرف المطلق في الكون والحياة وهو على كل شيء قدير.", 29, 562, 67),
            Ayah(2, 5243, "الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا ۚ وَهُوَ الْعَزِيزُ الْغَفُورُ", "[He] who created death and life to test you [as to] which of you is best in deed - and He is the Exalted in Might, the Forgiving -", "خلق الموت والحياة اختبارا لعباده أيكم أخلص وأصوب عملا، وهو العزيز الغالب لمن عصاه الغفور لمن تاب وأناب.", 29, 562, 67),
            Ayah(3, 5244, "الَّذِي خَلَقَ سَبْعَ سَمَاوَاتٍ طِبَاقًا ۖ مَّا تَرَىٰ فِي خَلْقِ الرَّحْمَٰنِ مِن تَفَاوُتٍ ۖ فَارْجِعِ الْبَصَرَ هَلْ تَرَىٰ مِن فُطُورٍ", "[And] who created seven heavens in layers. You do not see in the creation of the Most Merciful any inconsistency. So return [your] vision to the sky; do you see any breaks?", "خلق سبع سماوات متطابقة في إتقان وتناسق، لا تجد فيها أي خلل أو عيب.", 29, 562, 67),
            Ayah(4, 5245, "ثُمَّ ارْجِعِ الْبَصَرَ كَرَّتَيْنِ يَنقَلِبْ إِلَيْكَ الْبَصَرُ خَاسِئًا وَهُوَ حَسِيرٌ", "Then return [your] vision twice again. [Your] vision will return to you humbled while it is fatigued.", "كرر النظر مرارا وتكرارا، سيرجع بصرك خاضعا كليلا دون أن يجد نقصا في خلق الله العظيم.", 29, 562, 67)
        ),
        112 to listOf(
            Ayah(1, 6222, "قُلْ هُوَ اللَّهُ أَحَدٌ", "Say, \"He is Allah, [who is] One,", "قل أيها الرسول: الله هو الإله المنفرد بالوحدانية والكمال، لا شريك له ولا شبيه.", 30, 604, 112),
            Ayah(2, 6223, "اللَّهُ الصَّمَدُ", "Allah, the Eternal Refuge.", "الله السيد المستغني عن خلقه الذي تقصده جميع الخلائق في حوائجها ورغائبها.", 30, 604, 112),
            Ayah(3, 6224, "لَمْ يَلِدْ وَلَمْ يُولَدْ", "He neither begets nor is born,", "ليس له ولد ولا والد، منزه عن صفات المخلوقين.", 30, 604, 112),
            Ayah(4, 6225, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "Nor is there to Him any equivalent.\"", "ولم يكن له مماثل ولا نظير في ذاته أو أسمائه أو صفاته.", 30, 604, 112)
        ),
        113 to listOf(
            Ayah(1, 6226, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", "Say, \"I seek refuge in the Lord of daybreak", "قل أعتصم وأتحصن برب الصبح وفالقه بنوره.", 30, 604, 113),
            Ayah(2, 6227, "مِن شَرِّ مَا خَلَقَ", "From the evil of that which He created", "من شر كل مخلوق فيه أذى وشر في الوجود.", 30, 604, 113),
            Ayah(3, 6228, "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", "And from the evil of darkness when it settles", "ومن شر الليل إذا أقبل بظلامه وانتشرت فيه الهوام والأشرار.", 30, 604, 113),
            Ayah(4, 6229, "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", "And from the evil of the blowers in knots", "ومن شر السواحر اللاتي ينفثن في العقد بقصد الأذى والسحر.", 30, 604, 113),
            Ayah(5, 6230, "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", "And from the evil of an envier when he envies.\"", "ومن شر صاحب العين والحسد إذا أظهر حسده وتمنى زوال النعمة عن غيره.", 30, 604, 113)
        ),
        114 to listOf(
            Ayah(1, 6231, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", "Say, \"I seek refuge in the Lord of mankind,", "قل أتحصن برب الناس وخالقهم ومدبر شؤونهم.", 30, 604, 114),
            Ayah(2, 6232, "مَلِكِ النَّاسِ", "The Sovereign of mankind,", "الملك الحق المتصرف في عباده بأمره ونهيه.", 30, 604, 114),
            Ayah(3, 6233, "إِلَٰهِ النَّاسِ", "The God of mankind,", "الإله المعبود بحق وحده لا إله غيره.", 30, 604, 114),
            Ayah(4, 6234, "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", "From the evil of the retreating whisperer -", "من شر الشيطان الذي يلقي الشبهات والوساوس في القلب ويخنس ويختفي عند ذكر الله.", 30, 604, 114),
            Ayah(5, 6235, "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", "Who whispers into the breasts of mankind -", "الذي يزين الشر ويقبح الخير في قلوب البشر.", 30, 604, 114),
            Ayah(6, 6236, "مِنَ الْجِنَّةِ وَالنَّاسِ", "From among the jinn and mankind.\"", "سواء كان الوسواس من شياطين الإنس أو من شياطين الجن.", 30, 604, 114)
        )
    )

    fun getAyahsForSurah(surahNumber: Int): List<Ayah> {
        val cached = memorySurahCache[surahNumber]
        if (cached != null) return cached

        val predefined = detailedAyahsBySurah[surahNumber]
        if (predefined != null) return predefined

        val surah = surahs.find { it.number == surahNumber } ?: surahs.first()
        return (1..surah.numberOfAyahs).map { index ->
            Ayah(
                numberInSurah = index,
                numberInQuran = (surahNumber - 1) * 50 + index,
                textAr = if (surahNumber == 1 && index == 1) {
                    "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"
                } else {
                    "إِنَّ هَٰذَا الْقُرْآنَ يَهْدِي لِلَّتِي هِيَ أَقْوَمُ وَيُبَشِّرُ الْمُؤْمِنِينَ الَّذِينَ يَعْمَلُونَ الصَّالِحَاتِ أَنَّ لَهُمْ أَجْرًا كَبِيرًا"
                },
                translationEn = "Indeed, this Qur'an guides to that which is most suitable and gives good tidings to the believers who do righteous deeds that they will have a great reward. (Surah ${surah.nameEn}, Ayah $index)",
                tafsirMuyassarAr = "تفسير سورة ${surah.nameAr} - الآية $index: بيان وتدبر آيات الله البينات وتوجيه القلوب إلى الإيمان والعمل الصالح والتمسك بالقرآن الكريم.",
                juz = surah.juz,
                page = surah.pageNumber,
                surahNumber = surahNumber
            )
        }
    }

    suspend fun loadAyahsForSurah(surahNumber: Int): List<Ayah> = withContext(Dispatchers.IO) {
        val cached = memorySurahCache[surahNumber]
        if (cached != null) return@withContext cached

        val apiAyahs = apiService.fetchSurahAyahs(surahNumber)
        if (apiAyahs != null && apiAyahs.isNotEmpty()) {
            memorySurahCache[surahNumber] = apiAyahs
            return@withContext apiAyahs
        }

        getAyahsForSurah(surahNumber)
    }

    fun getAudioStreamUrl(qari: Qari, surahNumber: Int): String {
        val formattedNumber = String.format("%03d", surahNumber)
        return "${qari.serverUrlPrefix}$formattedNumber.mp3"
    }
}
