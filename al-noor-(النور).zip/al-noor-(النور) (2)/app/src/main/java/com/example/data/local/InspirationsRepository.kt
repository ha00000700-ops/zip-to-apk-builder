package com.example.data.local

import com.example.domain.model.DailyInspiration
import com.example.domain.model.InspirationType

object InspirationsRepository {

    val inspirations = listOf(
        DailyInspiration(
            id = "insp_1",
            type = InspirationType.QURAN_AYAH,
            textAr = "﴿ أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ ﴾",
            sourceAr = "سورة الرعد - الآية 28",
            explanationAr = "حقيقة الطمأنينة وسكينة النفس لا تُنال إلا باللجوء إلى الله تعالى واستدامة ذكره باللسان والجنان.",
            translationEn = "Unquestionably, by the remembrance of Allah hearts are assured.",
            contextTheme = "السكينة والطمأنينة"
        ),
        DailyInspiration(
            id = "insp_2",
            type = InspirationType.HADITH_NABAWY,
            textAr = "« مَثَلُ الَّذِي يَذْكُرُ رَبَّهُ وَالَّذِي لا يَذْكُرُ رَبَّهُ، مَثَلُ الحَيِّ وَالمَيِّتِ »",
            sourceAr = "صحيح البخاري (6407)",
            explanationAr = "الذكر حياة حقيقية للأرواح والقلوب، والغفلة عنه موت وظلمة تعتري النفس.",
            translationEn = "The example of the one who celebrates the praises of his Lord and the one who does not is like the living and the dead.",
            contextTheme = "فضل الذكر"
        ),
        DailyInspiration(
            id = "insp_3",
            type = InspirationType.QURAN_AYAH,
            textAr = "﴿ وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ ﴾",
            sourceAr = "سورة البقرة - الآية 186",
            explanationAr = "قرب الله من عباده سميع لدعائهم، مجيب لتضرعهم، لا يحتاج الداعي إلى وسيط ولا حائل.",
            translationEn = "And when My servants ask you concerning Me, indeed I am near. I respond to the invocation of the supplicant when he calls upon Me.",
            contextTheme = "إجابة الدعاء"
        ),
        DailyInspiration(
            id = "insp_4",
            type = InspirationType.HADITH_NABAWY,
            textAr = "« احْفَظِ اللَّهَ يَحْفَظْكَ، احْفَظِ اللَّهَ تَجِدْهُ تُجَاهَكَ، إِذَا سَأَلْتَ فَاسْأَلِ اللَّهَ، وَإِذَا اسْتَعَنْتَ فَاسْتَعِنْ بِاللَّهِ »",
            sourceAr = "جامع الترمذي وصححه (2516)",
            explanationAr = "قاعدة جامعة في التوكل على الله وحفظ حدوده وفرائضه، ليكون الله معك في كل شدة ورخاء.",
            translationEn = "Be mindful of Allah and He will protect you. Be mindful of Allah and you will find Him before you. If you ask, ask of Allah; if you seek help, seek help of Allah.",
            contextTheme = "التوكل واليقين"
        ),
        DailyInspiration(
            id = "insp_5",
            type = InspirationType.DUA_MASNOON,
            textAr = "« اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ، وَشُكْرِكَ، وَحُسْنِ عِبَادَتِكَ »",
            sourceAr = "سنن أبي داود (1522) وصححه الألباني",
            explanationAr = "وصية الحبيب المصطفى ﷺ لمعاذ بن جبل رضي الله عنه دبر كل صلاة.",
            translationEn = "O Allah, help me remember You, give thanks to You, and worship You in the best manner.",
            contextTheme = "التوفيق للعبادة"
        )
    )

    fun getTodayInspiration(): DailyInspiration {
        val dayOfYear = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
        val index = (dayOfYear - 1) % inspirations.size
        return inspirations[index]
    }
}
