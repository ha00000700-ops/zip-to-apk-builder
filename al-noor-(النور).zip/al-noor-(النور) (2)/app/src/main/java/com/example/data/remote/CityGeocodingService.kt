package com.example.data.remote

import com.example.domain.model.LocationData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.TimeZone
import java.util.concurrent.TimeUnit

class CityGeocodingService {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    /**
     * Searches for cities online using Open-Meteo Geocoding API with fallback to OpenStreetMap Nominatim.
     */
    suspend fun searchOnlineCities(query: String): List<LocationData> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.length < 2) return@withContext emptyList()

        val results = mutableListOf<LocationData>()

        // 1. Try Open-Meteo Geocoding API (Fast, reliable, multi-lingual Arabic/English, no key needed)
        try {
            val encodedQuery = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://geocoding-api.open-meteo.com/v1/search?name=$encodedQuery&count=15&language=ar&format=json"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "AlNoorApp/1.0 (Android; PrayerTimes)")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string()
                if (!body.isNullOrEmpty()) {
                    val root = JSONObject(body)
                    if (root.has("results")) {
                        val array = root.getJSONArray("results")
                        for (i in 0 until array.length()) {
                            val item = array.getJSONObject(i)
                            val name = item.optString("name", "")
                            val country = item.optString("country", "")
                            val admin1 = item.optString("admin1", "")
                            val lat = item.optDouble("latitude", 0.0)
                            val lng = item.optDouble("longitude", 0.0)
                            val timezoneId = item.optString("timezone", "")

                            var tzOffset = 0.0
                            if (timezoneId.isNotEmpty()) {
                                try {
                                    val tz = TimeZone.getTimeZone(timezoneId)
                                    tzOffset = tz.getOffset(System.currentTimeMillis()) / (1000.0 * 3600.0)
                                } catch (_: Exception) {
                                    tzOffset = Math.round(lng / 15.0).toDouble()
                                }
                            } else {
                                tzOffset = Math.round(lng / 15.0).toDouble()
                            }

                            val displaySub = if (admin1.isNotEmpty() && admin1 != name) "$admin1, $country" else country

                            if (name.isNotEmpty() && lat != 0.0 && lng != 0.0) {
                                results.add(
                                    LocationData(
                                        cityNameAr = name,
                                        cityNameEn = name,
                                        countryAr = displaySub.ifEmpty { "عالمي" },
                                        countryEn = country.ifEmpty { "World" },
                                        latitude = lat,
                                        longitude = lng,
                                        timeZoneOffsetHours = tzOffset,
                                        isAutoGps = false
                                    )
                                )
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Log or ignore to allow fallback
        }

        // 2. If Open-Meteo returned few or no results, fallback to OpenStreetMap Nominatim
        if (results.isEmpty()) {
            try {
                val encodedQuery = URLEncoder.encode(trimmed, "UTF-8")
                val nominatimUrl = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&addressdetails=1&limit=10&accept-language=ar,en"
                val request = Request.Builder()
                    .url(nominatimUrl)
                    .header("User-Agent", "AlNoorApp/1.0 (Android; Contact: jmw14077@gmail.com)")
                    .build()

                val response = httpClient.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string()
                    if (!body.isNullOrEmpty()) {
                        val array = org.json.JSONArray(body)
                        for (i in 0 until array.length()) {
                            val item = array.getJSONObject(i)
                            val lat = item.optString("lat", "0.0").toDoubleOrNull() ?: 0.0
                            val lng = item.optString("lon", "0.0").toDoubleOrNull() ?: 0.0
                            val displayName = item.optString("display_name", "")
                            val name = item.optString("name", displayName.split(",").firstOrNull() ?: trimmed)

                            val addr = item.optJSONObject("address")
                            val country = addr?.optString("country", "") ?: displayName.split(",").lastOrNull()?.trim() ?: ""
                            val state = addr?.optString("state", "") ?: ""

                            val sub = if (state.isNotEmpty() && state != name) "$state, $country" else country
                            val tzOffset = Math.round(lng / 15.0).toDouble()

                            if (name.isNotEmpty() && lat != 0.0 && lng != 0.0) {
                                results.add(
                                    LocationData(
                                        cityNameAr = name,
                                        cityNameEn = name,
                                        countryAr = sub.ifEmpty { "عالمي" },
                                        countryEn = country.ifEmpty { "World" },
                                        latitude = lat,
                                        longitude = lng,
                                        timeZoneOffsetHours = tzOffset,
                                        isAutoGps = false
                                    )
                                )
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        results
    }
}
