package com.example.data.local

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.domain.model.MuezzinVoice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

import android.util.Log

class AudioAndHapticService(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private var isAudioPlaying = false
    private var toneJob: Job? = null

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun playTasbihTapVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(25)
            }
        } catch (_: Exception) {}
    }

    fun playMilestoneTargetVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 70, 50, 120, 50, 180)
                val amplitudes = intArrayOf(0, 150, 0, 200, 0, 255)
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 80, 50, 150), -1)
            }
        } catch (_: Exception) {}
    }

    fun playQiblaAlignedHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(45, 180))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(45)
            }
        } catch (_: Exception) {}
    }

    /**
     * Plays spiritual Athan audio file from assets for the selected MuezzinVoice
     */
    fun playAthanTone(muezzin: MuezzinVoice, onFinished: (() -> Unit)? = null) {
        playMuezzinPreview(muezzin) { isPlaying ->
            if (!isPlaying) {
                onFinished?.invoke()
            }
        }
    }

    fun playMuezzinPreview(muezzin: MuezzinVoice, onPlaybackStateChanged: (Boolean) -> Unit) {
        stopAudio()
        isAudioPlaying = true
        onPlaybackStateChanged(true)

        val assetPath = when {
            muezzin.assetPath.isNotBlank() && isAssetAvailable(muezzin.assetPath) -> muezzin.assetPath
            isAssetAvailable("audio/athan.mp3") -> "audio/athan.mp3"
            else -> ""
        }

        if (assetPath.isNotBlank() || muezzin.audioUrl.isNotBlank()) {
            try {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    
                    if (assetPath.isNotBlank()) {
                        val fd = context.assets.openFd(assetPath)
                        setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                        fd.close()
                    } else {
                        setDataSource(muezzin.audioUrl)
                    }

                    setOnPreparedListener {
                        if (isAudioPlaying) {
                            start()
                            onPlaybackStateChanged(true)
                        } else {
                            stop()
                            release()
                            mediaPlayer = null
                        }
                    }
                    setOnCompletionListener {
                        isAudioPlaying = false
                        onPlaybackStateChanged(false)
                        stopAudio()
                    }
                    setOnErrorListener { _, what, extra ->
                        Log.e("AudioAndHapticService", "MediaPlayer error: what=$what, extra=$extra")
                        isAudioPlaying = false
                        onPlaybackStateChanged(false)
                        true
                    }
                    prepareAsync()
                }
            } catch (e: Exception) {
                Log.e("AudioAndHapticService", "MediaPlayer exception: ${e.message}", e)
                isAudioPlaying = false
                onPlaybackStateChanged(false)
            }
        } else {
            Log.e("AudioAndHapticService", "No asset or URL found for MuezzinVoice: ${muezzin.name}")
            isAudioPlaying = false
            onPlaybackStateChanged(false)
        }
    }

    fun playQuranAudioStream(url: String, onPlaybackStateChanged: (Boolean) -> Unit) {
        stopAudio()
        try {
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(url)
                setOnPreparedListener {
                    start()
                    isAudioPlaying = true
                    onPlaybackStateChanged(true)
                }
                setOnCompletionListener {
                    isAudioPlaying = false
                    onPlaybackStateChanged(false)
                }
                setOnErrorListener { _, _, _ ->
                    isAudioPlaying = false
                    onPlaybackStateChanged(false)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            isAudioPlaying = false
            onPlaybackStateChanged(false)
        }
    }

    fun stopAudio() {
        isAudioPlaying = false
        toneJob?.cancel()
        toneJob = null
        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    mp.stop()
                }
                mp.release()
            }
            mediaPlayer = null
        } catch (_: Exception) {
            mediaPlayer = null
        }
    }

    fun pauseAudio() {
        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    mp.pause()
                    isAudioPlaying = false
                }
            }
        } catch (_: Exception) {}
    }

    fun resumeAudio(onPlaybackStateChanged: (Boolean) -> Unit) {
        try {
            mediaPlayer?.let { mp ->
                if (!mp.isPlaying) {
                    mp.start()
                    isAudioPlaying = true
                    onPlaybackStateChanged(true)
                }
            }
        } catch (_: Exception) {}
    }

    fun hasPreparedMedia(): Boolean = mediaPlayer != null

    fun isPlaying(): Boolean = isAudioPlaying

    private fun isAssetAvailable(path: String): Boolean {
        return try {
            context.assets.open(path).close()
            true
        } catch (_: Exception) {
            false
        }
    }
}
