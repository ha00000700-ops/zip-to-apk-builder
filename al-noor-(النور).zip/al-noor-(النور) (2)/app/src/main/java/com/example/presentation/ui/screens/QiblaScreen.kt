package com.example.presentation.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.calculator.QiblaCalculator
import com.example.presentation.ui.components.IslamicCard
import com.example.presentation.ui.components.IslamicMotifHeader
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright
import com.example.ui.theme.RoyalGoldLight
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun QiblaScreen(viewModel: AlNoorViewModel) {
    val deviceAzimuth by viewModel.deviceAzimuth.collectAsState()
    val qiblaBearing by viewModel.qiblaBearing.collectAsState()
    val distanceKm by viewModel.distanceToKaabaKm.collectAsState()
    val isAligned by viewModel.isQiblaAligned.collectAsState()
    val calibrationNeeded by viewModel.accuracyCalibrationNeeded.collectAsState()
    val location by viewModel.currentLocation.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: 3D Compass, 1: Geodesic Map Info

    val animatedRotation by animateFloatAsState(
        targetValue = -deviceAzimuth,
        animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
        label = "compass_rotation"
    )

    DisposableEffect(Unit) {
        viewModel.startListeningSensors()
        onDispose {
            viewModel.stopListeningSensors()
        }
    }

    val directionLabel = QiblaCalculator.getDirectionLabel(qiblaBearing)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 100.dp)
            .testTag("qibla_screen")
    ) {
        IslamicMotifHeader(
            titleAr = "بوصلة القبلة المشرفة",
            subtitleAr = "تحديد اتجاه الكعبة المشرفة بدقة فلكية وحساسات الاتجاه"
        )

        // Mode Switcher (Compass / Geodesic Map)
        TabRow(
            selectedTabIndex = activeTab,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp)),
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                text = { Text("البوصلة التفاعلية", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.NearMe, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                text = { Text("الخريطة الجيوديسية", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        if (calibrationNeeded) {
            CalibrationWarningBanner()
        }

        if (activeTab == 0) {
            // Compass View
            CompassInteractiveView(
                rotationAngle = animatedRotation,
                qiblaBearing = qiblaBearing.toFloat(),
                isAligned = isAligned,
                deviceHeading = deviceAzimuth,
                distanceKm = distanceKm,
                cityName = location.cityNameAr,
                directionLabel = directionLabel
            )
        } else {
            // Geodesic Map & Kaaba Coordinates View
            GeodesicMapView(
                userLat = location.latitude,
                userLng = location.longitude,
                cityName = location.cityNameAr,
                countryName = location.countryAr,
                qiblaBearing = qiblaBearing,
                distanceKm = distanceKm
            )
        }
    }
}

@Composable
fun CompassInteractiveView(
    rotationAngle: Float,
    qiblaBearing: Float,
    isAligned: Boolean,
    deviceHeading: Float,
    distanceKm: Double,
    cityName: String,
    directionLabel: Pair<String, String>
) {
    val haloColor by animateColorAsState(
        targetValue = if (isAligned) EmeraldAccent else RoyalGoldBright.copy(alpha = 0.3f),
        animationSpec = tween(400),
        label = "halo_color"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status Alignment Badge
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(if (isAligned) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant)
                .border(
                    1.5.dp,
                    if (isAligned) EmeraldAccent else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                    RoundedCornerShape(20.dp)
                )
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isAligned) Icons.Default.CheckCircle else Icons.Default.NearMe,
                    contentDescription = null,
                    tint = if (isAligned) Color.White else RoyalGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isAligned) "أنت الآن باتجاه القبلة المشرفة 🕋" else "وجّه الهاتف حتى يضيء المؤشر بالأخضر",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isAligned) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Big 3D Styled Compass Dial
        Box(
            modifier = Modifier
                .size(310.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                )
                .border(6.dp, haloColor, CircleShape)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            // Rotating Compass Face
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(rotationAngle)
            ) {
                val center = Offset(size.width / 2, size.height / 2)
                val radius = size.minDimension / 2 - 12.dp.toPx()

                // Draw outer degree ticks
                for (angle in 0 until 360 step 5) {
                    val isMajor = angle % 30 == 0
                    val isCardinal = angle % 90 == 0
                    val tickLen = if (isCardinal) 16.dp.toPx() else if (isMajor) 10.dp.toPx() else 5.dp.toPx()
                    val strokeW = if (isCardinal) 3.dp.toPx() else if (isMajor) 2.dp.toPx() else 1.dp.toPx()
                    val rad = Math.toRadians(angle.toDouble())

                    val startX = center.x + (radius - tickLen) * sin(rad).toFloat()
                    val startY = center.y - (radius - tickLen) * cos(rad).toFloat()
                    val endX = center.x + radius * sin(rad).toFloat()
                    val endY = center.y - radius * cos(rad).toFloat()

                    val tickColor = if (angle == 0) Color(0xFFEF4444) else if (isMajor) Color(0xFFD97706) else Color.Gray.copy(alpha = 0.4f)
                    drawLine(
                        color = tickColor,
                        start = Offset(startX, startY),
                        end = Offset(endX, endY),
                        strokeWidth = strokeW
                    )
                }

                // Draw Kaaba pointer icon at qiblaBearing
                rotate(degrees = qiblaBearing, pivot = center) {
                    val kaabaDist = radius - 30.dp.toPx()
                    val kaabaCenter = Offset(center.x, center.y - kaabaDist)

                    // Draw golden Kaaba target beam
                    drawLine(
                        color = Color(0xFFF59E0B),
                        start = center,
                        end = Offset(center.x, center.y - radius + 5.dp.toPx()),
                        strokeWidth = 3.dp.toPx()
                    )

                    // Kaaba symbol box
                    drawRect(
                        color = Color(0xFF1E293B),
                        topLeft = Offset(kaabaCenter.x - 12.dp.toPx(), kaabaCenter.y - 12.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(24.dp.toPx(), 24.dp.toPx())
                    )
                    // Gold door / top border on Kaaba
                    drawLine(
                        color = Color(0xFFFBBF24),
                        start = Offset(kaabaCenter.x - 10.dp.toPx(), kaabaCenter.y - 10.dp.toPx()),
                        end = Offset(kaabaCenter.x + 10.dp.toPx(), kaabaCenter.y - 10.dp.toPx()),
                        strokeWidth = 3.dp.toPx()
                    )
                }

                // Center pivot ring
                drawCircle(color = Color(0xFF064E3B), radius = 18.dp.toPx(), center = center)
                drawCircle(color = Color(0xFFF59E0B), radius = 6.dp.toPx(), center = center)
            }

            // Fixed Top Device Pointer (Static needle pointing straight ahead)
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(24.dp),
                contentAlignment = Alignment.TopCenter
            ) {
                Canvas(modifier = Modifier.size(20.dp)) {
                    val path = Path().apply {
                        moveTo(size.width / 2, 0f)
                        lineTo(0f, size.height)
                        lineTo(size.width, size.height)
                        close()
                    }
                    drawPath(path = path, color = if (isAligned) Color(0xFF10B981) else Color(0xFFEF4444))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Coordinates & Bearing Metrics Card
        IslamicCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "زاوية القبلة",
                        style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "${qiblaBearing.roundToInt()}°",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = RoyalGold
                        )
                    )
                    Text(
                        text = directionLabel.first,
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.primary)
                    )
                }

                Box(
                    modifier = Modifier
                        .height(40.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "المسافة إلى مكة",
                        style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "${distanceKm.roundToInt()} كم",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = cityName,
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                Box(
                    modifier = Modifier
                        .height(40.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "اتجاه الهاتف",
                        style = MaterialTheme.typography.labelMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "${deviceHeading.roundToInt()}°",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = if (isAligned) "متطابق ✓" else "انحراف",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isAligned) EmeraldAccent else Color(0xFFF59E0B)
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun GeodesicMapView(
    userLat: Double,
    userLng: Double,
    cityName: String,
    countryName: String,
    qiblaBearing: Double,
    distanceKm: Double
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        IslamicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Mosque,
                        contentDescription = null,
                        tint = RoyalGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "المسار الجيوديسي المباشر إلى مكة المكرمة",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Visual Representation of Great Circle Line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF0F172A), Color(0xFF064E3B))
                            )
                        )
                        .padding(16.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height

                        // Start point (User City)
                        val start = Offset(w * 0.15f, h * 0.7f)
                        // End point (Kaaba)
                        val end = Offset(w * 0.85f, h * 0.3f)

                        // Geodesic curved arc
                        val path = Path().apply {
                            moveTo(start.x, start.y)
                            quadraticBezierTo(w * 0.5f, h * 0.1f, end.x, end.y)
                        }

                        drawPath(
                            path = path,
                            color = Color(0xFFF59E0B),
                            style = Stroke(width = 3.dp.toPx())
                        )

                        // Draw Start Node
                        drawCircle(color = Color(0xFF10B981), radius = 8.dp.toPx(), center = start)
                        drawCircle(color = Color.White, radius = 4.dp.toPx(), center = start)

                        // Draw Kaaba Node
                        drawCircle(color = Color(0xFFFBBF24), radius = 10.dp.toPx(), center = end)
                        drawCircle(color = Color(0xFF1E293B), radius = 6.dp.toPx(), center = end)
                    }

                    // Labels on Canvas
                    Text(
                        text = "موقعك: $cityName",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold),
                        modifier = Modifier.align(Alignment.BottomStart)
                    )
                    Text(
                        text = "الكعبة المشرفة (مكة)",
                        style = MaterialTheme.typography.labelSmall.copy(color = RoyalGoldBright, fontWeight = FontWeight.Bold),
                        modifier = Modifier.align(Alignment.TopEnd)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Detail Rows
                DetailInfoRow(label = "إحداثيات موقعك الحالي", value = "${String.format("%.4f", userLat)}° N, ${String.format("%.4f", userLng)}° E")
                DetailInfoRow(label = "إحداثيات الكعبة المشرفة", value = "21.4225° N, 39.8262° E")
                DetailInfoRow(label = "المسافة الجيوديسية الدقيقة", value = "${distanceKm.roundToInt()} كيلومتر")
                DetailInfoRow(label = "زاوية الانحراف عن الشمال الحقيقي", value = "${String.format("%.1f", qiblaBearing)}°")
            }
        }
    }
}

@Composable
fun DetailInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )
    }
}

@Composable
fun CalibrationWarningBanner() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF78350F).copy(alpha = 0.15f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.ScreenRotation,
                contentDescription = "Calibrate",
                tint = RoyalGold,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "يُرجى معايرة البوصلة",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = RoyalGold
                    )
                )
                Text(
                    text = "حرّك الهاتف على شكل رقم 8 في الهواء لضبط دقة الحساسات المغناطيسية.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}
