package com.example.data.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AthanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action

        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            // Reschedule all daily prayer alarms upon system restart
            AthanSchedulerHelper.scheduleAllPrayerAlarms(context)
            return
        }

        val prayerName = intent?.getStringExtra(AthanForegroundService.EXTRA_PRAYER_NAME) ?: "الصلاة"
        val muezzin = intent?.getStringExtra(AthanForegroundService.EXTRA_MUEZZIN) ?: "YASSER_AL_DOSARI"

        val serviceIntent = Intent(context, AthanForegroundService::class.java).apply {
            this.action = AthanForegroundService.ACTION_START_ATHAN
            putExtra(AthanForegroundService.EXTRA_PRAYER_NAME, prayerName)
            putExtra(AthanForegroundService.EXTRA_MUEZZIN, muezzin)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (_: Exception) {}

        // Reschedule next prayer alarms
        AthanSchedulerHelper.scheduleAllPrayerAlarms(context)
    }
}
