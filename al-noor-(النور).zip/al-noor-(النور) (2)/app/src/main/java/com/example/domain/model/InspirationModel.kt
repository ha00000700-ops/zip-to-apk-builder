package com.example.domain.model

data class DailyInspiration(
    val id: String,
    val type: InspirationType,
    val textAr: String,
    val sourceAr: String,
    val explanationAr: String,
    val translationEn: String,
    val contextTheme: String
)

enum class InspirationType(val titleAr: String, val titleEn: String) {
    QURAN_AYAH("آية كريمة", "Noble Ayah"),
    HADITH_NABAWY("حديث نبوي شريف", "Prophetic Hadith"),
    DUA_MASNOON("دعاء مأثور", "Supplication")
}
