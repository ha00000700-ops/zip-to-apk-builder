package com.example.domain.model

enum class PrayerType(val arName: String, val enName: String, val iconRes: String) {
    FAJR("الفجر", "Fajr", "fajr"),
    SUNRISE("الشروق", "Sunrise", "sunrise"),
    DHUHR("الظهر", "Dhuhr", "dhuhr"),
    ASR("العصر", "Asr", "asr"),
    MAGHRIB("المغرب", "Maghrib", "maghrib"),
    ISHA("العشاء", "Isha", "isha"),
    DUHA("الضحى", "Duha", "duha"),
    LAST_THIRD("ثلث الليل الآخر", "Last Third", "night")
}

enum class CalculationMethod(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val fajrAngle: Double,
    val ishaAngle: Double,
    val ishaFixedMinutes: Int = 0
) {
    MWL("mwl", "رابطة العالم الإسلامي", "Muslim World League", 18.0, 17.0),
    UMM_AL_QURA("umm_al_qura", "أم القرى (مكة المكرمة)", "Umm Al-Qura (Makkah)", 18.5, 0.0, ishaFixedMinutes = 90),
    EGYPTIAN("egyptian", "الهيئة المصرية العامة للمساحة", "Egyptian General Authority", 19.5, 17.5),
    ISNA("isna", "الجمعية الإسلامية لأمريكا الشمالية", "ISNA (North America)", 15.0, 15.0),
    KARACHI("karachi", "جامعة العلوم الإسلامية بكراتشي", "Univ. of Islamic Sciences, Karachi", 18.0, 18.0),
    DUBAI("dubai", "دبي (الشؤون الإسلامية)", "Dubai Awqaf", 18.2, 18.2),
    KUWAIT("kuwait", "وزارة الأوقاف الكويتية", "Kuwait Ministry of Awqaf", 18.0, 17.5),
    QATAR("qatar", "قطر (وزارة الأوقاف)", "Qatar Awqaf", 18.0, 0.0, ishaFixedMinutes = 90),
    SINGAPORE("singapore", "مجلس أوغاما إسلام سينغافورا (MUIS)", "Singapore (MUIS)", 20.0, 18.0),
    TEHRAN("tehran", "معهد الجيوفيزياء بجامعة طهران", "Tehran University", 17.7, 14.0)
}

enum class JuristicMethod(
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val shadowFactor: Double
) {
    STANDARD(
        "الجمهور (شافعي، مالكي، حنبلي)",
        "Standard (Shafi'i, Maliki, Hanbali)",
        "يبدأ وقت العصر إذا صار ظل كل شيء مثله سوى ظل الزوال (العامل: 1)",
        1.0
    ),
    HANAFI(
        "المذهب الحنفي (ظل المثلين)",
        "Hanafi (Shadow factor 2)",
        "يبدأ وقت العصر إذا صار ظل الشيء مثليه سوى ظل الزوال (العامل: 2)",
        2.0
    )
}

enum class HighLatitudeRule(val titleAr: String, val titleEn: String) {
    MIDDLE_OF_NIGHT("منتصف الليل", "Middle of the Night"),
    SEVENTH_OF_NIGHT("سبع الليل", "One Seventh of the Night"),
    ANGLE_BASED("النسبي القائم على الزاوية", "Angle-Based Approximation")
}

data class LocationData(
    val cityNameAr: String,
    val cityNameEn: String,
    val countryAr: String,
    val countryEn: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneOffsetHours: Double,
    val isAutoGps: Boolean = false
)

data class PrayerSchedule(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val duha: String,
    val lastThird: String,
    val fajrMillis: Long,
    val sunriseMillis: Long,
    val dhuhrMillis: Long,
    val asrMillis: Long,
    val maghribMillis: Long,
    val ishaMillis: Long,
    val nextPrayer: PrayerType,
    val nextPrayerTimeMillis: Long,
    val remainingMillis: Long,
    val hijriDateFormatted: String,
    val gregorianDateFormatted: String
)

data class PrayerAdjustments(
    val fajr: Int = 0,
    val sunrise: Int = 0,
    val dhuhr: Int = 0,
    val asr: Int = 0,
    val maghrib: Int = 0,
    val isha: Int = 0
)

enum class AthanNotificationType(val titleAr: String, val titleEn: String) {
    FULL_ATHAN("أذان كامل", "Full Athan"),
    TAKBEER_ONLY("التكبير فقط", "Takbeer Only"),
    GENTLE_CHIME("تنبيه هادئ", "Gentle Tone"),
    SILENT("صامت", "Silent")
}

enum class MuezzinVoice(
    val titleAr: String,
    val titleEn: String,
    val style: String,
    val audioUrl: String = "",
    val assetPath: String = ""
) {
    YASSER_AL_DOSARI(
        titleAr = "أذان الشيخ ياسر الدوسري",
        titleEn = "Sheikh Yasser Al-Dosari",
        style = "تلاوة ونداء خاشع بالحرم المكي",
        audioUrl = "https://www.islamcan.com/audio/adhan/makkah.mp3",
        assetPath = "audio/athan_yasser.mp3"
    ),
    MAKKAH(
        titleAr = "أذان مكة المكرمة (الحرم المكي)",
        titleEn = "Makkah Al-Mukarramah",
        style = "صوت الحرم المكي الشريف المهيب",
        audioUrl = "https://www.islamcan.com/audio/adhan/makkah.mp3",
        assetPath = "audio/athan_makkah.mp3"
    ),
    MADINAH(
        titleAr = "أذان المدينة المنورة (المسجد النبوي)",
        titleEn = "Madinah Al-Munawwarah",
        style = "أذان المسجد النبوي الشريف العذب",
        audioUrl = "https://www.islamcan.com/audio/adhan/madinah.mp3",
        assetPath = "audio/athan_madinah.mp3"
    ),
    AL_AQSA(
        titleAr = "أذان المسجد الأقصى المبارك",
        titleEn = "Al-Aqsa Mosque",
        style = "نداء القدس الشريف التراثي",
        audioUrl = "https://www.islamcan.com/audio/adhan/aqsa.mp3",
        assetPath = "audio/athan_aqsa.mp3"
    ),
    EGYPT(
        titleAr = "أذان مصر (الشيخ محمد رفعت)",
        titleEn = "Egyptian (Sheikh Mohamed Refaat)",
        style = "مقام البياتي المصري الكلاسيكي الأصيل",
        audioUrl = "https://www.islamcan.com/audio/adhan/egypt.mp3",
        assetPath = "audio/athan_refaat.mp3"
    ),
    NORTH_AFRICA(
        titleAr = "أذان المغرب العربي والجامع الأعظم",
        titleEn = "North African / Maghreb",
        style = "الطبوع الأندلسية والمغاربية الخاشعة",
        audioUrl = "https://www.islamcan.com/audio/adhan/north_africa.mp3",
        assetPath = "audio/athan_maghreb.mp3"
    ),
    SOFT_HARMONY(
        titleAr = "نغمة تكبير وخشوع روحانية",
        titleEn = "Soft Spiritual Melody",
        style = "تنبيه هادئ ومنسجم بدون صوت بشري",
        audioUrl = "",
        assetPath = "audio/athan.mp3"
    )
}
