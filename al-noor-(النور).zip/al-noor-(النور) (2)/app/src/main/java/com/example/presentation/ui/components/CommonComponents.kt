package com.example.presentation.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.PrayerType
import com.example.ui.theme.AsrGradientEnd
import com.example.ui.theme.AsrGradientStart
import com.example.ui.theme.DhuhrGradientEnd
import com.example.ui.theme.DhuhrGradientStart
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.FajrGradientEnd
import com.example.ui.theme.FajrGradientStart
import com.example.ui.theme.IshaGradientEnd
import com.example.ui.theme.IshaGradientStart
import com.example.ui.theme.MaghribGradientEnd
import com.example.ui.theme.MaghribGradientStart
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright
import com.example.ui.theme.RoyalGoldLight

@Composable
fun IslamicMotifHeader(
    titleAr: String,
    subtitleAr: String,
    modifier: Modifier = Modifier,
    trailingAction: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(RoyalGold)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = titleAr,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
            if (subtitleAr.isNotBlank()) {
                Text(
                    text = subtitleAr,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(start = 16.dp, top = 2.dp)
                )
            }
        }
        trailingAction?.invoke()
    }
}

@Composable
fun IslamicArabesqueBadge(
    text: String,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    val bg = if (isHighlighted) {
        Brush.horizontalGradient(listOf(EmeraldPrimary, EmeraldPrimaryLight))
    } else {
        Brush.horizontalGradient(
            listOf(
                MaterialTheme.colorScheme.surfaceVariant,
                MaterialTheme.colorScheme.surfaceVariant
            )
        )
    }
    val contentColor = if (isHighlighted) Color.White else MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .border(
                1.dp,
                if (isHighlighted) RoyalGoldBright else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                RoundedCornerShape(20.dp)
            )
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = contentColor
            )
        )
    }
}

@Composable
fun PrayerTimeGradientBackground(prayerType: PrayerType): Brush {
    return when (prayerType) {
        PrayerType.FAJR -> Brush.verticalGradient(listOf(FajrGradientStart, FajrGradientEnd))
        PrayerType.SUNRISE, PrayerType.DUHA -> Brush.verticalGradient(listOf(Color(0xFF3B1D54), Color(0xFFC2410C)))
        PrayerType.DHUHR -> Brush.verticalGradient(listOf(DhuhrGradientStart, DhuhrGradientEnd))
        PrayerType.ASR -> Brush.verticalGradient(listOf(AsrGradientStart, AsrGradientEnd))
        PrayerType.MAGHRIB -> Brush.verticalGradient(listOf(MaghribGradientStart, MaghribGradientEnd))
        PrayerType.ISHA, PrayerType.LAST_THIRD -> Brush.verticalGradient(listOf(IshaGradientStart, IshaGradientEnd))
    }
}

@Composable
fun GlowingIslamicCrescent(
    modifier: Modifier = Modifier,
    color: Color = RoyalGoldBright
) {
    val infiniteTransition = rememberInfiniteTransition(label = "crescent_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .size(54.dp)
            .scale(pulseScale),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(46.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = size.minDimension / 2.2f

            // Outer Crescent Path
            val path = Path().apply {
                addArc(
                    oval = androidx.compose.ui.geometry.Rect(
                        center.x - radius, center.y - radius,
                        center.x + radius, center.y + radius
                    ),
                    startAngleDegrees = 45f,
                    sweepAngleDegrees = 270f
                )
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = 4.dp.toPx())
            )

            // Star
            drawCircle(
                color = color,
                radius = 3.5.dp.toPx(),
                center = Offset(center.x + radius * 0.45f, center.y - radius * 0.25f)
            )
        }
    }
}

@Composable
fun IslamicCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderColor: Color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        content()
    }
}
