package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Islamic Emerald Green Palette
val EmeraldPrimaryDark = Color(0xFF064E3B)
val EmeraldPrimary = Color(0xFF0D5C46)
val EmeraldPrimaryLight = Color(0xFF10B981)
val EmeraldAccent = Color(0xFF34D399)

// Warm Royal Gold Palette
val RoyalGold = Color(0xFFD97706)
val RoyalGoldLight = Color(0xFFF59E0B)
val RoyalGoldBright = Color(0xFFFBBF24)
val RoyalGoldContainer = Color(0xFFFEF3C7)
val RoyalGoldContainerDark = Color(0xFF451A03)

// Dark Theme Surfaces (Deep Slate / Starry Night)
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkSurfaceCard = Color(0xFF192231)
val DarkStroke = Color(0xFF2E3D52)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Theme Surfaces (Soft Off-White / Cream)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightStroke = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)

// Time of Day Gradients
val FajrGradientStart = Color(0xFF0F172A)
val FajrGradientEnd = Color(0xFF2E1065)

val DhuhrGradientStart = Color(0xFF0D5C46)
val DhuhrGradientEnd = Color(0xFF047857)

val AsrGradientStart = Color(0xFF1E3A8A)
val AsrGradientEnd = Color(0xFFB45309)

val MaghribGradientStart = Color(0xFF7C2D12)
val MaghribGradientEnd = Color(0xFF1E1B4B)

val IshaGradientStart = Color(0xFF0B0F19)
val IshaGradientEnd = Color(0xFF064E3B)
