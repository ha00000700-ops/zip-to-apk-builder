package com.example.domain.model

enum class AzkarCategory(val id: String, val titleAr: String, val titleEn: String, val icon: String) {
    MORNING("morning", "أذكار الصباح", "Morning Azkar", "sunny"),
    EVENING("evening", "أذكار المساء", "Evening Azkar", "nightlight"),
    AFTER_PRAYER("after_prayer", "أذكار بعد الصلاة", "After Prayer", "mosque"),
    SLEEP_WAKE("sleep_wake", "أذكار النوم والاستيقاظ", "Sleep & Waking", "bedtime"),
    HAJJ_UMRAH("hajj_umrah", "أدعية الحج والعمرة", "Hajj & Umrah", "flight"),
    FORTIFICATION("fortification", "جوامع الدعاء والتحصين", "Fortification & Comprehensive Duas", "shield")
}

data class ZikrItem(
    val id: String,
    val categoryId: String,
    val textAr: String,
    val countTarget: Int,
    val virtueAr: String,
    val referenceAr: String,
    val translationEn: String = ""
)

data class DhikrPreset(
    val id: String,
    val textAr: String,
    val transliteration: String,
    val defaultTarget: Int = 33,
    val virtue: String = ""
)

data class TasbihSessionRecord(
    val id: String,
    val dhikrText: String,
    val count: Int,
    val target: Int,
    val dateMillis: Long
)
