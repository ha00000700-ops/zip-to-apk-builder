package com.example.presentation.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.DailyPrayerRecord
import com.example.domain.model.KhatmahPlan
import com.example.domain.model.PrayerCompletionStatus
import com.example.domain.model.PrayerType
import com.example.domain.model.ZakatCalculationResult
import com.example.domain.model.ZakatInput
import com.example.presentation.ui.components.IslamicArabesqueBadge
import com.example.presentation.ui.components.IslamicCard
import com.example.presentation.ui.components.IslamicMotifHeader
import com.example.presentation.viewmodel.AlNoorViewModel
import com.example.ui.theme.EmeraldAccent
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldPrimaryDark
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.RoyalGold
import com.example.ui.theme.RoyalGoldBright
import com.example.ui.theme.RoyalGoldLight

@Composable
fun TrackerScreen(viewModel: AlNoorViewModel) {
    val prayerRecord by viewModel.currentPrayerRecord.collectAsState()
    val khatmahPlan by viewModel.khatmahPlan.collectAsState()
    val zakatInput by viewModel.zakatInput.collectAsState()
    val zakatResult by viewModel.zakatResult.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Prayer Log, 1: Khatmah Planner, 2: Zakat Calculator

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 100.dp)
            .testTag("tracker_screen")
    ) {
        IslamicMotifHeader(
            titleAr = "رفيق المسلم والمتابعة",
            subtitleAr = "سجل الصلوات، مخطط الختمة القرآنية، وحاسبة الزكاة الشرعية"
        )

        // Tab Selector
        TabRow(
            selectedTabIndex = selectedTab,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp)),
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("سجل الصلوات", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.EventNote, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("مخطط الختمة", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("حاسبة الزكاة", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        when (selectedTab) {
            0 -> PrayerLogSection(
                record = prayerRecord,
                onUpdateStatus = { pType, status -> viewModel.updatePrayerStatus(pType, status) }
            )
            1 -> KhatmahPlannerSection(
                plan = khatmahPlan,
                onIncrementPage = { viewModel.incrementKhatmahPage(it) },
                onUpdatePlan = { pages, days -> viewModel.updateKhatmahPlan(pages, days) }
            )
            2 -> ZakatCalculatorSection(
                input = zakatInput,
                result = zakatResult,
                onUpdateInput = { viewModel.updateZakatInput(it) }
            )
        }
    }
}

@Composable
fun PrayerLogSection(
    record: DailyPrayerRecord,
    onUpdateStatus: (PrayerType, PrayerCompletionStatus) -> Unit
) {
    val prayerList = listOf(
        Pair(PrayerType.FAJR, record.fajr),
        Pair(PrayerType.DHUHR, record.dhuhr),
        Pair(PrayerType.ASR, record.asr),
        Pair(PrayerType.MAGHRIB, record.maghrib),
        Pair(PrayerType.ISHA, record.isha)
    )

    val completedCount = prayerList.count { it.second == PrayerCompletionStatus.IN_MOSQUE || it.second == PrayerCompletionStatus.ON_TIME }
    val progress = completedCount / 5f

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Summary Performance Card
        item {
            IslamicCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "إنجاز الصلوات اليوم",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "أداء الفروض في وقتها أحب الأعمال إلى الله",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                        Text(
                            text = "$completedCount / 5",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoyalGold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (completedCount == 5) EmeraldPrimaryLight else RoyalGold,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }

        item {
            Text(
                text = "سجل الصلوات الخمس اليومية",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        items(prayerList.size) { index ->
            val (prayerType, currentStatus) = prayerList[index]
            SinglePrayerTrackerCard(
                prayerType = prayerType,
                status = currentStatus,
                onStatusChange = { newStatus -> onUpdateStatus(prayerType, newStatus) }
            )
        }
    }
}

@Composable
fun SinglePrayerTrackerCard(
    prayerType: PrayerType,
    status: PrayerCompletionStatus,
    onStatusChange: (PrayerCompletionStatus) -> Unit
) {
    IslamicCard {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "صلاة ${prayerType.arName}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = status.titleAr,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(status.colorHex)
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val statuses = listOf(
                    PrayerCompletionStatus.IN_MOSQUE,
                    PrayerCompletionStatus.ON_TIME,
                    PrayerCompletionStatus.LATE,
                    PrayerCompletionStatus.QADA
                )
                statuses.forEach { s ->
                    val isSelected = status == s
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(s.colorHex) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { onStatusChange(s) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = s.titleAr,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun KhatmahPlannerSection(
    plan: KhatmahPlan,
    onIncrementPage: (Int) -> Unit,
    onUpdatePlan: (Int, Int) -> Unit
) {
    var targetDaysInput by remember { mutableStateOf(plan.targetDays.toString()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Plan Overview Card
        item {
            IslamicCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "مخطط ختم القرآن الكريم",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ختمة مباركة - إجمالي المصحف 604 صفحات",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "تمت قراءة ${plan.pagesReadSoFar} صفحة",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                        Text(
                            text = "${(plan.progressPercent * 100).toInt()}%",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoyalGold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { plan.progressPercent },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = EmeraldPrimaryLight,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Targets breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "المعدل اليومي",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "${plan.dailyPagesRequired} صفحات/يوم",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                        Box(
                            modifier = Modifier
                                .height(30.dp)
                                .width(1.dp)
                                .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "بعد كل صلاة",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                            Text(
                                text = "${plan.pagesPerPrayer} صفحات",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RoyalGold
                                )
                            )
                        }
                    }
                }
            }
        }

        // Quick page increment buttons
        item {
            IslamicCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "تسجيل قراءة صفحات جديدة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onIncrementPage(1) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("+1 صفحة")
                        }
                        Button(
                            onClick = { onIncrementPage(4) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("+4 (حزب)")
                        }
                        Button(
                            onClick = { onIncrementPage(20) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalGold)
                        ) {
                            Text("+20 (جزء)")
                        }
                    }
                }
            }
        }

        // Plan Config Presets
        item {
            IslamicCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "خطة مدة الختمة المستهدفة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Pair(7, "أسبوع (7 أيام)"),
                            Pair(15, "15 يوماً"),
                            Pair(30, "شهر (رمضان 30 يوماً)"),
                            Pair(60, "شهران (60 يوماً)")
                        ).forEach { (days, label) ->
                            val isSelected = plan.targetDays == days
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) RoyalGold else MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onUpdatePlan(plan.pagesReadSoFar, days) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$days يوم",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ZakatCalculatorSection(
    input: ZakatInput,
    result: ZakatCalculationResult,
    onUpdateInput: (ZakatInput) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Result Summary Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (result.isNisabReached) EmeraldPrimaryDark else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "مقدار الزكاة الشرعية الواجبة (2.5%)",
                        style = MaterialTheme.typography.titleSmall.copy(color = RoyalGoldBright, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${String.format("%,.2f", result.zakatPayableAmount)} ${input.currencySymbol}",
                        style = MaterialTheme.typography.headlineLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "إجمالي المال الخاضع للزكاة: ${String.format("%,.2f", result.totalZakatableWealth)}",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                        )
                        Text(
                            text = if (result.isNisabReached) "بلغ النصاب الشرعي ✓" else "لم يبلغ النصاب",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (result.isNisabReached) EmeraldAccent else RoyalGoldBright
                            )
                        )
                    }
                    Text(
                        text = "نصاب الذهب (85 غرام عيار 24): ${String.format("%,.2f", result.nisabThresholdGold)} ${input.currencySymbol}",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.65f))
                    )
                }
            }
        }

        // Input Fields
        item {
            IslamicCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "المدخرات والأموال السائلة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )

                    ZakatNumberField(
                        label = "النقد في اليد والخزينة",
                        value = if (input.cashOnHand > 0) input.cashOnHand.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(cashOnHand = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    ZakatNumberField(
                        label = "الرصيد والحسابات البنكية",
                        value = if (input.bankBalance > 0) input.bankBalance.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(bankBalance = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الذهب والفضة وعروض التجارة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )

                    ZakatNumberField(
                        label = "وزن الذهب عيار 24 (بالغرام)",
                        value = if (input.goldGrams24k > 0) input.goldGrams24k.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(goldGrams24k = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    ZakatNumberField(
                        label = "وزن الفضة (بالغرام)",
                        value = if (input.silverGrams > 0) input.silverGrams.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(silverGrams = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    ZakatNumberField(
                        label = "قيمة بضائع التجارة والمخزون",
                        value = if (input.tradeGoodsValue > 0) input.tradeGoodsValue.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(tradeGoodsValue = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الديون والالتزامات",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )

                    ZakatNumberField(
                        label = "ديون لك ترجو استردادها",
                        value = if (input.debtsOwedToYouRecoverable > 0) input.debtsOwedToYouRecoverable.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(debtsOwedToYouRecoverable = it.toDoubleOrNull() ?: 0.0)) }
                    )

                    ZakatNumberField(
                        label = "ديون والتزامات واجبة الخصم عليك",
                        value = if (input.debtsYouOweDeductible > 0) input.debtsYouOweDeductible.toString() else "",
                        onValueChange = { onUpdateInput(input.copy(debtsYouOweDeductible = it.toDoubleOrNull() ?: 0.0)) }
                    )
                }
            }
        }
    }
}

@Composable
fun ZakatNumberField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        singleLine = true
    )
}
