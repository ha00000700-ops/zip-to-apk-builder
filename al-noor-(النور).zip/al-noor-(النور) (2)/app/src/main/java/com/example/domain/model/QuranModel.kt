package com.example.domain.model

import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.Font
import com.example.R

data class Surah(
    val number: Int,
    val nameAr: String,
    val nameEn: String,
    val englishTranslation: String,
    val numberOfAyahs: Int,
    val revelationType: String, // "Meccan" or "Medinan"
    val revelationTypeAr: String,
    val juz: Int,
    val pageNumber: Int
)

data class Ayah(
    val numberInSurah: Int,
    val numberInQuran: Int,
    val textAr: String,
    val translationEn: String,
    val tafsirMuyassarAr: String,
    val juz: Int,
    val page: Int,
    val surahNumber: Int
)

data class Qari(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val style: String,
    val serverUrlPrefix: String
)

data class Bookmark(
    val id: String,
    val surahNumber: Int,
    val surahNameAr: String,
    val ayahNumber: Int,
    val timestamp: Long,
    val note: String = ""
)

enum class QuranReadingMode {
    AYA_BY_AYA,
    PAGE_VIEW,
    TAFSIR_SPLIT
}

enum class QuranFont(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val descriptionAr: String,
    val fontFamily: FontFamily,
    val fontWeight: FontWeight = FontWeight.Normal,
    val sampleVerse: String = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"
) {
    HAFS_UTHMANIC(
        id = "hafs_uthmanic",
        nameAr = "مصحف المدينة (الرسم العثماني)",
        nameEn = "Madinah Hafs Uthmanic",
        descriptionAr = "رسم المصحف المعتمد بمجمع الملك فهد لطباعة المصحف الشريف",
        fontFamily = FontFamily(Font(R.font.scheherazade_bold)),
        fontWeight = FontWeight.Normal
    ),
    NASKH(
        id = "naskh",
        nameAr = "خط النسخ القرآني",
        nameEn = "Quranic Naskh",
        descriptionAr = "خط نسخي واضح، مريح للعين ومناسب للقراءة اليومية السريعة",
        fontFamily = FontFamily(Font(R.font.lateef_regular)),
        fontWeight = FontWeight.Normal
    ),
    AMIRI(
        id = "amiri",
        nameAr = "الخط الأميري الأصيل",
        nameEn = "Amiri Classical",
        descriptionAr = "خط عربي تراثي كلاسيكي مستوحى من مصحف بولاق الشهير",
        fontFamily = FontFamily(Font(R.font.amiri_regular)),
        fontWeight = FontWeight.Normal
    ),
    TRADITIONAL(
        id = "traditional",
        nameAr = "الخط الكلاسيكي الحديث",
        nameEn = "Modern Arabic Clean",
        descriptionAr = "خط مبسط حديث ذو وضوح عالٍ ومقروئية ممتازة",
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal
    )
}

