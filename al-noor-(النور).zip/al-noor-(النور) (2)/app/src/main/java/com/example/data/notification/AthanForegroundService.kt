package com.example.data.notification

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.domain.model.MuezzinVoice
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AthanForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "athan_prayer_channel_high"
        const val CHANNEL_NAME = "أذان ومواقيت الصلاة"
        const val NOTIFICATION_ID = 1001

        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_MUEZZIN = "extra_muezzin"
        const val ACTION_STOP_ATHAN = "com.example.ACTION_STOP_ATHAN"
        const val ACTION_START_ATHAN = "com.example.ACTION_START_ATHAN"
    }

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("WakelockTimeout")
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlNoor:AthanWakeLock")
            wakeLock?.acquire(5 * 60 * 1000L) // 5 minutes max
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_ATHAN) {
            stopAthan()
            stopSelf()
            return START_NOT_STICKY
        }

        val prayerName = intent?.getStringExtra(EXTRA_PRAYER_NAME) ?: "الصلاة"
        val muezzinName = intent?.getStringExtra(EXTRA_MUEZZIN) ?: MuezzinVoice.YASSER_AL_DOSARI.name

        startForeground(NOTIFICATION_ID, buildAthanNotification(prayerName, muezzinName))
        playAthanAudio(muezzinName)

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات الأذان والنداء للصلوات الخمس"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500, 200, 800)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                setBypassDnd(true)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildAthanNotification(prayerName: String, muezzinName: String): Notification {
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingAppIntent = PendingIntent.getActivity(
            this,
            0,
            appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AthanForegroundService::class.java).apply {
            action = ACTION_STOP_ATHAN
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val muezzinDisplay = try {
            MuezzinVoice.valueOf(muezzinName).titleAr
        } catch (_: Exception) {
            "الشيخ ياسر الدوسري"
        }

        val alertIntent = Intent(this, com.example.presentation.ui.activities.AthanAlertActivity::class.java).apply {
            putExtra(EXTRA_PRAYER_NAME, prayerName)
            putExtra(EXTRA_MUEZZIN, muezzinName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this,
            102,
            alertIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("حان الآن موعد أذان $prayerName")
            .setContentText("الله أكبر، الله أكبر • بصوت: $muezzinDisplay")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOngoing(true)
            .setContentIntent(pendingAppIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف الأذان", stopPendingIntent)
            .build()
    }

    private fun playAthanAudio(muezzinName: String) {
        stopAthan()
        val muezzin = try {
            MuezzinVoice.valueOf(muezzinName)
        } catch (_: Exception) {
            MuezzinVoice.YASSER_AL_DOSARI
        }

        val assetPath = when {
            muezzin.assetPath.isNotBlank() && isAssetExist(muezzin.assetPath) -> muezzin.assetPath
            isAssetExist("audio/athan.mp3") -> "audio/athan.mp3"
            else -> ""
        }

        try {
            if (assetPath.isBlank() && muezzin.audioUrl.isBlank()) {
                stopSelf()
                return
            }

            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                
                if (assetPath.isNotBlank()) {
                    val fd = assets.openFd(assetPath)
                    setDataSource(fd.fileDescriptor, fd.startOffset, fd.length)
                    fd.close()
                } else {
                    setDataSource(this@AthanForegroundService, Uri.parse(muezzin.audioUrl))
                }
                
                setOnPreparedListener {
                    if (mediaPlayer != null) {
                        start()
                    }
                }
                setOnCompletionListener {
                    stopSelf()
                }
                setOnErrorListener { _, _, _ ->
                    stopSelf()
                    true
                }
                prepareAsync()
            }

            // Auto-stop after 4 minutes
            serviceScope.launch {
                delay(240_000L)
                stopSelf()
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun playSynthesizedAthan(muezzin: MuezzinVoice) {
        // Simple synthesized fallback using a basic tone if media fails
        // In a real app, you might use a local asset
        // For now, we reuse the logic from AudioAndHapticService but simplified or just stop
        // To keep it simple and robust, we'll just stop if even synthesized fails
        try {
            // Ideally we'd call playAthanTone from AudioAndHapticService here, 
            // but that class isn't designed for background services directly (needs context/scope)
            // For now, just logging or stopping is safer than duplicating complex synth logic
            stopSelf()
        } catch (_: Exception) {}
    }

    private fun stopAthan() {
        try {
            mediaPlayer?.let { mp ->
                if (mp.isPlaying) {
                    mp.stop()
                }
                mp.release()
            }
            mediaPlayer = null
        } catch (_: Exception) {
            mediaPlayer = null
        }
    }

    override fun onDestroy() {
        stopAthan()
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun isAssetExist(path: String): Boolean {
        return try {
            assets.open(path).close()
            true
        } catch (_: Exception) {
            false
        }
    }
}
