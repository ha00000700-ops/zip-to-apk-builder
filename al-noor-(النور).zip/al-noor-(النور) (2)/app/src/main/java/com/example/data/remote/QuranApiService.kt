package com.example.data.remote

import com.example.domain.model.Ayah
import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class AlQuranCloudResponse(
    val code: Int,
    val status: String,
    val data: List<EditionData>?
)

@JsonClass(generateAdapter = true)
data class EditionData(
    val number: Int,
    val name: String,
    val englishName: String,
    val edition: EditionMeta,
    val ayahs: List<AyahItem>
)

@JsonClass(generateAdapter = true)
data class EditionMeta(
    val identifier: String,
    val language: String,
    val name: String,
    val type: String
)

@JsonClass(generateAdapter = true)
data class AyahItem(
    val number: Int,
    val text: String,
    val numberInSurah: Int,
    val juz: Int,
    val manzil: Int?,
    val page: Int,
    val ruku: Int?,
    val hizbQuarter: Int?,
    val sajda: Any?
)

interface QuranApi {
    @GET("v1/surah/{surahNumber}/editions/quran-uthmani,en.sahih,ar.muyassar")
    suspend fun getSurahWithEditions(
        @Path("surahNumber") surahNumber: Int
    ): AlQuranCloudResponse
}

class QuranApiService {

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.alquran.cloud/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    private val api = retrofit.create(QuranApi::class.java)

    suspend fun fetchSurahAyahs(surahNumber: Int): List<Ayah>? = withContext(Dispatchers.IO) {
        try {
            val response = api.getSurahWithEditions(surahNumber)
            if (response.code == 200 && response.data != null && response.data.isNotEmpty()) {
                val uthmaniEdition = response.data.find { it.edition.identifier == "quran-uthmani" } ?: response.data[0]
                val englishEdition = response.data.find { it.edition.identifier == "en.sahih" }
                val tafsirEdition = response.data.find { it.edition.identifier == "ar.muyassar" }

                val count = uthmaniEdition.ayahs.size
                return@withContext (0 until count).map { index ->
                    val uthmani = uthmaniEdition.ayahs[index]
                    val enText = englishEdition?.ayahs?.getOrNull(index)?.text
                        ?: "Ayah ${uthmani.numberInSurah} translation"
                    val tafsirText = tafsirEdition?.ayahs?.getOrNull(index)?.text
                        ?: "التفسير الميسر للآية ${uthmani.numberInSurah}"

                    val cleanedText = cleanAyahText(surahNumber, uthmani.numberInSurah, uthmani.text)

                    Ayah(
                        numberInSurah = uthmani.numberInSurah,
                        numberInQuran = uthmani.number,
                        textAr = cleanedText,
                        translationEn = enText,
                        tafsirMuyassarAr = tafsirText,
                        juz = uthmani.juz,
                        page = uthmani.page,
                        surahNumber = surahNumber
                    )
                }
            }
        } catch (_: Exception) {
            // Handle error / offline fallback
        }
        null
    }

    private fun cleanAyahText(surahNumber: Int, ayahNumberInSurah: Int, rawText: String): String {
        if (surahNumber == 1 || ayahNumberInSurah != 1) return rawText.trim()
        val basmalaVariants = listOf(
            "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
            "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
            "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
            "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
            "بسم الله الرحمن الرحيم"
        )
        var cleaned = rawText.trim()
        for (pattern in basmalaVariants) {
            if (cleaned.startsWith(pattern)) {
                cleaned = cleaned.removePrefix(pattern).trim()
                break
            }
        }
        return if (cleaned.isNotEmpty()) cleaned else rawText.trim()
    }
}
