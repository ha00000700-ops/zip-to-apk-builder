package com.zekrni.app.core.quran

data class Surah(
    val number: Int,
    val nameArabic: String,
    val nameEnglish: String,
    val revelationType: String, // "مكية" or "مدنية"
    val versesCount: Int,
    val pageNumber: Int
)

data class Ayah(
    val numberInSurah: Int,
    val surahNumber: Int,
    val surahName: String,
    val text: String,
    val juzNumber: Int = 1,
    val pageNumber: Int = 1
)

data class QuranBookmark(
    val surahNumber: Int,
    val ayahNumber: Int,
    val surahName: String,
    val ayahText: String
)

data class AyahOfTheDay(
    val text: String,
    val surahName: String,
    val surahNumber: Int,
    val ayahNumber: Int
)
