package com.zekrni.app.core.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.zekrni.app.R

object NotificationHelper {

    const val PRAYER_CHANNEL_ID = "zekrni_prayer_channel"
    const val REMINDERS_CHANNEL_ID = "zekrni_reminders_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val prayerChannel = NotificationChannel(
                PRAYER_CHANNEL_ID,
                "تنبيهات الأذان والصلوات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات دخول وقت الصلاة والأذان"
                enableVibration(true)
            }

            val remindersChannel = NotificationChannel(
                REMINDERS_CHANNEL_ID,
                "أذكار وتذكيرات اليوم",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "تذكيرات الورد اليومي وأذكار الصباح والمساء"
            }

            notificationManager.createNotificationChannel(prayerChannel)
            notificationManager.createNotificationChannel(remindersChannel)
        }
    }

    fun showPrayerNotification(context: Context, prayerName: String, prayerTime: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder = NotificationCompat.Builder(context, PRAYER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("حان الآن موعد أذان $prayerName")
            .setContentText("الله أكبر.. وقت صلاة $prayerName ($prayerTime)")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        notificationManager.notify(prayerName.hashCode(), builder.build())
    }
}
