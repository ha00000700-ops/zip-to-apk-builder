package com.zekrni.app.features.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zekrni.app.core.adhkar.AdhkarRepository
import com.zekrni.app.core.data.preferences.UserPreferencesManager
import com.zekrni.app.core.prayer.PrayerCalculator
import com.zekrni.app.core.quran.QuranRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = UserPreferencesManager.getInstance(application)

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        loadInitialData()
        startLivePrayerTimer()
    }

    private fun loadInitialData() {
        val now = Date()
        val gregorianFormat = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar"))
        val gregorianString = gregorianFormat.format(now)

        val city = prefs.getCityName()
        val country = prefs.getCountryName()
        val lat = prefs.getLatitude()
        val lon = prefs.getLongitude()
        val tz = prefs.getTimezone()
        val calcMethod = prefs.getCalculationMethod()
        val asrMethod = prefs.getAsrMethod()
        val is24H = prefs.is24HourFormat()

        val prayerRes = PrayerCalculator.calculateTimes(
            date = now,
            latitude = lat,
            longitude = lon,
            timezone = tz,
            method = calcMethod,
            asrMethod = asrMethod,
            is24Hour = is24H
        )

        val todayAyah = QuranRepository.getTodaysAyah()
        val todayDhikr = AdhkarRepository.getTodaysDhikr()

        _uiState.value = _uiState.value.copy(
            cityName = city,
            countryName = country,
            gregorianDate = gregorianString,
            hijriDate = prayerRes.hijriDateArabic,
            prayerTimes = prayerRes,
            countdownFormatted = PrayerCalculator.formatCountdown(prayerRes.nextPrayerRemainingSeconds),
            ayahOfTheDay = todayAyah,
            dhikrOfTheDay = todayDhikr,
            streakDays = prefs.getStreakDays(),
            totalTasbeehCount = prefs.getTotalTasbeehAllTime()
        )
    }

    private fun startLivePrayerTimer() {
        viewModelScope.launch {
            while (isActive) {
                delay(1000)
                val current = _uiState.value.prayerTimes ?: continue
                val newRemaining = (current.nextPrayerRemainingSeconds - 1).coerceAtLeast(0)
                if (newRemaining <= 0) {
                    // Recalculate for next prayer
                    loadInitialData()
                } else {
                    val updatedTimes = current.copy(nextPrayerRemainingSeconds = newRemaining)
                    _uiState.value = _uiState.value.copy(
                        prayerTimes = updatedTimes,
                        countdownFormatted = PrayerCalculator.formatCountdown(newRemaining)
                    )
                }
            }
        }
    }

    fun incrementDhikrCount() {
        val currentDhikr = _uiState.value.dhikrOfTheDay ?: return
        val current = _uiState.value.dhikrCurrentCount
        if (current < currentDhikr.repeatCount) {
            val next = current + 1
            val isDone = next >= currentDhikr.repeatCount
            _uiState.value = _uiState.value.copy(
                dhikrCurrentCount = next,
                isDhikrCompleted = isDone
            )
            if (isDone) {
                prefs.incrementCompletedAdhkar()
            }
        }
    }

    fun refreshLocationAndTimes() {
        loadInitialData()
    }
}
