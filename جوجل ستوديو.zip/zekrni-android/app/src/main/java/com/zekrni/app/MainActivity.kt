package com.zekrni.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.zekrni.app.core.designsystem.components.ZekrniNavigationBar
import com.zekrni.app.core.designsystem.theme.ZekrniTheme
import com.zekrni.app.core.navigation.Screen
import com.zekrni.app.core.navigation.ZekrniNavHost
import com.zekrni.app.features.home.HomeViewModel

class MainActivity : ComponentActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by mainViewModel.themeMode.collectAsState()

            ZekrniTheme(themeMode = themeMode) {
                val navController = rememberNavController()
                val homeViewModel: HomeViewModel = viewModel()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val topLevelRoutes = listOf(
                    Screen.Home.route,
                    Screen.Prayer.route,
                    Screen.Quran.route,
                    Screen.Adhkar.route,
                    Screen.More.route
                )
                val showBottomBar = currentRoute in topLevelRoutes

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) {
                            ZekrniNavigationBar(
                                currentRoute = currentRoute,
                                onNavigateToRoute = { route ->
                                    navController.navigate(route) {
                                        popUpTo(Screen.Home.route) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    ZekrniNavHost(
                        navController = navController,
                        homeViewModel = homeViewModel,
                        currentThemeMode = themeMode,
                        onThemeModeChange = { newMode ->
                            mainViewModel.setThemeMode(newMode)
                        },
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}
