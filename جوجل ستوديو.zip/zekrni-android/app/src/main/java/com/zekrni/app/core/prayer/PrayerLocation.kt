package com.zekrni.app.core.prayer

data class CityLocation(
    val cityNameArabic: String,
    val countryNameArabic: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: Double
)

object PrayerLocationRepository {
    val predefinedCities = listOf(
        // Saudi Arabia
        CityLocation("مكة المكرمة", "المملكة العربية السعودية", 21.4225, 39.8262, 3.0),
        CityLocation("المدينة المنورة", "المملكة العربية السعودية", 24.5247, 39.5692, 3.0),
        CityLocation("الرياض", "المملكة العربية السعودية", 24.7136, 46.6753, 3.0),
        CityLocation("جدة", "المملكة العربية السعودية", 21.5433, 39.1728, 3.0),
        CityLocation("الدمام", "المملكة العربية السعودية", 26.4207, 50.0888, 3.0),

        // Egypt
        CityLocation("القاهرة", "مصر", 30.0444, 31.2357, 3.0),
        CityLocation("الإسكندرية", "مصر", 31.2001, 29.9187, 3.0),
        CityLocation("الأقصر", "مصر", 25.6872, 32.6396, 3.0),

        // UAE
        CityLocation("دبي", "الإمارات العربية المتحدة", 25.2048, 55.2708, 4.0),
        CityLocation("أبوظبي", "الإمارات العربية المتحدة", 24.4539, 54.3773, 4.0),
        CityLocation("الشارقة", "الإمارات العربية المتحدة", 25.3463, 55.4209, 4.0),

        // Jordan, Palestine, Syria, Lebanon
        CityLocation("عَمّان", "الأردن", 31.9539, 35.9106, 3.0),
        CityLocation("القدس الشريف", "فلسطين", 31.7683, 35.2137, 3.0),
        CityLocation("دمشق", "سوريا", 33.5138, 36.2765, 3.0),
        CityLocation("بيروت", "لبنان", 33.8938, 35.5018, 3.0),

        // Iraq, Kuwait, Qatar, Bahrain, Oman, Yemen
        CityLocation("بغداد", "العراق", 33.3152, 44.3661, 3.0),
        CityLocation("الكويت", "الكويت", 29.3759, 47.9774, 3.0),
        CityLocation("الدوحة", "قطر", 25.2854, 51.5310, 3.0),
        CityLocation("المنامة", "البحرين", 26.2285, 50.5860, 3.0),
        CityLocation("مسقط", "عُمان", 23.5880, 58.3829, 4.0),
        CityLocation("صنعاء", "اليمن", 15.3694, 44.1910, 3.0),

        // North Africa
        CityLocation("الخرطوم", "السودان", 15.5007, 32.5599, 2.0),
        CityLocation("طرابلس", "ليبيا", 32.8872, 13.1913, 2.0),
        CityLocation("تونس", "تونس", 36.8065, 10.1815, 1.0),
        CityLocation("الجزائر", "الجزائر", 36.7538, 3.0588, 1.0),
        CityLocation("الرباط", "المغرب", 34.0209, -6.8416, 1.0),
        CityLocation("الدار البيضاء", "المغرب", 33.5731, -7.5898, 1.0),
        CityLocation("نواكشوط", "موريتانيا", 18.0735, -15.9582, 0.0),

        // Islamic World & International
        CityLocation("إسطنبول", "تركيا", 41.0082, 28.9784, 3.0),
        CityLocation("جاكرتا", "إندونيسيا", -6.2088, 106.8456, 7.0),
        CityLocation("كوالالمبور", "ماليزيا", 3.1390, 101.6869, 8.0),
        CityLocation("لندن", "المملكة المتحدة", 51.5074, -0.1278, 1.0),
        CityLocation("باريس", "فرنسا", 48.8566, 2.3522, 2.0),
        CityLocation("نيويورك", "الولايات المتحدة", 40.7128, -74.0060, -4.0)
    )

    fun findCity(query: String): List<CityLocation> {
        val q = query.trim().lowercase()
        return if (q.isEmpty()) predefinedCities else predefinedCities.filter {
            it.cityNameArabic.contains(q, ignoreCase = true) ||
                    it.countryNameArabic.contains(q, ignoreCase = true)
        }
    }
}
