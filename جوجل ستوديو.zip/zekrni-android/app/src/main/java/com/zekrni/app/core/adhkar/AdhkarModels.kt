package com.zekrni.app.core.adhkar

data class DhikrItem(
    val id: String,
    val text: String,
    val repeatCount: Int,
    val source: String,
    val hadithStatus: String = "صحيح",
    val reward: String? = null,
    var currentCount: Int = 0,
    var isCompleted: Boolean = false
)

data class DhikrCategoryData(
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val items: List<DhikrItem>
)

data class DhikrOfTheDay(
    val text: String,
    val repeatCount: Int,
    val source: String,
    val reward: String? = null
)
