package com.zekrni.app.core.prayer

import com.zekrni.app.core.data.preferences.AsrJuristicMethod
import com.zekrni.app.core.data.preferences.PrayerCalculationMethod
import java.util.Calendar
import java.util.Date
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

data class PrayerTimesResult(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val nextPrayerName: String,
    val nextPrayerTime: String,
    val nextPrayerRemainingSeconds: Long,
    val hijriDateArabic: String,
    val rawTimes: Map<String, Calendar>
)

object PrayerCalculator {

    private const val DEG_TO_RAD = Math.PI / 180.0
    private const val RAD_TO_DEG = 180.0 / Math.PI

    fun calculateTimes(
        date: Date,
        latitude: Double,
        longitude: Double,
        timezone: Double,
        method: PrayerCalculationMethod = PrayerCalculationMethod.UMM_AL_QURA,
        asrMethod: AsrJuristicMethod = AsrJuristicMethod.STANDARD,
        is24Hour: Boolean = false,
        offsets: Map<String, Int> = emptyMap()
    ): PrayerTimesResult {
        val calendar = Calendar.getInstance().apply { time = date }
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val julianDay = getJulianDay(year, month, day) - longitude / (15.0 * 24.0)

        // Sun parameters
        val d = julianDay - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * sin(g * DEG_TO_RAD) + 0.020 * sin(2 * g * DEG_TO_RAD))
        val e = 23.439 - 0.00000036 * d
        val ra = atan2(cos(e * DEG_TO_RAD) * sin(l * DEG_TO_RAD), cos(l * DEG_TO_RAD)) * RAD_TO_DEG
        val raCorrected = fixHour(ra / 15.0)

        val declination = asin(sin(e * DEG_TO_RAD) * sin(l * DEG_TO_RAD)) * RAD_TO_DEG
        val equationOfTime = (q / 15.0) - raCorrected

        // Mid-Day (Dhuhr)
        val dhuhrTime = fixHour(12.0 + timezone - (longitude / 15.0) - equationOfTime)

        // Sunrise and Sunset (approx 0.833 degrees for atmospheric refraction and solar radius)
        val sunriseAngle = 0.833
        val sunriseHourDiff = hourAngle(-sunriseAngle, latitude, declination)
        val sunriseTime = dhuhrTime - sunriseHourDiff
        val sunsetTime = dhuhrTime + sunriseHourDiff

        // Fajr Time
        val fajrHourDiff = hourAngle(-method.fajrAngle, latitude, declination)
        val fajrTime = dhuhrTime - fajrHourDiff

        // Asr Time
        val shadowFactor = asrMethod.shadowFactor.toDouble()
        val asrAngle = -atan(1.0 / (shadowFactor + tan(abs(latitude - declination) * DEG_TO_RAD))) * RAD_TO_DEG
        val asrHourDiff = hourAngle(asrAngle, latitude, declination)
        val asrTime = dhuhrTime + asrHourDiff

        // Maghrib Time (Same as Sunset or + fixed minutes)
        val maghribTime = sunsetTime

        // Isha Time
        val ishaTime = if (method.isIshaFixedMinutes) {
            maghribTime + (method.ishaMinutes / 60.0)
        } else {
            val ishaHourDiff = hourAngle(-method.ishaAngle, latitude, declination)
            dhuhrTime + ishaHourDiff
        }

        // Apply offsets in minutes
        val fajrCal = makeCalendar(calendar, fajrTime, offsets["fajr"] ?: 0)
        val sunriseCal = makeCalendar(calendar, sunriseTime, offsets["sunrise"] ?: 0)
        val dhuhrCal = makeCalendar(calendar, dhuhrTime, offsets["dhuhr"] ?: 0)
        val asrCal = makeCalendar(calendar, asrTime, offsets["asr"] ?: 0)
        val maghribCal = makeCalendar(calendar, maghribTime, offsets["maghrib"] ?: 0)
        val ishaCal = makeCalendar(calendar, ishaTime, offsets["isha"] ?: 0)

        val rawMap = mapOf(
            "الفجر" to fajrCal,
            "الشروق" to sunriseCal,
            "الظهر" to dhuhrCal,
            "العصر" to asrCal,
            "المغرب" to maghribCal,
            "العشاء" to ishaCal
        )

        // Determine Next Prayer and Remaining Seconds
        val nowMillis = System.currentTimeMillis()
        var nextName = "الفجر"
        var nextCal = fajrCal
        var minDiff = Long.MAX_VALUE

        val prayerSequence = listOf(
            "الفجر" to fajrCal,
            "الشروق" to sunriseCal,
            "الظهر" to dhuhrCal,
            "العصر" to asrCal,
            "المغرب" to maghribCal,
            "العشاء" to ishaCal
        )

        for ((name, cal) in prayerSequence) {
            val diff = cal.timeInMillis - nowMillis
            if (diff > 0 && diff < minDiff) {
                minDiff = diff
                nextName = name
                nextCal = cal
                break
            }
        }

        // If all prayers today have passed, next is tomorrow's Fajr
        if (minDiff == Long.MAX_VALUE) {
            nextName = "الفجر"
            nextCal = (fajrCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
            minDiff = nextCal.timeInMillis - nowMillis
        }

        val remainingSec = (minDiff / 1000).coerceAtLeast(0)

        return PrayerTimesResult(
            fajr = formatTime(fajrCal, is24Hour),
            sunrise = formatTime(sunriseCal, is24Hour),
            dhuhr = formatTime(dhuhrCal, is24Hour),
            asr = formatTime(asrCal, is24Hour),
            maghrib = formatTime(maghribCal, is24Hour),
            isha = formatTime(ishaCal, is24Hour),
            nextPrayerName = nextName,
            nextPrayerTime = formatTime(nextCal, is24Hour),
            nextPrayerRemainingSeconds = remainingSec,
            hijriDateArabic = calculateApproxHijriDate(calendar),
            rawTimes = rawMap
        )
    }

    private fun hourAngle(alpha: Double, latitude: Double, declination: Double): Double {
        val cosH = (sin(alpha * DEG_TO_RAD) - sin(latitude * DEG_TO_RAD) * sin(declination * DEG_TO_RAD)) /
                (cos(latitude * DEG_TO_RAD) * cos(declination * DEG_TO_RAD))
        val clampedCosH = cosH.coerceIn(-1.0, 1.0)
        return acos(clampedCosH) * RAD_TO_DEG / 15.0
    }

    private fun getJulianDay(year: Int, month: Int, day: Int): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    private fun fixAngle(a: Double): Double {
        var res = a - 360.0 * floor(a / 360.0)
        if (res < 0) res += 360.0
        return res
    }

    private fun fixHour(h: Double): Double {
        var res = h - 24.0 * floor(h / 24.0)
        if (res < 0) res += 24.0
        return res
    }

    private fun makeCalendar(base: Calendar, decimalHours: Double, offsetMinutes: Int): Calendar {
        val cal = base.clone() as Calendar
        val totalMinutes = (decimalHours * 60.0).toInt() + offsetMinutes
        val hours = (totalMinutes / 60) % 24
        val minutes = totalMinutes % 60
        cal.set(Calendar.HOUR_OF_DAY, if (hours < 0) hours + 24 else hours)
        cal.set(Calendar.MINUTE, if (minutes < 0) minutes + 60 else minutes)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal
    }

    fun formatTime(cal: Calendar, is24Hour: Boolean): String {
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val minute = cal.get(Calendar.MINUTE)
        val minStr = String.format("%02d", minute)

        return if (is24Hour) {
            String.format("%02d:%s", hour24, minStr)
        } else {
            val hour12 = if (hour24 == 0 || hour24 == 12) 12 else hour24 % 12
            val period = if (hour24 < 12) "ص" else "م"
            "$hour12:$minStr $period"
        }
    }

    fun formatCountdown(seconds: Long): String {
        val hrs = seconds / 3600
        val mins = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format("%02d:%02d:%02d", hrs, mins, secs)
    }

    fun calculateApproxHijriDate(cal: Calendar): String {
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)

        // Accurate Islamic arithmetic algorithm
        val jd = getJulianDay(y, m, d).toInt()
        val l = jd - 1948440 + 10632
        val n = ((l - 1) / 10631).toInt()
        val l2 = l - 10631 * n + 354
        val j = (((10985 - l2) / 5316).toInt()) * (((50 * l2) / 17719).toInt()) +
                ((l2 / 5670).toInt()) * (((43 * l2) / 15238).toInt())
        val l3 = l2 - (((30 - j) / 15).toInt()) * (((17719 * j) / 50).toInt()) -
                ((j / 16).toInt()) * (((15238 * j) / 43).toInt()) + 29
        val mHijri = ((24 * l3) / 709).toInt()
        val dHijri = l3 - ((709 * mHijri) / 24).toInt()
        val yHijri = 30 * n + j - 30

        val hijriMonths = listOf(
            "محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
            "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
        )
        val monthName = hijriMonths.getOrElse((mHijri - 1).coerceIn(0, 11)) { "رمضان" }
        return "$dHijri $monthName $yHijri هـ"
    }
}
