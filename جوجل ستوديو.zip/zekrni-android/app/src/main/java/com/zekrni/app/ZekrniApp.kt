package com.zekrni.app

import android.app.Application

class ZekrniApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
