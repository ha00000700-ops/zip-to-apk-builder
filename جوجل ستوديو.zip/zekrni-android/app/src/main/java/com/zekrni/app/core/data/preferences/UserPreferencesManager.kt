package com.zekrni.app.core.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppColorTheme(val titleArabic: String) {
    EMERALD("أخضر إسلامي"),
    NIGHT_BLUE("أزرق ليلي"),
    ROYAL_GOLD("ذهبي ملكي"),
    PURPLE("بنفسجي وقار"),
    ONYX_BLACK("أسود فاخر")
}

enum class FontSizeScale(val titleArabic: String, val scale: Float) {
    SMALL("صغير", 0.9f),
    MEDIUM("متوسط", 1.0f),
    LARGE("كبير", 1.2f)
}

enum class PrayerCalculationMethod(val titleArabic: String, val fajrAngle: Double, val ishaAngle: Double, val isIshaFixedMinutes: Boolean = false, val ishaMinutes: Int = 90) {
    UMM_AL_QURA("أم القرى (مكة المكرمة)", 18.5, 0.0, true, 90),
    MUSLIM_WORLD_LEAGUE("رابطة العالم الإسلامي", 18.0, 17.0),
    EGYPTIAN("الهيئة المصرية العامة للمساحة", 19.5, 17.5),
    ISNA("الجمعية الإسلامية لأمريكا الشمالية (ISNA)", 15.0, 15.0),
    KARACHI("جامعة العلوم الإسلامية بكراتشي", 18.0, 18.0),
    TEHRAN("معهد الجيوفيزياء بجامعة طهران", 17.7, 14.0),
    GULF("دول الخليج العربي", 19.5, 0.0, true, 90)
}

enum class AsrJuristicMethod(val titleArabic: String, val shadowFactor: Int) {
    STANDARD("جمهور الفقهاء (الشافعي، المالكي، الحنبلي)", 1),
    HANAFI("المذهب الحنفي", 2)
}

class UserPreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("zekrni_user_prefs", Context.MODE_PRIVATE)

    // Flow states for immediate reactive Compose updates
    private val _themeModeFlow = MutableStateFlow(getThemeMode())
    val themeModeFlow: StateFlow<String> = _themeModeFlow.asStateFlow()

    private val _colorThemeFlow = MutableStateFlow(getColorTheme())
    val colorThemeFlow: StateFlow<AppColorTheme> = _colorThemeFlow.asStateFlow()

    private val _fontSizeFlow = MutableStateFlow(getFontSizeScale())
    val fontSizeFlow: StateFlow<FontSizeScale> = _fontSizeFlow.asStateFlow()

    private val _cityNameFlow = MutableStateFlow(getCityName())
    val cityNameFlow: StateFlow<String> = _cityNameFlow.asStateFlow()

    private val _timeFormat24HFlow = MutableStateFlow(is24HourFormat())
    val timeFormat24HFlow: StateFlow<Boolean> = _timeFormat24HFlow.asStateFlow()

    // 1. Theme and appearance
    fun getThemeMode(): String = prefs.getString("theme_mode", "SYSTEM") ?: "SYSTEM"
    fun setThemeMode(mode: String) {
        prefs.edit().putString("theme_mode", mode).apply()
        _themeModeFlow.value = mode
    }

    fun getColorTheme(): AppColorTheme {
        val name = prefs.getString("color_theme", AppColorTheme.EMERALD.name) ?: AppColorTheme.EMERALD.name
        return try { AppColorTheme.valueOf(name) } catch (e: Exception) { AppColorTheme.EMERALD }
    }
    fun setColorTheme(theme: AppColorTheme) {
        prefs.edit().putString("color_theme", theme.name).apply()
        _colorThemeFlow.value = theme
    }

    fun getFontSizeScale(): FontSizeScale {
        val name = prefs.getString("font_size_scale", FontSizeScale.MEDIUM.name) ?: FontSizeScale.MEDIUM.name
        return try { FontSizeScale.valueOf(name) } catch (e: Exception) { FontSizeScale.MEDIUM }
    }
    fun setFontSizeScale(scale: FontSizeScale) {
        prefs.edit().putString("font_size_scale", scale.name).apply()
        _fontSizeFlow.value = scale
    }

    // 2. Location
    fun getCityName(): String = prefs.getString("city_name", "مكة المكرمة") ?: "مكة المكرمة"
    fun getCountryName(): String = prefs.getString("country_name", "المملكة العربية السعودية") ?: "المملكة العربية السعودية"
    fun getLatitude(): Double = prefs.getFloat("latitude", 21.4225f).toDouble()
    fun getLongitude(): Double = prefs.getFloat("longitude", 39.8262f).toDouble()
    fun getTimezone(): Double = prefs.getFloat("timezone", 3.0f).toDouble()
    fun isAutoLocation(): Boolean = prefs.getBoolean("auto_location", true)

    fun saveLocation(city: String, country: String, lat: Double, lon: Double, tz: Double, auto: Boolean = false) {
        prefs.edit()
            .putString("city_name", city)
            .putString("country_name", country)
            .putFloat("latitude", lat.toFloat())
            .putFloat("longitude", lon.toFloat())
            .putFloat("timezone", tz.toFloat())
            .putBoolean("auto_location", auto)
            .apply()
        _cityNameFlow.value = city
    }

    // 3. Prayer calculation settings
    fun getCalculationMethod(): PrayerCalculationMethod {
        val name = prefs.getString("calc_method", PrayerCalculationMethod.UMM_AL_QURA.name) ?: PrayerCalculationMethod.UMM_AL_QURA.name
        return try { PrayerCalculationMethod.valueOf(name) } catch (e: Exception) { PrayerCalculationMethod.UMM_AL_QURA }
    }
    fun setCalculationMethod(method: PrayerCalculationMethod) {
        prefs.edit().putString("calc_method", method.name).apply()
    }

    fun getAsrMethod(): AsrJuristicMethod {
        val name = prefs.getString("asr_method", AsrJuristicMethod.STANDARD.name) ?: AsrJuristicMethod.STANDARD.name
        return try { AsrJuristicMethod.valueOf(name) } catch (e: Exception) { AsrJuristicMethod.STANDARD }
    }
    fun setAsrMethod(method: AsrJuristicMethod) {
        prefs.edit().putString("asr_method", method.name).apply()
    }

    fun is24HourFormat(): Boolean = prefs.getBoolean("is_24h_format", false)
    fun set24HourFormat(enable: Boolean) {
        prefs.edit().putBoolean("is_24h_format", enable).apply()
        _timeFormat24HFlow.value = enable
    }

    // Prayer manual adjustments in minutes
    fun getPrayerOffset(prayerKey: String): Int = prefs.getInt("offset_$prayerKey", 0)
    fun setPrayerOffset(prayerKey: String, offsetMinutes: Int) {
        prefs.edit().putInt("offset_$prayerKey", offsetMinutes).apply()
    }

    // 4. Notifications & Azan
    fun isAzanSoundEnabled(): Boolean = prefs.getBoolean("azan_sound_enabled", true)
    fun setAzanSoundEnabled(enable: Boolean) {
        prefs.edit().putBoolean("azan_sound_enabled", enable).apply()
    }

    fun isPrayerNotificationEnabled(prayerKey: String): Boolean = prefs.getBoolean("notify_$prayerKey", true)
    fun setPrayerNotificationEnabled(prayerKey: String, enabled: Boolean) {
        prefs.edit().putBoolean("notify_$prayerKey", enabled).apply()
    }

    fun getPrePrayerReminderMinutes(): Int = prefs.getInt("pre_prayer_reminder_min", 10)
    fun setPrePrayerReminderMinutes(minutes: Int) {
        prefs.edit().putInt("pre_prayer_reminder_min", minutes).apply()
    }

    // 5. Quran Last Read & Bookmarks
    fun getLastReadSurah(): Int = prefs.getInt("last_read_surah", 1)
    fun getLastReadAyah(): Int = prefs.getInt("last_read_ayah", 1)
    fun saveLastRead(surahNumber: Int, ayahNumber: Int) {
        prefs.edit()
            .putInt("last_read_surah", surahNumber)
            .putInt("last_read_ayah", ayahNumber)
            .apply()
    }

    fun getBookmarks(): Set<String> = prefs.getStringSet("quran_bookmarks", emptySet()) ?: emptySet()
    fun toggleBookmark(surahNumber: Int, ayahNumber: Int): Boolean {
        val key = "$surahNumber:$ayahNumber"
        val current = getBookmarks().toMutableSet()
        val isAdded: Boolean
        if (current.contains(key)) {
            current.remove(key)
            isAdded = false
        } else {
            current.add(key)
            isAdded = true
        }
        prefs.edit().putStringSet("quran_bookmarks", current).apply()
        return isAdded
    }

    // 6. Tasbeeh Counts & Haptics
    fun getTasbeehCount(dhikrKey: String): Int = prefs.getInt("tasbeeh_count_$dhikrKey", 0)
    fun setTasbeehCount(dhikrKey: String, count: Int) {
        prefs.edit().putInt("tasbeeh_count_$dhikrKey", count).apply()
    }

    fun getTotalTasbeehAllTime(): Long = prefs.getLong("total_tasbeeh_all_time", 0L)
    fun incrementTotalTasbeeh(amount: Long = 1L) {
        val current = getTotalTasbeehAllTime()
        prefs.edit().putLong("total_tasbeeh_all_time", current + amount).apply()
    }

    fun isTasbeehVibrationEnabled(): Boolean = prefs.getBoolean("tasbeeh_vib", true)
    fun setTasbeehVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("tasbeeh_vib", enabled).apply()
    }

    fun isTasbeehSoundEnabled(): Boolean = prefs.getBoolean("tasbeeh_sound", false)
    fun setTasbeehSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("tasbeeh_sound", enabled).apply()
    }

    // 7. Statistics & Streaks
    fun getStreakDays(): Int = prefs.getInt("streak_days", 3)
    fun incrementStreak() {
        prefs.edit().putInt("streak_days", getStreakDays() + 1).apply()
    }

    fun getCompletedAdhkarCount(): Int = prefs.getInt("completed_adhkar_count", 0)
    fun incrementCompletedAdhkar() {
        prefs.edit().putInt("completed_adhkar_count", getCompletedAdhkarCount() + 1).apply()
    }

    fun getReadQuranPagesCount(): Int = prefs.getInt("read_quran_pages", 0)
    fun incrementReadQuranPages(pages: Int = 1) {
        prefs.edit().putInt("read_quran_pages", getReadQuranPagesCount() + pages).apply()
    }

    companion object {
        @Volatile
        private var instance: UserPreferencesManager? = null

        fun getInstance(context: Context): UserPreferencesManager {
            return instance ?: synchronized(this) {
                instance ?: UserPreferencesManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
