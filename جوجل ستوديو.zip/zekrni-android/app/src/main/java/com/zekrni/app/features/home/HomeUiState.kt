package com.zekrni.app.features.home

import com.zekrni.app.core.adhkar.DhikrOfTheDay
import com.zekrni.app.core.prayer.PrayerTimesResult
import com.zekrni.app.core.quran.AyahOfTheDay

data class HomeUiState(
    val greeting: String = "السلام عليكم",
    val slogan: String = "ذكرني بالله واجعل يومك عامرًا بالذكر",
    val cityName: String = "مكة المكرمة",
    val countryName: String = "المملكة العربية السعودية",
    val hijriDate: String = "",
    val gregorianDate: String = "",
    val prayerTimes: PrayerTimesResult? = null,
    val countdownFormatted: String = "00:00:00",
    val dailyWirdProgress: Float = 0.25f,
    val dailyWirdCompletedCount: Int = 1,
    val dailyWirdTotalCount: Int = 4,
    val ayahOfTheDay: AyahOfTheDay? = null,
    val dhikrOfTheDay: DhikrOfTheDay? = null,
    val dhikrCurrentCount: Int = 0,
    val isDhikrCompleted: Boolean = false,
    val streakDays: Int = 3,
    val totalTasbeehCount: Long = 0L
)
