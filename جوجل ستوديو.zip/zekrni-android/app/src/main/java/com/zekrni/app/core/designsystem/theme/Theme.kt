package com.zekrni.app.core.designsystem.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat
import com.zekrni.app.core.data.preferences.AppColorTheme

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

@Composable
fun ZekrniTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    colorTheme: AppColorTheme = AppColorTheme.EMERALD,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    val palette = getPaletteForTheme(colorTheme)

    val lightScheme = lightColorScheme(
        primary = palette.primary,
        onPrimary = SurfaceLight,
        primaryContainer = palette.containerLight,
        onPrimaryContainer = palette.primary,
        secondary = GoldAccent,
        onSecondary = TextPrimaryLight,
        tertiary = palette.primaryLight,
        onTertiary = SurfaceLight,
        background = BackgroundLight,
        onBackground = TextPrimaryLight,
        surface = SurfaceLight,
        onSurface = TextPrimaryLight,
        surfaceVariant = SurfaceVariantLight,
        onSurfaceVariant = TextSecondaryLight,
        outline = OutlineLight
    )

    val darkScheme = darkColorScheme(
        primary = palette.primaryLight,
        onPrimary = BackgroundDark,
        primaryContainer = palette.containerDark,
        onPrimaryContainer = palette.containerLight,
        secondary = GoldAccentLight,
        onSecondary = BackgroundDark,
        tertiary = GoldAccent,
        onTertiary = BackgroundDark,
        background = BackgroundDark,
        onBackground = TextPrimaryDark,
        surface = SurfaceDark,
        onSurface = TextPrimaryDark,
        surfaceVariant = SurfaceVariantDark,
        onSurfaceVariant = TextSecondaryDark,
        outline = OutlineDark
    )

    val colorScheme = if (darkTheme) darkScheme else lightScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = colorScheme.background.toArgb()
                window.navigationBarColor = colorScheme.background.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = !darkTheme
                insetsController.isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    // Force RTL direction for complete Arabic natural experience
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = Shapes,
            content = content
        )
    }
}
