package com.zekrni.app.core.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.zekrni.app.core.designsystem.theme.ThemeMode
import com.zekrni.app.features.adhkar.AdhkarScreen
import com.zekrni.app.features.home.HomeScreen
import com.zekrni.app.features.home.HomeViewModel
import com.zekrni.app.features.more.MoreScreen
import com.zekrni.app.features.more.ask.AskZekrniScreen
import com.zekrni.app.features.more.dailywird.DailyWirdScreen
import com.zekrni.app.features.more.qibla.QiblaScreen
import com.zekrni.app.features.more.settings.SettingsScreen
import com.zekrni.app.features.more.statistics.StatisticsScreen
import com.zekrni.app.features.more.tasbeeh.TasbeehScreen
import com.zekrni.app.features.prayer.PrayerScreen
import com.zekrni.app.features.quran.QuranScreen

@Composable
fun ZekrniNavHost(
    navController: NavHostController,
    homeViewModel: HomeViewModel,
    currentThemeMode: ThemeMode,
    onThemeModeChange: (ThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = modifier
    ) {
        // Main Bottom Bar Routes
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel = homeViewModel,
                onNavigateTo = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                }
            )
        }

        composable(Screen.Prayer.route) {
            PrayerScreen()
        }

        composable(Screen.Quran.route) {
            QuranScreen()
        }

        composable(Screen.Adhkar.route) {
            AdhkarScreen()
        }

        composable(Screen.More.route) {
            MoreScreen(
                onNavigateTo = { route ->
                    navController.navigate(route) {
                        launchSingleTop = true
                    }
                }
            )
        }

        // Sub-routes under More
        composable(Screen.Tasbeeh.route) {
            TasbeehScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.Qibla.route) {
            QiblaScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.DailyWird.route) {
            DailyWirdScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.AskZekrni.route) {
            AskZekrniScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.Statistics.route) {
            StatisticsScreen(onBackClick = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                currentThemeMode = currentThemeMode,
                onThemeModeChange = onThemeModeChange,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
