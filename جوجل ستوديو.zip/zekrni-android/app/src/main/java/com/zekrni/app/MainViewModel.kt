package com.zekrni.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zekrni.app.core.data.preferences.AppColorTheme
import com.zekrni.app.core.data.preferences.FontSizeScale
import com.zekrni.app.core.data.preferences.UserPreferencesManager
import com.zekrni.app.core.designsystem.theme.ThemeMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = UserPreferencesManager.getInstance(application)

    private val _themeMode = MutableStateFlow(
        try { ThemeMode.valueOf(prefs.getThemeMode()) } catch (e: Exception) { ThemeMode.SYSTEM }
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _colorTheme = MutableStateFlow(prefs.getColorTheme())
    val colorTheme: StateFlow<AppColorTheme> = _colorTheme.asStateFlow()

    private val _fontSizeScale = MutableStateFlow(prefs.getFontSizeScale())
    val fontSizeScale: StateFlow<FontSizeScale> = _fontSizeScale.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.setThemeMode(mode.name)
    }

    fun setColorTheme(theme: AppColorTheme) {
        _colorTheme.value = theme
        prefs.setColorTheme(theme)
    }

    fun setFontSizeScale(scale: FontSizeScale) {
        _fontSizeScale.value = scale
        prefs.setFontSizeScale(scale)
    }
}
