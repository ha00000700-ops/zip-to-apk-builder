package com.zekrni.app.core.designsystem.theme

import androidx.compose.ui.graphics.Color
import com.zekrni.app.core.data.preferences.AppColorTheme

// 1. Emerald Palette (أخضر إسلامي فاخر)
val EmeraldPrimaryDark = Color(0xFF0F3832)
val EmeraldPrimary = Color(0xFF164E48)
val EmeraldPrimaryLight = Color(0xFF246C64)
val EmeraldContainerLight = Color(0xFFE3F1EE)
val EmeraldContainerDark = Color(0xFF1A3D38)

// 2. Night Blue Palette (أزرق ليلي)
val NightBluePrimary = Color(0xFF1A365D)
val NightBluePrimaryLight = Color(0xFF2B6CB0)
val NightBlueContainerLight = Color(0xFFEBF8FF)
val NightBlueContainerDark = Color(0xFF152A4A)

// 3. Royal Gold Palette (ذهبي ملكي)
val RoyalGoldPrimary = Color(0xFF8C6D23)
val RoyalGoldPrimaryLight = Color(0xFFC5A059)
val RoyalGoldContainerLight = Color(0xFFFEFCF0)
val RoyalGoldContainerDark = Color(0xFF382F1D)

// 4. Purple Palette (بنفسجي وقار)
val PurplePrimary = Color(0xFF4A154B)
val PurplePrimaryLight = Color(0xFF702472)
val PurpleContainerLight = Color(0xFFF7ECF8)
val PurpleContainerDark = Color(0xFF2E0D2F)

// 5. Onyx Black Palette (أسود فاخر)
val OnyxPrimary = Color(0xFF1F2421)
val OnyxPrimaryLight = Color(0xFF3B443F)
val OnyxContainerLight = Color(0xFFF0F2F1)
val OnyxContainerDark = Color(0xFF141715)

// Accent Gold Palette
val GoldAccent = Color(0xFFC5A059)
val GoldAccentLight = Color(0xFFDFC07E)
val GoldAccentDark = Color(0xFF9E7B35)

// Surfaces Light & Dark
val BackgroundLight = Color(0xFFF7F9F7)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEEF2F0)
val OutlineLight = Color(0xFFD3DDD8)
val TextPrimaryLight = Color(0xFF152220)
val TextSecondaryLight = Color(0xFF5D6E6B)

val BackgroundDark = Color(0xFF0D1413)
val SurfaceDark = Color(0xFF141F1D)
val SurfaceVariantDark = Color(0xFF1C2C29)
val OutlineDark = Color(0xFF2E403C)
val TextPrimaryDark = Color(0xFFF0F5F3)
val TextSecondaryDark = Color(0xFFA5B6B3)

data class ColorPalettePair(
    val primary: Color,
    val primaryLight: Color,
    val containerLight: Color,
    val containerDark: Color
)

fun getPaletteForTheme(theme: AppColorTheme): ColorPalettePair {
    return when (theme) {
        AppColorTheme.EMERALD -> ColorPalettePair(EmeraldPrimary, EmeraldPrimaryLight, EmeraldContainerLight, EmeraldContainerDark)
        AppColorTheme.NIGHT_BLUE -> ColorPalettePair(NightBluePrimary, NightBluePrimaryLight, NightBlueContainerLight, NightBlueContainerDark)
        AppColorTheme.ROYAL_GOLD -> ColorPalettePair(RoyalGoldPrimary, RoyalGoldPrimaryLight, RoyalGoldContainerLight, RoyalGoldContainerDark)
        AppColorTheme.PURPLE -> ColorPalettePair(PurplePrimary, PurplePrimaryLight, PurpleContainerLight, PurpleContainerDark)
        AppColorTheme.ONYX_BLACK -> ColorPalettePair(OnyxPrimary, OnyxPrimaryLight, OnyxContainerLight, OnyxContainerDark)
    }
}
