import re

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

# Replace the Search Bar section
target_search = """        // Search Bar with Filter
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { query -> authViewModel.updateSearchQuery(query) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("customer_search_input"),
                    placeholder = { 
                        Text(
                            text = "ابحث عن خدمة (سباك، دهان...)", 
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextTertiaryLight
                        ) 
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = BluePrimary,
                        unfocusedBorderColor = OutlineLight.copy(alpha = 0.5f)
                    )
                )
                
                Spacer(modifier = Modifier.width(12.dp))
                
                IconButton(
                    onClick = { /* TODO: Filter Dialog */ },
                    modifier = Modifier
                        .size(56.dp)
                        .background(BluePrimary, RoundedCornerShape(20.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "تصفية",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }"""

replacement_search = """        // Search Bar with Filter
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { query -> authViewModel.updateSearchQuery(query) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("customer_search_input")
                            .onFocusChanged { isSearchFocused = it.isFocused },
                        placeholder = { 
                            Text(
                                text = "ابحث عن خدمة (سباك، دهان...)", 
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextTertiaryLight
                            ) 
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = BluePrimary,
                            unfocusedBorderColor = OutlineLight.copy(alpha = 0.5f)
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    IconButton(
                        onClick = { showFilterDialog = true },
                        modifier = Modifier
                            .size(56.dp)
                            .background(BluePrimary, RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "تصفية",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                
                // Search Suggestions
                if (isSearchFocused && searchQuery.isNotBlank() && filteredProfessions.isNotEmpty()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        shadowElevation = 4.dp
                    ) {
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            filteredProfessions.take(5).forEach { profession ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            authViewModel.updateSearchQuery(profession.nameAr)
                                        }
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = TextTertiaryLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = profession.nameAr,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = BlueDark
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }"""

if target_search in content:
    content = content.replace(target_search, replacement_search)
else:
    print("Could not find search target")

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
