with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'r') as f:
    content = f.read()

target = """                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {"""

replacement = """                                    }
                                }
                            }
                            } // Close Box
                            Spacer(modifier = Modifier.height(16.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'w') as f:
    f.write(content)
