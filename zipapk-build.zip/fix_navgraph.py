import re

with open('app/src/main/java/com/example/ui/navigation/NavGraph.kt', 'r') as f:
    content = f.read()

# Fix LaunchedEffect
old_launched = """                navController.navigate(target) {
                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                    popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    popUpTo(KhedmatiDestinations.LOGIN) { inclusive = true }
                }"""
new_launched = """                navController.navigate(target) {
                    popUpTo(0) { inclusive = true }
                }"""
content = content.replace(old_launched, new_launched)

# Fix splash provider
old_splash_p = """navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }"""
new_splash_p = """navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                                    popUpTo(0) { inclusive = true }
                                }"""
content = content.replace(old_splash_p, new_splash_p)

# Fix splash customer
old_splash_c = """navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }"""
new_splash_c = """navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                                    popUpTo(0) { inclusive = true }
                                }"""
content = content.replace(old_splash_c, new_splash_c)

# Fix splash provider register
old_splash_pr = """navController.navigate(KhedmatiDestinations.PROVIDER_REGISTER) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }"""
new_splash_pr = """navController.navigate(KhedmatiDestinations.PROVIDER_REGISTER) {
                                    popUpTo(0) { inclusive = true }
                                }"""
content = content.replace(old_splash_pr, new_splash_pr)

# Fix splash customer register
old_splash_cr = """navController.navigate(KhedmatiDestinations.CUSTOMER_REGISTER) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }"""
new_splash_cr = """navController.navigate(KhedmatiDestinations.CUSTOMER_REGISTER) {
                                    popUpTo(0) { inclusive = true }
                                }"""
content = content.replace(old_splash_cr, new_splash_cr)

# Fix splash role selection
old_splash_rs = """navController.navigate(KhedmatiDestinations.ROLE_SELECTION) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }"""
new_splash_rs = """navController.navigate(KhedmatiDestinations.ROLE_SELECTION) {
                                    popUpTo(0) { inclusive = true }
                                }"""
content = content.replace(old_splash_rs, new_splash_rs)

# Fix splash welcome
old_splash_w = """navController.navigate(KhedmatiDestinations.WELCOME) {
                                popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                            }"""
new_splash_w = """navController.navigate(KhedmatiDestinations.WELCOME) {
                                popUpTo(0) { inclusive = true }
                            }"""
content = content.replace(old_splash_w, new_splash_w)

# Fix login provider
old_login_p = """navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }"""
new_login_p = """navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                        popUpTo(0) { inclusive = true }
                    }"""
content = content.replace(old_login_p, new_login_p)

# Fix login customer
old_login_c = """navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }"""
new_login_c = """navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                        popUpTo(0) { inclusive = true }
                    }"""
content = content.replace(old_login_c, new_login_c)

# Fix register customer
old_reg_c = """navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }"""
content = content.replace(old_reg_c, new_login_c) # same replacement string

# Fix register provider
old_reg_p = """navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }"""
content = content.replace(old_reg_p, new_login_p) # same replacement string

with open('app/src/main/java/com/example/ui/navigation/NavGraph.kt', 'w') as f:
    f.write(content)

print("NavGraph fixed")
