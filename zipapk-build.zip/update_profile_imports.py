with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'r') as f:
    content = f.read()

imports = """
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ServiceProviderProfile
"""

new_imports = """
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ServiceProviderProfile
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
"""

content = content.replace(imports, new_imports)

with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'w') as f:
    f.write(content)
