import urllib.request
import urllib.error
import json

API_KEY = "AIzaSyDZjOA5F2tQLMH-ZOBTR_GHRhHVyQkVLd0"
SIGNIN_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={API_KEY}"
EDGE_URL = "https://mgpzpdbvfrbwousswphg.supabase.co/functions/v1/chargily-pay"

EMAIL = "testedge@khedmati.dz"
PASSWORD = "password123"

print("1. Authenticating with Firebase...")
payload = json.dumps({"email": EMAIL, "password": PASSWORD, "returnSecureToken": True}).encode("utf-8")
req = urllib.request.Request(SIGNIN_URL, data=payload, headers={"Content-Type": "application/json"}, method="POST")

id_token = None
try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode())
        id_token = data.get("idToken")
        print("   Signed in successfully.")
except Exception as e:
    print("   Sign in error:", e)
    exit(1)

print("\n2. Testing Pro Subscription Checkout via Supabase Edge Function...")
checkout_payload = json.dumps({
    "action": "pro_checkout",
    "planId": "PREMIUM",
    "paymentMethod": "EDAHABIA"
}).encode("utf-8")

headers = {
    "Authorization": f"Bearer {id_token}",
    "Content-Type": "application/json",
    "Accept": "application/json"
}

req_edge = urllib.request.Request(EDGE_URL, data=checkout_payload, headers=headers, method="POST")
try:
    with urllib.request.urlopen(req_edge) as resp_edge:
        res_data = json.loads(resp_edge.read().decode())
        print("   Edge Function Response Status:", resp_edge.status)
        print("   Edge Function Response Body:", json.dumps(res_data, indent=2))
except urllib.error.HTTPError as e:
    print("   HTTP Error:", e.code)
    print("   Response Body:", e.read().decode())
except Exception as e:
    print("   Exception:", e)
