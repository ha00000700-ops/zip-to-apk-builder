import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import * as jose from "https://deno.land/x/jose@v4.14.4/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const FIREBASE_PROJECT_ID = "khedmati-dz";

async function verifyFirebaseToken(token: string): Promise<string> {
  const response = await fetch("https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com");
  if (!response.ok) throw new Error("Failed to fetch Google public keys");
  const publicKeys = await response.json();

  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");
  const header = JSON.parse(atob(parts[0]));
  const kid = header.kid;
  if (!kid) throw new Error("No kid found in JWT header");

  const certificate = publicKeys[kid];
  if (!certificate) throw new Error("Invalid token kid or expired certificate");

  const publicKey = await jose.importX509(certificate, "RS256");
  
  const { payload } = await jose.jwtVerify(token, publicKey, {
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  });

  if (!payload.sub) throw new Error("No subject (UID) found in token");
  return payload.sub;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // 1. Authenticate Firebase Token
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ success: false, error: "Missing or invalid Authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const token = authHeader.replace("Bearer ", "");
    
    let uid: string;
    try {
      uid = await verifyFirebaseToken(token);
    } catch (e) {
      console.error("Token verification failed:", e.message);
      return new Response(JSON.stringify({ success: false, error: "Unauthorized: Invalid Firebase token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 2. Parse Multipart Form Data
    const formData = await req.formData();
    const file = formData.get("file") as File;
    const mediaType = formData.get("mediaType") as string;
    const conversationId = formData.get("conversationId") as string;

    if (!file || !mediaType || !conversationId) {
      return new Response(JSON.stringify({ success: false, error: "Missing required fields: file, mediaType, conversationId" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 3. Validate Constraints
    let maxSize = 0;
    let allowedPrefixes: string[] = [];

    if (mediaType === "image") {
      maxSize = 5 * 1024 * 1024; // 5 MB
      allowedPrefixes = ["image/jpeg", "image/png", "image/webp"];
    } else if (mediaType === "video") {
      maxSize = 30 * 1024 * 1024; // 30 MB
      allowedPrefixes = ["video/mp4"];
    } else if (mediaType === "audio") {
      maxSize = 10 * 1024 * 1024; // 10 MB
      // Support common Android audio outputs (AAC, M4A, MP4 audio)
      allowedPrefixes = ["audio/mp4", "audio/aac", "audio/m4a", "audio/x-m4a", "audio/mpeg"];
    } else {
      return new Response(JSON.stringify({ success: false, error: "Invalid mediaType. Allowed: image, video, audio" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (file.size > maxSize) {
      return new Response(JSON.stringify({ success: false, error: `File exceeds limit for ${mediaType} (${maxSize / 1024 / 1024} MB)` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const isValidType = allowedPrefixes.some(prefix => file.type.startsWith(prefix));
    if (!isValidType) {
      return new Response(JSON.stringify({ success: false, error: `Invalid file type for ${mediaType}. Uploaded: ${file.type}` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 4. Supabase Setup
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    
    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment variables");
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // 5. Construct secure path: chat_media/{verified_uid}/{conversation_id}/{timestamp}_{random}.{extension}
    const ext = file.name.split(".").pop() || "bin";
    const timestamp = Date.now();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const safePath = `chat_media/${uid}/${conversationId}/${timestamp}_${randomStr}.${ext}`;

    // 6. Upload file
    const { data, error: uploadError } = await supabase.storage
      .from("khedmati")
      .upload(safePath, file, {
        contentType: file.type,
        upsert: true,
      });

    if (uploadError) {
      throw uploadError;
    }

    // 7. Get Public URL
    const publicUrl = `${supabaseUrl}/storage/v1/object/public/khedmati/${safePath}`;

    return new Response(JSON.stringify({
      success: true,
      url: publicUrl,
      path: safePath,
      mediaType: mediaType
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Edge function error:", error);
    return new Response(JSON.stringify({ success: false, error: "Internal Server Error", details: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
