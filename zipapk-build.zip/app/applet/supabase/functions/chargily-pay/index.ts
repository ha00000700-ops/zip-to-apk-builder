import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import * as jose from "https://deno.land/x/jose@v4.14.4/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, signature, x-chargily-signature",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const FIREBASE_PROJECT_ID = "khedmati-dz";

function getChargilySecretKey(): string {
  return (Deno.env.get("CHARGILY_SECRET_KEY") || "").trim();
}

function getChargilyBaseUrl(): string {
  const mode = (Deno.env.get("CHARGILY_MODE") || "test").trim().toLowerCase();
  return mode === "production"
    ? "https://pay.chargily.net/api/v2"
    : "https://pay.chargily.net/test/api/v2";
}

async function verifyFirebaseToken(token: string): Promise<string> {
  const response = await fetch(
    "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com"
  );
  if (!response.ok) throw new Error("Failed to fetch Google public keys");
  const publicKeys = await response.json();

  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");
  const header = JSON.parse(atob(parts[0]));
  const kid = header.kid;
  if (!kid) throw new Error("No kid found in JWT header");

  const certificate = publicKeys[kid];
  if (!certificate) throw new Error("Invalid token kid or expired certificate");

  const publicKey = await jose.importX509(certificate, "RS256");

  const { payload } = await jose.jwtVerify(token, publicKey, {
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  });

  if (!payload.sub) throw new Error("No subject (UID) found in token");
  return payload.sub;
}

function resolveSubscriptionPrice(planId: string): number {
  const upper = String(planId || "").trim().toUpperCase();
  if (upper === "BASIC") return 500;
  if (upper === "STANDARD") return 1000;
  if (upper === "PREMIUM" || upper === "PRO") return 1500;
  return 1500;
}

function resolveAdBoostPrice(packageId: string): number {
  const upper = String(packageId || "").trim().toUpperCase();
  if (upper === "BOOST_BASIC" || upper === "BASIC") return 100;
  if (upper === "BOOST_STANDARD" || upper === "STANDARD") return 250;
  if (upper === "BOOST_PREMIUM" || upper === "PREMIUM") return 500;
  return 100;
}

async function verifyChargilySignature(
  rawBody: string,
  signatureHeader: string | null,
  secretKey: string
): Promise<boolean> {
  if (!signatureHeader || !secretKey) return false;
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secretKey),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign", "verify"]
    );
    const signatureBytes = await crypto.subtle.sign(
      "HMAC",
      key,
      encoder.encode(rawBody)
    );
    const computedHex = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    return computedHex.toLowerCase() === signatureHeader.trim().toLowerCase();
  } catch (e) {
    console.error("Signature verification exception:", e);
    return false;
  }
}

function parseFirestoreValue(val: any): any {
  if (!val) return null;
  if (val.stringValue !== undefined) return val.stringValue;
  if (val.integerValue !== undefined) return Number(val.integerValue);
  if (val.doubleValue !== undefined) return Number(val.doubleValue);
  if (val.booleanValue !== undefined) return val.booleanValue;
  if (val.mapValue !== undefined) {
    const mapRes: Record<string, any> = {};
    const fields = val.mapValue.fields || {};
    for (const [k, v] of Object.entries(fields)) {
      mapRes[k] = parseFirestoreValue(v);
    }
    return mapRes;
  }
  return null;
}

async function getFirestoreAuthHeader(): Promise<Record<string, string>> {
  const saRaw = Deno.env.get("FIREBASE_SERVICE_ACCOUNT") || Deno.env.get("FIREBASE_SERVICE_ACCOUNT_KEY") || Deno.env.get("GCP_SERVICE_ACCOUNT");
  if (!saRaw) return {};
  try {
    const sa = JSON.parse(saRaw);
    const privateKeyPem = sa.private_key;
    const clientEmail = sa.client_email;
    if (!privateKeyPem || !clientEmail) return {};
    const privateKey = await jose.importPKCS8(privateKeyPem, "RS256");
    const jwt = await new jose.SignJWT({
      iss: clientEmail,
      sub: clientEmail,
      aud: "https://oauth2.googleapis.com/token",
      scope: "https://www.googleapis.com/auth/datastore",
    })
      .setProtectedHeader({ alg: "RS256" })
      .setIssuedAt()
      .setExpirationTime("1h")
      .sign(privateKey);

    const resp = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: jwt,
      }),
    });
    if (!resp.ok) return {};
    const data = await resp.json();
    if (data.access_token) {
      return { Authorization: `Bearer ${data.access_token}` };
    }
  } catch (e) {
    console.error("Failed to generate Firestore service account token:", e);
  }
  return {};
}

async function getFirestoreDocument(collection: string, docId: string): Promise<Record<string, any> | null> {
  const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${collection}/${docId}`;
  const authHeaders = await getFirestoreAuthHeader();
  const resp = await fetch(url, { headers: authHeaders });
  if (!resp.ok) return null;
  const doc = await resp.json();
  if (!doc.fields) return null;
  const result: Record<string, any> = {};
  for (const [k, v] of Object.entries(doc.fields)) {
    result[k] = parseFirestoreValue(v);
  }
  return result;
}

async function updateFirestoreFields(
  collection: string,
  docId: string,
  fieldsPayload: Record<string, any>
): Promise<boolean> {
  const fieldNames = Object.keys(fieldsPayload);
  const fieldPaths = fieldNames.map((f) => `updateMask.fieldPaths=${encodeURIComponent(f)}`).join("&");
  const url = `https://firestore.googleapis.com/v1/projects/${FIREBASE_PROJECT_ID}/databases/(default)/documents/${collection}/${docId}?${fieldPaths}`;
  const authHeaders = await getFirestoreAuthHeader();

  const resp = await fetch(url, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders,
    },
    body: JSON.stringify({ fields: fieldsPayload }),
  });
  return resp.ok;
}

async function getPromotedAdFromFirestore(adId: string): Promise<Record<string, any> | null> {
  return await getFirestoreDocument("promotedAds", adId);
}

async function updatePromotedAdInFirestore(
  adId: string,
  updates: Record<string, { type: "string" | "integer"; value: any }>
): Promise<boolean> {
  const fieldsPayload: Record<string, any> = {};
  for (const [k, v] of Object.entries(updates)) {
    if (v.type === "integer") {
      fieldsPayload[k] = { integerValue: String(v.value) };
    } else {
      fieldsPayload[k] = { stringValue: String(v.value) };
    }
  }
  return await updateFirestoreFields("promotedAds", adId, fieldsPayload);
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;

  const secretKey = getChargilySecretKey();
  if (!secretKey) {
    console.error("CHARGILY_SECRET_KEY is missing from Supabase Edge Function Secrets.");
    return new Response(
      JSON.stringify({ success: false, error: "Chargily Secret Key is not configured on server." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const apiBaseUrl = getChargilyBaseUrl();

  // ---------------------------------------------------------------------------
  // WEBHOOK HANDLER
  // ---------------------------------------------------------------------------
  if (pathname.endsWith("/webhook") || pathname.endsWith("/chargilyWebhook")) {
    try {
      const rawBody = await req.text();
      const signature = req.headers.get("signature") || req.headers.get("x-chargily-signature");

      const isValid = await verifyChargilySignature(rawBody, signature, secretKey);
      if (!isValid) {
        console.warn("Invalid webhook signature received.");
        return new Response(JSON.stringify({ error: "Invalid signature" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const event = JSON.parse(rawBody);
      const eventType = String(event.type || "").toLowerCase();
      const checkoutData = event.data || {};
      const status = String(checkoutData.status || (eventType === "checkout.paid" ? "paid" : "failed")).toLowerCase();
      const metadata = checkoutData.metadata || {};

      // Handle PROMOTED_AD payment activation
      if (metadata.type === "PROMOTED_AD" || metadata.adId) {
        const adId = metadata.adId;
        if (adId) {
          const existingAd = await getPromotedAdFromFirestore(adId);
          const currentStatus = String(existingAd?.status || "").toUpperCase();

          // Idempotency: skip if already active to avoid duplicate extensions
          if (currentStatus === "ACTIVE") {
            console.log(`Promoted ad ${adId} is already ACTIVE. Skipping duplicate webhook processing.`);
            return new Response(
              JSON.stringify({
                success: true,
                message: "Webhook processed (Already Active / Idempotency)",
                event: event.type,
                adId: adId,
                status: "ACTIVE",
              }),
              { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          if (eventType === "checkout.paid" || status === "paid") {
            // Read durationDays strictly from existing Firestore document (fallback to package resolution if missing)
            let durationDays = Number(existingAd?.durationDays || 0);
            if (durationDays <= 0) {
              const packageId = metadata.packageId || existingAd?.packageId || "BOOST_BASIC";
              const upper = String(packageId).toUpperCase();
              if (upper.includes("PREMIUM")) durationDays = 30;
              else if (upper.includes("STANDARD")) durationDays = 7;
              else durationDays = 3;
            }

            const now = Date.now();
            const endDate = now + (durationDays * 86400000);

            await updatePromotedAdInFirestore(adId, {
              status: { type: "string", value: "ACTIVE" },
              paymentStatus: { type: "string", value: "SUCCESSFUL" },
              startDate: { type: "integer", value: now },
              endDate: { type: "integer", value: endDate },
              updatedAt: { type: "integer", value: now },
            });

            console.log(`Promoted ad ${adId} successfully activated for ${durationDays} days.`);
          } else if (eventType === "checkout.failed" || status === "failed") {
            await updatePromotedAdInFirestore(adId, {
              status: { type: "string", value: "PENDING_PAYMENT" },
              paymentStatus: { type: "string", value: "FAILED" },
              updatedAt: { type: "integer", value: Date.now() },
            });
          } else if (eventType === "checkout.canceled" || status === "canceled") {
            await updatePromotedAdInFirestore(adId, {
              status: { type: "string", value: "CANCELLED" },
              paymentStatus: { type: "string", value: "CANCELLED" },
              updatedAt: { type: "integer", value: Date.now() },
            });
          }
        }
      } else if (
        metadata.type === "SUBSCRIPTION" ||
        metadata.type === "PRO_SUBSCRIPTION" ||
        (metadata.userId && !metadata.adId)
      ) {
        // Handle SUBSCRIPTION payment activation
        const userId = metadata.userId || metadata.user_id;
        if (userId) {
          const planId = metadata.planId || metadata.plan || "PREMIUM";
          const expectedPrice = resolveSubscriptionPrice(planId);

          const userDoc = await getFirestoreDocument("users", userId);
          const existingSub = userDoc?.subscription || {};
          const currentSubStatus = String(existingSub.status || "FREE").toUpperCase();
          const existingPaymentId = existingSub.paymentId || existingSub.checkoutId;

          // Idempotency check: skip if already active for this checkout
          if (currentSubStatus === "ACTIVE" && existingPaymentId === checkoutData.id) {
            console.log(`Subscription for user ${userId} is already ACTIVE for checkout ${checkoutData.id}. Skipping duplicate webhook processing.`);
            return new Response(
              JSON.stringify({
                success: true,
                message: "Webhook processed (Already Active / Idempotency)",
                event: event.type,
                userId: userId,
                status: "ACTIVE",
              }),
              { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }

          if (eventType === "checkout.paid" || status === "paid") {
            const now = Date.now();
            const durationMs = 30 * 86400000; // 30 Days
            const expirationDate = now + durationMs;
            const existingCreatedAt = Number(existingSub.createdAt || now);
            const checkoutId = String(checkoutData.id || `chk_${now}`);

            const subscriptionMapPayload = {
              mapValue: {
                fields: {
                  plan: { stringValue: planId },
                  status: { stringValue: "ACTIVE" },
                  startDate: { integerValue: String(now) },
                  endDate: { integerValue: String(expirationDate) },
                  paymentId: { stringValue: checkoutId },
                  checkoutId: { stringValue: checkoutId },
                  amount: { integerValue: String(expectedPrice) },
                  currency: { stringValue: "DZD" },
                  createdAt: { integerValue: String(existingCreatedAt) },
                  updatedAt: { integerValue: String(now) },
                },
              },
            };

            // 1. Update user profile subscription field in 'users/{userId}'
            await updateFirestoreFields("users", userId, {
              subscription: subscriptionMapPayload,
              updatedAt: { integerValue: String(now) },
            });

            // 2. Update secure root collection 'subscriptions/{userId}'
            await updateFirestoreFields("subscriptions", userId, {
              userId: { stringValue: userId },
              plan: { stringValue: planId },
              status: { stringValue: "ACTIVE" },
              startDate: { integerValue: String(now) },
              endDate: { integerValue: String(expirationDate) },
              paymentId: { stringValue: checkoutId },
              checkoutId: { stringValue: checkoutId },
              amount: { integerValue: String(expectedPrice) },
              currency: { stringValue: "DZD" },
              createdAt: { integerValue: String(existingCreatedAt) },
              updatedAt: { integerValue: String(now) },
            });

            // 3. Sync to 'serviceProviders/{userId}' if provider document exists
            const spDoc = await getFirestoreDocument("serviceProviders", userId);
            if (spDoc) {
              await updateFirestoreFields("serviceProviders", userId, {
                subscriptionPlan: { stringValue: planId },
                subscriptionStatus: { stringValue: "ACTIVE" },
                updatedAt: { integerValue: String(now) },
              });
            }

            console.log(`Subscription (${planId}) activated successfully for user ${userId}.`);
          } else if (eventType === "checkout.failed" || status === "failed") {
            const failedSubMapPayload = {
              mapValue: {
                fields: {
                  plan: { stringValue: planId },
                  status: { stringValue: "PAYMENT_FAILED" },
                  updatedAt: { integerValue: String(Date.now()) },
                },
              },
            };
            await updateFirestoreFields("users", userId, {
              subscription: failedSubMapPayload,
              updatedAt: { integerValue: String(Date.now()) },
            });
            await updateFirestoreFields("subscriptions", userId, {
              status: { stringValue: "PAYMENT_FAILED" },
              updatedAt: { integerValue: String(Date.now()) },
            });
            const spDoc = await getFirestoreDocument("serviceProviders", userId);
            if (spDoc) {
              await updateFirestoreFields("serviceProviders", userId, {
                subscriptionStatus: { stringValue: "PAYMENT_FAILED" },
                updatedAt: { integerValue: String(Date.now()) },
              });
            }
          } else if (eventType === "checkout.canceled" || status === "canceled") {
            const cancelledSubMapPayload = {
              mapValue: {
                fields: {
                  plan: { stringValue: planId },
                  status: { stringValue: "CANCELLED" },
                  updatedAt: { integerValue: String(Date.now()) },
                },
              },
            };
            await updateFirestoreFields("users", userId, {
              subscription: cancelledSubMapPayload,
              updatedAt: { integerValue: String(Date.now()) },
            });
            await updateFirestoreFields("subscriptions", userId, {
              status: { stringValue: "CANCELLED" },
              updatedAt: { integerValue: String(Date.now()) },
            });
            const spDoc = await getFirestoreDocument("serviceProviders", userId);
            if (spDoc) {
              await updateFirestoreFields("serviceProviders", userId, {
                subscriptionStatus: { stringValue: "CANCELLED" },
                updatedAt: { integerValue: String(Date.now()) },
              });
            }
          }
        }
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: "Webhook processed successfully",
          event: event.type,
          checkoutId: checkoutData.id,
          status: status,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e: any) {
      console.error("Webhook processing error:", e.message);
      return new Response(JSON.stringify({ error: "Webhook error: " + e.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  // ---------------------------------------------------------------------------
  // VERIFY CHECKOUT DIRECTLY WITH CHARGILY API
  // ---------------------------------------------------------------------------
  if (pathname.endsWith("/verify") || pathname.endsWith("/verifyCheckout")) {
    try {
      const body = await req.json();
      const checkoutId = body.checkoutId;
      if (!checkoutId) {
        return new Response(
          JSON.stringify({ success: false, error: "checkoutId is required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const chargilyResp = await fetch(`${apiBaseUrl}/checkouts/${checkoutId}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json",
        },
      });

      if (!chargilyResp.ok) {
        const errText = await chargilyResp.text();
        return new Response(
          JSON.stringify({ success: false, error: "Failed to fetch checkout from Chargily", details: errText }),
          { status: chargilyResp.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const checkoutObj = await chargilyResp.json();
      return new Response(
        JSON.stringify({
          success: true,
          checkoutId: checkoutObj.id,
          status: checkoutObj.status,
          amount: checkoutObj.amount,
          currency: checkoutObj.currency,
          receiptUrl: checkoutObj.receipt_url || null,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e: any) {
      return new Response(
        JSON.stringify({ success: false, error: e.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }

  // ---------------------------------------------------------------------------
  // AUTHENTICATED ENDPOINTS (Service Request, Subscription, Ad Boost)
  // ---------------------------------------------------------------------------
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return new Response(
      JSON.stringify({ success: false, error: "Missing or invalid Authorization header" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const token = authHeader.replace("Bearer ", "");
  let uid: string;
  try {
    uid = await verifyFirebaseToken(token);
  } catch (e: any) {
    console.error("Token verification failed:", e.message);
    return new Response(
      JSON.stringify({ success: false, error: "Unauthorized: " + e.message }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch (_e) {
    body = {};
  }

  const action = body.action || (
    pathname.endsWith("/chargilyProCheckout") || pathname.endsWith("/pro-checkout") ? "pro_checkout" :
    pathname.endsWith("/chargilyAdCheckout") || pathname.endsWith("/ad-checkout") ? "ad_checkout" :
    pathname.endsWith("/chargilyCheckout") || pathname.endsWith("/service-checkout") ? "service_checkout" :
    body.planId ? "pro_checkout" :
    body.adId ? "ad_checkout" :
    "service_checkout"
  );

  try {
    let amountDzd = 0;
    let paymentMethod = (body.paymentMethod || "EDAHABIA").toString().toUpperCase();
    let metadata: Record<string, any> = {};
    let successUrl = "https://khedmatidz.app/payment/success";
    let failureUrl = "https://khedmatidz.app/payment/failure";

    if (action === "pro_checkout") {
      const planId = body.planId || "PREMIUM";
      amountDzd = resolveSubscriptionPrice(planId);
      metadata = {
        type: "SUBSCRIPTION",
        userId: uid,
        planId: planId,
      };
      successUrl = `https://khedmatidz.app/payment/success?type=pro_subscription&user_id=${uid}`;
      failureUrl = `https://khedmatidz.app/payment/failure?type=pro_subscription&user_id=${uid}`;
    } else if (action === "ad_checkout") {
      const adId = body.adId || "ad_preview";
      const packageId = body.packageId || body.packageChoice || "PROMO_7D";
      amountDzd = resolveAdBoostPrice(packageId);
      metadata = {
        type: "PROMOTED_AD",
        adId: adId,
        providerId: uid,
        packageId: packageId,
      };
      successUrl = `https://khedmatidz.app/payment/success?ad_id=${adId}`;
      failureUrl = `https://khedmatidz.app/payment/failure?ad_id=${adId}`;
    } else {
      // Service Request Checkout
      const requestId = body.requestId || "request_preview";
      amountDzd = Number(body.amountDzd || body.proposedPriceDzd || body.amount || 1000);
      if (amountDzd <= 0) amountDzd = 1000;
      metadata = {
        type: "SERVICE_PAYMENT",
        requestId: requestId,
        customerId: uid,
        customerName: body.customerName || "Customer",
      };
      successUrl = `https://khedmatidz.app/payment/success?request_id=${requestId}`;
      failureUrl = `https://khedmatidz.app/payment/failure?request_id=${requestId}`;
    }

    const chargilyPayload = {
      amount: amountDzd,
      currency: "dzd",
      payment_method: paymentMethod === "CIB" ? "cib" : "edahabia",
      success_url: successUrl,
      failure_url: failureUrl,
      webhook_endpoint: `${url.origin}${url.pathname.replace(/\/(chargilyCheckout|chargilyProCheckout|chargilyAdCheckout|pro-checkout|ad-checkout|service-checkout)$/, "")}/webhook`,
      metadata: metadata,
    };

    const chargilyResp = await fetch(`${apiBaseUrl}/checkouts`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(chargilyPayload),
    });

    const respText = await chargilyResp.text();
    if (!chargilyResp.ok) {
      console.error("Chargily API error:", respText);
      return new Response(
        JSON.stringify({
          success: false,
          error: "Chargily Pay session creation failed",
          details: respText,
        }),
        { status: chargilyResp.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const responseJson = JSON.parse(respText);
    return new Response(
      JSON.stringify({
        success: true,
        checkoutId: responseJson.id,
        checkoutUrl: responseJson.checkout_url,
        amountDzd: amountDzd,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e: any) {
    console.error("Checkout creation exception:", e.message);
    return new Response(
      JSON.stringify({ success: false, error: e.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
