import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import * as jose from "https://deno.land/x/jose@v4.14.4/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, signature, x-chargily-signature",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const FIREBASE_PROJECT_ID = "khedmati-dz";

function getChargilySecretKey(): string {
  return (Deno.env.get("CHARGILY_SECRET_KEY") || "").trim();
}

function getChargilyBaseUrl(): string {
  const mode = (Deno.env.get("CHARGILY_MODE") || "test").trim().toLowerCase();
  return mode === "production"
    ? "https://pay.chargily.net/api/v2"
    : "https://pay.chargily.net/test/api/v2";
}

async function verifyFirebaseToken(token: string): Promise<string> {
  const response = await fetch(
    "https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com"
  );
  if (!response.ok) throw new Error("Failed to fetch Google public keys");
  const publicKeys = await response.json();

  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");
  const header = JSON.parse(atob(parts[0]));
  const kid = header.kid;
  if (!kid) throw new Error("No kid found in JWT header");

  const certificate = publicKeys[kid];
  if (!certificate) throw new Error("Invalid token kid or expired certificate");

  const publicKey = await jose.importX509(certificate, "RS256");

  const { payload } = await jose.jwtVerify(token, publicKey, {
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  });

  if (!payload.sub) throw new Error("No subject (UID) found in token");
  return payload.sub;
}

function resolveSubscriptionPrice(planId: string): number {
  const upper = String(planId || "").trim().toUpperCase();
  if (upper === "BASIC") return 500;
  if (upper === "STANDARD") return 1000;
  if (upper === "PREMIUM" || upper === "PRO") return 1500;
  return 1500;
}

function resolveAdBoostPrice(packageId: string): number {
  const upper = String(packageId || "").trim().toUpperCase();
  if (upper === "BOOST_BASIC" || upper === "BASIC") return 100;
  if (upper === "BOOST_STANDARD" || upper === "STANDARD") return 250;
  if (upper === "BOOST_PREMIUM" || upper === "PREMIUM") return 500;
  return 100;
}

async function verifyChargilySignature(
  rawBody: string,
  signatureHeader: string | null,
  secretKey: string
): Promise<boolean> {
  if (!signatureHeader || !secretKey) return false;
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(secretKey),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign", "verify"]
    );
    const signatureBytes = await crypto.subtle.sign(
      "HMAC",
      key,
      encoder.encode(rawBody)
    );
    const computedHex = Array.from(new Uint8Array(signatureBytes))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
    return computedHex.toLowerCase() === signatureHeader.trim().toLowerCase();
  } catch (e) {
    console.error("Signature verification exception:", e);
    return false;
  }
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;

  const secretKey = getChargilySecretKey();
  if (!secretKey) {
    console.error("CHARGILY_SECRET_KEY is missing from Supabase Edge Function Secrets.");
    return new Response(
      JSON.stringify({ success: false, error: "Chargily Secret Key is not configured on server." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const apiBaseUrl = getChargilyBaseUrl();

  // ---------------------------------------------------------------------------
  // WEBHOOK HANDLER
  // ---------------------------------------------------------------------------
  if (pathname.endsWith("/webhook") || pathname.endsWith("/chargilyWebhook")) {
    try {
      const rawBody = await req.text();
      const signature = req.headers.get("signature") || req.headers.get("x-chargily-signature");

      const isValid = await verifyChargilySignature(rawBody, signature, secretKey);
      if (!isValid) {
        console.warn("Invalid webhook signature received.");
        return new Response(JSON.stringify({ error: "Invalid signature" }), {
          status: 403,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const event = JSON.parse(rawBody);
      const checkoutData = event.data || {};
      const status = checkoutData.status || (event.type === "checkout.paid" ? "paid" : "failed");

      return new Response(
        JSON.stringify({
          success: true,
          message: "Webhook processed successfully",
          event: event.type,
          checkoutId: checkoutData.id,
          status: status,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e: any) {
      console.error("Webhook processing error:", e.message);
      return new Response(JSON.stringify({ error: "Webhook error: " + e.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  // ---------------------------------------------------------------------------
  // VERIFY CHECKOUT DIRECTLY WITH CHARGILY API
  // ---------------------------------------------------------------------------
  if (pathname.endsWith("/verify") || pathname.endsWith("/verifyCheckout")) {
    try {
      const body = await req.json();
      const checkoutId = body.checkoutId;
      if (!checkoutId) {
        return new Response(
          JSON.stringify({ success: false, error: "checkoutId is required" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const chargilyResp = await fetch(`${apiBaseUrl}/checkouts/${checkoutId}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json",
        },
      });

      if (!chargilyResp.ok) {
        const errText = await chargilyResp.text();
        return new Response(
          JSON.stringify({ success: false, error: "Failed to fetch checkout from Chargily", details: errText }),
          { status: chargilyResp.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const checkoutObj = await chargilyResp.json();
      return new Response(
        JSON.stringify({
          success: true,
          checkoutId: checkoutObj.id,
          status: checkoutObj.status,
          amount: checkoutObj.amount,
          currency: checkoutObj.currency,
          receiptUrl: checkoutObj.receipt_url || null,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (e: any) {
      return new Response(
        JSON.stringify({ success: false, error: e.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }

  // ---------------------------------------------------------------------------
  // AUTHENTICATED ENDPOINTS (Service Request, Subscription, Ad Boost)
  // ---------------------------------------------------------------------------
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return new Response(
      JSON.stringify({ success: false, error: "Missing or invalid Authorization header" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  const token = authHeader.replace("Bearer ", "");
  let uid: string;
  try {
    uid = await verifyFirebaseToken(token);
  } catch (e: any) {
    console.error("Token verification failed:", e.message);
    return new Response(
      JSON.stringify({ success: false, error: "Unauthorized: " + e.message }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch (_e) {
    body = {};
  }

  const action = body.action || (
    pathname.endsWith("/chargilyProCheckout") || pathname.endsWith("/pro-checkout") ? "pro_checkout" :
    pathname.endsWith("/chargilyAdCheckout") || pathname.endsWith("/ad-checkout") ? "ad_checkout" :
    pathname.endsWith("/chargilyCheckout") || pathname.endsWith("/service-checkout") ? "service_checkout" :
    body.planId ? "pro_checkout" :
    body.adId ? "ad_checkout" :
    "service_checkout"
  );

  try {
    let amountDzd = 0;
    let paymentMethod = (body.paymentMethod || "EDAHABIA").toString().toUpperCase();
    let metadata: Record<string, any> = {};
    let successUrl = "https://khedmatidz.app/payment/success";
    let failureUrl = "https://khedmatidz.app/payment/failure";

    if (action === "pro_checkout") {
      const planId = body.planId || "PREMIUM";
      amountDzd = resolveSubscriptionPrice(planId);
      metadata = {
        type: "SUBSCRIPTION",
        userId: uid,
        planId: planId,
      };
      successUrl = `https://khedmatidz.app/payment/success?type=pro_subscription&user_id=${uid}`;
      failureUrl = `https://khedmatidz.app/payment/failure?type=pro_subscription&user_id=${uid}`;
    } else if (action === "ad_checkout") {
      const adId = body.adId || "ad_preview";
      const packageId = body.packageId || body.packageChoice || "PROMO_7D";
      amountDzd = resolveAdBoostPrice(packageId);
      metadata = {
        type: "PROMOTED_AD",
        adId: adId,
        providerId: uid,
        packageId: packageId,
      };
      successUrl = `https://khedmatidz.app/payment/success?ad_id=${adId}`;
      failureUrl = `https://khedmatidz.app/payment/failure?ad_id=${adId}`;
    } else {
      // Service Request Checkout
      const requestId = body.requestId || "request_preview";
      amountDzd = Number(body.amountDzd || body.proposedPriceDzd || body.amount || 1000);
      if (amountDzd <= 0) amountDzd = 1000;
      metadata = {
        type: "SERVICE_PAYMENT",
        requestId: requestId,
        customerId: uid,
        customerName: body.customerName || "Customer",
      };
      successUrl = `https://khedmatidz.app/payment/success?request_id=${requestId}`;
      failureUrl = `https://khedmatidz.app/payment/failure?request_id=${requestId}`;
    }

    const chargilyPayload = {
      amount: amountDzd,
      currency: "dzd",
      payment_method: paymentMethod === "CIB" ? "cib" : "edahabia",
      success_url: successUrl,
      failure_url: failureUrl,
      webhook_endpoint: `${url.origin}${url.pathname.replace(/\/(chargilyCheckout|chargilyProCheckout|chargilyAdCheckout|pro-checkout|ad-checkout|service-checkout)$/, "")}/webhook`,
      metadata: metadata,
    };

    const chargilyResp = await fetch(`${apiBaseUrl}/checkouts`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(chargilyPayload),
    });

    const respText = await chargilyResp.text();
    if (!chargilyResp.ok) {
      console.error("Chargily API error:", respText);
      return new Response(
        JSON.stringify({
          success: false,
          error: "Chargily Pay session creation failed",
          details: respText,
        }),
        { status: chargilyResp.status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const responseJson = JSON.parse(respText);
    return new Response(
      JSON.stringify({
        success: true,
        checkoutId: responseJson.id,
        checkoutUrl: responseJson.checkout_url,
        amountDzd: amountDzd,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e: any) {
    console.error("Checkout creation exception:", e.message);
    return new Response(
      JSON.stringify({ success: false, error: e.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
