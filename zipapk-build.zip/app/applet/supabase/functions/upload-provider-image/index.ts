import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";
import * as jose from "https://deno.land/x/jose@v4.14.4/index.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const FIREBASE_PROJECT_ID = "khedmati-dz"; // Your Firebase Project ID

async function verifyFirebaseToken(token: string): Promise<string> {
  // 1. Fetch Google's public JWKS (JSON Web Key Set)
  const response = await fetch("https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com");
  if (!response.ok) throw new Error("Failed to fetch Google public keys");
  const publicKeys = await response.json();

  // 2. Decode the JWT header to find the Key ID (kid)
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT format");
  const header = JSON.parse(atob(parts[0]));
  const kid = header.kid;
  if (!kid) throw new Error("No kid found in JWT header");

  // 3. Get the corresponding public certificate
  const certificate = publicKeys[kid];
  if (!certificate) throw new Error("Invalid token kid or expired certificate");

  // 4. Import the cert and verify the token using jose
  const publicKey = await jose.importX509(certificate, "RS256");
  
  const { payload } = await jose.jwtVerify(token, publicKey, {
    issuer: `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`,
    audience: FIREBASE_PROJECT_ID,
  });

  if (!payload.sub) throw new Error("No subject (UID) found in token");
  return payload.sub; // This is the verified Firebase UID
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // 1. Get Authorization Header
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Missing or invalid Authorization header" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const token = authHeader.replace("Bearer ", "");

    // 2. Verify Firebase Token and Extract UID
    let uid: string;
    try {
      uid = await verifyFirebaseToken(token);
    } catch (e) {
      console.error("Token verification failed:", e.message);
      return new Response(JSON.stringify({ error: "Unauthorized: Invalid Firebase token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 3. Read the Multipart Form Data
    const formData = await req.formData();
    const file = formData.get("file") as File;
    if (!file) {
      return new Response(JSON.stringify({ error: "No file uploaded in form data" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 4. Validate File Size (e.g., Max 5MB) and Type
    const MAX_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      return new Response(JSON.stringify({ error: "File exceeds 5MB limit" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    
    if (!file.type.startsWith("image/")) {
      return new Response(JSON.stringify({ error: "Invalid file type. Only images are allowed." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // 5. Initialize Supabase Admin Client (Bypasses RLS)
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    
    if (!supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing Supabase environment variables");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // 6. Enforce UID-based Path
    // Even if a user tries to forge a path, we override it and force their UID.
    const ext = file.name.split(".").pop() || "jpg";
    const timestamp = Date.now();
    const safePath = `providers/${uid}/img_${timestamp}.${ext}`;

    // 7. Upload to Supabase Storage
    const { data, error: uploadError } = await supabase.storage
      .from("khedmati")
      .upload(safePath, file, {
        contentType: file.type,
        upsert: true,
      });

    if (uploadError) {
      throw uploadError;
    }

    // 8. Construct Public URL
    const publicUrl = `${supabaseUrl}/storage/v1/object/public/khedmati/${safePath}`;

    // 9. Return Success Response
    return new Response(JSON.stringify({ url: publicUrl, path: safePath, success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Upload error:", error.message);
    return new Response(JSON.stringify({ error: "Internal Server Error", details: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
