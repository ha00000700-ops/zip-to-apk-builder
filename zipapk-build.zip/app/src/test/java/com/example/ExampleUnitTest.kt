package com.example

import com.example.data.model.GardenPlant
import com.example.data.repository.EncyclopediaData
import com.example.data.repository.SamplePlants
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun samplePresets_containValidDiagnosesAndMedicines() {
        val presets = SamplePlants.presets
        assertTrue("Presets must not be empty", presets.isNotEmpty())
        
        val tomatoPreset = presets.first { it.title.contains("طماطم") }
        assertFalse(tomatoPreset.diagnosis.isHealthy)
        assertTrue(tomatoPreset.diagnosis.chemicalMedicines.isNotEmpty())
        assertTrue(tomatoPreset.diagnosis.organicTreatments.isNotEmpty())
        assertTrue(tomatoPreset.diagnosis.confidenceScore > 0.8f)
    }

    @Test
    fun encyclopedia_containsComprehensiveData() {
        val diseases = EncyclopediaData.diseases
        assertTrue(diseases.size >= 5)
        for (disease in diseases) {
            assertTrue(disease.nameAr.isNotBlank())
            assertTrue(disease.chemicalTreatment.isNotBlank())
            assertTrue(disease.organicTreatment.isNotBlank())
            assertTrue(disease.symptoms.isNotBlank())
        }
    }

    @Test
    fun gardenPlant_wateringCalculationIsAccurate() {
        val plantDue = GardenPlant(
            name = "نعناع بلدي",
            plantType = "عطري",
            wateringFrequencyDays = 2,
            lastWateredTimestamp = System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 3)
        )
        assertTrue(plantDue.isWateringDue())
        assertEquals(0, plantDue.daysUntilNextWatering())

        val plantNotDue = GardenPlant(
            name = "صبار ألوفيرا",
            plantType = "عصاري",
            wateringFrequencyDays = 10,
            lastWateredTimestamp = System.currentTimeMillis()
        )
        assertFalse(plantNotDue.isWateringDue())
        assertEquals(10, plantNotDue.daysUntilNextWatering())
    }
}
