package com.example

import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `verify public request notification ID and model serialization`() {
    val reqId = "req_12345"
    val providerUid = "prov_67890"
    val notifId = AppNotification.generatePublicRequestNotificationId(reqId, providerUid)
    assertEquals("notif_public_request_req_12345_prov_67890", notifId)

    val notif = AppNotification(
      id = notifId,
      recipientId = providerUid,
      senderId = "cust_abc",
      title = "طلب خدمة جديد في مجالك 📢",
      body = "تصليح حنفية - الجزائر الوسطى، الجزائر",
      type = AppNotificationType.NEW_PUBLIC_REQUEST,
      targetId = reqId,
      targetType = AppNotificationTargetType.PUBLIC_REQUEST,
      isRead = false,
      createdAt = 1700000000000L
    )

    val map = notif.toFirestoreMap()
    assertEquals(notifId, map["id"])
    assertEquals(providerUid, map["recipientId"])
    assertEquals("cust_abc", map["senderId"])
    assertEquals(AppNotificationType.NEW_PUBLIC_REQUEST, map["type"])
    assertEquals(AppNotificationTargetType.PUBLIC_REQUEST, map["targetType"])
    assertEquals(reqId, map["targetId"])
    assertEquals(false, map["isRead"])

    val restored = AppNotification.fromFirestoreMap(notifId, map)
    assertEquals(notif.id, restored.id)
    assertEquals(notif.recipientId, restored.recipientId)
    assertEquals(notif.senderId, restored.senderId)
    assertEquals(notif.title, restored.title)
    assertEquals(notif.body, restored.body)
    assertEquals(notif.type, restored.type)
    assertEquals(notif.targetId, restored.targetId)
    assertEquals(notif.targetType, restored.targetType)
    assertEquals(notif.isRead, restored.isRead)
  }

  @Test
  fun `verify LocalNotificationHelper session baseline and pre-existing notification filtering`() {
    val helper = com.example.service.LocalNotificationHelper
    helper.startSession()

    val oldUnreadNotif = AppNotification(
      id = "notif_old_1",
      recipientId = "prov_123",
      senderId = "cust_999",
      title = "طلب قديم",
      body = "تفاصيل الطلب القديم",
      type = AppNotificationType.NEW_PUBLIC_REQUEST,
      targetId = "req_old",
      targetType = AppNotificationTargetType.PUBLIC_REQUEST,
      isRead = false,
      createdAt = System.currentTimeMillis() - 100000L
    )

    // Emission 1 & 2: Initial sync phase (establishes baseline)
    val context = org.robolectric.RuntimeEnvironment.getApplication()
    helper.handleNewNotifications(context, listOf(oldUnreadNotif))
    helper.handleNewNotifications(context, listOf(oldUnreadNotif))

    // Verify old notification is seen / in baseline
    assertTrue(helper.isSeen("notif_old_1"))

    // Emission 3+: Subsequent emission containing old notification AND a genuinely new notification
    val newNotif = AppNotification(
      id = "notif_new_1",
      recipientId = "prov_123",
      senderId = "cust_888",
      title = "طلب جديد",
      body = "تفاصيل الطلب الجديد",
      type = AppNotificationType.NEW_PUBLIC_REQUEST,
      targetId = "req_new",
      targetType = AppNotificationTargetType.PUBLIC_REQUEST,
      isRead = false,
      createdAt = System.currentTimeMillis()
    )

    // Since emissionsHandledInSession is now > 2, handleNewNotifications should process newNotif
    // (oldNotif is in baseline so it won't trigger notification)
    helper.handleNewNotifications(context, listOf(oldUnreadNotif, newNotif))
    assertTrue(helper.isSeen("notif_new_1"))
  }
}

