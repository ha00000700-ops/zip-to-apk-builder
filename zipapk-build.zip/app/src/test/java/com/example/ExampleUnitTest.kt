package com.example

import com.example.architecture.MediaProjectionAnalysis
import com.example.architecture.XiaomiCompatibilityGuide
import com.example.model.CastStatus
import com.example.model.StreamConfig
import com.example.util.NetworkUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testStreamConfigDefaults() {
        val config = StreamConfig()
        assertEquals(1280, config.width)
        assertEquals(720, config.height)
        assertEquals(30, config.fps)
        assertEquals(8080, config.port)
        assertTrue(config.adaptiveQuality)
        assertTrue(config.pinSecurityEnabled)
        assertEquals("4829", config.pairingPin)
    }

    @Test
    fun testUrlGeneration() {
        val url = NetworkUtils.getStreamUrl("192.168.1.100", 8080)
        assertEquals("http://192.168.1.100:8080", url)

        val streamUrl = NetworkUtils.getTvDirectStreamUrl("192.168.1.100", 8080)
        assertEquals("http://192.168.1.100:8080/stream", streamUrl)
    }

    @Test
    fun testArchitecturalAnalysisFacts() {
        assertTrue(MediaProjectionAnalysis.ARCHITECTURAL_FACTS.isNotEmpty())
        val firstFact = MediaProjectionAnalysis.ARCHITECTURAL_FACTS.first()
        assertTrue(firstFact.codeReference.contains("MediaProjectionManagerService.java"))

        val autoResume = MediaProjectionAnalysis.SUPPORTED_SOLUTIONS.find { it.id == "auto_resume" }
        assertNotNull(autoResume)
        assertTrue(autoResume!!.isRecommended)
    }

    @Test
    fun testCastStatusEnum() {
        assertEquals(CastStatus.PAUSED_BY_SYSTEM, CastStatus.valueOf("PAUSED_BY_SYSTEM"))
    }

    @Test
    fun testXiaomiGuideItems() {
        assertTrue(XiaomiCompatibilityGuide.GUIDE_ITEMS.isNotEmpty())
        assertEquals(4, XiaomiCompatibilityGuide.GUIDE_ITEMS.size)
        val batteryStep = XiaomiCompatibilityGuide.GUIDE_ITEMS.find { it.stepNumber == 1 }
        assertNotNull(batteryStep)
        assertTrue(batteryStep!!.title.contains("البطارية"))
    }
}
