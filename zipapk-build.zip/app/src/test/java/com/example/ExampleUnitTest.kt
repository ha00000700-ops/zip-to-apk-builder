package com.example

import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `verify public request notification ID and model serialization`() {
    val reqId = "req_12345"
    val providerUid = "prov_67890"
    val notifId = AppNotification.generatePublicRequestNotificationId(reqId, providerUid)
    assertEquals("notif_public_request_req_12345_prov_67890", notifId)

    val notif = AppNotification(
      id = notifId,
      recipientId = providerUid,
      senderId = "cust_abc",
      title = "طلب خدمة جديد في مجالك 📢",
      body = "تصليح حنفية - الجزائر الوسطى، الجزائر",
      type = AppNotificationType.NEW_PUBLIC_REQUEST,
      targetId = reqId,
      targetType = AppNotificationTargetType.PUBLIC_REQUEST,
      isRead = false,
      createdAt = 1700000000000L
    )

    val map = notif.toFirestoreMap()
    assertEquals(notifId, map["id"])
    assertEquals(providerUid, map["recipientId"])
    assertEquals("cust_abc", map["senderId"])
    assertEquals(AppNotificationType.NEW_PUBLIC_REQUEST, map["type"])
    assertEquals(AppNotificationTargetType.PUBLIC_REQUEST, map["targetType"])
    assertEquals(reqId, map["targetId"])
    assertEquals(false, map["isRead"])

    val restored = AppNotification.fromFirestoreMap(notifId, map)
    assertEquals(notif.id, restored.id)
    assertEquals(notif.recipientId, restored.recipientId)
    assertEquals(notif.senderId, restored.senderId)
    assertEquals(notif.title, restored.title)
    assertEquals(notif.body, restored.body)
    assertEquals(notif.type, restored.type)
    assertEquals(notif.targetId, restored.targetId)
    assertEquals(notif.targetType, restored.targetType)
    assertEquals(notif.isRead, restored.isRead)
  }
}

