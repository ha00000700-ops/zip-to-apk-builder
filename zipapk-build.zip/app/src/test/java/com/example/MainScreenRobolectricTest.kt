package com.example

import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.assertIsDisplayed
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(sdk = [36])
class MainScreenRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun testAppLaunchesAndDisplaysHomeScreenWithoutCrash() {
        // Verify Home Screen elements are rendered
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("main_bottom_nav").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_screen_column").assertIsDisplayed()
        composeTestRule.onNodeWithTag("home_search_bar").assertIsDisplayed()
        composeTestRule.onNodeWithTag("ai_diagnosis_banner").assertIsDisplayed()
    }
}
