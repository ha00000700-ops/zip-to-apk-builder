package com.example

import com.example.data.model.PublicServiceRequest
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthRepository
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PublicRequestNotificationEligibilityTest {

    @Test
    fun `electrician provider must NOT be eligible for carpenter public request even if same wilaya and same commune`() {
        // Provider: Electrician located in Alger (16), Alger Centre
        val electricianProvider = ServiceProviderProfile(
            uid = "provider_electrician_123",
            fullName = "أحمد الكهربائي",
            professionId = "electrician",
            professionNameAr = "كهربائي مباني وصناعي",
            professionCategoryAr = "الكهرباء المنزلية والصناعية",
            wilayaCode = 16,
            wilayaName = "الجزائر",
            communeName = "الجزائر الوسطى",
            isAvailable = true
        )

        // Customer's Public Request: Carpenter in Alger (16), Alger Centre
        val carpenterRequest = PublicServiceRequest(
            id = "req_carpenter_456",
            customerId = "customer_789",
            customerName = "محمد الزبون",
            title = "تركيب خزانة ومطبخ خشب",
            professionId = "wood_carpenter",
            professionNameAr = "نجار خشب ومطابخ",
            professionCategoryAr = "النجارة والألمنيوم وPVC",
            wilayaCode = 16,
            wilayaName = "الجزائر",
            communeName = "الجزائر الوسطى"
        )

        // Eligibility test:
        // ELECTRICIAN + CARPENTER + SAME WILAYA + SAME COMMUNE = ZERO notification (false)
        val isEligible = AuthRepository.isProviderEligibleForPublicRequest(
            provider = electricianProvider,
            request = carpenterRequest,
            creatorUid = "customer_789"
        )

        assertFalse(
            "An electrician provider MUST NOT be eligible for a carpenter request, even with identical Wilaya and Commune!",
            isEligible
        )
    }

    @Test
    fun `carpenter provider IS eligible for carpenter public request in same wilaya`() {
        val carpenterProvider = ServiceProviderProfile(
            uid = "provider_carpenter_101",
            fullName = "كريم النجار",
            professionId = "wood_carpenter",
            professionNameAr = "نجار خشب ومطابخ",
            professionCategoryAr = "النجارة والألمنيوم وPVC",
            wilayaCode = 16,
            wilayaName = "الجزائر",
            communeName = "الجزائر الوسطى",
            isAvailable = true
        )

        val carpenterRequest = PublicServiceRequest(
            id = "req_carpenter_456",
            customerId = "customer_789",
            customerName = "محمد الزبون",
            title = "تركيب خزانة ومطبخ خشب",
            professionId = "wood_carpenter",
            professionNameAr = "نجار خشب ومطابخ",
            professionCategoryAr = "النجارة والألمنيوم وPVC",
            wilayaCode = 16,
            wilayaName = "الجزائر",
            communeName = "الجزائر الوسطى"
        )

        val isEligible = AuthRepository.isProviderEligibleForPublicRequest(
            provider = carpenterProvider,
            request = carpenterRequest,
            creatorUid = "customer_789"
        )

        assertTrue("A carpenter provider MUST be eligible for a carpenter request in the same Wilaya", isEligible)
    }

    @Test
    fun `provider is NOT eligible if unavailable`() {
        val unavailableCarpenter = ServiceProviderProfile(
            uid = "provider_carpenter_102",
            fullName = "كريم النجار",
            professionId = "wood_carpenter",
            isAvailable = false
        )

        val carpenterRequest = PublicServiceRequest(
            id = "req_carpenter_456",
            customerId = "customer_789",
            professionId = "wood_carpenter"
        )

        val isEligible = AuthRepository.isProviderEligibleForPublicRequest(
            provider = unavailableCarpenter,
            request = carpenterRequest,
            creatorUid = "customer_789"
        )

        assertFalse("An unavailable provider must NOT receive notifications", isEligible)
    }

    @Test
    fun `provider who created the request is NOT eligible`() {
        val providerCreator = ServiceProviderProfile(
            uid = "provider_creator_103",
            fullName = "علي الحرفي",
            professionId = "wood_carpenter",
            isAvailable = true
        )

        val request = PublicServiceRequest(
            id = "req_carpenter_456",
            customerId = "provider_creator_103", // Same as provider UID
            professionId = "wood_carpenter"
        )

        val isEligible = AuthRepository.isProviderEligibleForPublicRequest(
            provider = providerCreator,
            request = request,
            creatorUid = "provider_creator_103"
        )

        assertFalse("A provider cannot receive a notification for their own request", isEligible)
    }
}
