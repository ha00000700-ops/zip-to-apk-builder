package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AlgerianLocationData
import com.example.data.model.ProfessionData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies Khedmati app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("خدمتي", appName)
    }

    @Test
    fun `verify 58 Algerian wilayas and profession catalog loaded`() {
        assertEquals(58, AlgerianLocationData.wilayas.size)
        val alger = AlgerianLocationData.getWilayaByCode(16)
        assertNotNull(alger)
        assertEquals("الجزائر", alger?.nameAr)
        assertTrue(alger?.communes?.isNotEmpty() == true)

        assertTrue(ProfessionData.professions.isNotEmpty())
        val plumber = ProfessionData.getProfessionById("plumber")
        assertNotNull(plumber)
        assertEquals("سباك / ترصيص صحي وغاز", plumber?.nameAr)
    }
}

