package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.StandbyFrameGenerator
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("CastDirect TV", appName)
  }

  @Test
  fun `test standby frame generation in Robolectric`() {
    val frame = StandbyFrameGenerator.generatePausedFrame()
    assertNotNull(frame)
    assertTrue(frame.isNotEmpty())
    // Verify JPEG SOI marker: 0xFF 0xD8
    assertEquals(0xFF.toByte(), frame[0])
    assertEquals(0xD8.toByte(), frame[1])
  }
}
