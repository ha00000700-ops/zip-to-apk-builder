package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.CareTaskEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.DiagnosisEntity
import com.example.data.local.IssueReportEntity
import com.example.data.local.PlantEntity
import com.example.data.local.PlantGrowthEntryEntity
import com.example.data.model.PlantEncyclopediaData
import com.example.data.model.UserProfileManager
import com.example.data.remote.GeminiService
import com.example.data.remote.WeatherService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.net.UnknownHostException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testAppName() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("طبيب النباتات", appName)
    }

    @Test
    fun testEncyclopediaData() {
        assertTrue("Plant encyclopedia should have entries", PlantEncyclopediaData.plants.isNotEmpty())
        val olive = PlantEncyclopediaData.plants.find { it.id == "olive" }
        assertNotNull("Olive entry should exist", olive)
        assertEquals("شجرة الزيتون", olive?.arabicName)
        assertEquals("Olivier", olive?.frenchName)
        assertEquals("Olea europaea", olive?.scientificName)
        assertTrue("Olive should list common diseases", olive!!.commonDiseases.isNotEmpty())
    }

    @Test
    fun testDiseaseLibraryAndAuthoritativeSources() {
        assertTrue("Disease library should have entries", PlantEncyclopediaData.diseases.isNotEmpty())
        val mildew = PlantEncyclopediaData.diseases.find { it.id == "powdery_mildew" }
        assertNotNull("Powdery mildew should exist", mildew)
        assertEquals("فطري", mildew?.pathogenType)
        assertTrue("Should have non-chemical IPM steps first", mildew!!.ipmPreventiveSteps.isNotEmpty())
        assertTrue("Should list active substances", mildew.activeSubstances.isNotEmpty())
        assertTrue("Should cite authoritative sources like INRAA or FAO", mildew.authoritativeSource.contains("INRAA") || mildew.authoritativeSource.contains("FAO"))
    }

    @Test
    fun testPlantDaoCrud() = runBlocking {
        val plantDao = db.plantDao()
        val plant = PlantEntity(
            name = "طماطم حديقة السطح",
            scientificName = "Solanum lycopersicum",
            plantType = "خضروات",
            location = "أصيص",
            wateringIntervalDays = 2,
            fertilizingIntervalDays = 14
        )

        // Insert
        val id = plantDao.insertPlant(plant)
        assertTrue("Generated ID should be positive", id > 0)

        // Query
        val fetched = plantDao.getPlantById(id)
        assertNotNull("Fetched plant should not be null", fetched)
        assertEquals("طماطم حديقة السطح", fetched?.name)

        // Update
        val updated = fetched!!.copy(healthStatus = "يتعافى")
        plantDao.updatePlant(updated)
        val fetchedAfterUpdate = plantDao.getPlantById(id)
        assertEquals("يتعافى", fetchedAfterUpdate?.healthStatus)

        // Delete
        plantDao.deletePlant(updated)
        val fetchedAfterDelete = plantDao.getPlantById(id)
        assertNull("Plant should be null after deletion", fetchedAfterDelete)
    }

    @Test
    fun testCareTaskDao() = runBlocking {
        val careTaskDao = db.careTaskDao()
        val task = CareTaskEntity(
            plantId = 1L,
            plantName = "ليمون المتيجة",
            taskType = "ري",
            dueDate = System.currentTimeMillis() + 86400000L,
            notes = "ري مسائي هادئ"
        )

        val id = careTaskDao.insertTask(task)
        val pendingList = careTaskDao.getPendingTasks().first()
        assertTrue("Pending tasks should contain inserted task", pendingList.any { it.id == id })

        // Mark completed
        careTaskDao.markTaskCompleted(id, System.currentTimeMillis())
        val pendingAfter = careTaskDao.getPendingTasks().first()
        assertTrue("Task should no longer be pending", pendingAfter.none { it.id == id })

        val completedList = careTaskDao.getCompletedTasks().first()
        assertTrue("Task should appear in completed list", completedList.any { it.id == id })
    }

    @Test
    fun testDiagnosisDao() = runBlocking {
        val diagnosisDao = db.diagnosisDao()
        val record = DiagnosisEntity(
            plantCommonName = "نخلة دقلة نور",
            diseaseName = "حلم الغبار (بوفروة)",
            confidenceLevel = "مرتفع",
            severity = "متوسط",
            urgency = "خلال 24 ساعة",
            affectedPart = "الشماريخ والثمار",
            symptomsSummary = "نسيج عنكبوتي وغبار على العراجين",
            possibleCauses = "جفاف وحرارة عالية ورياح رملية",
            immediateActions = "تعفير بالكبريت الميكروني",
            preventiveCare = "نظافة الواحة والتكريب الدوري",
            chemicalTreatments = "كبريت ميكروني مرخص مع مراعاة فترات الأمان",
            pathogenType = "آفة حشرية",
            clarifyingQuestions = "هل فحصت قواعد السعف؟;;متى ظهر الغبار؟",
            scientificSources = "المعهد الوطني الجزائري للأبحاث الزراعية (INRAA)",
            advisoryNote = "التشخيص استرشادي"
        )

        val id = diagnosisDao.insertDiagnosis(record)
        val all = diagnosisDao.getAllDiagnoses().first()
        assertTrue("All diagnoses should contain new record", all.any { it.id == id })

        val forPlant = diagnosisDao.getDiagnosesByPlantName("نخلة دقلة نور").first()
        assertTrue("Query by plant name should return record", forPlant.any { it.id == id })
    }

    @Test
    fun testPlantGrowthDao() = runBlocking {
        val growthDao = db.plantGrowthDao()
        val entry = PlantGrowthEntryEntity(
            plantId = 1L,
            imagePath = "/data/local/growth_1.jpg",
            stageTitle = "تزهير",
            heightCm = 45.0,
            notes = "ظهور تفرعات زهرية ممتازة"
        )
        val id = growthDao.insertGrowthEntry(entry)
        assertTrue("Growth entry ID should be positive", id > 0)

        val list = growthDao.getGrowthEntriesForPlant(1L).first()
        assertEquals(1, list.size)
        assertEquals("تزهير", list[0].stageTitle)
        assertEquals(45.0, list[0].heightCm ?: 0.0, 0.01)

        growthDao.deleteGrowthEntry(list[0])
        val listAfter = growthDao.getGrowthEntriesForPlant(1L).first()
        assertTrue("List should be empty after deletion", listAfter.isEmpty())
    }

    @Test
    fun testIssueReportDao() = runBlocking {
        val reportDao = db.issueReportDao()
        val report = IssueReportEntity(
            diagnosisId = 10L,
            userComment = "أعتقد أن المرض هو نقص بوتاسيوم وليس بياض دقيقي",
            contactEmail = "farmer@example.dz"
        )
        val id = reportDao.insertReport(report)
        assertTrue("Report ID should be positive", id > 0)

        val allReports = reportDao.getAllReports().first()
        assertEquals(1, allReports.size)
        assertEquals("farmer@example.dz", allReports[0].contactEmail)
    }

    @Test
    fun testChatMessageDao() = runBlocking {
        val chatDao = db.chatMessageDao()
        val msg = ChatMessageEntity(
            sender = "user",
            text = "كيف أعالج تجعد أوراق الليمون؟"
        )
        chatDao.insertMessage(msg)

        val history = chatDao.getAllMessages().first()
        assertEquals(1, history.size)
        assertEquals("كيف أعالج تجعد أوراق الليمون؟", history[0].text)

        chatDao.clearHistory()
        val cleared = chatDao.getAllMessages().first()
        assertTrue("History should be empty after clear", cleared.isEmpty())
    }

    @Test
    fun testWeatherAll58WilayasData() {
        val wilayas = WeatherService.allWilayas
        assertTrue("Should include all Algerian wilayas", wilayas.size >= 58)

        val adrar = wilayas.find { it.wilayaNumber == 1 }
        assertNotNull("Wilaya 01 Adrar should exist", adrar)
        assertEquals("أدرار", adrar?.name)

        val algiers = wilayas.find { it.wilayaNumber == 16 }
        assertNotNull("Wilaya 16 Algiers should exist", algiers)
        assertEquals("الجزائر العاصمة", algiers?.name)

        val elMeniaa = wilayas.find { it.wilayaNumber == 58 }
        assertNotNull("Wilaya 58 El Meniaa should exist", elMeniaa)
        assertEquals("المنيعة", elMeniaa?.name)
    }

    @Test
    fun testUserProfileQuotaManager() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = UserProfileManager(context)
        assertTrue("Initial profile can make request", manager.canMakeAiRequest())

        manager.recordAiRequest()
        val updated = manager.userProfile.value
        assertEquals(1, updated.dailyAiUsageCount)

        manager.toggleFavorite("olive")
        assertTrue("Olive should be in favorites", manager.isFavorite("olive"))
        manager.toggleFavorite("olive")
        assertTrue("Olive should be removed from favorites", !manager.isFavorite("olive"))
    }

    @Test
    fun testGeminiErrorMessageFormatting() {
        // 1. Test HTTP 400 API key invalid message
        val invalidKeyMsg = GeminiService.formatErrorMessage(400, "{\"error\":{\"message\":\"API_KEY_INVALID\",\"status\":\"INVALID_ARGUMENT\"}}")
        assertTrue("Message should mention API key invalid or Secrets", invalidKeyMsg.contains("غير صالح") || invalidKeyMsg.contains("Secrets"))

        // 2. Test HTTP 400 bad image payload
        val badPayloadMsg = GeminiService.formatErrorMessage(400, "{\"error\":{\"message\":\"Invalid image payload\",\"status\":\"INVALID_ARGUMENT\"}}")
        assertTrue("Message should mention bad request or image", badPayloadMsg.contains("400") || badPayloadMsg.contains("الصورة"))

        // 3. Test HTTP 401 & 403 Authentication/Forbidden
        val authMsg = GeminiService.formatErrorMessage(403, "{\"error\":{\"message\":\"PERMISSION_DENIED\"}}")
        assertTrue("Message should mention authentication or permissions", authMsg.contains("403") && (authMsg.contains("المصادقة") || authMsg.contains("الإذن")))

        // 4. Test HTTP 404 Model Not Found
        val notFoundMsg = GeminiService.formatErrorMessage(404, "{\"error\":{\"message\":\"models/gemini-3.8-flash not found\"}}")
        assertTrue("Message should mention not found and model", notFoundMsg.contains("404") && notFoundMsg.contains("غير موجود"))

        // 5. Test HTTP 429 Quota with and without Retry-After
        val quotaMsg = GeminiService.formatErrorMessage(429, "{\"error\":{\"message\":\"RESOURCE_EXHAUSTED\"}}", retryAfterSeconds = 45)
        assertTrue("Message should mention quota and retry after seconds", quotaMsg.contains("429") && quotaMsg.contains("45"))

        val quotaNoRetryMsg = GeminiService.formatErrorMessage(429, "{\"error\":{\"message\":\"RESOURCE_EXHAUSTED\"}}")
        assertTrue("Message should mention quota", quotaNoRetryMsg.contains("429") || quotaNoRetryMsg.contains("الحصة"))

        // 6. Test HTTP 500 Internal Server Error (Must NOT say maintenance)
        val serverErrorMsg = GeminiService.formatErrorMessage(500, "Internal Server Error")
        assertTrue("HTTP 500 should describe internal error", serverErrorMsg.contains("500") && serverErrorMsg.contains("داخلي"))
        assertTrue("HTTP 500 should NOT claim maintenance without proof", !serverErrorMsg.contains("تحت الصيانة"))

        // 7. Test HTTP 502 Bad Gateway
        val badGatewayMsg = GeminiService.formatErrorMessage(502, "Bad Gateway")
        assertTrue("HTTP 502 should mention bad gateway", badGatewayMsg.contains("502") && badGatewayMsg.contains("بوابة"))

        // 8. Test HTTP 504 Gateway Timeout
        val timeoutMsg = GeminiService.formatErrorMessage(504, "Gateway Timeout")
        assertTrue("HTTP 504 should mention gateway timeout", timeoutMsg.contains("504") && timeoutMsg.contains("مهلة"))

        // 9. Test HTTP 503 Maintenance ONLY when proof exists
        val realMaintenanceMsg = GeminiService.formatErrorMessage(503, "The service is currently down for scheduled maintenance")
        assertTrue("HTTP 503 with maintenance should state maintenance", realMaintenanceMsg.contains("الصيانة") && realMaintenanceMsg.contains("503"))

        val overload503Msg = GeminiService.formatErrorMessage(503, "High traffic overload")
        assertTrue("HTTP 503 without maintenance proof should state unavailable", overload503Msg.contains("غير متوفرة") || overload503Msg.contains("503"))

        // 10. Test Network Exceptions
        val unknownHostMsg = GeminiService.formatExceptionMessage(java.net.UnknownHostException("Unable to resolve host"))
        assertTrue("UnknownHost should mention internet connection", unknownHostMsg.contains("الإنترنت") || unknownHostMsg.contains("الخادم"))

        val socketTimeoutMsg = GeminiService.formatExceptionMessage(java.net.SocketTimeoutException("timeout"))
        assertTrue("SocketTimeout should mention timeout", socketTimeoutMsg.contains("مهلة"))

        val connectMsg = GeminiService.formatExceptionMessage(java.net.ConnectException("Connection refused"))
        assertTrue("ConnectException should mention failed connection", connectMsg.contains("الاتصال"))
    }

    @Test
    fun testKeySanitizationAndDiagnosticLog() {
        val rawErrorWithKey = "Request failed for url: https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=AIzaSyFakeSecretKeyABC1234567890XYZ"
        val sanitized = GeminiService.sanitizeErrorMessage(rawErrorWithKey)
        assertTrue("API Key must be redacted", !sanitized.contains("AIzaSyFakeSecretKeyABC1234567890XYZ"))
        assertTrue("Sanitized string should contain REDACTED", sanitized.contains("REDACTED"))

        // Test Diagnostic Log Recording
        GeminiService.recordDiagnosticLog(
            httpCode = 404,
            endpointType = "الاتصال المباشر",
            sanitizedReason = "Model not found",
            errorCategory = "ENDPOINT_NOT_FOUND"
        )
        val log = GeminiService.lastDiagnosticLog.value
        assertNotNull("Diagnostic log must be recorded", log)
        assertEquals(404, log?.httpCode)
        assertEquals("ENDPOINT_NOT_FOUND", log?.errorCategory)
        assertTrue("Timestamp must not be empty", !log?.timestamp.isNullOrBlank())
    }

    @Test
    fun testPlantDiagnosisInputRetentionAndOperationalPipeline() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val app = context as android.app.Application
            val viewModel = com.example.ui.PlantDoctorViewModel(app)

            // Set inputs
            viewModel.setDiagnosisPlantType("طماطم جبلية")
            viewModel.setDiagnosisLocation("دفيئة بلاستيكية")
            viewModel.setDiagnosisAffectedPart("الأوراق")
            viewModel.setDiagnosisUserSymptoms("اصفرار في الحواف وبقع داكنة")

            assertEquals("طماطم جبلية", viewModel.diagnosisPlantTypeInput.value)
            assertEquals("دفيئة بلاستيكية", viewModel.diagnosisLocation.value)
            assertEquals("الأوراق", viewModel.diagnosisAffectedPart.value)
            assertEquals("اصفرار في الحواف وبقع داكنة", viewModel.diagnosisUserSymptoms.value)

            // Create a real temporary test image file with real JPEG bitmap bytes
            val testImageFile = java.io.File(context.cacheDir, "test_plant_sample.jpg")
            val bitmap = android.graphics.Bitmap.createBitmap(200, 200, android.graphics.Bitmap.Config.RGB_565)
            val fos = java.io.FileOutputStream(testImageFile)
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, fos)
            fos.close()
            assertTrue("Test image must exist on disk", testImageFile.exists())

            // Set image in ViewModel
            viewModel.setImageForDiagnosis(testImageFile)
            assertEquals(testImageFile.absolutePath, viewModel.selectedImageFile.value?.absolutePath)

            // Execute diagnosis flow directly via GeminiService to test real pipeline behaviour
            val realCallResult = GeminiService.diagnosePlant(
                imageFile = testImageFile,
                plantTypeInput = "طماطم جبلية",
                plantLocation = "دفيئة بلاستيكية",
                affectedPart = "الأوراق",
                userSymptoms = "اصفرار في الحواف"
            )

            // In test environment without runtime GEMINI_API_KEY injected into .env,
            // it must report the clear, honest configuration failure (not "الخوادم تحت الصيانة"!)
            assertTrue("Call in unit test without runtime key must fail truthfully", realCallResult.isFailure)
            val errorMsg = realCallResult.exceptionOrNull()?.message ?: ""
            assertTrue(
                "Error message must specify API key configuration or Secrets panel rather than false maintenance message: $errorMsg",
                errorMsg.contains("Gemini API") || errorMsg.contains("Secrets") || errorMsg.contains("المفتاح")
            )

            // Verify inputs are preserved
            assertEquals("طماطم جبلية", viewModel.diagnosisPlantTypeInput.value)
            assertEquals(testImageFile.absolutePath, viewModel.selectedImageFile.value?.absolutePath)

            // Cleanup
            testImageFile.delete()
        }
    }

    @Test
    fun testDatabaseStartsCleanWithoutMockSeedData() = runBlocking {
        val repo = com.example.data.repository.PlantRepository(db)
        repo.seedInitialDataIfEmpty()

        val plants = db.plantDao().getAllPlants().first()
        assertTrue("Plant database should start clean without fake seeded plants", plants.isEmpty())

        val diagnoses = db.diagnosisDao().getAllDiagnoses().first()
        assertTrue("Diagnoses should start clean without fake pre-written diagnoses", diagnoses.isEmpty())

        val tasks = db.careTaskDao().getPendingTasks().first()
        assertTrue("Care tasks should start clean without fake demo tasks", tasks.isEmpty())

        val chat = db.chatMessageDao().getAllMessages().first()
        assertTrue("Chat should start clean without fake canned responses", chat.isEmpty())
    }

    @Test
    fun testCleanUserProfileDefaults() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = UserProfileManager(context)
        val profile = manager.userProfile.value

        assertTrue("Default email should not contain fake domain like farmer@bustan.dz", !profile.email.contains("bustan.dz"))
        assertTrue("Default wilaya should start empty to require user selection", profile.wilayaOrCity.isBlank())
    }
}
