package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.EventType
import com.example.data.model.LoveCategory
import com.example.data.model.LoveQuotesRepository
import com.example.data.model.SpecialEvent
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("طقس القلوب", appName)
  }

  @Test
  fun `verify love quotes repository returns algerian and romantic quotes`() {
    val dailyQuote = LoveQuotesRepository.getDailyQuote()
    assertNotNull(dailyQuote)
    assertTrue(dailyQuote.text.isNotBlank())

    val algerianQuote = LoveQuotesRepository.getRandomQuote(LoveCategory.ALGERIAN)
    assertNotNull(algerianQuote)
    assertTrue(algerianQuote.isAlgerian)
  }

  @Test
  fun `verify anniversary countdown calculations`() {
    val event = SpecialEvent(
      id = "test_1",
      title = "عيد ميلاد حبيبتي",
      year = 2020,
      month = 8,
      day = 25,
      eventType = EventType.HER_BIRTHDAY
    )
    val daysUntil = event.daysUntilNext()
    assertTrue(daysUntil in 0..366)
    assertTrue(event.totalDaysPassed() > 0)
  }

  @Test
  fun `verify romantic themes and card styles are available`() {
    val themes = com.example.ui.theme.RomanticTheme.values()
    assertTrue(themes.size >= 6)
    val ruby = com.example.ui.theme.RomanticTheme.fromId("ROSE_RUBY")
    assertEquals("ROSE_RUBY", ruby.id)

    val styles = com.example.ui.theme.CardTransparencyStyle.values()
    assertTrue(styles.size >= 3)
  }
}
