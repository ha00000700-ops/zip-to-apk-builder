package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AlgeriaWilayasData
import androidx.test.core.app.ActivityScenario
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `launch MainActivity directly without crash`() {
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.onActivity { activity ->
            assertNotNull(activity)
        }
        scenario.close()
    }

    @Test
    fun `read string from context matches app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("خدملي DZ", appName)
    }

    @Test
    fun `verify all 58 Algerian Wilayas exist in dataset`() {
        val wilayas = AlgeriaWilayasData.allWilayas
        assertEquals(58, wilayas.size)
        assertEquals(1, wilayas.first().code)
        assertEquals("أدرار", wilayas.first().nameAr)
        assertEquals(58, wilayas.last().code)
        assertEquals("المنيعة", wilayas.last().nameAr)
    }

    @Test
    fun `verify communes exist for major wilayas`() {
        val algerCommunes = AlgeriaWilayasData.getCommunesForWilaya(16)
        assertTrue(algerCommunes.isNotEmpty())
        assertTrue(algerCommunes.any { it.contains("الجزائر الوسطى") })

        val oranCommunes = AlgeriaWilayasData.getCommunesForWilaya(31)
        assertTrue(oranCommunes.isNotEmpty())
        assertTrue(oranCommunes.any { it.contains("وهران") })

        val constantineCommunes = AlgeriaWilayasData.getCommunesForWilaya(25)
        assertTrue(constantineCommunes.isNotEmpty())
        assertTrue(constantineCommunes.any { it.contains("قسنطينة") })
    }
}
