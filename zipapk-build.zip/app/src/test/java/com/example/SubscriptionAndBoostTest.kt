package com.example

import com.example.data.model.AdBoostPackage
import com.example.data.model.AdStatus
import com.example.data.model.PaymentStatus
import com.example.data.model.PromotedAd
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.SubscriptionPlan
import com.example.data.model.SubscriptionStatus
import com.example.data.model.UserSubscription
import org.junit.Assert.*
import org.junit.Test

class SubscriptionAndBoostTest {

    // ==========================================
    // 1. Monthly Subscription Plans Verification
    // ==========================================
    @Test
    fun `verify monthly subscription plans configuration`() {
        // Plan 1: BASIC - 500 DZD / 1 month
        val basic = SubscriptionPlan.BASIC
        assertEquals("BASIC", basic.code)
        assertEquals(500L, basic.priceDzd)
        assertEquals(1, basic.tierLevel)
        assertEquals("الخطة الأساسية", basic.displayNameAr)

        // Plan 2: STANDARD - 1000 DZD / 1 month
        val standard = SubscriptionPlan.STANDARD
        assertEquals("STANDARD", standard.code)
        assertEquals(1000L, standard.priceDzd)
        assertEquals(2, standard.tierLevel)
        assertEquals("الخطة القياسية", standard.displayNameAr)

        // Plan 3: PREMIUM - 1500 DZD / 1 month
        val premium = SubscriptionPlan.PREMIUM
        assertEquals("PREMIUM", premium.code)
        assertEquals(1500L, premium.priceDzd)
        assertEquals(3, premium.tierLevel)
        assertEquals("الخطة المميزة", premium.displayNameAr)
    }

    @Test
    fun `verify subscription plan resolution from Code`() {
        assertEquals(SubscriptionPlan.BASIC, SubscriptionPlan.fromCode("BASIC"))
        assertEquals(SubscriptionPlan.STANDARD, SubscriptionPlan.fromCode("STANDARD"))
        assertEquals(SubscriptionPlan.PREMIUM, SubscriptionPlan.fromCode("PREMIUM"))
        assertEquals(SubscriptionPlan.PREMIUM, SubscriptionPlan.fromCode("PRO"))
        assertEquals(SubscriptionPlan.FREE, SubscriptionPlan.fromCode("UNKNOWN_CODE"))
    }

    @Test
    fun `verify subscription active and expired status logic`() {
        val now = System.currentTimeMillis()

        // Active Provider with Premium subscription
        val activeSub = UserSubscription(
            plan = SubscriptionPlan.PREMIUM,
            status = SubscriptionStatus.ACTIVE,
            startDate = now - 10000L,
            endDate = now + 86400000L * 15, // 15 days in future
            amount = 1500L
        )
        assertTrue("Subscription with future expiration must be active", activeSub.isSubscribed)
        assertEquals(3, activeSub.tierLevel)

        // Expired Subscription
        val expiredSub = UserSubscription(
            plan = SubscriptionPlan.PREMIUM,
            status = SubscriptionStatus.ACTIVE,
            startDate = now - 86400000L * 35,
            endDate = now - 1000L, // In the past
            amount = 1500L
        )
        assertFalse("Subscription with past expiration must NOT be active", expiredSub.isSubscribed)
        assertEquals(0, expiredSub.tierLevel)
    }

    // ==========================================
    // 2. Promotional Boost Packages Verification
    // ==========================================
    @Test
    fun `verify promotional boost packages configuration`() {
        // Boost 1: BOOST_BASIC - 100 DZD / 3 days
        val boostBasic = AdBoostPackage.BASIC
        assertEquals("BOOST_BASIC", boostBasic.id)
        assertEquals(100, boostBasic.priceDzd)
        assertEquals(3, boostBasic.durationDays)
        assertEquals(1, boostBasic.priorityLevel)

        // Boost 2: BOOST_STANDARD - 250 DZD / 7 days
        val boostStandard = AdBoostPackage.STANDARD
        assertEquals("BOOST_STANDARD", boostStandard.id)
        assertEquals(250, boostStandard.priceDzd)
        assertEquals(7, boostStandard.durationDays)
        assertEquals(2, boostStandard.priorityLevel)

        // Boost 3: BOOST_PREMIUM - 500 DZD / 30 days
        val boostPremium = AdBoostPackage.PREMIUM
        assertEquals("BOOST_PREMIUM", boostPremium.id)
        assertEquals(500, boostPremium.priceDzd)
        assertEquals(30, boostPremium.durationDays)
        assertEquals(3, boostPremium.priorityLevel)
        assertTrue(boostPremium.isRecommended)
    }

    @Test
    fun `verify boost package resolution from ID`() {
        assertEquals(AdBoostPackage.BASIC, AdBoostPackage.fromId("BOOST_BASIC"))
        assertEquals(AdBoostPackage.STANDARD, AdBoostPackage.fromId("BOOST_STANDARD"))
        assertEquals(AdBoostPackage.PREMIUM, AdBoostPackage.fromId("BOOST_PREMIUM"))
        assertEquals(AdBoostPackage.BASIC, AdBoostPackage.fromId("INVALID_ID"))
    }

    @Test
    fun `verify promoted ad active and expired status logic`() {
        val now = System.currentTimeMillis()

        // Active Ad
        val activeAd = PromotedAd(
            id = "ad_1",
            providerId = "prov_1",
            packageId = "BOOST_PREMIUM",
            status = AdStatus.ACTIVE,
            paymentStatus = PaymentStatus.SUCCESSFUL,
            startDate = now - 10000L,
            endDate = now + 86400000L * 10, // 10 days remaining
            priorityLevel = 3
        )
        assertTrue(activeAd.isActive)

        // Expired Ad
        val expiredAd = PromotedAd(
            id = "ad_2",
            providerId = "prov_2",
            packageId = "BOOST_BASIC",
            status = AdStatus.ACTIVE,
            paymentStatus = PaymentStatus.SUCCESSFUL,
            startDate = now - 86400000L * 5,
            endDate = now - 1000L, // Ended
            priorityLevel = 1
        )
        assertFalse(expiredAd.isActive)

        // Unpaid / Pending Ad
        val pendingAd = PromotedAd(
            id = "ad_3",
            providerId = "prov_3",
            packageId = "BOOST_STANDARD",
            status = AdStatus.PENDING_PAYMENT,
            paymentStatus = PaymentStatus.UNPAID,
            startDate = 0L,
            endDate = 0L
        )
        assertFalse(pendingAd.isActive)
    }

    // ==========================================
    // 3. Search Ranking Verification
    // Priority: Promoted Ad (3 > 2 > 1 > 0) -> Subscription (3 > 2 > 1 > 0) -> Rating -> ReviewCount -> CompletedJobs
    // ==========================================
    @Test
    fun `verify search ranking order with boost priority, subscription tier, and rating`() {
        val now = System.currentTimeMillis()

        // Provider A: Free tier, but with Active BOOST_PREMIUM ad (priority 3)
        val providerA = ServiceProviderProfile(
            uid = "prov_A",
            fullName = "حرفي أ (مروّج باقة مميزة)",
            subscriptionPlan = "FREE",
            subscriptionStatus = "NONE",
            rating = 4.0,
            reviewCount = 5,
            completedJobsCount = 10
        )
        val adA = PromotedAd(
            id = "ad_A",
            providerId = "prov_A",
            packageId = "BOOST_PREMIUM",
            status = AdStatus.ACTIVE,
            paymentStatus = PaymentStatus.SUCCESSFUL,
            startDate = now,
            endDate = now + 86400000L,
            priorityLevel = 3
        )

        // Provider B: Premium monthly subscriber (level 3), but no active boost ad (ad priority 0)
        val providerB = ServiceProviderProfile(
            uid = "prov_B",
            fullName = "حرفي ب (مشترك VIP)",
            subscriptionPlan = "PREMIUM",
            subscriptionStatus = "ACTIVE",
            rating = 4.9,
            reviewCount = 50,
            completedJobsCount = 80
        )

        // Provider C: Free tier, BOOST_BASIC ad (priority 1)
        val providerC = ServiceProviderProfile(
            uid = "prov_C",
            fullName = "حرفي ج (مروّج باقة أساسية)",
            subscriptionPlan = "FREE",
            subscriptionStatus = "FREE",
            rating = 4.5,
            reviewCount = 10,
            completedJobsCount = 20
        )
        val adC = PromotedAd(
            id = "ad_C",
            providerId = "prov_C",
            packageId = "BOOST_BASIC",
            status = AdStatus.ACTIVE,
            paymentStatus = PaymentStatus.SUCCESSFUL,
            startDate = now,
            endDate = now + 86400000L,
            priorityLevel = 1
        )

        // Provider D: Free tier, no ad, low rating
        val providerD = ServiceProviderProfile(
            uid = "prov_D",
            fullName = "حرفي د (عادي)",
            subscriptionPlan = "FREE",
            subscriptionStatus = "FREE",
            rating = 3.5,
            reviewCount = 2,
            completedJobsCount = 5
        )

        val activeAds = listOf(adA, adC)
        val activeAdsByProvider = activeAds.filter { it.isActive }.associateBy { it.providerId }

        val unsortedList = listOf(providerD, providerB, providerC, providerA)

        val sortedList = unsortedList.sortedWith(
            compareByDescending<ServiceProviderProfile> { provider ->
                activeAdsByProvider[provider.uid]?.priorityLevel ?: 0
            }
            .thenByDescending { it.subscriptionTierLevel }
            .thenByDescending { it.rating }
            .thenByDescending { it.reviewCount }
            .thenByDescending { it.completedJobsCount }
        )

        // Ranking must be:
        // 1. Provider A (Boost Level 3)
        // 2. Provider C (Boost Level 1)
        // 3. Provider B (Boost Level 0, but Subscription Level 3)
        // 4. Provider D (Boost Level 0, Subscription Level 0)
        assertEquals("prov_A", sortedList[0].uid)
        assertEquals("prov_C", sortedList[1].uid)
        assertEquals("prov_B", sortedList[2].uid)
        assertEquals("prov_D", sortedList[3].uid)
    }

    // ==========================================
    // 4. Payment Failure and Cancellation Verification
    // ==========================================
    @Test
    fun `failed and cancelled payments must not activate ads or subscriptions`() {
        val failedAd = PromotedAd(
            id = "ad_fail",
            providerId = "prov_fail",
            status = AdStatus.PENDING_PAYMENT,
            paymentStatus = PaymentStatus.FAILED,
            startDate = 0L,
            endDate = 0L
        )
        assertFalse("Failed payment ad must NOT be active", failedAd.isActive)

        val cancelledAd = PromotedAd(
            id = "ad_cancel",
            providerId = "prov_cancel",
            status = AdStatus.CANCELLED,
            paymentStatus = PaymentStatus.CANCELLED,
            startDate = 0L,
            endDate = 0L
        )
        assertFalse("Cancelled ad must NOT be active", cancelledAd.isActive)
    }
}
