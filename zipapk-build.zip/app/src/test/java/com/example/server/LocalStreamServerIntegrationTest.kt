package com.example.server

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.Socket
import java.net.URL

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalStreamServerIntegrationTest {

    private var server: LocalStreamServer? = null
    private val testPin = "7412"

    @Before
    fun setUp() {
        // Port 0 tells the OS to assign an available ephemeral port automatically
        server = LocalStreamServer(
            port = 0,
            pinSecurityEnabled = true,
            pairingPin = testPin
        )
        server?.start()
        assertTrue("Server socket must be bound", (server?.actualPort ?: 0) > 0)
    }

    @After
    fun tearDown() {
        server?.stop()
        server = null
    }

    @Test
    fun testUnauthorizedStreamRequestReturns401() = runBlocking {
        val port = server!!.actualPort
        val socket = Socket("127.0.0.1", port)
        val out = socket.getOutputStream()
        val inStream = socket.getInputStream()

        // Request without PIN
        val request = "GET /stream HTTP/1.1\r\nHost: 127.0.0.1:$port\r\nConnection: close\r\n\r\n"
        out.write(request.toByteArray())
        out.flush()

        val reader = BufferedReader(InputStreamReader(inStream))
        val statusLine = reader.readLine()

        assertNotNull(statusLine)
        assertTrue(statusLine!!.contains("401 Unauthorized"))
        socket.close()
    }

    @Test
    fun testAuthorizedStreamRequestSucceedsWithMjpegHeaders() = runBlocking {
        val port = server!!.actualPort
        val socket = Socket("127.0.0.1", port)
        val out = socket.getOutputStream()
        val inStream = socket.getInputStream()

        // Request with valid PIN in query parameter
        val request = "GET /stream?pin=$testPin HTTP/1.1\r\nHost: 127.0.0.1:$port\r\nConnection: close\r\n\r\n"
        out.write(request.toByteArray())
        out.flush()

        val reader = BufferedReader(InputStreamReader(inStream))
        val statusLine = reader.readLine()
        assertNotNull(statusLine)
        assertTrue(statusLine!!.contains("200 OK"))

        var hasMultipartHeader = false
        for (i in 0..10) {
            val line = reader.readLine() ?: break
            if (line.isEmpty()) break
            if (line.contains("multipart/x-mixed-replace")) {
                hasMultipartHeader = true
            }
        }
        assertTrue("Server must return multipart/x-mixed-replace content-type", hasMultipartHeader)

        // Broadcast a test frame and verify transmission
        val sampleFrame = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0x01, 0x02, 0xFF.toByte(), 0xD9.toByte())
        server?.broadcastFrame(sampleFrame)

        delay(100)
        assertTrue(server?.totalBytesTransferred ?: 0L > 0L)

        socket.close()
    }

    @Test
    fun testStatusEndpointReturnsLiveMetrics() = runBlocking {
        val port = server!!.actualPort
        val url = URL("http://127.0.0.1:$port/status")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 3000
        conn.readTimeout = 3000
        conn.connect()

        assertEquals(200, conn.responseCode)
        val responseBody = conn.inputStream.bufferedReader().use { it.readText() }

        assertTrue(responseBody.contains("\"status\""))
        assertTrue(responseBody.contains("\"fps\""))
        assertTrue(responseBody.contains("\"clients\""))
        assertTrue(responseBody.contains("\"pinRequired\":true"))
        conn.disconnect()
    }

    @Test
    fun testKeepaliveDuringSystemPauseState() = runBlocking {
        val port = server!!.actualPort
        val socket = Socket("127.0.0.1", port)
        val out = socket.getOutputStream()
        val inStream = socket.getInputStream()

        val request = "GET /stream?pin=$testPin HTTP/1.1\r\nHost: 127.0.0.1:$port\r\nConnection: close\r\n\r\n"
        out.write(request.toByteArray())
        out.flush()

        var clients = 0
        for (i in 0..10) {
            clients = server?.activeClientsCount ?: 0
            if (clients > 0) break
            delay(50)
        }
        assertEquals(1, clients)

        // Trigger Messenger pause state
        server?.isPausedBySystem = true
        delay(100)

        // Verify socket is still active and connected
        assertFalse(socket.isClosed)
        assertTrue(socket.isConnected)

        // Verify server status reflects paused
        val statusUrl = URL("http://127.0.0.1:$port/status")
        val conn = statusUrl.openConnection() as HttpURLConnection
        assertEquals(200, conn.responseCode)
        val responseBody = conn.inputStream.bufferedReader().use { it.readText() }
        assertTrue(responseBody.contains("\"status\":\"paused\""))

        conn.disconnect()
        socket.close()
    }
}
