package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.example.model.LogLevel
import com.example.model.StreamConfig
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureEngine(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val config: StreamConfig,
    private val onFrameEncoded: (jpegData: ByteArray, encodeDurationMs: Long) -> Unit,
    private val onSessionInterrupted: (reason: String) -> Unit,
    private val onLogEvent: (source: String, message: String, details: String, level: LogLevel) -> Unit
) {
    private val tag = "ScreenCaptureEngine"
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private val isCapturing = AtomicBoolean(false)
    private var lastFrameTime = 0L
    private val minFrameIntervalMs = 1000L / config.fps

    // Pre-allocated reusable bitmap and byte buffer to eliminate GC allocations
    private var reusableBitmap: Bitmap? = null
    private val jpegBuffer = ByteArrayOutputStream(192 * 1024)

    @Volatile
    var currentJpegQuality: Int = config.jpegQuality

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            super.onStop()
            Log.w(tag, "MediaProjection.Callback.onStop() triggered by Android OS!")
            onLogEvent(
                "AOSP MediaProjectionManagerService",
                "تم استدعاء Callback.onStop() بواسطة نظام Android",
                "قام تطبيق آخر (مثل Facebook Messenger أو أداة تسجيل أخرى) ببدء التقاط الشاشة، مما دفع نظام Android لإلغاء تفويض تطبيقنا إجبارياً بحسب معمارية التنافي الحصري.",
                LogLevel.CRITICAL
            )
            onSessionInterrupted("توقف البث: تطبيق خارجي (مثل Messenger) بدأ مشاركة الشاشة.")
            stop()
        }
    }

    fun start() {
        if (isCapturing.getAndSet(true)) return

        try {
            onLogEvent(
                "ScreenCaptureEngine",
                "بدء إعداد التقاط الشاشة المطور",
                "الدقة: ${config.width}x${config.height} @ ${config.fps}fps، كثافة الشاشة: ${config.dpi}dpi، جودة الترميز: $currentJpegQuality%",
                LogLevel.INFO
            )

            // Allocate reusable bitmap once
            reusableBitmap = Bitmap.createBitmap(config.width, config.height, Bitmap.Config.ARGB_8888)

            val thread = HandlerThread("ScreenCaptureThread").apply { start() }
            backgroundThread = thread
            backgroundHandler = Handler(thread.looper)

            // Register callback to intercept Messenger conflict
            mediaProjection.registerCallback(projectionCallback, backgroundHandler)

            // Create ImageReader with maxImages = 2 for low memory footprint
            val reader = ImageReader.newInstance(
                config.width,
                config.height,
                PixelFormat.RGBA_8888,
                2
            )
            imageReader = reader

            reader.setOnImageAvailableListener({ ir ->
                handleImageAvailable(ir)
            }, backgroundHandler)

            // Create VirtualDisplay
            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR or DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
            virtualDisplay = mediaProjection.createVirtualDisplay(
                "CastDirectVirtualDisplay",
                config.width,
                config.height,
                config.dpi,
                flags,
                reader.surface,
                null,
                backgroundHandler
            )

            onLogEvent(
                "VirtualDisplay",
                "تم ربط الشاشة الافتراضية بنجاح",
                "Surface موصول مع حماية الذاكرة ومنع تسريب الـ Bitmaps",
                LogLevel.INFO
            )
        } catch (e: Exception) {
            Log.e(tag, "Failed to start capture: ${e.message}", e)
            onLogEvent("ScreenCaptureEngine", "فشل بدء الالتقاط", e.localizedMessage ?: "Unknown error", LogLevel.ERROR)
            stop()
        }
    }

    private fun handleImageAvailable(reader: ImageReader) {
        if (!isCapturing.get()) return

        var image: Image? = null
        val startTime = System.currentTimeMillis()

        try {
            image = reader.acquireLatestImage() ?: return

            val now = System.currentTimeMillis()
            if (now - lastFrameTime < minFrameIntervalMs) {
                // Drop frame to enforce configured target FPS and conserve Wi-Fi bandwidth
                return
            }
            lastFrameTime = now

            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * config.width

            val targetBitmap = reusableBitmap ?: return

            if (rowPadding == 0) {
                // Optimal zero-allocation path
                buffer.rewind()
                targetBitmap.copyPixelsFromBuffer(buffer)

                jpegBuffer.reset()
                targetBitmap.compress(Bitmap.CompressFormat.JPEG, currentJpegQuality, jpegBuffer)
            } else {
                // Row padding offset handling with reusable stride copy
                val paddedBitmap = Bitmap.createBitmap(
                    config.width + rowPadding / pixelStride,
                    config.height,
                    Bitmap.Config.ARGB_8888
                )
                paddedBitmap.copyPixelsFromBuffer(buffer)
                val clean = Bitmap.createBitmap(paddedBitmap, 0, 0, config.width, config.height)
                paddedBitmap.recycle()

                jpegBuffer.reset()
                clean.compress(Bitmap.CompressFormat.JPEG, currentJpegQuality, jpegBuffer)
                clean.recycle()
            }

            val jpegData = jpegBuffer.toByteArray()
            val encodeDurationMs = System.currentTimeMillis() - startTime
            onFrameEncoded(jpegData, encodeDurationMs)

        } catch (e: Exception) {
            // Buffer acquisition error or surface shutdown
        } finally {
            try {
                image?.close()
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        if (!isCapturing.getAndSet(false)) return

        try {
            mediaProjection.unregisterCallback(projectionCallback)
        } catch (_: Exception) {}

        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (_: Exception) {}

        try {
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}

        try {
            backgroundThread?.quitSafely()
            backgroundThread = null
            backgroundHandler = null
        } catch (_: Exception) {}

        reusableBitmap?.recycle()
        reusableBitmap = null

        onLogEvent(
            "ScreenCaptureEngine",
            "تم إيقاف محرك التقاط الشاشة",
            "تم تحرير مصادر الـ VirtualDisplay بنجاح",
            LogLevel.INFO
        )
    }
}
