package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.example.model.LogLevel
import com.example.model.StreamConfig
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureEngine(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val config: StreamConfig,
    private val onFrameEncoded: (jpegData: ByteArray, encodeDurationMs: Long) -> Unit,
    private val onSessionInterrupted: (reason: String) -> Unit,
    private val onLogEvent: (source: String, message: String, details: String, level: LogLevel) -> Unit
) {
    private val tag = "ScreenCaptureEngine"
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    private val isCapturing = AtomicBoolean(false)
    private var lastFrameTime = 0L
    private val minFrameIntervalMs = 1000L / config.fps

    // Pre-allocated reusable bitmap and byte buffer to eliminate GC allocations
    private var reusableBitmap: Bitmap? = null
    private var cleanByteBuffer: ByteBuffer? = null
    private val jpegBuffer = ByteArrayOutputStream(192 * 1024)

    @Volatile
    var currentJpegQuality: Int = config.jpegQuality

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            super.onStop()
            Log.w(tag, "MediaProjection.Callback.onStop() triggered by Android OS!")
            onLogEvent(
                "AOSP MediaProjectionManagerService",
                "تم استدعاء Callback.onStop() بواسطة نظام Android",
                "قام تطبيق آخر (مثل Facebook Messenger أو أداة تسجيل أخرى) ببدء التقاط الشاشة، مما دفع نظام Android لإلغاء تفويض تطبيقنا إجبارياً بحسب معمارية التنافي الحصري.",
                LogLevel.CRITICAL
            )
            onSessionInterrupted("توقف البث: تطبيق خارجي (مثل Messenger) بدأ مشاركة الشاشة.")
            stop()
        }
    }

    fun start() {
        if (isCapturing.getAndSet(true)) return

        try {
            onLogEvent(
                "ScreenCaptureEngine",
                "بدء إعداد التقاط الشاشة المطور",
                "الدقة: ${config.width}x${config.height} @ ${config.fps}fps، كثافة الشاشة: ${config.dpi}dpi، جودة الترميز: $currentJpegQuality%",
                LogLevel.INFO
            )

            // Allocate reusable bitmap and direct byte buffer once
            reusableBitmap = Bitmap.createBitmap(config.width, config.height, Bitmap.Config.ARGB_8888)
            cleanByteBuffer = ByteBuffer.allocateDirect(config.width * config.height * 4)

            val thread = HandlerThread("ScreenCaptureThread").apply { start() }
            backgroundThread = thread
            backgroundHandler = Handler(thread.looper)

            // Register callback to intercept Messenger conflict
            mediaProjection.registerCallback(projectionCallback, backgroundHandler)

            // Create ImageReader with maxImages = 2 for low memory footprint
            val reader = ImageReader.newInstance(
                config.width,
                config.height,
                PixelFormat.RGBA_8888,
                2
            )
            imageReader = reader

            reader.setOnImageAvailableListener({ ir ->
                handleImageAvailable(ir)
            }, backgroundHandler)

            // Create VirtualDisplay - use only VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR for user applications
            val flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR
            val vd = mediaProjection.createVirtualDisplay(
                "CastDirectVirtualDisplay",
                config.width,
                config.height,
                config.dpi,
                flags,
                reader.surface,
                null,
                backgroundHandler
            )
            if (vd == null) {
                throw IllegalStateException("فشل النظام في إنشاء الشاشة الافتراضية VirtualDisplay")
            }
            virtualDisplay = vd

            onLogEvent(
                "VirtualDisplay",
                "تم ربط الشاشة الافتراضية بنجاح",
                "Surface موصول مع حماية الذاكرة ومنع تسريب الـ Bitmaps",
                LogLevel.INFO
            )
        } catch (e: Exception) {
            Log.e(tag, "Failed to start capture: ${e.message}", e)
            onLogEvent("ScreenCaptureEngine", "فشل بدء الالتقاط", e.localizedMessage ?: "Unknown error", LogLevel.ERROR)
            stop()
            throw e
        }
    }

    fun resetFramePacing() {
        lastFrameTime = 0L
    }

    private fun handleImageAvailable(reader: ImageReader) {
        if (!isCapturing.get()) return

        var image: Image? = null
        val startTime = System.currentTimeMillis()

        try {
            image = reader.acquireLatestImage() ?: return

            val now = System.currentTimeMillis()
            // 4ms jitter tolerance allows 60Hz/120Hz display refresh to cleanly hit 30fps without dropping every 2nd frame
            if (now - lastFrameTime < (minFrameIntervalMs - 4L)) {
                return
            }
            lastFrameTime = now

            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * config.width

            val targetBitmap = reusableBitmap ?: return

            if (rowPadding == 0) {
                // Optimal zero-allocation path
                buffer.rewind()
                targetBitmap.copyPixelsFromBuffer(buffer)
            } else {
                // Zero-allocation row copy using pre-allocated direct ByteBuffer (eliminates GC pauses)
                val clean = cleanByteBuffer ?: return
                clean.clear()
                val rowBytes = config.width * pixelStride
                for (row in 0 until config.height) {
                    val offset = row * rowStride
                    buffer.position(offset)
                    buffer.limit(offset + rowBytes)
                    clean.put(buffer)
                }
                clean.flip()
                targetBitmap.copyPixelsFromBuffer(clean)
            }

            jpegBuffer.reset()
            targetBitmap.compress(Bitmap.CompressFormat.JPEG, currentJpegQuality, jpegBuffer)

            val jpegData = jpegBuffer.toByteArray()
            val encodeDurationMs = System.currentTimeMillis() - startTime
            onFrameEncoded(jpegData, encodeDurationMs)

        } catch (e: Exception) {
            // Buffer acquisition error or surface shutdown
        } finally {
            try {
                image?.close()
            } catch (_: Exception) {}
        }
    }

    fun stop() {
        if (!isCapturing.getAndSet(false)) return

        try {
            mediaProjection.unregisterCallback(projectionCallback)
        } catch (_: Exception) {}

        try {
            virtualDisplay?.release()
            virtualDisplay = null
        } catch (_: Exception) {}

        try {
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}

        try {
            backgroundThread?.quitSafely()
            backgroundThread = null
            backgroundHandler = null
        } catch (_: Exception) {}

        reusableBitmap?.recycle()
        reusableBitmap = null
        cleanByteBuffer = null

        onLogEvent(
            "ScreenCaptureEngine",
            "تم إيقاف محرك التقاط الشاشة",
            "تم تحرير مصادر الـ VirtualDisplay بنجاح",
            LogLevel.INFO
        )
    }
}
