package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import com.example.model.AudioStatus
import com.example.model.LogLevel
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * AudioCaptureEngine captures internal application, media, and game audio
 * using Android's AudioPlaybackCaptureConfiguration (API 29+).
 *
 * Strict Privacy & Isolation Guarantees:
 * 1. Cellular, VoIP, and Messenger calls are EXPLICITLY EXCLUDED via AudioAttributes.USAGE_VOICE_COMMUNICATION.
 * 2. Microphone audio is NEVER recorded; only system playback from apps allowing audio capture.
 * 3. Completely decoupled from ScreenCaptureEngine: failures or permission issues in audio never affect video.
 */
class AudioCaptureEngine(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val onAudioChunkEncoded: (pcmData: ByteArray, timestamp: Long) -> Unit,
    private val onStatusChanged: (AudioStatus, String) -> Unit,
    private val onLogEvent: (source: String, message: String, details: String, level: LogLevel) -> Unit
) {
    private val tag = "AudioCaptureEngine"
    private val isCapturing = AtomicBoolean(false)
    private var captureThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    @Volatile
    var isMuted: Boolean = false

    companion object {
        const val SAMPLE_RATE = 48000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        const val BYTES_PER_SAMPLE = 2
        const val CHANNELS = 2

        // 20ms chunk = 48000 * 2 channels * 2 bytes * 0.02s = 3840 bytes (960 frames)
        const val CHUNK_DURATION_MS = 20
        const val SAMPLES_PER_CHUNK = SAMPLE_RATE * CHUNK_DURATION_MS / 1000 // 960 stereo frames
        const val CHUNK_SIZE_BYTES = SAMPLES_PER_CHUNK * CHANNELS * BYTES_PER_SAMPLE // 3840 bytes
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (isCapturing.getAndSet(true)) return

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            onLogEvent(
                "AudioCaptureEngine",
                "غير مدعوم على هذا الإصدار",
                "يتطلب Android AudioPlaybackCapture إصدار Android 10 (API 29) أو أحدث.",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.UNSUPPORTED, "يتطلب Android 10+")
            isCapturing.set(false)
            return
        }

        captureThread = Thread({
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            runCaptureLoop()
        }, "AudioPlaybackCaptureThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    @SuppressLint("MissingPermission", "NewApi")
    private fun runCaptureLoop() {
        var currentPhase = "INIT"
        try {
            onLogEvent(
                "AudioCaptureEngine",
                "تهيئة مسار صوت التطبيقات (AudioPlaybackCapture)",
                "معدل العينات: $SAMPLE_RATE Hz ستيريو 16-bit. تم استبعاد صوت المكالمات وMessenger تلقائياً.",
                LogLevel.INFO
            )
            onStatusChanged(AudioStatus.STARTING, "جاري إعداد التقاط الصوت...")

            // 1. Build Playback Capture Configuration using inclusive rules only
            currentPhase = "AUDIO_PLAYBACK_CAPTURE_CONFIG"
            Log.d(tag, "[STAGE 1] Building AudioPlaybackCaptureConfiguration with inclusive rules only...")
            val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()

            // 2. Calculate optimal buffer size & Build AudioRecord
            currentPhase = "AUDIO_RECORD_BUILD"
            val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            val bufferSize = (minBufferSize * 2).coerceAtLeast(CHUNK_SIZE_BYTES * 4)
            Log.d(tag, "[STAGE 2] Building AudioRecord (minBufferSize=$minBufferSize, bufferSize=$bufferSize)...")

            val record = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(playbackConfig)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()

            // 3. Verify AudioRecord initialization state
            currentPhase = "AUDIO_RECORD_INIT_CHECK"
            Log.d(tag, "[STAGE 3] Checking AudioRecord state: ${record.state} (1=STATE_INITIALIZED)")
            onLogEvent(
                "AudioCaptureEngine",
                "تشخيص تهيئة AudioRecord",
                "Record state=${record.state} (1=INITIALIZED), AudioFormat=$AUDIO_FORMAT, SampleRate=$SAMPLE_RATE, BufferSize=$bufferSize",
                LogLevel.INFO
            )

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                throw IllegalStateException("فشل تهيئة AudioRecord لـ AudioPlaybackCapture: record.state = ${record.state} (STATE_UNINITIALIZED)")
            }

            // 4. Start recording
            currentPhase = "AUDIO_RECORD_START"
            audioRecord = record
            record.startRecording()
            Log.d(tag, "[STAGE 4] AudioRecord.startRecording() executed. RecordingState: ${record.recordingState} (3=RECORDING)")

            onLogEvent(
                "AudioPlaybackCapture",
                "تم تشغيل التقاط صوت الوسائط بنجاح",
                "RecordingState: ${record.recordingState} | يتم التقاط صوت التطبيقات والأفلام مع عزل المكالمات.",
                LogLevel.INFO
            )
            onStatusChanged(AudioStatus.SILENT, "صوت الوسائط جاهز (في انتظار تشغيل محتوى)")

            // 5. PCM Read Loop
            currentPhase = "PCM_READ_LOOP"
            val readBuffer = ByteArray(CHUNK_SIZE_BYTES)
            var silentStreakCount = 0
            var lastCallModeNotice = 0L
            var totalBytesCaptured = 0L
            var totalChunksRead = 0L
            var lastLogTime = System.currentTimeMillis()

            while (isCapturing.get()) {
                val bytesRead = record.read(readBuffer, 0, CHUNK_SIZE_BYTES)
                if (bytesRead > 0) {
                    totalChunksRead++
                    val timestamp = System.currentTimeMillis()
                    totalBytesCaptured += bytesRead

                    if (totalChunksRead == 1L) {
                        Log.d(tag, "[STAGE 5] FIRST PCM chunk emitted from AudioCaptureEngine: $bytesRead bytes")
                        onLogEvent(
                            "AudioCaptureEngine",
                            "أول حزمة صوت متولدة",
                            "حجم أول حزمة PCM: $bytesRead بايت. إجمالي الحزم: 1",
                            LogLevel.INFO
                        )
                    }

                    // Fast peak amplitude calculation (avoids heavy floating-point math in 50Hz audio capture loop)
                    var maxAmp = 0
                    var i = 0
                    while (i < bytesRead - 1) {
                        val sample = ((readBuffer[i].toInt() and 0xFF) or (readBuffer[i + 1].toInt() shl 8)).toShort().toInt()
                        val absSample = abs(sample)
                        if (absSample > maxAmp) maxAmp = absSample
                        i += 2
                    }

                    // Periodic diagnostic log every 5 seconds
                    if (timestamp - lastLogTime > 5000) {
                        lastLogTime = timestamp
                        Log.d(
                            tag,
                            "[DIAGNOSTIC AUDIO READ] Chunks: $totalChunksRead | BytesRead: $bytesRead | " +
                                    "TotalKB: ${totalBytesCaptured / 1024} | MaxAmp: $maxAmp | " +
                                    "RecordingState: ${record.recordingState}"
                        )
                    }

                    // Check if phone or VoIP call (e.g. Messenger) is currently active
                    val currentMode = audioManager?.mode ?: AudioManager.MODE_NORMAL
                    val isCallActive = currentMode == AudioManager.MODE_IN_COMMUNICATION ||
                            currentMode == AudioManager.MODE_IN_CALL

                    if (isCallActive) {
                        val now = System.currentTimeMillis()
                        if (now - lastCallModeNotice > 5000) {
                            lastCallModeNotice = now
                            onLogEvent(
                                "PrivacyAudioGuard",
                                "رصد مكالمة صوتية (Messenger / اتصال هاتف)",
                                "صوت المكالمة معزول ومستبعد تماماً من البث للحفاظ على الخصوصية.",
                                LogLevel.INFO
                            )
                        }
                    }

                    if (isMuted) {
                        // Stream silence when muted by user
                        val silentData = ByteArray(bytesRead)
                        onAudioChunkEncoded(silentData, timestamp)
                        onStatusChanged(AudioStatus.MUTED, "الصوت مكتوم من التطبيق")
                    } else {
                        if (maxAmp > 80) {
                            silentStreakCount = 0
                            if (isCallActive) {
                                onStatusChanged(AudioStatus.CALL_EXCLUDED, "بث صوت الوسائط (المكالمة مستبعدة)")
                            } else {
                                onStatusChanged(AudioStatus.STREAMING, "بث صوت الوسائط نشط (48kHz | Peak: $maxAmp)")
                            }
                            onAudioChunkEncoded(readBuffer.copyOf(bytesRead), timestamp)
                        } else {
                            silentStreakCount++
                            if (silentStreakCount > 100) { // > 2 seconds of zero amplitude
                                val status = if (isCallActive) AudioStatus.CALL_EXCLUDED else AudioStatus.SILENT
                                val msg = if (isCallActive) "مكالمة Messenger نشطة (صوت المكالمة محمي ومستبعد)" else "صوت الوسائط هادئ (صامت)"
                                onStatusChanged(status, msg)
                            }
                            onAudioChunkEncoded(readBuffer.copyOf(bytesRead), timestamp)
                        }
                    }
                } else if (bytesRead == AudioRecord.ERROR_INVALID_OPERATION || bytesRead == AudioRecord.ERROR_BAD_VALUE) {
                    Log.w(tag, "[DIAGNOSTIC AUDIO ERROR] AudioRecord read returned error code: $bytesRead")
                    Thread.sleep(20)
                }
            }

        } catch (e: SecurityException) {
            Log.e(tag, "[AUDIO ERROR - Phase: $currentPhase] SecurityException: ${e.message}", e)
            onLogEvent(
                "AudioCaptureEngine",
                "إذن التقاط الصوت غير ممنوح [$currentPhase]",
                "SecurityException: ${e.localizedMessage}\n${e.stackTraceToString()}",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.BLOCKED_BY_APP, "إذن التقاط الصوت غير متوفر ($currentPhase: ${e.javaClass.simpleName})")
        } catch (e: Exception) {
            val exceptionName = e.javaClass.simpleName
            val exceptionMsg = e.localizedMessage ?: e.message ?: "Unknown Exception"
            val stackTrace = e.stackTraceToString()

            Log.e(tag, "[AUDIO ERROR - Phase: $currentPhase] $exceptionName: $exceptionMsg\n$stackTrace", e)
            onLogEvent(
                "AudioCaptureEngine",
                "خطأ في مسار الصوت [$currentPhase]",
                "$exceptionName: $exceptionMsg\n$stackTrace",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.ERROR, "خطأ في الصوت ($currentPhase: $exceptionName - $exceptionMsg)")
        } finally {
            cleanupAudioRecord()
        }
    }

    private fun cleanupAudioRecord() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {}
        try {
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun stop() {
        if (!isCapturing.getAndSet(false)) return

        cleanupAudioRecord()
        try {
            captureThread?.interrupt()
            captureThread = null
        } catch (_: Exception) {}

        onStatusChanged(AudioStatus.IDLE, "متوقف")
        onLogEvent("AudioCaptureEngine", "تم إيقاف محرك التقاط الصوت", "تم تحرير موارد الصوت بنجاح", LogLevel.INFO)
    }
}
