package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import com.example.model.AudioStatus
import com.example.model.LogLevel
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * AudioCaptureEngine captures internal application, media, and game audio
 * using Android's AudioPlaybackCaptureConfiguration (API 29+).
 *
 * Strict Privacy & Isolation Guarantees:
 * 1. Cellular, VoIP, and Messenger calls are EXPLICITLY EXCLUDED via AudioAttributes.USAGE_VOICE_COMMUNICATION.
 * 2. Microphone audio is NEVER recorded; only system playback from apps allowing audio capture.
 * 3. Completely decoupled from ScreenCaptureEngine: failures or permission issues in audio never affect video.
 */
class AudioCaptureEngine(
    private val context: Context,
    private val mediaProjection: MediaProjection,
    private val onAudioChunkEncoded: (pcmData: ByteArray, timestamp: Long) -> Unit,
    private val onStatusChanged: (AudioStatus, String) -> Unit,
    private val onLogEvent: (source: String, message: String, details: String, level: LogLevel) -> Unit
) {
    private val tag = "AudioCaptureEngine"
    private val isCapturing = AtomicBoolean(false)
    private var captureThread: Thread? = null
    private var audioRecord: AudioRecord? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    @Volatile
    var isMuted: Boolean = false

    companion object {
        const val SAMPLE_RATE = 48000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_STEREO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        const val BYTES_PER_SAMPLE = 2
        const val CHANNELS = 2

        // 20ms chunk = 48000 * 2 channels * 2 bytes * 0.02s = 3840 bytes (960 frames)
        const val CHUNK_DURATION_MS = 20
        const val SAMPLES_PER_CHUNK = SAMPLE_RATE * CHUNK_DURATION_MS / 1000 // 960 stereo frames
        const val CHUNK_SIZE_BYTES = SAMPLES_PER_CHUNK * CHANNELS * BYTES_PER_SAMPLE // 3840 bytes
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (isCapturing.getAndSet(true)) return

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            onLogEvent(
                "AudioCaptureEngine",
                "غير مدعوم على هذا الإصدار",
                "يتطلب Android AudioPlaybackCapture إصدار Android 10 (API 29) أو أحدث.",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.UNSUPPORTED, "يتطلب Android 10+")
            isCapturing.set(false)
            return
        }

        captureThread = Thread({
            runCaptureLoop()
        }, "AudioPlaybackCaptureThread").apply {
            priority = Thread.MAX_PRIORITY
            start()
        }
    }

    @SuppressLint("MissingPermission", "NewApi")
    private fun runCaptureLoop() {
        try {
            onLogEvent(
                "AudioCaptureEngine",
                "تهيئة مسار صوت التطبيقات (AudioPlaybackCapture)",
                "معدل العينات: $SAMPLE_RATE Hz ستيريو 16-bit. تم استبعاد صوت المكالمات وMessenger تلقائياً.",
                LogLevel.INFO
            )
            onStatusChanged(AudioStatus.STARTING, "جاري إعداد التقاط الصوت...")

            // 1. Build Playback Capture Configuration excluding Voice Communication (Messenger, phone calls)
            val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .excludeUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .excludeUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING)
                .excludeUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .build()

            // 2. Calculate optimal buffer size
            val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            val bufferSize = (minBufferSize * 2).coerceAtLeast(CHUNK_SIZE_BYTES * 4)

            // 3. Create AudioRecord
            val record = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(playbackConfig)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()

            if (record.state != AudioRecord.STATE_INITIALIZED) {
                record.release()
                throw IllegalStateException("فشل تهيئة AudioRecord لـ AudioPlaybackCapture")
            }

            audioRecord = record
            record.startRecording()

            onLogEvent(
                "AudioPlaybackCapture",
                "تم تشغيل التقاط صوت الوسائط بنجاح",
                "يتم التقاط صوت التطبيقات والأفلام المسموح بها مع فلترة المكالمات والميكروفون.",
                LogLevel.INFO
            )
            onStatusChanged(AudioStatus.SILENT, "صوت الوسائط جاهز (في انتظار تشغيل محتوى)")

            val readBuffer = ByteArray(CHUNK_SIZE_BYTES)
            var silentStreakCount = 0
            var lastCallModeNotice = 0L
            var totalBytesCaptured = 0L
            var lastLogTime = System.currentTimeMillis()

            while (isCapturing.get()) {
                val bytesRead = record.read(readBuffer, 0, CHUNK_SIZE_BYTES)
                if (bytesRead > 0) {
                    val timestamp = System.currentTimeMillis()
                    totalBytesCaptured += bytesRead

                    // Periodic log every 5 seconds to verify active audio capturing
                    if (timestamp - lastLogTime > 5000) {
                        lastLogTime = timestamp
                        onLogEvent(
                            "AudioCaptureEngine",
                            "التقاط صوت التطبيقات نشط",
                            "إجمالي PCM الملتقط: ${totalBytesCaptured / 1024} KB | إرسال حزم 48kHz للـ TV",
                            LogLevel.INFO
                        )
                    }

                    // Check if phone or VoIP call (e.g. Messenger) is currently active
                    val currentMode = audioManager?.mode ?: AudioManager.MODE_NORMAL
                    val isCallActive = currentMode == AudioManager.MODE_IN_COMMUNICATION ||
                            currentMode == AudioManager.MODE_IN_CALL

                    if (isCallActive) {
                        val now = System.currentTimeMillis()
                        if (now - lastCallModeNotice > 5000) {
                            lastCallModeNotice = now
                            onLogEvent(
                                "PrivacyAudioGuard",
                                "رصد مكالمة صوتية (Messenger / اتصال هاتف)",
                                "صوت المكالمة معزول ومستبعد تماماً من البث للحفاظ على الخصوصية.",
                                LogLevel.INFO
                            )
                        }
                    }

                    if (isMuted) {
                        // Stream silence when muted by user
                        val silentData = ByteArray(bytesRead)
                        onAudioChunkEncoded(silentData, timestamp)
                        onStatusChanged(AudioStatus.MUTED, "الصوت مكتوم من التطبيق")
                    } else {
                        // Calculate peak amplitude to differentiate active sound vs silence vs blocked audio
                        var maxAmp = 0
                        var i = 0
                        while (i < bytesRead - 1) {
                            val sample = (readBuffer[i].toInt() and 0xFF) or (readBuffer[i + 1].toInt() shl 8)
                            val absSample = abs(sample.toShort().toInt())
                            if (absSample > maxAmp) maxAmp = absSample
                            i += 2
                        }

                        if (maxAmp > 80) {
                            silentStreakCount = 0
                            if (isCallActive) {
                                onStatusChanged(AudioStatus.CALL_EXCLUDED, "بث صوت الوسائط (المكالمة مستبعدة)")
                            } else {
                                onStatusChanged(AudioStatus.STREAMING, "بث صوت الوسائط نشط (48kHz)")
                            }
                            onAudioChunkEncoded(readBuffer.copyOf(bytesRead), timestamp)
                        } else {
                            silentStreakCount++
                            // If prolonged silence while phone is in active playback, note it
                            if (silentStreakCount > 100) { // > 2 seconds of zero amplitude
                                val status = if (isCallActive) AudioStatus.CALL_EXCLUDED else AudioStatus.SILENT
                                val msg = if (isCallActive) "مكالمة Messenger نشطة (صوت المكالمة محمي ومستبعد)" else "صوت الوسائط هادئ (صامت)"
                                onStatusChanged(status, msg)
                            }
                            onAudioChunkEncoded(readBuffer.copyOf(bytesRead), timestamp)
                        }
                    }
                } else if (bytesRead == AudioRecord.ERROR_INVALID_OPERATION || bytesRead == AudioRecord.ERROR_BAD_VALUE) {
                    Log.w(tag, "AudioRecord read returned error: $bytesRead")
                    Thread.sleep(20)
                }
            }

        } catch (e: SecurityException) {
            Log.e(tag, "SecurityException in AudioCaptureEngine: ${e.message}", e)
            onLogEvent(
                "AudioCaptureEngine",
                "إذن التقاط الصوت غير ممنوح",
                "يلزم إذن RECORD_AUDIO لتفعيل AudioPlaybackCapture.",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.BLOCKED_BY_APP, "إذن التقاط الصوت غير متوفر")
        } catch (e: Exception) {
            Log.e(tag, "Exception in AudioCaptureEngine: ${e.message}", e)
            onLogEvent(
                "AudioCaptureEngine",
                "خطأ في مسار الصوت (الفيديو مستمر دون تأثر)",
                e.localizedMessage ?: "Unknown audio error",
                LogLevel.WARNING
            )
            onStatusChanged(AudioStatus.ERROR, "خطأ في الصوت (البث المرئي مستمر)")
        } finally {
            cleanupAudioRecord()
        }
    }

    private fun cleanupAudioRecord() {
        try {
            audioRecord?.stop()
        } catch (_: Exception) {}
        try {
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
    }

    fun stop() {
        if (!isCapturing.getAndSet(false)) return

        cleanupAudioRecord()
        try {
            captureThread?.interrupt()
            captureThread = null
        } catch (_: Exception) {}

        onStatusChanged(AudioStatus.IDLE, "متوقف")
        onLogEvent("AudioCaptureEngine", "تم إيقاف محرك التقاط الصوت", "تم تحرير موارد الصوت بنجاح", LogLevel.INFO)
    }
}
