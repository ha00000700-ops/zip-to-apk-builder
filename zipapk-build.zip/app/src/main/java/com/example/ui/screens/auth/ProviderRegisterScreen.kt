package com.example.ui.screens.auth

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.Profession
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPasswordField
import com.example.ui.components.KhedmatiPhoneField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.components.MandatoryProfessionSelector
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProviderRegisterScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onRegistrationSuccess: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(authViewModel.currentAuthUserEmail ?: "") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    // Mandatory Profession Selection
    var selectedProfessionId by remember { mutableStateOf("") }
    var selectedProfessionNameAr by remember { mutableStateOf("") }
    var selectedProfessionCategoryAr by remember { mutableStateOf("") }

    // Location
    var selectedWilayaCode by remember { mutableIntStateOf(16) } // Alger
    var selectedWilayaName by remember { mutableStateOf("الجزائر") }
    var selectedCommuneName by remember { mutableStateOf("الجزائر الوسطى") }

    // Service details
    var serviceDescription by remember { mutableStateOf("") }
    var experienceYearsText by remember { mutableStateOf("3") }

    // Field errors
    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var professionError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current
    val regState by authViewModel.providerRegState.collectAsState()

    LaunchedEffect(regState) {
        if (regState is AuthResult.Success) {
            onRegistrationSuccess()
        }
    }

    fun validateAndSubmit() {
        var isValid = true

        if (fullName.trim().isEmpty()) {
            fullNameError = "يرجى إدخال الاسم واللقب المهني"
            isValid = false
        } else {
            fullNameError = null
        }

        // Mandatory profession validation
        if (selectedProfessionId.isBlank() || selectedProfessionNameAr.isBlank()) {
            professionError = "يجب اختيار المهنة أو التخصص الحرفي لمتابعة التسجيل"
            isValid = false
        } else {
            professionError = null
        }

        if (phone.trim().isEmpty()) {
            phoneError = "يرجى إدخال رقم الهاتف للتواصل مع الزبائن"
            isValid = false
        } else if (phone.length != 10 || (!phone.startsWith("05") && !phone.startsWith("06") && !phone.startsWith("07"))) {
            phoneError = "رقم الهاتف الجزائري يجب أن يبدأ بـ 05 أو 06 أو 07 ويتكون من 10 أرقام"
            isValid = false
        } else {
            phoneError = null
        }

        if (serviceDescription.trim().isEmpty()) {
            descriptionError = "يرجى كتابة نبذة مختصرة عن خدماتك وخبرتك"
            isValid = false
        } else if (serviceDescription.trim().length < 10) {
            descriptionError = "الوصف قصير جداً، يرجى كتابة 10 أحرف على الأقل"
            isValid = false
        } else {
            descriptionError = null
        }

        if (email.trim().isEmpty()) {
            emailError = "يرجى إدخال البريد الإلكتروني"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            emailError = "صيغة البريد الإلكتروني غير صحيحة"
            isValid = false
        } else {
            emailError = null
        }

        if (password.isEmpty()) {
            passwordError = "يرجى إدخال كلمة المرور"
            isValid = false
        } else if (password.length < 6) {
            passwordError = "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل"
            isValid = false
        } else {
            passwordError = null
        }

        if (confirmPassword.isEmpty()) {
            confirmPasswordError = "يرجى تأكيد كلمة المرور"
            isValid = false
        } else if (confirmPassword != password) {
            confirmPasswordError = "كلمتا المرور غير متطابقتين"
            isValid = false
        } else {
            confirmPasswordError = null
        }

        if (isValid) {
            focusManager.clearFocus()
            val expYears = experienceYearsText.toIntOrNull() ?: 1
            authViewModel.registerServiceProvider(
                fullName = fullName.trim(),
                email = email.trim(),
                password = password,
                phone = phone.trim(),
                professionId = selectedProfessionId,
                professionNameAr = selectedProfessionNameAr,
                professionCategoryAr = selectedProfessionCategoryAr,
                wilayaCode = selectedWilayaCode,
                wilayaName = selectedWilayaName,
                communeName = selectedCommuneName,
                serviceDescription = serviceDescription.trim(),
                experienceYears = expYears
            )
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تسجيل حساب حرفي / مهني",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "انضم إلى شبكة حرفيي خدمتي",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldDark
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "أنشئ ملفك المهني المعتمد وابدأ في استقبال طلبات العمل من الزبائن في منطقتك",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Error Card if registration failed
                if (regState is AuthResult.Error) {
                    val errorMsg = (regState as AuthResult.Error).messageAr
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        colors = CardDefaults.cardColors(containerColor = ErrorRedContainer)
                    ) {
                        Text(
                            text = errorMsg,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ErrorRed,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(14.dp),
                            textAlign = TextAlign.Start
                        )
                    }
                }

                // 1. Mandatory Profession Selection (CRITICAL RULE 8)
                MandatoryProfessionSelector(
                    selectedProfessionId = selectedProfessionId,
                    onProfessionSelected = { prof: Profession ->
                        selectedProfessionId = prof.id
                        selectedProfessionNameAr = prof.nameAr
                        selectedProfessionCategoryAr = prof.categoryAr
                        if (professionError != null) professionError = null
                    },
                    isError = professionError != null,
                    errorMessage = professionError
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Full Name
                KhedmatiTextField(
                    value = fullName,
                    onValueChange = {
                        fullName = it
                        if (fullNameError != null) fullNameError = null
                    },
                    label = "الاسم واللقب المهني",
                    placeholder = "مثال: حسان بوزيد (سباك محترف)",
                    leadingIcon = Icons.Default.Person,
                    errorMessage = fullNameError,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_name"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Phone
                KhedmatiPhoneField(
                    value = phone,
                    onValueChange = {
                        phone = it
                        if (phoneError != null) phoneError = null
                    },
                    label = "رقم الهاتف المهني (05 / 06 / 07)",
                    errorMessage = phoneError,
                    leadingIcon = Icons.Default.Phone,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_phone"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Wilaya & Commune Selection
                WilayaCommuneSelector(
                    selectedWilayaCode = selectedWilayaCode,
                    selectedCommuneName = selectedCommuneName,
                    onLocationSelected = { code, wName, cName ->
                        selectedWilayaCode = code
                        selectedWilayaName = wName
                        selectedCommuneName = cName
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Experience Years
                KhedmatiTextField(
                    value = experienceYearsText,
                    onValueChange = { input ->
                        if (input.all { it.isDigit() } && input.length <= 2) {
                            experienceYearsText = input
                        }
                    },
                    label = "سنوات الخبرة في المجال",
                    placeholder = "مثال: 5",
                    leadingIcon = Icons.Default.WorkHistory,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_experience"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Service Description
                KhedmatiTextField(
                    value = serviceDescription,
                    onValueChange = {
                        serviceDescription = it
                        if (descriptionError != null) descriptionError = null
                    },
                    label = "نبذة عن الخدمات التي تقدمها",
                    placeholder = "اكتب شرحاً موجزاً عن تخصصك، المعدات التي تستخدمها، وساعات العمل المتاحة...",
                    leadingIcon = Icons.Default.Description,
                    errorMessage = descriptionError,
                    singleLine = false,
                    maxLines = 3,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_description"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Email
                KhedmatiTextField(
                    value = email,
                    onValueChange = {
                        email = it
                        if (emailError != null) emailError = null
                    },
                    label = "البريد الإلكتروني",
                    placeholder = "pro@example.dz",
                    leadingIcon = Icons.Default.Email,
                    errorMessage = emailError,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_email"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Password
                KhedmatiPasswordField(
                    value = password,
                    onValueChange = {
                        password = it
                        if (passwordError != null) passwordError = null
                    },
                    label = "كلمة المرور",
                    placeholder = "6 أحرف أو أرقام على الأقل",
                    leadingIcon = Icons.Default.Lock,
                    errorMessage = passwordError,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focusManager.moveFocus(FocusDirection.Down) }
                    ),
                    testTag = "provider_reg_password"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Confirm Password
                KhedmatiPasswordField(
                    value = confirmPassword,
                    onValueChange = {
                        confirmPassword = it
                        if (confirmPasswordError != null) confirmPasswordError = null
                    },
                    label = "تأكيد كلمة المرور",
                    placeholder = "أعد كتابة كلمة المرور",
                    leadingIcon = Icons.Default.Lock,
                    errorMessage = confirmPasswordError,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { validateAndSubmit() }
                    ),
                    testTag = "provider_reg_confirm_password"
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Submit Button
                KhedmatiPrimaryButton(
                    text = "تسجيل الملف المهني والبدء",
                    onClick = { validateAndSubmit() },
                    isLoading = regState is AuthResult.Loading,
                    testTag = "provider_reg_submit"
                )
            }

            // Already have account link
            Row(
                modifier = Modifier
                    .padding(vertical = 16.dp)
                    .clickable { onNavigateToLogin() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "لديك حساب حرفي بالفعل؟ ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "تسجيل الدخول",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
            }
        }
    }
}
