package com.example.ui.screens.home

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.BorderStroke
import com.example.ui.theme.*
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.Profession
import com.example.data.model.PromotedAd
import com.example.data.model.Review
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.ServiceRequest
import com.example.data.repository.AuthResult
import com.example.ui.viewmodel.AuthViewModel
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldContainer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material.icons.filled.ErrorOutline

@Composable
fun KhedmatiEmptyState(
    title: String,
    subtitle: String? = null,
    icon: ImageVector,
    iconColor: Color = BluePrimary,
    iconBgColor: Color = BlueContainer
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier.size(88.dp),
            shape = CircleShape,
            color = iconBgColor
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(44.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        if (subtitle != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
fun KhedmatiErrorState(message: String, onRetry: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(24.dp),
        shape = RoundedCornerShape(24.dp),
        color = ErrorRedContainer
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.ErrorOutline,
                contentDescription = null,
                tint = ErrorRed,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                color = ErrorRed,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("إعادة المحاولة", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ServiceProviderCard(
    provider: ServiceProviderProfile,
    promotedAd: PromotedAd? = null,
    onCardClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hasActiveAd = promotedAd != null && promotedAd.isActive

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable { onCardClick() }
            .testTag("provider_card_${provider.uid}"),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = if (hasActiveAd) 4.dp else 2.dp,
        border = BorderStroke(
            width = if (hasActiveAd) 1.5.dp else 1.dp,
            color = if (hasActiveAd) EmeraldPrimary.copy(alpha = 0.6f) else OutlineLight.copy(alpha = 0.5f)
        )
    ) {
        Column {
            if (hasActiveAd) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = EmeraldPrimary.copy(alpha = 0.10f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RocketLaunch,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = promotedAd?.boostPackage?.badgeLabelAr ?: "إعلان مروّج 🚀",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Black,
                                color = EmeraldPrimary
                            )
                        }

                        if (promotedAd?.adTitle?.isNotBlank() == true) {
                            Text(
                                text = promotedAd.adTitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryLight,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
            // Avatar
            Surface(
                modifier = Modifier.size(80.dp),
                shape = RoundedCornerShape(16.dp),
                color = BackgroundLight
            ) {
                Box(contentAlignment = Alignment.Center) {
                    val avatarUrl = provider.effectiveAvatarUrl()
                    if (avatarUrl.isNotBlank()) {
                        AsyncImage(
                            model = avatarUrl,
                            contentDescription = provider.fullName,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = provider.fullName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (provider.subscriptionTierLevel >= 3) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AmberPrimary.copy(alpha = 0.15f),
                                border = BorderStroke(1.dp, AmberPrimary.copy(alpha = 0.5f))
                            ) {
                                Text(
                                    text = "⭐ مميز",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = AmberDark,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else if (provider.subscriptionTierLevel == 2) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BluePrimary.copy(alpha = 0.12f),
                                border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.4f))
                            ) {
                                Text(
                                    text = "🥈 معتمد",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BluePrimary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (provider.isVerified) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "موثق",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Text(
                    text = provider.professionNameAr,
                    style = MaterialTheme.typography.labelMedium,
                    color = BluePrimary,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = TextTertiaryLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${provider.wilayaName}، ${provider.communeName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryLight
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "4.9",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = BlueDark
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "(${provider.experienceYears} سنة خبرة)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiaryLight
                    )
                }
            }
        }
    }
}
}

@Composable
fun ProfessionMarketplaceCard(
    profession: Profession,
    wilayaName: String,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("profession_card_${profession.id}"),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.15f))
    ) {
        Column(
            modifier = Modifier
                .clickable { isExpanded = !isExpanded }
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    modifier = Modifier.size(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = BlueContainer.copy(alpha = 0.35f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Handyman,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(18.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profession.nameAr,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = profession.categoryAr,
                        style = MaterialTheme.typography.labelMedium,
                        color = BluePrimary,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AmberPrimary.copy(alpha = 0.1f),
                    border = BorderStroke(1.2.dp, AmberPrimary.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = "اطلب الآن",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = AmberPrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = profession.descriptionAr,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                lineHeight = 22.sp
            )

            if (isExpanded) {
                Spacer(modifier = Modifier.height(18.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = BackgroundLight,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.05f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "الحرفيون في $wilayaName ومحيطها جاهزون لاستقبال طلبك",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}


@Composable
fun MyRequestsTab(
    paddingValues: PaddingValues,
    authViewModel: AuthViewModel,
    onNewRequest: (() -> Unit)? = null,
    onNavigateToRequestDetails: (String) -> Unit,
    onNavigateToPublicRequestDetails: (String) -> Unit = {},
    onNavigateToCreatePublicRequest: (() -> Unit)? = null
) {
    var selectedRequestType by remember { mutableIntStateOf(0) } // 0: Direct, 1: Public
    val requestsState by authViewModel.customerRequestsState.collectAsState()
    val publicRequestsState by authViewModel.customerPublicRequestsState.collectAsState()
    var selectedFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Active, 2: History

    LaunchedEffect(Unit) {
        authViewModel.observeCustomerRequests()
        authViewModel.observeCustomerPublicRequests()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
    ) {
        // Header Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BlueDark)
                .padding(16.dp)
        ) {
            Text(
                text = "طلباتي المرسلة",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "متابعة حالة طلبات الصيانة وعروض الأسعار",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Selector: Direct vs Public
            TabRow(
                selectedTabIndex = selectedRequestType,
                containerColor = BlueDark,
                contentColor = Color.White,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedRequestType]),
                        color = AmberPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedRequestType == 0,
                    onClick = { selectedRequestType = 0 },
                    text = {
                        Text(
                            text = "طلبات مباشرة (للحرفيين)",
                            fontWeight = if (selectedRequestType == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedRequestType == 1,
                    onClick = { selectedRequestType = 1 },
                    text = {
                        Text(
                            text = "طلبات عامة منشورة 📢",
                            fontWeight = if (selectedRequestType == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        if (selectedRequestType == 0) {
            // Filter Chips for Direct Requests
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedFilter == 0,
                        onClick = { selectedFilter = 0 },
                        label = { Text("جميع الطلبات") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == 1,
                        onClick = { selectedFilter = 1 },
                        label = { Text("النشطة ⏳") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = selectedFilter == 2,
                        onClick = { selectedFilter = 2 },
                        label = { Text("الأرشيف والمكتملة ✅") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            when (val state = requestsState) {
                is AuthResult.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BluePrimary)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        KhedmatiErrorState(message = state.messageAr) {
                            authViewModel.observeCustomerRequests()
                        }
                    }
                }
                is AuthResult.Success -> {
                    val allRequests = state.data
                    val filtered = remember(allRequests, selectedFilter) {
                        when (selectedFilter) {
                            1 -> allRequests.filter {
                                it.status == com.example.data.model.RequestStatus.PENDING ||
                                it.status == com.example.data.model.RequestStatus.ACCEPTED ||
                                it.status == com.example.data.model.RequestStatus.IN_PROGRESS
                            }
                            2 -> allRequests.filter {
                                it.status == com.example.data.model.RequestStatus.COMPLETED ||
                                it.status == com.example.data.model.RequestStatus.REJECTED ||
                                it.status == com.example.data.model.RequestStatus.CANCELLED
                            }
                            else -> allRequests
                        }
                    }

                    if (filtered.isEmpty()) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(top = 40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            KhedmatiEmptyState(
                                title = "ليس لديك طلبات مباشرة حالياً",
                                subtitle = "تصفح الحرفيين المتاحين في منطقتك وأرسل طلب خدمة لتظهر تفاصيله وحالته هنا.",
                                icon = Icons.Default.ListAlt
                            )
                            if (onNewRequest != null) {
                                KhedmatiPrimaryButton(
                                    text = "تصفح الحرفيين والخدمات",
                                    onClick = onNewRequest,
                                    modifier = Modifier.padding(horizontal = 48.dp)
                                )
                            }
                        }
                    } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(filtered, key = { it.id }) { req ->
                            RequestCardItem(
                                request = req,
                                onClick = { onNavigateToRequestDetails(req.id) }
                            )
                        }
                    }
                }
            }
            null -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
            else -> {}
        }
    } else {
        // Public Requests View
        when (val pState = publicRequestsState) {
            is AuthResult.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
            is AuthResult.Error -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    KhedmatiErrorState(message = pState.messageAr) {
                        authViewModel.observeCustomerPublicRequests()
                    }
                }
            }
            is AuthResult.Success -> {
                val pList = pState.data
                if (pList.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(top = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        KhedmatiEmptyState(
                            title = "لم تقم بنشر أي طلب عام بعد",
                            subtitle = "انشر طلب خدمة ليصل إلى جميع الحرفيين في ولايتك وتتلقى عروض أسعار منهم مباشرة.",
                            icon = Icons.Default.Campaign
                        )
                        if (onNavigateToCreatePublicRequest != null) {
                            KhedmatiPrimaryButton(
                                text = "نشر طلب خدمة عام 📢",
                                onClick = onNavigateToCreatePublicRequest,
                                modifier = Modifier.padding(horizontal = 48.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(pList, key = { it.id }) { pubReq ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigateToPublicRequestDetails(pubReq.id) },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = pubReq.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (pubReq.status == com.example.data.model.PublicRequestStatus.OPEN) BlueContainer else MaterialTheme.colorScheme.surfaceVariant
                                        ) {
                                            Text(
                                                text = pubReq.status.titleAr,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = if (pubReq.status == com.example.data.model.PublicRequestStatus.OPEN) BlueDark else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = pubReq.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${pubReq.professionNameAr} • ${pubReq.wilayaName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = BluePrimary,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = AmberLight
                                        ) {
                                            Text(
                                                text = "${pubReq.offersCount} عروض مستلمة 💼",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = AmberPrimary,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            null -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
            else -> {}
        }
    }
}
}

@Composable
fun RequestCardItem(
    request: ServiceRequest,
    onClick: () -> Unit
) {
    val (statusBg, statusText, statusTitle) = when (request.status) {
        com.example.data.model.RequestStatus.PENDING -> Triple(AmberLight, AmberPrimary, "قيد الانتظار")
        com.example.data.model.RequestStatus.ACCEPTED -> Triple(BlueContainer.copy(alpha = 0.5f), BluePrimary, "تم القبول")
        com.example.data.model.RequestStatus.IN_PROGRESS -> Triple(Color(0xFFEDE7F6), Color(0xFF673AB7), "قيد التنفيذ")
        com.example.data.model.RequestStatus.COMPLETED -> Triple(SuccessGreenContainer, SuccessGreen, "مكتمل")
        com.example.data.model.RequestStatus.REJECTED -> Triple(Color(0xFFFFEBEE), com.example.ui.theme.ErrorRed, "مرفوض")
        com.example.data.model.RequestStatus.CANCELLED -> Triple(OutlineLight.copy(alpha = 0.1f), TextSecondaryLight, "ملغى")
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("request_card_${request.id}"),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier.size(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = BlueContainer.copy(alpha = 0.4f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Handyman,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = request.providerName.ifBlank { "حرفي خدمتي" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = request.professionNameAr,
                            style = MaterialTheme.typography.labelSmall,
                            color = BluePrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = statusBg,
                    border = BorderStroke(1.dp, statusText.copy(alpha = 0.15f))
                ) {
                    Text(
                        text = statusTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = statusText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            if (request.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = request.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    maxLines = 2,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = TextTertiaryLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${request.communeName}، ${request.wilayaName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryLight
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "عرض التفاصيل",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = BluePrimary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
