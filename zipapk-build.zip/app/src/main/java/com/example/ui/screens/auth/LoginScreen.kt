package com.example.ui.screens.auth

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPasswordField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.ui.theme.*
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.LocalContext
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToRoleSelection: () -> Unit,
    onLoginSuccessCustomer: () -> Unit,
    onLoginSuccessProvider: () -> Unit,
    onLoginSuccessAdmin: () -> Unit = {}
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current
    val loginState by authViewModel.loginState.collectAsState()

    LaunchedEffect(loginState) {
        when (val state = loginState) {
            is AuthResult.Success -> {
                when (state.data.role) {
                    UserRole.ADMIN -> onLoginSuccessAdmin()
                    UserRole.SERVICE_PROVIDER -> onLoginSuccessProvider()
                    UserRole.CUSTOMER -> onLoginSuccessCustomer()
                }
            }
            is AuthResult.ProfileMissing -> {
                onNavigateToRoleSelection()
            }
            else -> {}
        }
    }

    fun validateAndSubmit() {
        var isValid = true
        if (email.trim().isEmpty()) {
            emailError = "يرجى إدخال البريد الإلكتروني"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            emailError = "صيغة البريد الإلكتروني غير صحيحة"
            isValid = false
        } else {
            emailError = null
        }

        if (password.isEmpty()) {
            passwordError = "يرجى إدخال كلمة المرور"
            isValid = false
        } else if (password.length < 6) {
            passwordError = "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل"
            isValid = false
        } else {
            passwordError = null
        }

        if (isValid) {
            focusManager.clearFocus()
            authViewModel.login(email.trim(), password)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Color.White,
            topBar = {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 48.dp, start = 16.dp, end = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(44.dp)
                            .background(BackgroundLight, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = BluePrimary
                        )
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Professional Illustration
                Image(
                    painter = painterResource(id = R.drawable.auth_illustration_modern_1788459966349),
                    contentDescription = null,
                    modifier = Modifier
                        .height(180.dp)
                        .fillMaxWidth(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                )

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "تسجيل الدخول",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    color = BlueDark
                )

                Text(
                    text = "مرحباً بعودتك 👋\nسجل دخولك للمتابعة",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondaryLight,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // Error Banner
                if (loginState is AuthResult.Error) {
                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                        shape = RoundedCornerShape(16.dp),
                        color = ErrorRedContainer
                    ) {
                        Text(
                            text = (loginState as AuthResult.Error).messageAr,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ErrorRed,
                            modifier = Modifier.padding(16.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Inputs
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    KhedmatiTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            if (emailError != null) emailError = null
                        },
                        label = "البريد الإلكتروني أو رقم الهاتف",
                        placeholder = "example@domain.dz",
                        leadingIcon = Icons.Default.Email,
                        errorMessage = emailError,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) }),
                        testTag = "login_email_input"
                    )

                    Column {
                        KhedmatiPasswordField(
                            value = password,
                            onValueChange = {
                                password = it
                                if (passwordError != null) passwordError = null
                            },
                            label = "كلمة المرور",
                            placeholder = "••••••••",
                            leadingIcon = Icons.Default.Lock,
                            errorMessage = passwordError,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { validateAndSubmit() }),
                            testTag = "login_password_input"
                        )
                        
                        androidx.compose.material3.TextButton(
                            onClick = { /* TODO */ },
                            modifier = Modifier.align(Alignment.Start)
                        ) {
                            Text(
                                text = "نسيت كلمة المرور؟",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = BluePrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                KhedmatiPrimaryButton(
                    text = "تسجيل الدخول",
                    onClick = { validateAndSubmit() },
                    isLoading = loginState is AuthResult.Loading,
                    shape = RoundedCornerShape(20.dp),
                    testTag = "login_submit_button"
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Social Logins
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.material3.HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        color = OutlineLight.copy(alpha = 0.5f)
                    )
                    Text(
                        text = " أو ",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextTertiaryLight,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    androidx.compose.material3.HorizontalDivider(
                        modifier = Modifier.weight(1f),
                        color = OutlineLight.copy(alpha = 0.5f)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

/*
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    SocialButton(icon = R.drawable.ic_google, modifier = Modifier.weight(1f))
                    SocialButton(icon = R.drawable.ic_facebook, modifier = Modifier.weight(1f))
                    SocialButton(icon = R.drawable.ic_phone, modifier = Modifier.weight(1f))
                }
*/

                Spacer(modifier = Modifier.height(32.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToRoleSelection() }
                        .padding(bottom = 32.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "ليس لديك حساب؟ ",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = "إنشاء حساب جديد",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun SocialButton(
    icon: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = { /* TODO */ },
        modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(20.dp),
        color = BackgroundLight,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Image(
                painter = painterResource(id = icon),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}
