package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.model.UserRole
import com.example.ui.screens.auth.CustomerRegisterScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.ProviderRegisterScreen
import com.example.ui.screens.auth.RoleSelectionScreen
import com.example.ui.screens.home.CustomerHomeScreen
import com.example.ui.screens.home.ProviderHomeScreen
import com.example.ui.screens.profile.EditProviderProfileScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.welcome.WelcomeScreen
import com.example.ui.viewmodel.AuthSessionState
import com.example.ui.viewmodel.AuthViewModel

object KhedmatiDestinations {
    const val SPLASH = "splash"
    const val WELCOME = "welcome"
    const val ROLE_SELECTION = "role_selection"
    const val LOGIN = "login"
    const val CUSTOMER_REGISTER = "customer_register"
    const val PROVIDER_REGISTER = "provider_register"
    const val CUSTOMER_HOME = "customer_home"
    const val PROVIDER_HOME = "provider_home"
    const val PROFILE = "profile"
    const val EDIT_PROVIDER_PROFILE = "edit_provider_profile"
}

@Composable
fun KhedmatiNavGraph(
    navController: NavHostController = rememberNavController(),
    authViewModel: AuthViewModel = viewModel()
) {
    val sessionState by authViewModel.sessionState.collectAsState()

    NavHost(
        navController = navController,
        startDestination = KhedmatiDestinations.SPLASH
    ) {
        // 1. Splash Screen
        composable(KhedmatiDestinations.SPLASH) {
            SplashScreen(
                isLoading = sessionState is AuthSessionState.Loading,
                onSplashFinished = {
                    when (val state = sessionState) {
                        is AuthSessionState.Authenticated -> {
                            if (state.userProfile.role == UserRole.SERVICE_PROVIDER) {
                                navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }
                            } else {
                                navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }
                            }
                        }
                        is AuthSessionState.NeedsProfileCompletion -> {
                            if (state.role == UserRole.SERVICE_PROVIDER) {
                                navController.navigate(KhedmatiDestinations.PROVIDER_REGISTER) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }
                            } else if (state.role == UserRole.CUSTOMER) {
                                navController.navigate(KhedmatiDestinations.CUSTOMER_REGISTER) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }
                            } else {
                                navController.navigate(KhedmatiDestinations.ROLE_SELECTION) {
                                    popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                                }
                            }
                        }
                        else -> {
                            navController.navigate(KhedmatiDestinations.WELCOME) {
                                popUpTo(KhedmatiDestinations.SPLASH) { inclusive = true }
                            }
                        }
                    }
                }
            )
        }

        // 2. Welcome Screen
        composable(KhedmatiDestinations.WELCOME) {
            WelcomeScreen(
                onNavigateToLogin = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.LOGIN)
                },
                onNavigateToRoleSelection = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.ROLE_SELECTION)
                },
                isFirebaseReady = authViewModel.isFirebaseReady
            )
        }

        // 3. Role Selection Screen
        composable(KhedmatiDestinations.ROLE_SELECTION) {
            RoleSelectionScreen(
                onNavigateBack = { navController.popBackStack() },
                onSelectCustomer = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.CUSTOMER_REGISTER)
                },
                onSelectProvider = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.PROVIDER_REGISTER)
                }
            )
        }

        // 4. Login Screen
        composable(KhedmatiDestinations.LOGIN) {
            LoginScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToRoleSelection = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.ROLE_SELECTION)
                },
                onLoginSuccessCustomer = {
                    navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }
                },
                onLoginSuccessProvider = {
                    navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        // 5. Customer Registration Screen
        composable(KhedmatiDestinations.CUSTOMER_REGISTER) {
            CustomerRegisterScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToLogin = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.LOGIN) {
                        popUpTo(KhedmatiDestinations.ROLE_SELECTION) { inclusive = true }
                    }
                },
                onRegistrationSuccess = {
                    navController.navigate(KhedmatiDestinations.CUSTOMER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        // 6. Service Provider Registration Screen (Mandatory Profession Selector included)
        composable(KhedmatiDestinations.PROVIDER_REGISTER) {
            ProviderRegisterScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToLogin = {
                    authViewModel.resetAuthStates()
                    navController.navigate(KhedmatiDestinations.LOGIN) {
                        popUpTo(KhedmatiDestinations.ROLE_SELECTION) { inclusive = true }
                    }
                },
                onRegistrationSuccess = {
                    navController.navigate(KhedmatiDestinations.PROVIDER_HOME) {
                        popUpTo(KhedmatiDestinations.WELCOME) { inclusive = true }
                    }
                }
            )
        }

        // 7. Customer Home Screen
        composable(KhedmatiDestinations.CUSTOMER_HOME) {
            CustomerHomeScreen(
                authViewModel = authViewModel,
                onNavigateToProfile = {
                    navController.navigate(KhedmatiDestinations.PROFILE)
                },
                onNavigateToLogin = {
                    navController.navigate(KhedmatiDestinations.LOGIN) {
                        popUpTo(KhedmatiDestinations.CUSTOMER_HOME) { inclusive = true }
                    }
                }
            )
        }

        // 8. Service Provider Home Screen
        composable(KhedmatiDestinations.PROVIDER_HOME) {
            ProviderHomeScreen(
                authViewModel = authViewModel,
                onNavigateToProfile = {
                    navController.navigate(KhedmatiDestinations.PROFILE)
                },
                onNavigateToEditProfile = {
                    navController.navigate(KhedmatiDestinations.EDIT_PROVIDER_PROFILE)
                }
            )
        }

        // 9. Profile Screen
        composable(KhedmatiDestinations.PROFILE) {
            ProfileScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToEditProviderProfile = {
                    navController.navigate(KhedmatiDestinations.EDIT_PROVIDER_PROFILE)
                },
                onLogoutFinished = {
                    navController.navigate(KhedmatiDestinations.WELCOME) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        // 10. Edit Provider Profile Screen
        composable(KhedmatiDestinations.EDIT_PROVIDER_PROFILE) {
            EditProviderProfileScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
