package com.example.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FilterList
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlgeriaWilayasData
import com.example.data.model.ProfessionalEntity
import com.example.data.model.ServiceCategoryEntity
import com.example.ui.components.CraftsmanCard
import com.example.ui.components.EmptyState
import com.example.ui.components.WilayaCommuneSelector

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    initialQuery: String = "",
    services: List<ServiceCategoryEntity>,
    craftsmenList: List<ProfessionalEntity>,
    selectedWilayaCode: Int,
    selectedServiceId: Long,
    onlyAvailable: Boolean,
    sortByRating: Boolean,
    onQueryChanged: (String) -> Unit,
    onWilayaSelected: (Int) -> Unit,
    onServiceSelected: (Long) -> Unit,
    onToggleOnlyAvailable: (Boolean) -> Unit,
    onToggleSortByRating: (Boolean) -> Unit,
    onCraftsmanClick: (ProfessionalEntity) -> Unit,
    onRequestServiceClick: (ProfessionalEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf(initialQuery) }
    var showFilterSheet by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("search_screen")
    ) {
        // Search Input Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = {
                            searchQuery = it
                            onQueryChanged(it)
                        },
                        placeholder = { Text("ابحث بالاسم، المهنة، أو الكلمات المفتاحية...") },
                        leadingIcon = {
                            Icon(Icons.Outlined.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = {
                                    searchQuery = ""
                                    onQueryChanged("")
                                }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_input_field")
                    )

                    // Filter Button with Badge
                    val activeFiltersCount = (if (selectedWilayaCode != 0) 1 else 0) +
                            (if (selectedServiceId != 0L) 1 else 0) +
                            (if (onlyAvailable) 1 else 0)

                    BadgedBox(
                        badge = {
                            if (activeFiltersCount > 0) {
                                Badge { Text(activeFiltersCount.toString()) }
                            }
                        }
                    ) {
                        FilledTonalIconButton(
                            onClick = { showFilterSheet = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(52.dp)
                        ) {
                            Icon(Icons.Outlined.FilterList, contentDescription = "تصفية")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Service Horizontal Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedServiceId == 0L,
                            onClick = { onServiceSelected(0L) },
                            label = { Text("جميع الخدمات", fontSize = 12.sp) }
                        )
                    }
                    items(services) { service ->
                        val isSelected = selectedServiceId == service.id
                        FilterChip(
                            selected = isSelected,
                            onClick = { onServiceSelected(if (isSelected) 0L else service.id) },
                            label = { Text(service.nameAr, fontSize = 12.sp) },
                            leadingIcon = if (isSelected) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            } else null
                        )
                    }
                }
            }
        }

        // Quick Active Filter Indicator Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val wilayaLabel = if (selectedWilayaCode == 0) "كافة الـ 58 ولاية"
            else "${selectedWilayaCode} - ${AlgeriaWilayasData.getWilayaByCode(selectedWilayaCode)?.nameAr ?: ""}"

            Text(
                text = "${craftsmenList.size} حرفي في $wilayaLabel",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (sortByRating) "الأعلى تقييماً" else "الأحدث",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onToggleSortByRating(!sortByRating) }
                )
                Icon(
                    imageVector = Icons.Default.SwapVert,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Results List
        if (craftsmenList.isEmpty()) {
            EmptyState(
                title = "لم يتم العثور على حرفيين",
                description = "جرب تغيير معايير البحث أو اختيار ولاية/خدمة أخرى.",
                actionLabel = "إعادة ضبط التصفية",
                onAction = {
                    onQueryChanged("")
                    searchQuery = ""
                    onWilayaSelected(0)
                    onServiceSelected(0L)
                    onToggleOnlyAvailable(false)
                }
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("search_results_list"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(craftsmenList) { craftsman ->
                    CraftsmanCard(
                        craftsman = craftsman,
                        onClick = { onCraftsmanClick(craftsman) },
                        onRequestService = { onRequestServiceClick(craftsman) }
                    )
                }
            }
        }
    }

    // Advanced Filter Modal Bottom Sheet
    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "خيارات التصفية والفرز",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = {
                        onWilayaSelected(0)
                        onServiceSelected(0L)
                        onToggleOnlyAvailable(false)
                        onToggleSortByRating(true)
                    }) {
                        Text("إعادة تعيين")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Wilaya Filter
                Text("الولاية الجغرافية:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))

                var wilayaDropdownOpen by remember { mutableStateOf(false) }
                Surface(
                    onClick = { wilayaDropdownOpen = true },
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (selectedWilayaCode == 0) "جميع الـ 58 ولاية"
                            else "${selectedWilayaCode}. ${AlgeriaWilayasData.getWilayaByCode(selectedWilayaCode)?.nameAr ?: ""}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                }

                if (wilayaDropdownOpen) {
                    AlertDialog(
                        onDismissRequest = { wilayaDropdownOpen = false },
                        title = { Text("اختر الولاية (58 ولاية)") },
                        text = {
                            LazyColumn(modifier = Modifier.height(300.dp)) {
                                item {
                                    TextButton(onClick = {
                                        onWilayaSelected(0)
                                        wilayaDropdownOpen = false
                                    }, modifier = Modifier.fillMaxWidth()) {
                                        Text("جميع الولايات الـ 58")
                                    }
                                }
                                items(AlgeriaWilayasData.allWilayas) { w ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                onWilayaSelected(w.code)
                                                wilayaDropdownOpen = false
                                            }
                                            .padding(vertical = 8.dp, horizontal = 10.dp)
                                    ) {
                                        Text("${w.code}. ${w.nameAr} - ${w.nameFr}")
                                    }
                                }
                            }
                        },
                        confirmButton = { TextButton(onClick = { wilayaDropdownOpen = false }) { Text("إغلاق") } }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Availability Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("الحرفيون المتاحون الآن فقط", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("إخفاء الحرفيين غير المستعدين للتدخل السريع", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = onlyAvailable,
                        onCheckedChange = onToggleOnlyAvailable
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sort By Rating
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("ترتيب حسب الأعلى تقييماً", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("إظهار الحرفيين ذوي أعلى تقييم أولاً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = sortByRating,
                        onCheckedChange = onToggleSortByRating
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تطبيق الفلاتر", fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
