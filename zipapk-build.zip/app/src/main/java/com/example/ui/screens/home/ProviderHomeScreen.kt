package com.example.ui.screens.home

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.data.model.RequestStatus
import com.example.data.model.Review
import com.example.data.model.ServiceRequest
import com.example.data.repository.AuthResult
import com.example.ui.components.FirebaseStatusBanner
import com.example.ui.screens.chat.ConversationsScreen
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProviderHomeScreen(
    authViewModel: AuthViewModel,
    onNavigateToProfile: () -> Unit,
    onNavigateToEditProfile: () -> Unit,
    onNavigateToMyServices: (String) -> Unit,
    onNavigateToRequestDetails: (String) -> Unit = {},
    onNavigateToChat: (String) -> Unit = {},
    onNavigateToProviderProfile: (String) -> Unit = {},
    onNavigateToPublicRequestsMarketplace: () -> Unit = {},
    onNavigateToPublicRequestDetails: (String) -> Unit = {},
    onNavigateToCreatePublicRequest: () -> Unit = {},
    onNavigateToNotifications: () -> Unit = {},
    onNavigateToAdminDashboard: () -> Unit = {}
) {
    val currentUser by authViewModel.currentUserProfile.collectAsState()
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    var currentTab by remember { mutableIntStateOf(0) }
    val unreadNotifsCount by authViewModel.unreadNotificationsCount.collectAsState()
    val unreadChatCount by authViewModel.totalUnreadChatCount.collectAsState()

    var showRatingsSheet by remember { mutableStateOf(false) }
    var showExperienceSheet by remember { mutableStateOf(false) }

    val context = LocalContext.current

    LaunchedEffect(Unit) {
        authViewModel.observeUserNotifications(context.applicationContext)
        authViewModel.observeProviderRequests()
        currentUser?.uid?.let { uid ->
            authViewModel.loadProviderProfile(uid)
            authViewModel.loadMyVerificationRequest(uid)
        }
    }

    val isAvailable = providerProfile?.isAvailable ?: true

    Scaffold(
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isAdmin = currentUser?.role == UserRole.ADMIN
                    val items = mutableListOf(
                        Triple(Icons.Default.Home, "الرئيسية", 0),
                        Triple(Icons.Default.ListAlt, "الواردة", 1),
                        Triple(Icons.Default.Storefront, "البحث", 2),
                        Triple(Icons.Default.Message, "الرسائل", 4),
                        Triple(Icons.Default.Person, "حسابي", 5)
                    )
                    if (isAdmin) {
                        items.add(Triple(Icons.Default.AdminPanelSettings, "لوحة الإدارة 👑", 6))
                    }

                    items.forEach { (icon, label, index) ->
                        val isSelected = currentTab == index
                        val contentColor = if (isSelected) BluePrimary else TextTertiaryLight
                        
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { 
                                    if (index == 5) {
                                        onNavigateToProfile()
                                    } else if (isAdmin && index == 6) {
                                        onNavigateToAdminDashboard()
                                    } else {
                                        currentTab = index 
                                    }
                                }
                                .padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = contentColor,
                                    modifier = Modifier.size(24.dp)
                                )
                                if (index == 4 && unreadChatCount > 0) {
                                    Surface(
                                        modifier = Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp),
                                        shape = CircleShape,
                                        color = EmeraldPrimary,
                                        border = BorderStroke(2.dp, Color.White)
                                    ) {
                                        Box(modifier = Modifier.size(10.dp))
                                    }
                                }
                            }
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = contentColor,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        when (currentTab) {
            1 -> {
                ProviderRequestsTab(
                    paddingValues = paddingValues,
                    authViewModel = authViewModel,
                    onNavigateToRequestDetails = onNavigateToRequestDetails
                )
            }
            2 -> {
                MarketplaceTab(
                    paddingValues = paddingValues,
                    authViewModel = authViewModel,
                    onNavigateToProviderProfile = onNavigateToProviderProfile,
                    onNavigateToCreatePublicRequest = onNavigateToCreatePublicRequest,
                    header = {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 48.dp, start = 24.dp, end = 24.dp, bottom = 12.dp)
                        ) {
                            Text(
                                text = "سوق الخدمات",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Black,
                                color = BlueDark
                            )
                            Text(
                                text = "تواصل مع حرفيين آخرين للتعاون أو لطلب خدماتهم",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                    }
                )
            }
            4 -> {
                Box(modifier = Modifier.padding(paddingValues)) {
                    ConversationsScreen(
                        authViewModel = authViewModel,
                        onNavigateToChat = onNavigateToChat,
                        onNavigateBack = null
                    )
                }
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(bottom = 120.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Header Section
                    item {
                        ProviderHeaderSection(
                            providerName = providerProfile?.fullName ?: currentUser?.fullName ?: "حرفي",
                            professionName = providerProfile?.professionNameAr ?: "حرفي",
                            wilayaName = providerProfile?.wilayaName ?: "غير محدد",
                            onProfileClick = onNavigateToProfile,
                            unreadCount = unreadNotifsCount,
                            onNotificationsClick = onNavigateToNotifications,
                            isVerified = providerProfile?.isVerified ?: false
                        )
                    }

                    // Stats Section
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            StatCard(
                                title = "الطلبات",
                                value = "${providerProfile?.completedJobsCount ?: 0}",
                                icon = Icons.Default.WorkHistory,
                                color = BluePrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { currentTab = 1 }
                            )
                            StatCard(
                                title = "التقييم",
                                value = if (providerProfile?.rating == 0.0) "-" else String.format("%.1f", providerProfile?.rating ?: 0.0),
                                icon = Icons.Default.Star,
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val uid = providerProfile?.uid ?: ""
                                    if (uid.isNotBlank()) {
                                        authViewModel.loadProviderReviews(uid)
                                    }
                                    showRatingsSheet = true
                                }
                            )
                            StatCard(
                                title = "الخبرة",
                                value = "${providerProfile?.experienceYears ?: 0}+",
                                icon = Icons.Default.CheckCircle,
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { showExperienceSheet = true }
                            )
                        }
                    }

                    // Availability Status
                    item {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            shape = RoundedCornerShape(24.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "حالة العمل",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Black,
                                        color = BlueDark
                                    )
                                    Text(
                                        text = if (isAvailable) "أنت متاح لاستقبال الطلبات" else "أنت في وضع غير متاح حالياً",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondaryLight
                                    )
                                }

                                Switch(
                                    checked = isAvailable,
                                    onCheckedChange = { authViewModel.toggleProviderAvailability(it) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = EmeraldPrimary,
                                        uncheckedThumbColor = Color.White,
                                        uncheckedTrackColor = OutlineLight
                                    )
                                )
                            }
                        }
                    }

                    // Public Requests Banner
                    item {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            shape = RoundedCornerShape(28.dp),
                            color = BlueDark,
                        ) {
                            Row(
                                modifier = Modifier.padding(24.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "طلبات عامة جديدة",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "تصفح الطلبات في منطقتك",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = 0.7f),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onNavigateToPublicRequestsMarketplace() },
                                        color = EmeraldPrimary,
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "تصفح الطلبات 🚀",
                                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.Black,
                                            color = Color.White
                                        )
                                    }
                                }
                                
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.1f),
                                    modifier = Modifier.size(80.dp)
                                )
                            }
                        }
                    }
                    
                    // Firebase Status
                    item {
                        Box(modifier = Modifier.padding(horizontal = 24.dp)) {
                            FirebaseStatusBanner(isFirebaseReady = authViewModel.isFirebaseReady)
                        }
                    }
                }
            }
        }
    }

    if (showRatingsSheet) {
        AlertDialog(
            onDismissRequest = { showRatingsSheet = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        showRatingsSheet = false
                        val uid = providerProfile?.uid ?: ""
                        if (uid.isNotBlank()) {
                            onNavigateToProviderProfile(uid)
                        }
                    }
                ) {
                    Text("عرض الملف العام", color = BluePrimary, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRatingsSheet = false }) {
                    Text("إغلاق", color = TextSecondaryLight)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = AmberPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تقييمات وآراء الزبائن", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }
            },
            text = {
                val reviewsState by authViewModel.providerReviewsState.collectAsState()
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = AmberPrimary.copy(alpha = 0.1f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (providerProfile?.rating == 0.0) "-" else String.format("%.1f ★", providerProfile?.rating ?: 0.0),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = AmberPrimary
                                )
                                Text("معدل التقييم", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${providerProfile?.reviewCount ?: 0}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = BlueDark
                                )
                                Text("عدد المراجعات", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                            }
                        }
                    }

                    when (val state = reviewsState) {
                        is AuthResult.Loading -> {
                            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(color = BluePrimary, modifier = Modifier.size(32.dp))
                            }
                        }
                        is AuthResult.Error -> {
                            Text(text = state.messageAr, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
                        }
                        is AuthResult.Success -> {
                            val reviews = state.data
                            if (reviews.isEmpty()) {
                                Text(
                                    text = "لا توجد تقييمات مسجلة بعد.\nتظهر التقييمات هنا عندما يقوم الزبائن بتقييم خدماتك المكتملة.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondaryLight,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    reviews.forEach { review ->
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = BackgroundLight,
                                            border = BorderStroke(1.dp, OutlineLight)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = review.customerName.ifBlank { "زبون خدمتي" },
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = BlueDark
                                                    )
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Icon(Icons.Default.Star, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("${review.rating}/5", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                                if (review.comment.isNotBlank()) {
                                                    Spacer(modifier = Modifier.height(6.dp))
                                                    Text(text = review.comment, style = MaterialTheme.typography.bodySmall, color = TextSecondaryLight)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else -> {}
                    }
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(28.dp)
        )
    }

    if (showExperienceSheet) {
        AlertDialog(
            onDismissRequest = { showExperienceSheet = false },
            confirmButton = {
                Button(
                    onClick = {
                        showExperienceSheet = false
                        onNavigateToEditProfile()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تعديل الخبرة والملف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExperienceSheet = false }) {
                    Text("إغلاق", color = TextSecondaryLight)
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = EmeraldPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("خبرة الحرفي والملف المهني", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = EmeraldPrimary.copy(alpha = 0.1f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(EmeraldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${providerProfile?.experienceYears ?: 1}+",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "${providerProfile?.experienceYears ?: 1} سنوات خبرة عمل معتمدة",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueDark
                                )
                                Text(
                                    text = providerProfile?.professionNameAr ?: "حرفي متخصص",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight
                                )
                            }
                        }
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (!providerProfile?.specialization.isNullOrBlank()) {
                            Column {
                                Text("التخصص الدقيق:", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                                Text(providerProfile?.specialization ?: "", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BlueDark)
                            }
                        }

                        Column {
                            Text("موقع التغطية والعمل:", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                            Text("${providerProfile?.communeName ?: ""}، ولاية ${providerProfile?.wilayaName ?: ""}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BlueDark)
                        }

                        Column {
                            Text("نبذة وصنع القرار المهني:", style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                            Text(
                                text = providerProfile?.effectiveBio()?.ifBlank { "لم يقم الحرفي بإضافة نبذة تعريفية مطولة بعد. يمكنك تحديثها من زر التعديل." } ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            },
            containerColor = Color.White,
            shape = RoundedCornerShape(28.dp)
        )
    }
}

@Composable
fun ProviderHeaderSection(
    providerName: String,
    professionName: String,
    wilayaName: String,
    onProfileClick: () -> Unit,
    unreadCount: Int = 0,
    onNotificationsClick: () -> Unit = {},
    isVerified: Boolean = false
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 48.dp, start = 24.dp, end = 24.dp, bottom = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = wilayaName,
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondaryLight,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "مرحباً، $providerName",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    if (isVerified) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "موثق",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                
                Text(
                    text = professionName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BluePrimary,
                    fontWeight = FontWeight.Black
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                // Notification Button
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color.White, CircleShape)
                        .border(1.dp, OutlineLight.copy(alpha = 0.5f), CircleShape)
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "الإشعارات",
                            tint = BlueDark,
                            modifier = Modifier.size(22.dp)
                        )
                        if (unreadCount > 0) {
                            Surface(
                                modifier = Modifier.align(Alignment.TopEnd).offset(x = 2.dp, y = (-2).dp),
                                shape = CircleShape,
                                color = Color.Red,
                                border = BorderStroke(1.dp, Color.White)
                            ) {
                                Box(modifier = Modifier.size(8.dp))
                            }
                        }
                    }
                }

                // Profile Image
                Surface(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .clickable { onProfileClick() },
                    color = BlueContainer.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.1f))
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "الملف الشخصي",
                            tint = BluePrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = BlueDark
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondaryLight,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ProviderRequestsTab(
    paddingValues: PaddingValues,
    authViewModel: AuthViewModel,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val requestsState by authViewModel.providerRequestsState.collectAsState()
    var selectedFilter by remember { mutableIntStateOf(0) } // 0: Pending, 1: Active, 2: Archive

    LaunchedEffect(Unit) {
        authViewModel.observeProviderRequests()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
    ) {
        // Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BlueDark)
                .padding(16.dp)
        ) {
            Text(
                text = "الطلبات الواردة",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "إدارة وسجل طلبات الخدمة الواردة من الزبائن",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.8f)
            )
        }

        // Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedFilter == 0,
                    onClick = { selectedFilter = 0 },
                    label = { Text("طلبات جديدة 🆕") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BluePrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = selectedFilter == 1,
                    onClick = { selectedFilter = 1 },
                    label = { Text("قيد التنفيذ 🛠️") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BluePrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item {
                FilterChip(
                    selected = selectedFilter == 2,
                    onClick = { selectedFilter = 2 },
                    label = { Text("السجل والأرشيف 📜") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BluePrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        when (val state = requestsState) {
            is AuthResult.Loading -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
            is AuthResult.Error -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = state.messageAr,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }
            is AuthResult.Success -> {
                val allRequests = state.data
                val filtered = remember(allRequests, selectedFilter) {
                    when (selectedFilter) {
                        0 -> allRequests.filter { it.status == RequestStatus.PENDING }
                        1 -> allRequests.filter {
                            it.status == RequestStatus.ACCEPTED || it.status == RequestStatus.IN_PROGRESS
                        }
                        2 -> allRequests.filter {
                            it.status == RequestStatus.COMPLETED ||
                            it.status == RequestStatus.REJECTED ||
                            it.status == RequestStatus.CANCELLED
                        }
                        else -> allRequests
                    }
                }

                if (filtered.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(BlueContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ListAlt,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "لا توجد طلبات واردة حالياً في هذا المجلد",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "تأكد من تفعيل حالة التوفر لتظهر في نتائج بحث الزبائن وتتلقى الطلبات المباشرة.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(items = filtered, key = { it.id }) { request ->
                            ProviderRequestCardItem(
                                request = request,
                                authViewModel = authViewModel,
                                onClick = { onNavigateToRequestDetails(request.id) }
                            )
                        }
                    }
                }
            }
            null -> {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = BluePrimary)
                }
            }
            else -> {}
        }
    }
}

@Composable
fun ProviderRequestCardItem(
    request: ServiceRequest,
    authViewModel: AuthViewModel,
    onClick: () -> Unit
) {
    val context = LocalContext.current
    var isUpdating by remember { mutableStateOf(false) }

    val (statusBg, statusText, statusTitle) = when (request.status) {
        RequestStatus.PENDING -> Triple(AmberLight, AmberPrimary, "طلب جديد")
        RequestStatus.ACCEPTED -> Triple(Color(0xFFE3F2FD), Color(0xFF1976D2), "تم القبول")
        RequestStatus.IN_PROGRESS -> Triple(Color(0xFFEDE7F6), Color(0xFF673AB7), "قيد التنفيذ")
        RequestStatus.COMPLETED -> Triple(SuccessGreenContainer, SuccessGreen, "مكتمل")
        RequestStatus.REJECTED -> Triple(Color(0xFFFFEBEE), ErrorRed, "مرفوض")
        RequestStatus.CANCELLED -> Triple(Color(0xFFF5F5F5), Color(0xFF757575), "ملغى")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("provider_request_card_${request.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(AmberLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = request.customerName.ifBlank { "زبون" },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "طلب خدمة: ${request.professionNameAr}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(statusBg)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusText
                    )
                }
            }

            if (request.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = request.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${request.communeName}، ${request.wilayaName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (request.customerPhone.isNotBlank()) {
                    IconButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${request.customerPhone}")
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BlueContainer)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال بالزبون",
                            tint = BluePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Inline action buttons if status is PENDING
            if (request.status == RequestStatus.PENDING) {
                Spacer(modifier = Modifier.height(12.dp))
                if (isUpdating) {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BluePrimary, modifier = Modifier.size(24.dp))
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                isUpdating = true
                                authViewModel.updateServiceRequestStatus(request.id, RequestStatus.ACCEPTED) { _, _ ->
                                    isUpdating = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("قبول الطلب", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                isUpdating = true
                                authViewModel.updateServiceRequestStatus(request.id, RequestStatus.REJECTED) { _, _ ->
                                    isUpdating = false
                                }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("رفض", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
