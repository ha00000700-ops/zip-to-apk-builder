package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PlantGrowthEntryEntity
import com.example.ui.PlantDoctorViewModel
import com.example.ui.Screen
import com.example.ui.components.AppTopBar
import com.example.ui.components.SeverityBadge
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.AlertRed
import com.example.ui.theme.SoilAmber
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlantDetailScreen(viewModel: PlantDoctorViewModel) {
    val context = LocalContext.current
    val plant by viewModel.selectedPlant.collectAsState()
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showAddGrowthDialog by remember { mutableStateOf(false) }

    if (plant == null) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "تفاصيل النبتة",
                    showBackButton = true,
                    onBackClick = { viewModel.navigateBack() }
                )
            }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لا توجد نبتة محددة")
            }
        }
        return
    }

    val item = plant!!

    // Growth entries stream for this plant
    val growthEntries by viewModel.getGrowthEntriesForPlant(item.id).collectAsState(initial = emptyList())

    // Add growth entry form state
    var growthImagePath by remember { mutableStateOf("") }
    var growthStage by remember { mutableStateOf("نمو خضري") }
    var growthHeightText by remember { mutableStateOf("") }
    var growthNotes by remember { mutableStateOf("") }

    val growthPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = viewModel.copyUriToLocalCache(context, uri)
            if (copied != null) {
                growthImagePath = copied.absolutePath
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("حذف النبتة", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من حذف '${item.name}' من سجلك النباتي؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteDialog = false
                        viewModel.deletePlant(item)
                    }
                ) {
                    Text("حذف", color = AlertRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add Growth Entry Dialog
    if (showAddGrowthDialog) {
        val stages = listOf("إنبات/شتلة", "نمو خضري", "تزهير", "عقد ثمار", "نضج وحصاد")
        AlertDialog(
            onDismissRequest = { showAddGrowthDialog = false },
            title = { Text("تسجيل محطة نمو جديدة 📸", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Photo preview or picker button
                    if (growthImagePath.isNotBlank()) {
                        val bm = remember(growthImagePath) { BitmapFactory.decodeFile(growthImagePath) }
                        if (bm != null) {
                            Image(
                                bitmap = bm.asImageBitmap(),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .clip(RoundedCornerShape(10.dp))
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            growthPhotoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (growthImagePath.isBlank()) "اختر صورة للنبتة اليوم" else "تغيير الصورة")
                    }

                    Text("مرحلة النمو الحالية:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        stages.take(3).forEach { s ->
                            FilterChip(
                                selected = growthStage == s,
                                onClick = { growthStage = s },
                                label = { Text(s, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        stages.drop(3).forEach { s ->
                            FilterChip(
                                selected = growthStage == s,
                                onClick = { growthStage = s },
                                label = { Text(s, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = growthHeightText,
                        onValueChange = { growthHeightText = it },
                        label = { Text("ارتفاع النبتة التقريبي بالـ سم (اختياري)") },
                        placeholder = { Text("مثال: 45") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = growthNotes,
                        onValueChange = { growthNotes = it },
                        label = { Text("ملاحظاتك حول التطور") },
                        placeholder = { Text("مثال: تفرع جديد، ظهور براعم زهرية...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val height = growthHeightText.toDoubleOrNull()
                        viewModel.addGrowthEntry(
                            plantId = item.id,
                            imagePath = growthImagePath,
                            stage = growthStage,
                            heightCm = height,
                            notes = growthNotes
                        )
                        showAddGrowthDialog = false
                        growthImagePath = ""
                        growthHeightText = ""
                        growthNotes = ""
                    }
                ) {
                    Text("حفظ بالسجل")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddGrowthDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = item.name,
                subtitle = item.plantType,
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = { viewModel.navigateTo(Screen.AddEditPlant) },
                        modifier = Modifier.testTag("edit_plant_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(
                        onClick = { showDeleteDialog = true },
                        modifier = Modifier.testTag("delete_plant_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = AlertRed)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card with Plant Avatar
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(AgriGreenMint),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🌿", fontSize = 38.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    if (item.scientificName.isNotBlank()) {
                        Text(
                            text = item.scientificName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(AgriGreenMint)
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "الحالة: ${item.healthStatus}",
                            color = AgriGreenDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Ask Plant Doctor About this Plant Direct Action Button
            Button(
                onClick = { viewModel.askDoctorAboutPlant(item) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("ask_doctor_about_plant_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("اسأل طبيب النباتات عن هذه النبتة 💬", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.WaterDrop, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "دورة السقاية", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                        Text(text = "كل ${item.wateringIntervalDays} أيام", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.LocalFlorist, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "دورة التسميد", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                        Text(text = "كل ${item.fertilizingIntervalDays} يوماً", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            // Details Info Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "المعلومات الزراعية والموقع", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "التصنيف:", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp)
                        Text(text = item.plantType, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "مكان الزراعة:", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp)
                        Text(text = item.location, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    }
                    if (item.plantedDate.isNotBlank()) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "تاريخ الغرس:", color = MaterialTheme.colorScheme.outline, fontSize = 13.sp)
                            Text(text = item.plantedDate, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                    }
                    if (item.notes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "ملاحظات وتوصيات خاصة:", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp)
                        Text(text = item.notes, fontSize = 13.sp)
                    }
                }
            }

            // Growth Journal Timeline (سجل تطور النمو بالصور)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timeline, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "سجل صور مراحل النمو (${growthEntries.size})",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        IconButton(
                            onClick = { showAddGrowthDialog = true },
                            modifier = Modifier.testTag("add_growth_entry_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "إضافة محطة نمو", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    if (growthEntries.isEmpty()) {
                        Text(
                            text = "لم تقم بتسجيل أي مرحلة نمو حتى الآن. التقط صورة دورية لتوثيق تقدم النبتة وتطورها عبر الزمن! 📸",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        OutlinedButton(
                            onClick = { showAddGrowthDialog = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تسجيل أول صورة نمو")
                        }
                    } else {
                        Spacer(modifier = Modifier.height(8.dp))
                        growthEntries.forEach { entry ->
                            val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(entry.timestamp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (entry.imagePath.isNotBlank()) {
                                    val f = File(entry.imagePath)
                                    if (f.exists()) {
                                        val bm = remember(entry.imagePath) { BitmapFactory.decodeFile(entry.imagePath) }
                                        if (bm != null) {
                                            Image(
                                                bitmap = bm.asImageBitmap(),
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .size(60.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                        }
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = entry.stageTitle, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(text = dateStr, fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    }
                                    if (entry.heightCm != null) {
                                        Text(text = "الارتفاع: ${entry.heightCm} سم", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                    if (entry.notes.isNotBlank()) {
                                        Text(text = entry.notes, fontSize = 12.sp, maxLines = 2)
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.deleteGrowthEntry(entry) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = AlertRed.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Quick Diagnose Action
            Button(
                onClick = { viewModel.navigateTo(Screen.Diagnose) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("diagnose_plant_again_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.MedicalServices, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("إجراء فحص صحي وتشخيص جديد لهذه النبتة", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
