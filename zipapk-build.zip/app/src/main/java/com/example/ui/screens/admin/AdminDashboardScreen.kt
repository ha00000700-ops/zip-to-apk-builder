package com.example.ui.screens.admin

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.RatingStars
import com.example.ui.components.StatusBadge
import com.example.ui.components.VerifiedBadge
import com.example.ui.screens.dialogs.AdminRevokeVerificationDialog
import com.example.ui.screens.dialogs.AdminVerificationReviewDialog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    users: List<UserEntity>,
    professionals: List<ProfessionalEntity>,
    requests: List<ServiceRequestEntity>,
    reports: List<ReportEntity>,
    verificationRequests: List<VerificationRequestEntity>,
    reviews: List<ReviewEntity>,
    flaggedReviews: List<ReviewEntity>,
    services: List<ServiceCategoryEntity>,
    onBack: () -> Unit,
    onApproveVerification: (requestId: Long, proId: Long) -> Unit,
    onRejectVerification: (requestId: Long, proId: Long, reason: String) -> Unit,
    onRevokeVerification: (proId: Long, reason: String) -> Unit,
    onDeleteReview: (reviewId: Long) -> Unit,
    onToggleBlockUser: (UserEntity) -> Unit,
    onDeleteUser: (UserEntity) -> Unit,
    onUpdateReport: (reportId: Long, status: ReportStatus, actionTaken: String) -> Unit,
    onAddServiceCategory: (nameAr: String, nameFr: String, iconName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedAdminTab by remember { mutableStateOf(0) }
    // 0: Verification (طلبات التوثيق), 1: Craftsmen (الحرفيون), 2: Reviews (التقييمات), 3: Reports (البلاغات), 4: Users (المستخدمون), 5: Services (الخدمات)

    var reviewingVerificationRequest by remember { mutableStateOf<VerificationRequestEntity?>(null) }
    var revokingPro by remember { mutableStateOf<ProfessionalEntity?>(null) }
    var showAddServiceDialog by remember { mutableStateOf(false) }

    val pendingVerifications = verificationRequests.filter { it.status == VerificationStatus.PENDING }
    val newReports = reports.filter { it.status == ReportStatus.NEW || it.status == ReportStatus.UNDER_REVIEW }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text("لوحة إدارة الأمان والرقابة — خدملي DZ 🇩🇿", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f))
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .testTag("admin_dashboard_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. KPI Metric Summary Grid
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Pending Verifications
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = DzGreenLight)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${pendingVerifications.size}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = DzGreenPrimary)
                            Text("طلبات التوثيق", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = DzGreenPrimary)
                        }
                    }

                    // Active Reports
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${newReports.size}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFFDC2626))
                            Text("البلاغات النشطة", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
                        }
                    }

                    // Flagged Reviews
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${flaggedReviews.size}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFFD97706))
                            Text("تقييمات مشبوهة", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                        }
                    }

                    // Total Craftsmen
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${professionals.size}", fontWeight = FontWeight.Black, fontSize = 18.sp, color = Color(0xFF1D4ED8))
                            Text("إجمالي الحرفيين", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1D4ED8))
                        }
                    }
                }
            }

            // 2. Admin Tabs Navigation Bar
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedAdminTab,
                    edgePadding = 0.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                    divider = {}
                ) {
                    Tab(
                        selected = selectedAdminTab == 0,
                        onClick = { selectedAdminTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("التوثيق (${pendingVerifications.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedAdminTab == 1,
                        onClick = { selectedAdminTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("الحرفيون (${professionals.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedAdminTab == 2,
                        onClick = { selectedAdminTab = 2 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.RateReview, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("التقييمات (${flaggedReviews.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedAdminTab == 3,
                        onClick = { selectedAdminTab = 3 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("البلاغات (${reports.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedAdminTab == 4,
                        onClick = { selectedAdminTab = 4 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("المستخدمون (${users.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedAdminTab == 5,
                        onClick = { selectedAdminTab = 5 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Category, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("المهن والخدمات (${services.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }
            }

            // TAB 0: VERIFICATION SYSTEM (نظام توثيق الحرفيين)
            if (selectedAdminTab == 0) {
                if (verificationRequests.isEmpty()) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("لا توجد أي طلبات توثيق حالياً", fontWeight = FontWeight.Bold)
                                Text("ستظهر هنا ملفات الحرفيين الراغبين في نيل شارة التوثيق", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                } else {
                    items(verificationRequests) { req ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = when (req.status) {
                                    VerificationStatus.PENDING -> Color(0xFFF0FDF4)
                                    VerificationStatus.APPROVED -> MaterialTheme.colorScheme.surface
                                    VerificationStatus.REJECTED -> Color(0xFFFEF2F2)
                                    else -> MaterialTheme.colorScheme.surface
                                }
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(req.professionalName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        if (req.status == VerificationStatus.APPROVED) {
                                            VerifiedBadge()
                                        }
                                    }
                                    Surface(
                                        color = when (req.status) {
                                            VerificationStatus.PENDING -> Color(0xFFD97706)
                                            VerificationStatus.APPROVED -> DzGreenPrimary
                                            VerificationStatus.REJECTED -> Color(0xFFDC2626)
                                            else -> Color.Gray
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = req.status.labelAr,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text("المهنة: ${req.professionNameAr} • الولاية: ${req.wilayaNameAr} (${req.communeNameAr})", fontSize = 12.sp)
                                Text("الهاتف: ${req.phone} • بطاقة التعريف: ${req.idCardNumber}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("السجل/المؤهل: ${req.qualificationOrTradeRegister}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

                                if (req.status == VerificationStatus.PENDING) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = { reviewingVerificationRequest = req },
                                            colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("مراجعة الملف والقرار", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                } else if (req.status == VerificationStatus.REJECTED && req.adminRejectionReason.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("سبب الرفض السابق: ${req.adminRejectionReason}", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            // TAB 1: CRAFTSMEN & TRUST BADGE MANAGEMENT
            if (selectedAdminTab == 1) {
                items(professionals) { pro ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(pro.fullName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        if (pro.isVerified) VerifiedBadge()
                                    }
                                    Text("${pro.professionNameAr} • ولاية ${pro.wilayaNameAr} (${pro.communeNameAr})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("الهاتف: ${pro.phone} • خدمات مكتملة: ${pro.completedJobsCount}", fontSize = 12.sp)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    RatingStars(rating = pro.ratingAverage)
                                    Text("${pro.ratingAverage} (${pro.ratingCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = if (pro.isVerified) DzGreenLight else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (pro.isVerified) "حرفي موثوق ومعتمد 🛡️" else "غير موثوق (حساب عادي)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (pro.isVerified) DzGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                if (pro.isVerified) {
                                    OutlinedButton(
                                        onClick = { revokingPro = pro },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.GppBad, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("سحب الشارة", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 2: REVIEWS & MODERATION (إدارة التقييمات ومنع التقييمات المزيفة)
            if (selectedAdminTab == 2) {
                val listToShow = if (flaggedReviews.isNotEmpty()) flaggedReviews else reviews

                if (listToShow.isEmpty()) {
                    item {
                        Text("لا توجد تقييمات مسجلة حالياً.", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    if (flaggedReviews.isNotEmpty()) {
                        item {
                            Surface(
                                color = Color(0xFFFFFBEB),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("يوجد ${flaggedReviews.size} تقييم تم الإبلاغ عنه من قبل المستخدمين أو الحرفيين للمراجعة", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                }
                            }
                        }
                    }

                    items(listToShow) { rev ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (rev.isFlagged) Color(0xFFFFF7ED) else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(rev.customerName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        if (rev.requestId > 0) {
                                            Surface(color = DzGreenLight, shape = RoundedCornerShape(4.dp)) {
                                                Text("طلب حقيقي #${rev.requestId}", fontSize = 10.sp, color = DzGreenPrimary, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                        }
                                    }

                                    RatingStars(rating = rev.rating.toDouble())
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(rev.comment, fontSize = 13.sp)

                                if (rev.isFlagged) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("سبب الإبلاغ: ${rev.flagReason}", fontSize = 11.sp, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    Button(
                                        onClick = {
                                            onDeleteReview(rev.id)
                                            Toast.makeText(context, "تم حذف التقييم وإعادة حساب متوسط الحرفي", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("حذف التقييم المخالف", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 3: REPORTS & DISPUTES
            if (selectedAdminTab == 3) {
                if (reports.isEmpty()) {
                    item {
                        Text("لا توجد أي بلاغات مسجلة حالياً.", modifier = Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    items(reports) { rep ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (rep.status == ReportStatus.NEW) Color(0xFFFEF2F2) else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("بلاغ ضد: ${rep.targetName} (${rep.targetType})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Surface(
                                        color = when (rep.status) {
                                            ReportStatus.NEW -> Color(0xFFDC2626)
                                            ReportStatus.UNDER_REVIEW -> Color(0xFFD97706)
                                            ReportStatus.RESOLVED -> DzGreenPrimary
                                            ReportStatus.CLOSED -> Color.Gray
                                        },
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = rep.status.labelAr,
                                            color = Color.White,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text("المبلغ: ${rep.reporterName}", fontSize = 12.sp)
                                Text("السبب: ${rep.reason}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                if (rep.details.isNotBlank()) {
                                    Text("التفاصيل: ${rep.details}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (rep.adminActionTaken.isNotBlank()) {
                                    Text("إجراء الإدارة: ${rep.adminActionTaken}", fontSize = 12.sp, color = DzGreenPrimary, fontWeight = FontWeight.SemiBold)
                                }

                                if (rep.status == ReportStatus.NEW || rep.status == ReportStatus.UNDER_REVIEW) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                onUpdateReport(rep.id, ReportStatus.RESOLVED, "تم التحقق والتواصل مع الأطراف وتصحيح الوضع")
                                                Toast.makeText(context, "تم تحديد البلاغ كـ محلول", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("حل ومعالجة البلاغ", fontSize = 11.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                onUpdateReport(rep.id, ReportStatus.CLOSED, "تم الرفض لعدم كفاية الأدلة أو الكيدية")
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("تجاهل البلاغ", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 4: USERS MANAGEMENT
            if (selectedAdminTab == 4) {
                items(users) { u ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(u.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    if (u.isBlocked) {
                                        Surface(color = MaterialTheme.colorScheme.error, shape = RoundedCornerShape(4.dp)) {
                                            Text("مجمد ⚠️", color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                }
                                Text("الهاتف: ${u.phone} • ${u.wilayaNameAr}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("الدور: ${u.role.name}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                            }

                            if (u.role != UserRole.ADMIN) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(
                                        onClick = { onToggleBlockUser(u) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(if (u.isBlocked) "إلغاء التجميد" else "تجميد الحساب", fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { onDeleteUser(u) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف المستخدم", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TAB 5: SERVICES MANAGEMENT
            if (selectedAdminTab == 5) {
                item {
                    Button(
                        onClick = { showAddServiceDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إضافة مهنة أو خدمة جديدة للمنصة", fontWeight = FontWeight.Bold)
                    }
                }

                items(services) { s ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(s.nameAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("الاسم بالفرنسية: ${s.nameFr} • الأيقونة: ${s.iconName}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }

    // Review Verification Dialog
    reviewingVerificationRequest?.let { req ->
        AdminVerificationReviewDialog(
            request = req,
            onDismiss = { reviewingVerificationRequest = null },
            onApprove = {
                onApproveVerification(req.id, req.professionalId)
                reviewingVerificationRequest = null
                Toast.makeText(context, "تمت الموافقة ومنح شارة الحرفي الموثوق ✓", Toast.LENGTH_SHORT).show()
            },
            onReject = { reason ->
                onRejectVerification(req.id, req.professionalId, reason)
                reviewingVerificationRequest = null
                Toast.makeText(context, "تم رفض طلب التوثيق وتنبيه الحرفي", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Revoke Verification Dialog
    revokingPro?.let { pro ->
        AdminRevokeVerificationDialog(
            professionalName = pro.fullName,
            onDismiss = { revokingPro = null },
            onConfirmRevoke = { reason ->
                onRevokeVerification(pro.id, reason)
                revokingPro = null
                Toast.makeText(context, "تم سحب شارة التوثيق بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showAddServiceDialog) {
        var newNameAr by remember { mutableStateOf("") }
        var newNameFr by remember { mutableStateOf("") }
        var newIconName by remember { mutableStateOf("construction") }

        AlertDialog(
            onDismissRequest = { showAddServiceDialog = false },
            title = { Text("إضافة مهنة / خدمة جديدة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newNameAr,
                        onValueChange = { newNameAr = it },
                        label = { Text("الاسم بالعربية (مثال: عزل وتزفيت)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newNameFr,
                        onValueChange = { newNameFr = it },
                        label = { Text("الاسم بالفرنسية (مثال: Étanchéité)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newNameAr.isNotBlank()) {
                        onAddServiceCategory(newNameAr, newNameFr.ifBlank { newNameAr }, newIconName)
                        showAddServiceDialog = false
                        Toast.makeText(context, "تمت إضافة الخدمة بنجاح", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddServiceDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
