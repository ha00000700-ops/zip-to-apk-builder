package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.remote.CityLocation
import com.example.data.remote.WeatherService
import com.example.ui.PlantDoctorViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.AlertRed
import com.example.ui.theme.SoilAmber
import com.example.ui.theme.WarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(viewModel: PlantDoctorViewModel) {
    val selectedCity by viewModel.selectedCity.collectAsState()
    val weatherData by viewModel.weatherData.collectAsState()
    val isWeatherLoading by viewModel.isWeatherLoading.collectAsState()
    val weatherError by viewModel.weatherError.collectAsState()

    var showCitySearchDialog by remember { mutableStateOf(false) }
    var citySearchQuery by remember { mutableStateOf("") }

    val filteredCities = remember(citySearchQuery) {
        val q = citySearchQuery.trim().lowercase()
        if (q.isBlank()) WeatherService.allWilayas
        else WeatherService.allWilayas.filter {
            it.name.contains(q, ignoreCase = true) ||
            it.nameFrench.contains(q, ignoreCase = true) ||
            it.wilayaNumber.toString() == q ||
            it.country.contains(q, ignoreCase = true)
        }
    }

    // Wilaya Selection Dialog with Quick Search
    if (showCitySearchDialog) {
        AlertDialog(
            onDismissRequest = { showCitySearchDialog = false },
            title = {
                Text("اختر الولاية أو المدينة 📍", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = citySearchQuery,
                        onValueChange = { citySearchQuery = it },
                        placeholder = { Text("ابحث برقم الولاية أو الاسم...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp)
                    ) {
                        items(filteredCities) { city ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.selectWilaya(city)
                                        showCitySearchDialog = false
                                        citySearchQuery = ""
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (city.wilayaNumber in 1..58) "${city.wilayaNumber}. ${city.name} (${city.nameFrench})" else "${city.name} (${city.country})",
                                    fontWeight = if (city.name == selectedCity?.name) FontWeight.Bold else FontWeight.Normal,
                                    color = if (city.name == selectedCity?.name) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                                if (city.name == selectedCity?.name) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showCitySearchDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "الطقس الزراعي والمناخ 🌤️",
                subtitle = "58 ولاية جزائرية ومؤشرات ملاءمة الرش",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = {
                            if (selectedCity != null) {
                                viewModel.loadWeatherForCity(selectedCity!!)
                            } else {
                                showCitySearchDialog = true
                            }
                        },
                        modifier = Modifier.testTag("refresh_weather_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // City / Wilaya Selector Button Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCitySearchDialog = true }
                    .testTag("open_wilaya_selector_button"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(AgriGreenMint),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = AgriGreenDark)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "المنطقة الزراعية المختارة:", fontSize = 12.sp, color = MaterialTheme.colorScheme.outline)
                            val currentCity = selectedCity
                            Text(
                                text = if (currentCity != null) {
                                    if (currentCity.wilayaNumber in 1..58) "${currentCity.wilayaNumber}. ${currentCity.name} (${currentCity.nameFrench})"
                                    else "${currentCity.name} (${currentCity.country})"
                                } else {
                                    "اضغط هنا لاختيار ولايتك 📍"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (currentCity != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Text(
                        text = if (selectedCity != null) "تغيير ❯" else "اختيار ❯",
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }

            if (isWeatherLoading) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("جاري الاتصال بخدمة Open-Meteo وجلب بيانات الطقس الحقيقية...")
                    }
                }
            }

            if (weatherError != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AlertRed.copy(alpha = 0.08f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = AlertRed)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = "تعذر جلب بيانات الطقس", fontWeight = FontWeight.Bold, color = AlertRed, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${weatherError}. لا يعرض التطبيق أي بيانات طقس تخمينية أو عشوائية حرصاً على عدم تضليلك في قرارات الري والرش.",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            lineHeight = 19.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                if (selectedCity != null) viewModel.loadWeatherForCity(selectedCity!!)
                                else showCitySearchDialog = true
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إعادة المحاولة")
                        }
                    }
                }
            }

            // Prompt when no city is selected yet
            if (selectedCity == null && !isWeatherLoading && weatherError == null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showCitySearchDialog = true },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "📍", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "يرجى تحديد ولايتك أو منطقتك الزراعية",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "اختر ولايتك من قائمة الـ 58 ولاية جزائرية لنقوم بالاتصال المباشر بخدمة الأرصاد Open-Meteo وتقديم مؤشرات حقيقية لملاءمة الرش وسرعة الرياح وجدول الري.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = { showCitySearchDialog = true },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("اختيار ولايتي الآن")
                        }
                    }
                }
            }

            val data = weatherData
            if (data != null) {
                // Live vs Cached status badge row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (data.isLive) AgriGreenMint else SoilAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (data.isLive) "🟢 بث مباشر (Live)" else "🟡 مخزن مؤقتاً (Cached Offline)",
                            color = if (data.isLive) AgriGreenDark else SoilAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = "آخر تحديث: ${data.lastUpdated}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                // Main Weather Dashboard Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${data.temperature}°C",
                                    style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.ExtraBold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = data.weatherCondition,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(AgriGreenMint),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = when {
                                        data.precipitation > 0 -> "🌧️"
                                        data.temperature > 32 -> "☀️"
                                        data.temperature < 10 -> "❄️"
                                        else -> "⛅"
                                    },
                                    fontSize = 36.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Stats Grid (Humidity, Wind, Precipitation)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Humidity
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.WaterDrop, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("الرطوبة", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Text("${data.humidity}%", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            // Wind Speed
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Air, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("سرعة الرياح", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Text("${data.windSpeed} كم/س", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }

                            // Precipitation
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Cloud, contentDescription = null, tint = AgriGreenDark, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("الأمطار", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                    Text("${data.precipitation} ملم", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }

                // Spraying Suitability Card (تحليل ملائمة الرش)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (data.isSprayingSuitable) AgriGreenMint else WarningOrange.copy(alpha = 0.12f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (data.isSprayingSuitable) AgriGreenDark.copy(alpha = 0.3f) else WarningOrange.copy(alpha = 0.4f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (data.isSprayingSuitable) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (data.isSprayingSuitable) AgriGreenDark else WarningOrange
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (data.isSprayingSuitable) "الظروف مواتية ومثالية للرش اليوم ✓" else "تنبيه: ظروف غير ملائمة للرش ⚠️",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (data.isSprayingSuitable) AgriGreenDark else WarningOrange
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = data.sprayingAdvice,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (data.isSprayingSuitable) AgriGreenDark else WarningOrange
                        )
                    }
                }

                // Irrigation Recommendation
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WaterDrop, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "توصية الري وفقاً للطقس",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = data.irrigationAdvice, style = MaterialTheme.typography.bodyMedium)
                    }
                }

                // Agricultural Alerts
                if (data.agriAlerts.isNotEmpty()) {
                    Text(
                        text = "التنبيهات والمخاطر المناخية:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    data.agriAlerts.forEach { alert ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (alert.isCritical) AlertRed.copy(alpha = 0.1f)
                                else MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = alert.title,
                                        fontWeight = FontWeight.Bold,
                                        color = if (alert.isCritical) AlertRed else MaterialTheme.colorScheme.primary
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (alert.isCritical) AlertRed else MaterialTheme.colorScheme.secondary)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(alert.severity, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = alert.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
