package com.example.ui.screens.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlgeriaWilayasData
import com.example.data.model.ProfessionalEntity
import com.example.data.model.ServiceCategoryEntity
import com.example.data.model.UserEntity
import com.example.ui.components.CraftsmanCard
import com.example.ui.components.ServiceIcon
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.screens.dialogs.AiDiagnosisDialog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    currentUser: UserEntity?,
    services: List<ServiceCategoryEntity>,
    topCraftsmen: List<ProfessionalEntity>,
    selectedWilayaCode: Int,
    selectedCommuneName: String,
    onLocationChanged: (Int, String, String) -> Unit,
    onCategoryClick: (ServiceCategoryEntity) -> Unit,
    onCraftsmanClick: (ProfessionalEntity) -> Unit,
    onRequestServiceClick: (ProfessionalEntity?) -> Unit,
    onNavigateToSearch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showAiDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_column"),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // 1. Sleek Top Header
        item {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Sleek Brand Logo Box
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "DZ",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    color = Color.White
                                )
                            }

                            Column {
                                Text(
                                    text = "خدملي DZ",
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 22.sp
                                )
                                Text(
                                    text = "لقى لي يخدمها • 58 ولاية",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Location Pill
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            onClick = { /* opens selector below */ },
                            modifier = Modifier.testTag("header_location_pill")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (selectedWilayaCode == 0) "كافة الـ 58 ولاية"
                                    else selectedCommuneName.ifBlank { AlgeriaWilayasData.getWilayaByCode(selectedWilayaCode)?.nameAr ?: "كل الولايات" },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.primary)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sleek Search Bar Trigger
                    Surface(
                        onClick = { onNavigateToSearch("") },
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        shadowElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_search_bar")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Search,
                                contentDescription = "بحث",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "ابحث عن حرفي (كهربائي، سباك، ميكانيكي...)",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 2. Location Selector
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                WilayaCommuneSelector(
                    selectedWilayaCode = selectedWilayaCode,
                    selectedCommuneName = selectedCommuneName,
                    onLocationSelected = onLocationChanged
                )
            }
        }

        // 3. AI Smart Diagnostic Banner
        item {
            Card(
                onClick = { showAiDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("ai_diagnosis_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تشخيص الأعطال بالذكاء الاصطناعي 🇩🇿",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "اشرح مشكلتك وسنقترح عليك الحرفي المناسب وإرشادات السلامة",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 16.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // 4. Categories Grid (الفئات الأكثر طلباً)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الفئات الأكثر طلباً",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = { onNavigateToSearch("") }) {
                        Text(
                            text = "عرض الكل",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                val displayServices = services.take(8)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    displayServices.chunked(4).forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowItems.forEach { service ->
                                val (boxBg, iconTint) = when (service.key) {
                                    "electrician" -> Pair(SleekOrangeContainer, SleekOrange)
                                    "plumber" -> Pair(SleekBlueLight, SleekBluePrimary)
                                    "mechanic" -> Pair(SleekEmeraldContainer, SleekEmerald)
                                    "builder" -> Pair(SleekPurpleContainer, SleekPurple)
                                    "painter" -> Pair(Color(0xFFFDF2F8), Color(0xFFDB2777))
                                    "ac_technician" -> Pair(Color(0xFFECFEFF), Color(0xFF0891B2))
                                    "cleaner" -> Pair(Color(0xFFF0FDFA), Color(0xFF0D9488))
                                    else -> Pair(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                                }

                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { onCategoryClick(service) }
                                        .testTag("service_item_${service.key}"),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(boxBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        ServiceIcon(
                                            iconName = service.iconName,
                                            tint = iconTint,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = service.nameAr.split(" ").firstOrNull() ?: service.nameAr,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                            repeat(4 - rowItems.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // 5. Emergency Intervention Banner
        item {
            Card(
                onClick = { onRequestServiceClick(null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .testTag("urgent_service_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SleekRedContainer),
                border = BorderStroke(1.dp, SleekRedAccent.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SleekRedAccent),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "طلب خدمة مستعجلة أو طارئة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = SleekRedAccent
                        )
                        Text(
                            text = "نشر طلبك لجميع الحرفيين المتاحين فوراً في ولايتك",
                            fontSize = 12.sp,
                            color = Color(0xFF7A0909)
                        )
                    }
                    Button(
                        onClick = { onRequestServiceClick(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = SleekRedAccent),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("اطلب الآن", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 6. Featured Artisans Section ("حرفيين موثوقين قريباً منك")
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "حرفيين موثوقين قريباً منك",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = { onNavigateToSearch("") }) {
                        Text("المزيد", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        if (topCraftsmen.isEmpty()) {
            item {
                Text(
                    text = "لا يوجد حرفيون مسجلون حالياً في هذه الولاية، يمكنك نشر طلب خدمة عام ليصل لجميع الحرفيين القريبين.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        } else {
            items(topCraftsmen, key = { it.id }) { craftsman ->
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
                    CraftsmanCard(
                        craftsman = craftsman,
                        onClick = { onCraftsmanClick(craftsman) },
                        onRequestService = { onRequestServiceClick(craftsman) }
                    )
                }
            }
        }
    }

    if (showAiDialog) {
        AiDiagnosisDialog(
            onDismiss = { showAiDialog = false },
            onApplyCategory = { catKey ->
                val matched = services.find { it.key == catKey }
                if (matched != null) {
                    onCategoryClick(matched)
                } else {
                    onNavigateToSearch(catKey)
                }
            }
        )
    }
}

