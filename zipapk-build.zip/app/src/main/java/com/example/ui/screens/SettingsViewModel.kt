package com.example.ui.screens

import android.app.Application
import android.location.Geocoder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Madhab
import com.example.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SettingsState(
    val calculationMethod: CalculationMethod = CalculationMethod.MUSLIM_WORLD_LEAGUE,
    val asrMethod: Madhab = Madhab.SHAFI,
    val useManualLocation: Boolean = false,
    val cityName: String? = null,
    val notificationsEnabled: Boolean = true,
    val preAlertEnabled: Boolean = false,
    val preAlertDuration: Int = 15,
    val adhanEnabled: Boolean = false,
    val vibrationEnabled: Boolean = true
)

data class CitySearchResult(val name: String, val lat: Double, val lng: Double)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val settingsRepository = SettingsRepository(application)
    
    private val _settingsState = MutableStateFlow(SettingsState())
    val settingsState: StateFlow<SettingsState> = _settingsState

    private val _searchResults = MutableStateFlow<List<CitySearchResult>>(emptyList())
    val searchResults: StateFlow<List<CitySearchResult>> = _searchResults

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError

    init {
        viewModelScope.launch {
            settingsRepository.calculationMethodFlow.collect {
                _settingsState.value = _settingsState.value.copy(calculationMethod = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.asrMethodFlow.collect {
                _settingsState.value = _settingsState.value.copy(asrMethod = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.useManualLocationFlow.collect {
                _settingsState.value = _settingsState.value.copy(useManualLocation = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.cityNameFlow.collect {
                _settingsState.value = _settingsState.value.copy(cityName = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.notificationsEnabledFlow.collect {
                _settingsState.value = _settingsState.value.copy(notificationsEnabled = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.preAlertEnabledFlow.collect {
                _settingsState.value = _settingsState.value.copy(preAlertEnabled = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.preAlertDurationFlow.collect {
                _settingsState.value = _settingsState.value.copy(preAlertDuration = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.adhanEnabledFlow.collect {
                _settingsState.value = _settingsState.value.copy(adhanEnabled = it)
            }
        }
        viewModelScope.launch {
            settingsRepository.vibrationEnabledFlow.collect {
                _settingsState.value = _settingsState.value.copy(vibrationEnabled = it)
            }
        }
    }

    fun setCalculationMethod(method: CalculationMethod) {
        viewModelScope.launch {
            settingsRepository.updateCalculationMethod(method)
            sendUpdateBroadcast()
        }
    }

    fun setAsrMethod(method: Madhab) {
        viewModelScope.launch {
            settingsRepository.updateAsrMethod(method)
            sendUpdateBroadcast()
        }
    }

    fun setUseManualLocation(useManual: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateUseManualLocation(useManual)
            if (!useManual) {
                clearSearch()
            }
            sendUpdateBroadcast()
        }
    }

    fun setManualLocation(lat: Double, lng: Double, cityName: String) {
        viewModelScope.launch {
            val tzId = com.example.data.TimeZoneHelper.getTimeZoneId(lat, lng)
            settingsRepository.updateLocation(lat, lng, cityName, tzId)
            settingsRepository.updateUseManualLocation(true)
            clearSearch()
            sendUpdateBroadcast()
        }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateNotificationsEnabled(enabled)
            sendUpdateBroadcast()
        }
    }

    fun setPreAlertEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updatePreAlertEnabled(enabled)
            sendUpdateBroadcast()
        }
    }

    fun setPreAlertDuration(duration: Int) {
        viewModelScope.launch {
            settingsRepository.updatePreAlertDuration(duration)
            sendUpdateBroadcast()
        }
    }

    fun setAdhanEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateAdhanEnabled(enabled)
            sendUpdateBroadcast()
        }
    }

    fun setVibrationEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.updateVibrationEnabled(enabled)
            sendUpdateBroadcast()
        }
    }
    
    private fun sendUpdateBroadcast() {
        val intent = android.content.Intent(getApplication(), com.example.receivers.PrayerAlarmReceiver::class.java).apply {
            putExtra(com.example.receivers.PrayerAlarmReceiver.EXTRA_IS_UPDATE, true)
        }
        getApplication<Application>().sendBroadcast(intent)
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
             _searchResults.value = emptyList()
             _searchError.value = null
        }
    }

    fun searchCity() {
        val query = _searchQuery.value
        if (query.isBlank()) return
        
        _isSearching.value = true
        _searchError.value = null
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
                val url = java.net.URL("https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=5&accept-language=ar,en")
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", "WathakkirApp/1.0")
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                if (connection.responseCode == java.net.HttpURLConnection.HTTP_OK) {
                    val response = connection.inputStream.bufferedReader().use { it.readText() }
                    val jsonArray = org.json.JSONArray(response)
                    val results = mutableListOf<CitySearchResult>()
                    
                    for (i in 0 until jsonArray.length()) {
                        val obj = jsonArray.getJSONObject(i)
                        val displayName = obj.getString("display_name")
                        val lat = obj.getString("lat").toDouble()
                        val lng = obj.getString("lon").toDouble()
                        
                        val parts = displayName.split(",").map { it.trim() }
                        val shortName = parts.take(3).joinToString("، ")
                        
                        results.add(CitySearchResult(shortName, lat, lng))
                    }
                    
                    val distinctResults = results.distinctBy { it.name }
                    
                    if (distinctResults.isNotEmpty()) {
                        _searchResults.value = distinctResults
                    } else {
                        _searchResults.value = emptyList()
                        _searchError.value = "لم يتم العثور على مدينة بهذا الاسم."
                    }
                } else {
                    _searchResults.value = emptyList()
                    _searchError.value = "فشل الاتصال بخادم البحث."
                }
                connection.disconnect()
            } catch (e: Exception) {
                _searchResults.value = emptyList()
                _searchError.value = "حدث خطأ أثناء البحث. يرجى التحقق من الاتصال بالإنترنت."
            } finally {
                _isSearching.value = false
            }
        }
    }
    
    fun clearSearch() {
        _searchQuery.value = ""
        _searchResults.value = emptyList()
        _searchError.value = null
    }
}
