package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppBackground
import com.example.ui.theme.AppPrimary
import com.example.ui.theme.AppSurface
import com.example.ui.theme.CardBorder

@Composable
fun WirdScreen(modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            WirdCircularProgress()
            Spacer(modifier = Modifier.height(24.dp))
        }
        item {
            WirdStatsRow()
            Spacer(modifier = Modifier.height(16.dp))
        }
        item {
            WeeklyChartCard()
            Spacer(modifier = Modifier.height(16.dp))
        }
        item {
            Button(
                onClick = { /* TODO */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AppPrimary,
                    contentColor = Color.Black
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("تابع الورد — صفحة ٤", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.Outlined.MenuBook, contentDescription = null)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
        item {
            ExtraGoalsSection()
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun WirdCircularProgress() {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(240.dp)
    ) {
        Canvas(modifier = Modifier.size(240.dp)) {
            drawArc(
                color = CardBorder,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = AppPrimary,
                startAngle = -90f,
                sweepAngle = 360f * 0.6f,
                useCenter = false,
                style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ورد اليوم", color = Color.White, fontSize = 20.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text("٣/٥", color = AppPrimary, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("صفحات", color = Color.White, fontSize = 20.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            HorizontalDivider(
                modifier = Modifier
                    .width(80.dp)
                    .padding(vertical = 12.dp),
                color = CardBorder,
                thickness = 2.dp
            )
            Text("٪٦٠", color = AppPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun WirdStatsRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.weight(1f).height(80.dp),
            colors = CardDefaults.cardColors(containerColor = AppSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("الختمة", color = Color.White, fontSize = 14.sp)
                    Text("١٧ جزءًا متبقيًا", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Icon(Icons.Outlined.MenuBook, contentDescription = null, tint = AppPrimary, modifier = Modifier.size(32.dp))
            }
        }

        Card(
            modifier = Modifier.weight(1f).height(80.dp),
            colors = CardDefaults.cardColors(containerColor = AppSurface),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("١٤", color = AppPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("يومًا متتاليًا", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Icon(Icons.Outlined.LocalFireDepartment, contentDescription = null, tint = AppPrimary, modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
fun WeeklyChartCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("صفحات مقروءة هذا الأسبوع", color = Color.White, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(24.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth().height(120.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                val data = listOf(
                    "الجمعة" to 3,
                    "الخميس" to 5,
                    "الأربعاء" to 5,
                    "الثلاثاء" to 4,
                    "الاثنين" to 5,
                    "الأحد" to 3,
                    "السبت" to 5
                )
                val maxVal = 6f
                
                data.forEach { (day, value) ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Text(value.toString(), color = Color(0xFF4ADE80), fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .width(24.dp)
                                .fillMaxHeight(value / maxVal)
                                .background(Color(0xFF22543D), RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(day, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ExtraGoalsSection() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text("أهداف إضافية", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(bottom = 12.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GoalCard("أذكار الصباح", Icons.Outlined.Check, isCompleted = true, modifier = Modifier.weight(1f))
            GoalCard("حفظ: سورة الملك", Icons.Outlined.BookmarkBorder, isCompleted = false, modifier = Modifier.weight(1.2f))
            GoalCard("تسبيح: ٣٣/٣٣", Icons.Outlined.Circle, isCompleted = false, modifier = Modifier.weight(1f))
        }
    }
}

@Composable
fun GoalCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, isCompleted: Boolean, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .background(if (isCompleted) Color(0xFF162215) else AppSurface, RoundedCornerShape(12.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = if (isCompleted) Color(0xFF4ADE80) else Color.White.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(title, color = if (isCompleted) Color(0xFF4ADE80) else Color.White, fontSize = 11.sp)
    }
}
