package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiseaseLibraryItem
import com.example.data.model.EncyclopediaPlant
import com.example.data.model.PlantEncyclopediaData
import com.example.ui.PlantDoctorViewModel
import com.example.ui.Screen
import com.example.ui.components.AppTopBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.SoilAmber
import com.example.ui.theme.WarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncyclopediaScreen(viewModel: PlantDoctorViewModel) {
    val userProfile by viewModel.userProfile.collectAsState()
    val isFrench = userProfile.preferredLanguage.contains("Fran", ignoreCase = true)

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Plants, 1: Treatments (IPM), 2: Favorites
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }

    val categories = listOf("الكل", "أشجار مثمرة", "خضروات", "نباتات زينة", "نباتات عطرية", "نخيل")

    val filteredPlants = PlantEncyclopediaData.plants.filter { plant ->
        val matchesCategory = selectedCategory == "الكل" || plant.category == selectedCategory
        val matchesSearch = searchQuery.isBlank() ||
                plant.arabicName.contains(searchQuery, ignoreCase = true) ||
                plant.frenchName.contains(searchQuery, ignoreCase = true) ||
                plant.commonName.contains(searchQuery, ignoreCase = true) ||
                plant.scientificName.contains(searchQuery, ignoreCase = true)
        val isFav = !userProfile.favoriteItems.contains(plant.id) || selectedTabIndex != 2
        matchesCategory && matchesSearch && (selectedTabIndex != 2 || userProfile.favoriteItems.contains(plant.id))
    }

    val filteredDiseases = PlantEncyclopediaData.diseases.filter { disease ->
        val matchesSearch = searchQuery.isBlank() ||
                disease.arabicName.contains(searchQuery, ignoreCase = true) ||
                disease.frenchName.contains(searchQuery, ignoreCase = true) ||
                disease.scientificName.contains(searchQuery, ignoreCase = true) ||
                disease.pathogenType.contains(searchQuery, ignoreCase = true) ||
                disease.affectedPlants.any { it.contains(searchQuery, ignoreCase = true) }
        matchesSearch && (selectedTabIndex != 2 || userProfile.favoriteItems.contains(disease.id))
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (isFrench) "Encyclopédie & Traitements 📖" else "الموسوعة والمكتبة الزراعية 📖",
                subtitle = if (isFrench) "Guide de protection des cultures (INRAA / FAO)" else "دليل النباتات والمكافحة المتكاملة (INRAA / FAO)",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Three Tabs: Plants, Treatments & IPM, Favorites
            TabRow(selectedTabIndex = selectedTabIndex) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text(if (isFrench) "Plantes" else "النباتات والمحاصيل", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text(if (isFrench) "Maladies & IPM" else "مكتبة الأمراض والوقاية", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text(if (isFrench) "Favoris ⭐" else "المفضلة ⭐", fontWeight = FontWeight.Bold) }
                )
            }

            // Universal Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("encyclopedia_search_input"),
                placeholder = {
                    Text(
                        when (selectedTabIndex) {
                            1 -> if (isFrench) "Rechercher une maladie, champignon..." else "ابحث عن مرض أو حشرة أو مادة فعالة..."
                            else -> if (isFrench) "Rechercher une plante, olivier..." else "ابحث عن نبتة أو شجرة أو محصول..."
                        }
                    )
                },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            // Category Chips for Plants tab
            if (selectedTabIndex == 0) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            // Content based on tab
            when (selectedTabIndex) {
                0 -> {
                    // Plants List
                    if (filteredPlants.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.MenuBook,
                            title = "لم يتم العثور على نتائج",
                            description = "جرب البحث باسم نبات آخر مثل الزيتون، الطماطم، الليمون أو النخيل"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(filteredPlants) { plant ->
                                val isFav = viewModel.isFavorite(plant.id)
                                EncyclopediaItemCard(
                                    plant = plant,
                                    isFrench = isFrench,
                                    isFavorite = isFav,
                                    onFavoriteClick = { viewModel.toggleFavorite(plant.id) },
                                    onClick = {
                                        viewModel.addRecentView(plant.arabicName)
                                        viewModel.setSelectedEncyclopediaPlant(plant)
                                        viewModel.navigateTo(Screen.EncyclopediaDetail)
                                    }
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // Diseases & IPM Library List
                    if (filteredDiseases.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.MedicalServices,
                            title = "لم يتم العثور على أمراض مطابقة",
                            description = "جرب البحث باسم المسبب مثل البياض، الميلديو، التوتا أو الكلوروز"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filteredDiseases) { disease ->
                                val isFav = viewModel.isFavorite(disease.id)
                                DiseaseLibraryItemCard(
                                    item = disease,
                                    isFrench = isFrench,
                                    isFavorite = isFav,
                                    onFavoriteClick = { viewModel.toggleFavorite(disease.id) }
                                )
                            }
                        }
                    }
                }
                2 -> {
                    // Favorites Tab (Plants + Diseases)
                    val favoritePlants = PlantEncyclopediaData.plants.filter { viewModel.isFavorite(it.id) }
                    val favoriteDiseases = PlantEncyclopediaData.diseases.filter { viewModel.isFavorite(it.id) }

                    if (favoritePlants.isEmpty() && favoriteDiseases.isEmpty()) {
                        EmptyStateCard(
                            icon = Icons.Default.Star,
                            title = "قائمة المفضلة فارغة",
                            description = "اضغط على أيقونة النجمة ⭐ بجانب أي نبتة أو مرض للرجوع إليه سريعاً هنا"
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (favoritePlants.isNotEmpty()) {
                                item {
                                    Text(
                                        text = "النباتات المحفوظة:",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                }
                                items(favoritePlants) { plant ->
                                    EncyclopediaItemCard(
                                        plant = plant,
                                        isFrench = isFrench,
                                        isFavorite = true,
                                        onFavoriteClick = { viewModel.toggleFavorite(plant.id) },
                                        onClick = {
                                            viewModel.setSelectedEncyclopediaPlant(plant)
                                            viewModel.navigateTo(Screen.EncyclopediaDetail)
                                        }
                                    )
                                }
                            }

                            if (favoriteDiseases.isNotEmpty()) {
                                item {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = "الأمراض والعلاجات المحفوظة:",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    )
                                }
                                items(favoriteDiseases) { disease ->
                                    DiseaseLibraryItemCard(
                                        item = disease,
                                        isFrench = isFrench,
                                        isFavorite = true,
                                        onFavoriteClick = { viewModel.toggleFavorite(disease.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EncyclopediaItemCard(
    plant: EncyclopediaPlant,
    isFrench: Boolean,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("encyclopedia_item_${plant.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(AgriGreenMint),
                contentAlignment = Alignment.Center
            ) {
                Text(text = plant.imageEmoji, fontSize = 28.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isFrench) "${plant.frenchName} (${plant.arabicName})" else plant.arabicName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    text = plant.scientificName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isFrench) plant.frenchCategory else plant.category,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "سقاية كل ${plant.wateringIntervalDays} أيام",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            IconButton(onClick = onFavoriteClick) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                    contentDescription = "تفضيل",
                    tint = if (isFavorite) SoilAmber else Color.LightGray
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun DiseaseLibraryItemCard(
    item: DiseaseLibraryItem,
    isFrench: Boolean,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("disease_item_${item.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isFrench) "${item.frenchName} (${item.arabicName})" else item.arabicName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = item.scientificName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                when {
                                    item.pathogenType.contains("فطر") -> MaterialTheme.colorScheme.secondaryContainer
                                    item.pathogenType.contains("حشر") -> Color(0xFFFFF3E0)
                                    item.pathogenType.contains("عناصر") -> AgriGreenMint
                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = item.pathogenType,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                item.pathogenType.contains("فطر") -> MaterialTheme.colorScheme.secondary
                                item.pathogenType.contains("حشر") -> WarningOrange
                                item.pathogenType.contains("عناصر") -> AgriGreenDark
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )
                    }

                    IconButton(onClick = onFavoriteClick) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = "تفضيل",
                            tint = if (isFavorite) SoilAmber else Color.LightGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "المحاصيل المعرضة: ${item.affectedPlants.joinToString("، ")}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = item.symptomsSummary, style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(10.dp))

            // IPM Preventive Steps Box (أولاً: الحلول غير الكيميائية)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(AgriGreenMint.copy(alpha = 0.5f))
                    .padding(10.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Eco, contentDescription = null, tint = AgriGreenDark, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "المكافحة الزراعية والوقائية (IPM):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AgriGreenDark
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    item.ipmPreventiveSteps.forEach { step ->
                        Text(text = "• $step", fontSize = 11.sp, color = AgriGreenDark)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Active Substances & Safety
            Text(
                text = "المواد الفعالة المرخصة: ${item.activeSubstances.joinToString(" • ")}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "فترة الأمان (PHI): ${item.phiDays}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "تنبيه النحل والبيئة: ${item.safetyAndBeePrecautions}",
                fontSize = 11.sp,
                color = WarningOrange
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "المرجع: ${item.authoritativeSource}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}
