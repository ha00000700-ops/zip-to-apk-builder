package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.QuranRepository
import com.example.data.Surah
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class SurahViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = QuranRepository(application)
    
    private val _surah = MutableStateFlow<Surah?>(null)
    val surah: StateFlow<Surah?> = _surah
    
    private val _fontSize = MutableStateFlow(24f)
    val fontSize: StateFlow<Float> = _fontSize

    fun loadSurah(surahNumber: Int) {
        viewModelScope.launch {
            _surah.value = repository.getSurah(surahNumber)
        }
    }
    
    fun increaseFontSize() {
        if (_fontSize.value < 40f) {
            _fontSize.value += 2f
        }
    }
    
    fun decreaseFontSize() {
        if (_fontSize.value > 16f) {
            _fontSize.value -= 2f
        }
    }
    
    fun toggleBookmark(surahNumber: Int, surahName: String, ayahNumber: Int, textSnippet: String, isBookmarked: Boolean) {
        viewModelScope.launch {
            repository.toggleBookmark(surahNumber, surahName, ayahNumber, textSnippet, isBookmarked)
        }
    }
    
    fun isBookmarked(surahNumber: Int, ayahNumber: Int): Flow<Boolean> {
        return repository.isBookmarked(surahNumber, ayahNumber)
    }
    
    fun saveLastRead(surahNumber: Int, surahName: String, ayahNumber: Int) {
        viewModelScope.launch {
            repository.saveLastRead(surahNumber, surahName, ayahNumber)
        }
    }
}
