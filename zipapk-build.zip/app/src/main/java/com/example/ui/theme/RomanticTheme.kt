package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class RomanticTheme(
    val id: String,
    val titleArabic: String,
    val subtitleArabic: String,
    val emoji: String,
    val primary: Color,
    val primaryContainer: Color,
    val secondary: Color,
    val tertiary: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val previewGradient: List<Color>
) {
    ROSE_RUBY(
        id = "ROSE_RUBY",
        titleArabic = "ورد وياقوت",
        subtitleArabic = "الرومانسية الكلاسيكية الدافئة",
        emoji = "🌹",
        primary = Color(0xFFF43F5E),
        primaryContainer = Color(0xFFFFE4E6),
        secondary = Color(0xFFFB923C),
        tertiary = Color(0xFFEC4899),
        background = Color(0xFFFFF7F8),
        surface = Color.White,
        surfaceVariant = Color(0xFFFFF1F2),
        previewGradient = listOf(Color(0xFFF43F5E), Color(0xFFFB7185), Color(0xFFFFD1DC))
    ),
    LOVERS_SUNSET(
        id = "LOVERS_SUNSET",
        titleArabic = "غروب العشاق",
        subtitleArabic = "دفء الشفق وألوان الغروب الذهبي",
        emoji = "🌅",
        primary = Color(0xFFEA580C),
        primaryContainer = Color(0xFFFFEDD5),
        secondary = Color(0xFFD97706),
        tertiary = Color(0xFFDB2777),
        background = Color(0xFFFFF8F1),
        surface = Color.White,
        surfaceVariant = Color(0xFFFFEAD5),
        previewGradient = listOf(Color(0xFFEA580C), Color(0xFFF59E0B), Color(0xFFFDA4AF))
    ),
    LAVENDER_DREAM(
        id = "LAVENDER_DREAM",
        titleArabic = "حلم اللافندر",
        subtitleArabic = "سحر البنفسج الهادئ والخيالي",
        emoji = "💜",
        primary = Color(0xFF8B5CF6),
        primaryContainer = Color(0xFFEDE9FE),
        secondary = Color(0xFFA855F7),
        tertiary = Color(0xFFEC4899),
        background = Color(0xFFFAF5FF),
        surface = Color.White,
        surfaceVariant = Color(0xFFF3E8FF),
        previewGradient = listOf(Color(0xFF8B5CF6), Color(0xFFA78BFA), Color(0xFFE9D5FF))
    ),
    MIDNIGHT_LOVE(
        id = "MIDNIGHT_LOVE",
        titleArabic = "سماء العشق الليلية",
        subtitleArabic = "نجوم لامعة ولمسات ليلية ملكية",
        emoji = "🌌",
        primary = Color(0xFF6366F1),
        primaryContainer = Color(0xFFE0E7FF),
        secondary = Color(0xFF38BDF8),
        tertiary = Color(0xFFF43F5E),
        background = Color(0xFF13152C),
        surface = Color(0xFF1E2243),
        surfaceVariant = Color(0xFF2B2F5C),
        previewGradient = listOf(Color(0xFF312E81), Color(0xFF4F46E5), Color(0xFF818CF8))
    ),
    CHERRY_BLOSSOM(
        id = "CHERRY_BLOSSOM",
        titleArabic = "زهر الكرز الساحر",
        subtitleArabic = "باستيل ناعم وأنوثة رقيقة",
        emoji = "🌸",
        primary = Color(0xFFE11D48),
        primaryContainer = Color(0xFFFFE4E6),
        secondary = Color(0xFFF472B6),
        tertiary = Color(0xFFFB7185),
        background = Color(0xFFFFF5F7),
        surface = Color.White,
        surfaceVariant = Color(0xFFFFEEF2),
        previewGradient = listOf(Color(0xFFFB7185), Color(0xFFF472B6), Color(0xFFFFE4E6))
    ),
    EMERALD_ROMANCE(
        id = "EMERALD_ROMANCE",
        titleArabic = "واحة الغرام",
        subtitleArabic = "خضرة الطبيعة وراحة البال والهدوء",
        emoji = "🌿",
        primary = Color(0xFF059669),
        primaryContainer = Color(0xFFD1FAE5),
        secondary = Color(0xFF10B981),
        tertiary = Color(0xFF14B8A6),
        background = Color(0xFFF0FDF4),
        surface = Color.White,
        surfaceVariant = Color(0xFFDCFCE7),
        previewGradient = listOf(Color(0xFF059669), Color(0xFF34D399), Color(0xFFA7F3D0))
    );

    companion object {
        fun fromId(id: String?): RomanticTheme {
            return values().firstOrNull { it.id == id } ?: ROSE_RUBY
        }
    }
}

enum class CardTransparencyStyle(
    val id: String,
    val titleArabic: String,
    val description: String,
    val surfaceAlpha: Float,
    val borderAlpha: Float
) {
    TRANSLUCENT_GLASS(
        id = "TRANSLUCENT_GLASS",
        titleArabic = "زجاجي شفاف 💎",
        description = "تظهر خلفية الطقس والغيوم خلف البطاقات برومانسية",
        surfaceAlpha = 0.82f,
        borderAlpha = 0.40f
    ),
    SOLID_COZY(
        id = "SOLID_COZY",
        titleArabic = "مصمت دافئ 📜",
        description = "تباين عالي ووضوح كامل للنصوص والأرقام",
        surfaceAlpha = 0.96f,
        borderAlpha = 0.20f
    ),
    GLOW_ROMANTIC(
        id = "GLOW_ROMANTIC",
        titleArabic = "توهج مشع ✨",
        description = "إطار متوهج يضفي لمسة عاطفية ساحرة",
        surfaceAlpha = 0.88f,
        borderAlpha = 0.80f
    );

    companion object {
        fun fromId(id: String?): CardTransparencyStyle {
            return values().firstOrNull { it.id == id } ?: TRANSLUCENT_GLASS
        }
    }
}
