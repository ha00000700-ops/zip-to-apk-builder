package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlantDoctorViewModel
import com.example.ui.Screen
import com.example.ui.components.AppTopBar
import com.example.ui.components.SeverityBadge
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.AlertRed
import com.example.ui.theme.SoilAmber
import com.example.ui.theme.WarningOrange
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosisDetailScreen(viewModel: PlantDoctorViewModel) {
    val context = LocalContext.current
    val diagnosis by viewModel.selectedDiagnosis.collectAsState()

    var showReportDialog by remember { mutableStateOf(false) }
    var reportText by remember { mutableStateOf("") }
    var reportEmail by remember { mutableStateOf("") }
    var reportSubmittedSuccess by remember { mutableStateOf(false) }

    if (diagnosis == null) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "تقرير التشخيص",
                    showBackButton = true,
                    onBackClick = { viewModel.navigateBack() }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("لا يوجد تقرير فحص محدد")
            }
        }
        return
    }

    val item = diagnosis!!
    var followUpNotes by remember(item) { mutableStateOf(item.followUpNotes) }
    var rating by remember(item) { mutableStateOf(item.improvementRating) }
    var secondImagePath by remember(item) { mutableStateOf(item.secondImagePath) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = viewModel.copyUriToLocalCache(context, uri)
            if (copied != null) {
                secondImagePath = copied.absolutePath
                viewModel.updateDiagnosisFollowUp(item.id, copied.absolutePath, followUpNotes, rating)
            }
        }
    }

    // Previous diagnoses of this plant for comparison
    val previousDiagnosesList by viewModel.getPreviousDiagnosesForPlant(item.plantCommonName)
        .collectAsState(initial = emptyList())
    val olderDiagnoses = previousDiagnosesList.filter { it.id != item.id }

    // Dialog for reporting inaccurate recommendation
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Flag, contentDescription = null, tint = AlertRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("الإبلاغ عن تشخيص أو نصيحة غير دقيقة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "نحن نحرص على تقديم معلومات زراعية دقيقة وموثوقة. ما هي الملاحظة أو التصويب لهذا التشخيص؟",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reportText,
                        onValueChange = { reportText = it },
                        label = { Text("ملاحظتك أو التشخيص البديل") },
                        placeholder = { Text("مثال: الأعراض تشبه نقص البوتاسيوم وليس البياض...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 4
                    )
                    OutlinedTextField(
                        value = reportEmail,
                        onValueChange = { reportEmail = it },
                        label = { Text("بريدك الإلكتروني للتواصل (اختياري)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reportText.isNotBlank()) {
                            viewModel.reportDiagnosisIssue(
                                diagnosisId = item.id,
                                userFeedback = reportText,
                                contactEmail = reportEmail,
                                onSuccess = {
                                    showReportDialog = false
                                    reportSubmittedSuccess = true
                                }
                            )
                        }
                    },
                    enabled = reportText.isNotBlank()
                ) {
                    Text("إرسال البلاغ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "تقرير الفحص والعلاج 📋",
                subtitle = item.plantCommonName,
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() },
                actions = {
                    IconButton(
                        onClick = { viewModel.shareDiagnosisReport(context, item) },
                        modifier = Modifier.testTag("share_diagnosis_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة التقرير",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = { showReportDialog = true },
                        modifier = Modifier.testTag("report_issue_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = "الإبلاغ عن خطأ",
                            tint = AlertRed
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("diagnosis_detail_scroll"),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (reportSubmittedSuccess) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AgriGreenMint)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "شكراً لمساهمتك! تم تسجيل ملاحظتك وسيتم مراجعتها من قِبل الفريق الزراعي.",
                            color = AgriGreenDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // 1. Primary Image Preview
            if (item.imagePath.isNotBlank()) {
                val file = File(item.imagePath)
                if (file.exists()) {
                    val bitmap = remember(item.imagePath) { BitmapFactory.decodeFile(item.imagePath) }
                    if (bitmap != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = item.plantCommonName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            // Additional Photos thumbnails if present
            if (item.additionalImages.isNotBlank()) {
                val paths = item.additionalImages.split(";").filter { it.isNotBlank() }
                if (paths.isNotEmpty()) {
                    Text(
                        text = "الصور التكميلية المفحوصة (ورقة / ساق / ثمرة):",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        paths.forEach { path ->
                            val f = File(path)
                            if (f.exists()) {
                                val bm = remember(path) { BitmapFactory.decodeFile(path) }
                                if (bm != null) {
                                    Box(
                                        modifier = Modifier
                                            .size(70.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                    ) {
                                        Image(
                                            bitmap = bm.asImageBitmap(),
                                            contentDescription = "صورة تكميلية",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 2. Main Disease Title & Classification Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.diseaseName,
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (item.scientificDiseaseName.isNotBlank()) {
                                Text(
                                    text = item.scientificDiseaseName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }
                        }
                        SeverityBadge(severity = item.severity)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Badges row: Pathogen type + Confidence + Urgency
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Pathogen category
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.secondaryContainer)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "مسبب: ${item.pathogenType}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }

                        // Confidence
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "اليقين: ${item.confidenceLevel}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Urgency
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(WarningOrange.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = item.urgency,
                                fontSize = 12.sp,
                                color = WarningOrange,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "النبات: ${item.plantCommonName} (${item.plantScientificName})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "الجزء المتضرر: ${item.affectedPart}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            // 3. Clarifying Follow-Up Questions (When photo was blurry or diagnosis needs refinement)
            if (item.clarifyingQuestions.isNotBlank()) {
                val questions = item.clarifyingQuestions.split(";;").filter { it.isNotBlank() }
                if (questions.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SoilAmber.copy(alpha = 0.1f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SoilAmber.copy(alpha = 0.4f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = SoilAmber)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "أسئلة متابعة ذكية لتدقيق التشخيص:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = SoilAmber
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            questions.forEach { q ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.White)
                                        .clickable {
                                            viewModel.setChatInputText("بخصوص تشخيص '${item.plantCommonName}': $q")
                                            viewModel.navigateTo(Screen.Chat)
                                        }
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = "• $q", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                    Icon(Icons.Default.Chat, contentDescription = "اسأل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // 4. Symptoms Summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الأعراض والمشاهدات السريرية",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = item.symptomsSummary, style = MaterialTheme.typography.bodyMedium)

                    if (item.possibleCauses.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "الأسباب والظروف المشجعة:",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(text = item.possibleCauses, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    if (item.alternativeDiagnoses.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "تشخيصات تفريقية أخرى محتملة:",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(text = item.alternativeDiagnoses, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                }
            }

            // 5. Immediate Agricultural Intervention
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AgriGreenMint.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MedicalServices, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "التدخل الفوري المقترح ⚡",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = AgriGreenDark
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = item.immediateActions, style = MaterialTheme.typography.bodyMedium, color = AgriGreenDark)
                }
            }

            // 6. Preventive & Non-Chemical IPM Solutions
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Eco, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "طرق الوقاية والعناية البيئية (IPM)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = item.preventiveCare, style = MaterialTheme.typography.bodyMedium)
                }
            }

            // 7. Active Substances & Chemical Treatments
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = WarningOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "المواد الفعالة والعلاج المرخص",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = item.chemicalTreatments, style = MaterialTheme.typography.bodyMedium)

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "📚 المرجع العلمي المعتمد:",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = item.scientificSources.ifBlank { "المعهد الوطني للأبحاث الزراعية (INRAA) / دليل FAO لحماية النباتات" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // 8. Compare with Older Diagnoses of the same plant
            if (olderDiagnoses.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "فحوصات سابقة لهذا النبات (${olderDiagnoses.size})",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        olderDiagnoses.take(3).forEach { old ->
                            val dateStr = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(old.timestamp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .clickable {
                                        viewModel.setSelectedDiagnosis(old)
                                    }
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = old.diseaseName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "$dateStr • ${old.severity}", fontSize = 11.sp, color = MaterialTheme.colorScheme.outline)
                                }
                                Icon(Icons.Default.Compare, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // 9. Follow-Up Tracking Card (Second photo + Improvement rating)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "متابعة تطور حالة النبات بعد العلاج 📸",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "التقط صورة بعد 5-7 أيام لمقارنة تطور الشفاء ومدى نجاح العلاج المقترح.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (secondImagePath.isNotBlank()) {
                        val file = File(secondImagePath)
                        if (file.exists()) {
                            val bitmap = remember(secondImagePath) { BitmapFactory.decodeFile(secondImagePath) }
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "صورة المتابعة",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(160.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (secondImagePath.isBlank()) "إضافة صورة متابعة بعد العلاج" else "تغيير صورة المتابعة")
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "تقييم تحسن النبات بعد تطبيق الإرشادات:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..5).forEach { star ->
                            IconButton(
                                onClick = {
                                    rating = star
                                    viewModel.updateDiagnosisFollowUp(item.id, secondImagePath, followUpNotes, star)
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = if (star <= rating) SoilAmber else Color.LightGray,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = followUpNotes,
                        onValueChange = {
                            followUpNotes = it
                            viewModel.updateDiagnosisFollowUp(item.id, secondImagePath, it, rating)
                        },
                        label = { Text("ملاحظاتك بعد أسبوع من العلاج") },
                        placeholder = { Text("مثال: توقف انتشار البقع، وبدأت أوراق فتية جديدة بالظهور...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )
                }
            }

            // Consult Plant Doctor Chat Directly Button
            Button(
                onClick = {
                    viewModel.setChatInputText("أريد استفساراً تفصيلياً حول نتائج فحص '${item.plantCommonName}' المصاب بـ '${item.diseaseName}'. ما هي الخطوات القادمة؟")
                    viewModel.navigateTo(Screen.Chat)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("تحدث مع طبيب النباتات حول هذا التقرير 💬", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
