package com.example.ui.screens.requests

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.ServiceIcon
import com.example.ui.components.UrgencyBadge
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.screens.dialogs.AiDiagnosisDialog
import com.example.ui.theme.DzGreenPrimary
import com.example.ui.theme.DzRedAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateRequestScreen(
    currentUser: UserEntity?,
    targetCraftsman: ProfessionalEntity?,
    services: List<ServiceCategoryEntity>,
    onBack: () -> Unit,
    onSubmitRequest: (ServiceRequestEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedServiceId by remember {
        mutableStateOf(targetCraftsman?.serviceCategoryId ?: services.firstOrNull()?.id ?: 1L)
    }
    var selectedServiceName by remember {
        mutableStateOf(targetCraftsman?.professionNameAr ?: services.firstOrNull()?.nameAr ?: "خدمة عامة")
    }
    var problemDescription by remember { mutableStateOf("") }
    var urgency by remember { mutableStateOf(RequestUrgency.NORMAL) }
    var wilayaCode by remember { mutableStateOf(currentUser?.wilayaCode ?: targetCraftsman?.wilayaCode ?: 16) }
    var wilayaName by remember { mutableStateOf(currentUser?.wilayaNameAr ?: targetCraftsman?.wilayaNameAr ?: "الجزائر") }
    var communeName by remember { mutableStateOf(currentUser?.communeNameAr ?: targetCraftsman?.communeNameAr ?: "الجزائر الوسطى") }
    var addressDetails by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf(currentUser?.phone ?: "") }
    var showAiDialog by remember { mutableStateOf(false) }
    var isSubmitting by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (targetCraftsman != null) "طلب خدمة من ${targetCraftsman.fullName}" else "إنشاء طلب خدمة جديد", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Target Craftsman Banner if any
            if (targetCraftsman != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = DzGreenPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("الحرفي الموجه إليه الطلب:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${targetCraftsman.fullName} (${targetCraftsman.professionNameAr})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }

            // 1. Service Category Selection
            item {
                Column {
                    Text("1. نوع الخدمة المطلوبة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(services) { s ->
                            val isSelected = s.id == selectedServiceId
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedServiceId = s.id
                                    selectedServiceName = s.nameAr
                                },
                                label = { Text(s.nameAr, fontSize = 12.sp) },
                                leadingIcon = {
                                    ServiceIcon(iconName = s.iconName, modifier = Modifier.size(16.dp))
                                }
                            )
                        }
                    }
                }
            }

            // 2. Problem Description with AI Assistant Trigger
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("2. وصف المشكلة أو العطل:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        TextButton(onClick = { showAiDialog = true }) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("المساعد الذكي", fontSize = 12.sp, color = DzGreenPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedTextField(
                        value = problemDescription,
                        onValueChange = { problemDescription = it },
                        placeholder = { Text("اشرح المشكلة بدقة (مثال: تسريب مياه في أنبوب المطبخ تحت الحوض، نحتاج تغيير القطعة التالفة...)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("request_problem_input"),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 5
                    )
                }
            }

            // 3. Urgency Selector
            item {
                Column {
                    Text("3. درجة الاستعجال:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RequestUrgency.values().forEach { u ->
                            val isSelected = urgency == u
                            Surface(
                                onClick = { urgency = u },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = when (u) {
                                            RequestUrgency.NORMAL -> "عادي"
                                            RequestUrgency.URGENT -> "مستعجل"
                                            RequestUrgency.EMERGENCY -> "طارئ 🚨"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (u == RequestUrgency.EMERGENCY) DzRedAccent else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 4. Location Selector
            item {
                Column {
                    Text("4. موقع التدخل (الولاية والبلدية):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    WilayaCommuneSelector(
                        selectedWilayaCode = wilayaCode,
                        selectedCommuneName = communeName,
                        onLocationSelected = { code, wName, cName ->
                            wilayaCode = code
                            wilayaName = wName
                            communeName = cName
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = addressDetails,
                        onValueChange = { addressDetails = it },
                        label = { Text("العنوان بالتفصيل أو الحي (اختياري)") },
                        placeholder = { Text("مثال: حي النصر عمارة 4 الشقة 12") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            }

            // 5. Contact Phone
            item {
                Column {
                    Text("5. رقم هاتف الزبون للتواصل:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("رقم الهاتف (05 / 06 / 07)") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("request_phone_input"),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            }

            // Submit Button
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (problemDescription.isBlank()) {
                            Toast.makeText(context, "الرجاء كتابة وصف للمشكلة", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (customerPhone.isBlank()) {
                            Toast.makeText(context, "الرجاء كتابة رقم الهاتف للتواصل", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        isSubmitting = true
                        val newReq = ServiceRequestEntity(
                            customerId = currentUser?.id ?: 2L,
                            customerName = currentUser?.fullName ?: "زبون خدملي",
                            customerPhone = customerPhone,
                            professionalId = targetCraftsman?.id,
                            professionalName = targetCraftsman?.fullName,
                            professionalPhone = targetCraftsman?.phone,
                            serviceCategoryId = selectedServiceId,
                            serviceNameAr = selectedServiceName,
                            description = problemDescription,
                            urgency = urgency,
                            wilayaCode = wilayaCode,
                            wilayaNameAr = wilayaName,
                            communeNameAr = communeName,
                            addressDetails = addressDetails,
                            status = RequestStatus.NEW
                        )
                        onSubmitRequest(newReq)
                    },
                    enabled = !isSubmitting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_request_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد وإرسال الطلب", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showAiDialog) {
        AiDiagnosisDialog(
            initialDescription = problemDescription,
            onDismiss = { showAiDialog = false },
            onApplyCategory = { catKey ->
                val matched = services.find { it.key == catKey }
                if (matched != null) {
                    selectedServiceId = matched.id
                    selectedServiceName = matched.nameAr
                }
            }
        )
    }
}
