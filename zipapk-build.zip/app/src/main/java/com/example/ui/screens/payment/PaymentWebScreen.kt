package com.example.ui.screens.payment

import android.graphics.Bitmap
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.PaymentMethod
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch

@Composable
fun PaymentWebScreen(
    requestId: String,
    checkoutUrl: String,
    paymentMethodCode: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isLoadingPage by remember { mutableStateOf(true) }
    var pageError by remember { mutableStateOf<String?>(null) }
    var showCancelConfirmDialog by remember { mutableStateOf(false) }

    val paymentMethod = PaymentMethod.fromCode(paymentMethodCode)

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الدفع الإلكتروني (Chargily Pay)",
                onNavigateBack = { showCancelConfirmDialog = true }
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Secure Sandbox Header Banner
            Surface(
                color = BlueDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "اتصال مشفر وآمن (Chargily Test Mode)",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        color = AmberPrimary,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = paymentMethod.titleAr,
                            style = MaterialTheme.typography.labelSmall,
                            color = BlueDark,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (isLoadingPage) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = BluePrimary,
                    trackColor = BluePrimary.copy(alpha = 0.2f)
                )
            }

            if (pageError != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payment,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = "تعذر تحميل بوابة الدفع الإلكتروني",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Text(
                            text = pageError ?: "يرجى التحقق من الاتصال بالإنترنت والمحاولة مجدداً",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = {
                                pageError = null
                                isLoadingPage = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text("إعادة المحاولة")
                        }
                    }
                }
            } else {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoadingPage = true
                                    pageError = null

                                    // Intercept success or failure callback URLs
                                    if (url != null) {
                                        if (url.contains("status=success") || url.contains("checkout/success")) {
                                            Toast.makeText(ctx, "تم تقديم طلب الدفع بنجاح! في انتظار تأكيد السيرفر...", Toast.LENGTH_LONG).show()
                                            onNavigateBack()
                                        } else if (url.contains("status=failed") || url.contains("status=cancelled") || url.contains("checkout/cancel")) {
                                            Toast.makeText(ctx, "تم إلغاء أو فشل عملية الدفع", Toast.LENGTH_SHORT).show()
                                            onNavigateBack()
                                        }
                                    }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoadingPage = false
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    super.onReceivedError(view, request, error)
                                    if (request?.isForMainFrame == true) {
                                        isLoadingPage = false
                                        pageError = "خطأ في الاتصال بالسيرفر (${error?.description})"
                                    }
                                }
                            }
                            // Enforce HTTPS to prevent ERR_CLEARTEXT_NOT_PERMITTED
                            val secureUrl = if (checkoutUrl.startsWith("http://", ignoreCase = true)) {
                                checkoutUrl.replaceFirst("http://", "https://", ignoreCase = true)
                            } else {
                                checkoutUrl
                            }
                            loadUrl(secureUrl)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    if (showCancelConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showCancelConfirmDialog = false },
            title = { Text("إلغاء عملية الدفع", fontWeight = FontWeight.Bold) },
            text = { Text("هل تريد الخروج من بوابة الدفع؟ سيبقى الطلب غير مدفوع.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCancelConfirmDialog = false
                        scope.launch {
                            authViewModel.cancelPendingPayment(requestId)
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("نعم، إلغاء", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelConfirmDialog = false }) {
                    Text("متابعة الدفع")
                }
            }
        )
    }
}
