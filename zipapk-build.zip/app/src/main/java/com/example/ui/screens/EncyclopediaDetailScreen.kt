package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlantDoctorViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EncyclopediaDetailScreen(viewModel: PlantDoctorViewModel) {
    val plant by viewModel.selectedEncyclopediaPlant.collectAsState()

    if (plant == null) {
        Scaffold(
            topBar = {
                AppTopBar(
                    title = "تفاصيل النبات",
                    showBackButton = true,
                    onBackClick = { viewModel.navigateBack() }
                )
            }
        ) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لا يوجد نبات محدد")
            }
        }
        return
    }

    val item = plant!!

    Scaffold(
        topBar = {
            AppTopBar(
                title = item.arabicName,
                subtitle = item.category,
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(AgriGreenMint),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = item.imageEmoji, fontSize = 42.sp)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = item.arabicName,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = item.scientificName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Quick Needs Grid
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الاحتياجات البيئية والنمو:", fontWeight = FontWeight.Bold)
                    DetailRow(icon = Icons.Default.WbSunny, label = "الإضاءة والشمس", value = item.lightRequirement)
                    DetailRow(icon = Icons.Default.WaterDrop, label = "الري والسقاية", value = item.wateringRequirement)
                    DetailRow(icon = Icons.Default.Thermostat, label = "الحرارة المثالية", value = item.optimalTemperature)
                    DetailRow(icon = Icons.Default.Eco, label = "نوع التربة", value = item.soilType)
                    DetailRow(icon = Icons.Default.Info, label = "موسم الغرس", value = item.plantingSeason)
                    DetailRow(icon = Icons.Default.Eco, label = "طرق الإكثار", value = item.propagationMethods)
                }
            }

            // Common Diseases Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BugReport, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("أشهر الأمراض والآفات الشائعة:", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    item.commonDiseases.forEach { disease ->
                        Text(
                            text = "• $disease",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(vertical = 3.dp)
                        )
                    }
                }
            }

            // Prevention & Care
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AgriGreenMint.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "طرق الوقاية والعناية الموصى بها:",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = AgriGreenDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = item.preventionAndCare,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )
                }
            }

            // Common Problems & Solutions
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("أبرز المشاكل والحلول العملية:", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    item.commonProblemsAndSolutions.forEach { (problem, solution) ->
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Text(text = "❓ $problem", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = "✅ $solution", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Add to My Plants Button
            Button(
                onClick = {
                    viewModel.saveOrUpdatePlant(
                        name = item.arabicName,
                        scientificName = item.scientificName,
                        type = item.category,
                        location = if (item.category == "نباتات زينة") "داخل المنزل" else "حديقة الحقل",
                        imagePath = "",
                        wateringDays = item.wateringIntervalDays,
                        fertilizingDays = item.fertilizingIntervalDays,
                        notes = "أُضيفت من الموسوعة النباتية (${item.commonName})"
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("add_encyclopedia_to_garden_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("إضافة هذا الصنف إلى نباتاتي وجدولة العناية به", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun DetailRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "$label:", fontSize = 13.sp, color = MaterialTheme.colorScheme.outline)
        }
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
