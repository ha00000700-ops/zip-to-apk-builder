package com.example.ui.screens.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPasswordField
import com.example.ui.components.KhedmatiPhoneField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.components.WilayaCommuneSelector
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun CustomerRegisterScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onRegistrationSuccess: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(authViewModel.currentAuthUserEmail ?: "") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var selectedWilayaCode by remember { mutableIntStateOf(16) }
    var selectedWilayaName by remember { mutableStateOf("الجزائر") }
    var selectedCommuneName by remember { mutableStateOf("الجزائر الوسطى") }

    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current
    val regState by authViewModel.customerRegState.collectAsState()

    LaunchedEffect(regState) {
        if (regState is AuthResult.Success) {
            onRegistrationSuccess()
        }
    }

    fun validateAndSubmit() {
        var isValid = true
        if (fullName.trim().isEmpty()) { fullNameError = "يرجى إدخال الاسم واللقب"; isValid = false }
        if (phone.length != 10) { phoneError = "رقم الهاتف غير صحيح"; isValid = false }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { emailError = "البريد غير صحيح"; isValid = false }
        if (password.length < 6) { passwordError = "كلمة المرور قصيرة"; isValid = false }
        if (confirmPassword != password) { confirmPasswordError = "كلمتا المرور غير متطابقتين"; isValid = false }

        if (isValid) {
            focusManager.clearFocus()
            authViewModel.registerCustomer(fullName.trim(), email.trim(), password, phone.trim(), selectedWilayaCode, selectedWilayaName, selectedCommuneName)
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "إنشاء حساب زبون",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Column(
                modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    modifier = Modifier.size(72.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = BlueContainer.copy(alpha = 0.4f),
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, null, tint = BluePrimary, modifier = Modifier.size(32.dp))
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(text = "مرحباً بك في خدمتي", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = BlueDark)
                Text(text = "سجل الآن لطلب أفضل الخدمات في منطقتك", style = MaterialTheme.typography.bodyMedium, color = TextTertiaryLight, textAlign = TextAlign.Center)
            }

            if (regState is AuthResult.Error) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
                    colors = CardDefaults.cardColors(containerColor = ErrorRedContainer.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(text = (regState as AuthResult.Error).messageAr, color = ErrorRed, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                }
            }

            // Form
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    KhedmatiTextField(value = fullName, onValueChange = { fullName = it; fullNameError = null }, label = "الاسم واللقب", leadingIcon = Icons.Default.Person, errorMessage = fullNameError)
                    Spacer(modifier = Modifier.height(12.dp))
                    KhedmatiPhoneField(value = phone, onValueChange = { phone = it; phoneError = null }, label = "رقم الهاتف", leadingIcon = Icons.Default.Phone, errorMessage = phoneError)
                    Spacer(modifier = Modifier.height(12.dp))
                    WilayaCommuneSelector(selectedWilayaCode = selectedWilayaCode, selectedCommuneName = selectedCommuneName, onLocationSelected = { code, wName, cName -> selectedWilayaCode = code; selectedWilayaName = wName; selectedCommuneName = cName })
                    Spacer(modifier = Modifier.height(12.dp))
                    KhedmatiTextField(value = email, onValueChange = { email = it; emailError = null }, label = "البريد الإلكتروني", leadingIcon = Icons.Default.Email, errorMessage = emailError)
                    Spacer(modifier = Modifier.height(12.dp))
                    KhedmatiPasswordField(value = password, onValueChange = { password = it; passwordError = null }, label = "كلمة المرور", leadingIcon = Icons.Default.Lock, errorMessage = passwordError)
                    Spacer(modifier = Modifier.height(12.dp))
                    KhedmatiPasswordField(value = confirmPassword, onValueChange = { confirmPassword = it; confirmPasswordError = null }, label = "تأكيد كلمة المرور", leadingIcon = Icons.Default.Lock, errorMessage = confirmPasswordError)
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    KhedmatiPrimaryButton(text = "إنشاء الحساب", onClick = { validateAndSubmit() }, isLoading = regState is AuthResult.Loading)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.clickable { onNavigateToLogin() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "لديك حساب بالفعل؟ ", style = MaterialTheme.typography.bodyMedium, color = TextTertiaryLight)
                Text(text = "تسجيل الدخول", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Black, color = BluePrimary)
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}
