package com.example.ui.screens.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPasswordField
import com.example.ui.components.KhedmatiPhoneField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun CustomerRegisterScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onRegistrationSuccess: () -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf(authViewModel.currentAuthUserEmail ?: "") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var selectedWilayaCode by remember { mutableIntStateOf(16) } // Alger
    var selectedWilayaName by remember { mutableStateOf("الجزائر") }
    var selectedCommuneName by remember { mutableStateOf("الجزائر الوسطى") }

    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var emailError by remember { mutableStateOf<String?>(null) }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var confirmPasswordError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current
    val regState by authViewModel.customerRegState.collectAsState()

    LaunchedEffect(regState) {
        if (regState is AuthResult.Success) {
            onRegistrationSuccess()
        }
    }

    fun validateAndSubmit() {
        var isValid = true

        if (fullName.trim().isEmpty()) {
            fullNameError = "يرجى إدخال الاسم واللقب"
            isValid = false
        } else if (fullName.trim().length < 3) {
            fullNameError = "الاسم قصير جداً"
            isValid = false
        } else {
            fullNameError = null
        }

        if (phone.trim().isEmpty()) {
            phoneError = "يرجى إدخال رقم الهاتف"
            isValid = false
        } else if (phone.length != 10 || (!phone.startsWith("05") && !phone.startsWith("06") && !phone.startsWith("07"))) {
            phoneError = "رقم الهاتف الجزائري يجب أن يبدأ بـ 05 أو 06 أو 07 ويتكون من 10 أرقام"
            isValid = false
        } else {
            phoneError = null
        }

        if (email.trim().isEmpty()) {
            emailError = "يرجى إدخال البريد الإلكتروني"
            isValid = false
        } else if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
            emailError = "صيغة البريد الإلكتروني غير صحيحة"
            isValid = false
        } else {
            emailError = null
        }

        if (password.isEmpty()) {
            passwordError = "يرجى إدخال كلمة المرور"
            isValid = false
        } else if (password.length < 6) {
            passwordError = "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل"
            isValid = false
        } else {
            passwordError = null
        }

        if (confirmPassword.isEmpty()) {
            confirmPasswordError = "يرجى تأكيد كلمة المرور"
            isValid = false
        } else if (confirmPassword != password) {
            confirmPasswordError = "كلمتا المرور غير متطابقتين"
            isValid = false
        } else {
            confirmPasswordError = null
        }

        if (isValid) {
            focusManager.clearFocus()
            authViewModel.registerCustomer(
                fullName = fullName.trim(),
                email = email.trim(),
                password = password,
                phone = phone.trim(),
                wilayaCode = selectedWilayaCode,
                wilayaName = selectedWilayaName,
                communeName = selectedCommuneName
            )
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                KhedmatiTopBar(
                    title = "تسجيل حساب زبون",
                    onNavigateBack = onNavigateBack
                )
            },
            containerColor = BackgroundLight
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = BlueContainer.copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.25f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                modifier = Modifier.size(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = BluePrimary
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = SurfaceLight,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "إنشاء حساب زبون جديد",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueDark
                                )
                                Text(
                                    text = "سجل للبحث عن الحرفيين وطلب الخدمات في بلديتك",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Error Card if backend registration returned error
                    if (regState is AuthResult.Error) {
                        val errorMsg = (regState as AuthResult.Error).messageAr
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 16.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = ErrorRedContainer),
                            border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = errorMsg,
                                style = MaterialTheme.typography.bodyMedium,
                                color = ErrorRed,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(14.dp),
                                textAlign = TextAlign.Start
                            )
                        }
                    }

                    // Form Container Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.6f)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Full Name
                            KhedmatiTextField(
                                value = fullName,
                                onValueChange = {
                                    fullName = it
                                    if (fullNameError != null) fullNameError = null
                                },
                                label = "الاسم واللقب",
                                placeholder = "مثال: أمين بلقاسم",
                                leadingIcon = Icons.Default.Person,
                                errorMessage = fullNameError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(
                                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                ),
                                testTag = "customer_reg_name"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Phone
                            KhedmatiPhoneField(
                                value = phone,
                                onValueChange = {
                                    phone = it
                                    if (phoneError != null) phoneError = null
                                },
                                label = "رقم الهاتف الجزائري (05 / 06 / 07)",
                                errorMessage = phoneError,
                                leadingIcon = Icons.Default.Phone,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Phone,
                                    imeAction = ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(
                                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                ),
                                testTag = "customer_reg_phone"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Wilaya & Commune Selection
                            WilayaCommuneSelector(
                                selectedWilayaCode = selectedWilayaCode,
                                selectedCommuneName = selectedCommuneName,
                                onLocationSelected = { code, wName, cName ->
                                    selectedWilayaCode = code
                                    selectedWilayaName = wName
                                    selectedCommuneName = cName
                                }
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Email
                            KhedmatiTextField(
                                value = email,
                                onValueChange = {
                                    email = it
                                    if (emailError != null) emailError = null
                                },
                                label = "البريد الإلكتروني",
                                placeholder = "customer@example.dz",
                                leadingIcon = Icons.Default.Email,
                                errorMessage = emailError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Email,
                                    imeAction = ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(
                                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                ),
                                testTag = "customer_reg_email"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Password
                            KhedmatiPasswordField(
                                value = password,
                                onValueChange = {
                                    password = it
                                    if (passwordError != null) passwordError = null
                                },
                                label = "كلمة المرور",
                                placeholder = "6 أحرف أو أرقام على الأقل",
                                leadingIcon = Icons.Default.Lock,
                                errorMessage = passwordError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Password,
                                    imeAction = ImeAction.Next
                                ),
                                keyboardActions = KeyboardActions(
                                    onNext = { focusManager.moveFocus(FocusDirection.Down) }
                                ),
                                testTag = "customer_reg_password"
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Confirm Password
                            KhedmatiPasswordField(
                                value = confirmPassword,
                                onValueChange = {
                                    confirmPassword = it
                                    if (confirmPasswordError != null) confirmPasswordError = null
                                },
                                label = "تأكيد كلمة المرور",
                                placeholder = "أعد كتابة كلمة المرور",
                                leadingIcon = Icons.Default.Lock,
                                errorMessage = confirmPasswordError,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Password,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = { validateAndSubmit() }
                                ),
                                testTag = "customer_reg_confirm_password"
                            )

                            Spacer(modifier = Modifier.height(22.dp))

                            // Submit Button
                            KhedmatiPrimaryButton(
                                text = "إنشاء الحساب والبدء",
                                onClick = { validateAndSubmit() },
                                isLoading = regState is AuthResult.Loading,
                                testTag = "customer_reg_submit"
                            )
                        }
                    }
                }

                // Already have account link
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = SurfaceLight,
                    border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp)
                        .clickable { onNavigateToLogin() }
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 14.dp, horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "لديك حساب بالفعل؟ ",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight
                        )
                        Text(
                            text = "تسجيل الدخول",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }
                }
            }
        }
    }
}
