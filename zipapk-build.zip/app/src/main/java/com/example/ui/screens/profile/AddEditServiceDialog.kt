package com.example.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.CustomService

@Composable
fun AddEditServiceDialog(
    providerId: String,
    service: CustomService? = null,
    onDismiss: () -> Unit,
    onSave: (CustomService) -> Unit
) {
    var name by remember { mutableStateOf(service?.name ?: "") }
    var description by remember { mutableStateOf(service?.description ?: "") }
    var price by remember { mutableStateOf(service?.priceDzd?.toString() ?: "") }
    var priceType by remember { mutableStateOf(service?.priceType ?: "بالخدمة") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (service == null) "إضافة خدمة جديدة" else "تعديل الخدمة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الخدمة *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("وصف الخدمة (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = price,
                    onValueChange = { price = it.filter { char -> char.isDigit() } },
                    label = { Text("السعر الابتدائي (اختياري)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                // Simplified price type selection for now
                OutlinedTextField(
                    value = priceType,
                    onValueChange = { priceType = it },
                    label = { Text("نوع السعر (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank()) return@Button
                    onSave(
                        (service ?: CustomService(providerId = providerId)).copy(
                            name = name.trim(),
                            description = description.trim(),
                            priceDzd = price.toLongOrNull(),
                            priceType = priceType.trim()
                        )
                    )
                }
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
