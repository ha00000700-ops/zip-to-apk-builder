package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val titleResId: Int, val icon: ImageVector) {
    object Home : Screen("home", com.example.R.string.nav_home, Icons.Outlined.Home)
    object Quran : Screen("quran", com.example.R.string.nav_quran, Icons.Outlined.MenuBook)
    object Wird : Screen("wird", com.example.R.string.nav_wird, Icons.Outlined.CheckCircleOutline)
    object More : Screen("more", com.example.R.string.nav_more, Icons.Outlined.MoreHoriz)
}
