package com.example.ui.screens

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.ui.PlantDoctorViewModel
import com.example.ui.Screen
import com.example.ui.components.AppTopBar
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.AlertRed
import com.example.ui.theme.WarningOrange
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnoseScreen(viewModel: PlantDoctorViewModel) {
    val context = LocalContext.current
    val selectedImageFile by viewModel.selectedImageFile.collectAsState()
    val additionalImages by viewModel.additionalImages.collectAsState()
    val isDiagnosing by viewModel.isDiagnosing.collectAsState()
    val diagnosisError by viewModel.diagnosisError.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    val plantTypeInput by viewModel.diagnosisPlantTypeInput.collectAsState()
    val selectedLocation by viewModel.diagnosisLocation.collectAsState()
    val selectedAffectedPart by viewModel.diagnosisAffectedPart.collectAsState()
    val userSymptoms by viewModel.diagnosisUserSymptoms.collectAsState()
    val lastDiagnosticLog by viewModel.lastDiagnosticLog.collectAsState()

    var showDiagnosticDetails by remember { mutableStateOf(false) }

    // Primary Camera setup
    var tempCameraFile by remember { mutableStateOf<File?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val file = tempCameraFile
        if (success && file != null && file.exists()) {
            viewModel.setImageForDiagnosis(file)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = viewModel.copyUriToLocalCache(context, uri)
            if (copied != null) {
                viewModel.setImageForDiagnosis(copied)
            }
        }
    }

    // Additional photo picker
    val additionalPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val copied = viewModel.copyUriToLocalCache(context, uri)
            if (copied != null) {
                viewModel.addAdditionalImage(copied)
            }
        }
    }

    val plantLocations = listOf("حديقة", "حقل زراعي", "داخل المنزل", "شرفة", "دفيئة بلاستيكية", "أصيص")
    val affectedParts = listOf("الأوراق", "الساق واللحاء", "الثمار والأزهار", "الجذور", "النبات كاملاً")

    Scaffold(
        topBar = {
            AppTopBar(
                title = "فحص وتشخيص النبات 🔬",
                subtitle = "تحليل بالرؤية الحاسوبية وتصنيف المسببات المرضية",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
                .testTag("diagnose_screen_content"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Daily Quota Bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "رصيد الفحص اليومي المجاني:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${userProfile.dailyAiUsageCount} / ${userProfile.dailyAiQuotaLimit} استخدام",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = if (userProfile.dailyAiUsageCount >= userProfile.dailyAiQuotaLimit) AlertRed else MaterialTheme.colorScheme.primary
                    )
                }
            }

            // 1. Primary Photo Selection Box
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                if (selectedImageFile != null && selectedImageFile!!.exists()) {
                    val bitmap = remember(selectedImageFile) {
                        BitmapFactory.decodeFile(selectedImageFile!!.absolutePath)
                    }
                    Box(modifier = Modifier.fillMaxSize()) {
                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "صورة النبات الأساسية للفحص",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Change photo overlay buttons
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    try {
                                        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
                                        tempCameraFile = file
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        cameraLauncher.launch(uri)
                                    } catch (_: Exception) {}
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إعادة التقاط", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f))
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تغيير من المعرض", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
                            }
                        }
                    }
                } else {
                    // Empty image state
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(AgriGreenMint),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = AgriGreenDark,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "التقط صورة واضحة للورقة أو الجزء المصاب",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "للحصول على أدق نتيجة، تأكد من وضوح الإضاءة وتركيز العدسة على البقع",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = {
                                    try {
                                        val file = File(context.cacheDir, "camera_${System.currentTimeMillis()}.jpg")
                                        tempCameraFile = file
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                        cameraLauncher.launch(uri)
                                    } catch (_: Exception) {}
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فتح الكاميرا")
                            }

                            OutlinedButton(
                                onClick = {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("المعرض")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Multi-Photo Support (Leaf, Stem, Fruit)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "صور تكميلية دقيقة (ورقة، ساق، ثمرة):",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${additionalImages.size} / 3",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "إضافة لقطات مقربة للأعضاء المختلفة ترفع دقة التشخيص وتمنع الاشتباه",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Display added additional images
                        additionalImages.forEachIndexed { index, file ->
                            val thumb = remember(file) { BitmapFactory.decodeFile(file.absolutePath) }
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                            ) {
                                if (thumb != null) {
                                    Image(
                                        bitmap = thumb.asImageBitmap(),
                                        contentDescription = "صورة تكميلية $index",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(2.dp)
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(AlertRed)
                                        .clickable { viewModel.removeAdditionalImage(index) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "حذف", tint = Color.White, modifier = Modifier.size(12.dp))
                                }
                            }
                        }

                        // Add photo button if < 3
                        if (additionalImages.size < 3) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                    .background(AgriGreenMint.copy(alpha = 0.4f))
                                    .clickable {
                                        additionalPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Add, contentDescription = "إضافة صورة", tint = AgriGreenDark, modifier = Modifier.size(22.dp))
                                    Text("إضافة", fontSize = 11.sp, color = AgriGreenDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Botanical Details Form
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "معلومات إضافية لتحسين دقة التشخيص",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Plant type
                    OutlinedTextField(
                        value = plantTypeInput,
                        onValueChange = { viewModel.setDiagnosisPlantType(it) },
                        label = { Text("نوع النبات (مثال: طماطم، زيتون، ليمون، بوتوس...)") },
                        placeholder = { Text("اتركه فارغاً ليتعرف الذكاء الاصطناعي عليه تلقائياً") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_plant_type"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "مكان زراعة النبات:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        plantLocations.take(3).forEach { loc ->
                            FilterChip(
                                selected = selectedLocation == loc,
                                onClick = { viewModel.setDiagnosisLocation(loc) },
                                label = { Text(loc, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        plantLocations.drop(3).forEach { loc ->
                            FilterChip(
                                selected = selectedLocation == loc,
                                onClick = { viewModel.setDiagnosisLocation(loc) },
                                label = { Text(loc, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Text(text = "الجزء المتضرر الذي لاحظت عليه الأعراض:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        affectedParts.take(3).forEach { part ->
                            FilterChip(
                                selected = selectedAffectedPart == part,
                                onClick = { viewModel.setDiagnosisAffectedPart(part) },
                                label = { Text(part, fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        affectedParts.drop(3).forEach { part ->
                            FilterChip(
                                selected = selectedAffectedPart == part,
                                onClick = { viewModel.setDiagnosisAffectedPart(part) },
                                label = { Text(part, fontSize = 12.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = userSymptoms,
                        onValueChange = { viewModel.setDiagnosisUserSymptoms(it) },
                        label = { Text("أعراض لاحظتها بنفسك (اختياري)") },
                        placeholder = { Text("مثال: اصفرار الأوراق السفلية، ظهور بقع بنية جافة، حشرات دقيقة...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_user_symptoms"),
                        shape = RoundedCornerShape(12.dp),
                        maxLines = 3
                    )
                }
            }

            // Error display
            if (diagnosisError != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AlertRed.copy(alpha = 0.08f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = AlertRed,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تنبيه في فحص النبات:",
                                    fontWeight = FontWeight.Bold,
                                    color = AlertRed,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = diagnosisError!!,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action buttons row (Retry & Profile & Technical details)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { viewModel.retryPlantDiagnosis() },
                                shape = RoundedCornerShape(10.dp),
                                enabled = !isDiagnosing && selectedImageFile != null,
                                colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                modifier = Modifier.weight(1.1f)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إعادة المحاولة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (diagnosisError!!.contains("Secrets") || diagnosisError!!.contains("مفتاح") || diagnosisError!!.contains("خادم وسيط")) {
                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(Screen.Profile) },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("ضبط المفتاح", fontSize = 11.sp)
                                }
                            }

                            OutlinedButton(
                                onClick = { showDiagnosticDetails = !showDiagnosticDetails },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (showDiagnosticDetails) "إخفاء التفاصيل" else "السجل التقني",
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Expandable Safe Technical Diagnostic Log
                        if (showDiagnosticDetails && lastDiagnosticLog != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "🔍 السجل التقني الآمن (Technical Diagnostic Log):",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "• التوقيت: ${lastDiagnosticLog!!.timestamp}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "• رمز الاستجابة: ${lastDiagnosticLog!!.httpCode?.let { "HTTP $it" } ?: "استثناء شبكة / محلي"}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "• مسار الطلب: ${lastDiagnosticLog!!.endpointType}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "• فئة الخطأ: ${lastDiagnosticLog!!.errorCategory}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "• تفاصيل منقحة: ${lastDiagnosticLog!!.sanitizedReason}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "🔒 تم تنقيح هذا التقرير تلقائياً لضمان عدم تضمين أي مفاتيح سرية أو بيانات خاصة.",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Diagnose Action Button
            Button(
                onClick = {
                    viewModel.startPlantDiagnosis(
                        plantTypeInput = plantTypeInput,
                        location = selectedLocation,
                        affectedPart = selectedAffectedPart,
                        userSymptoms = userSymptoms
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("submit_diagnosis_button"),
                shape = RoundedCornerShape(16.dp),
                enabled = !isDiagnosing && selectedImageFile != null,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                if (isDiagnosing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = Color.White,
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "جاري الفحص بالرؤية الحاسوبية...",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedImageFile == null) "التقط صورة للبدء بالفحص" else "ابدأ فحص النبات وتشخيصه الآن",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
