package com.example.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape

@Composable
fun SettingsScreen(
    onNavigateBack: () -> Unit
) {
    var activeDialog by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الإعدادات",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            Text(
                text = "إعدادات الحساب",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
                color = BlueDark,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    SettingsItem(
                        icon = Icons.Default.Notifications,
                        title = "الإشعارات",
                        description = "التحكم في تنبيهات التطبيق",
                        onClick = { activeDialog = "notifications" }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    SettingsItem(
                        icon = Icons.Default.Security,
                        title = "الخصوصية والأمان",
                        description = "حماية الحساب والبيانات",
                        onClick = { activeDialog = "security" }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    SettingsItem(
                        icon = Icons.Default.Language,
                        title = "اللغة",
                        description = "العربية (الافتراضية)",
                        onClick = { activeDialog = "language" }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "حول التطبيق",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Black,
                color = BlueDark,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    SettingsItem(
                        icon = Icons.Default.Info,
                        title = "عن خدمتي",
                        description = "الإصدار 1.0.0 • Huossam_07",
                        onClick = { activeDialog = "about" }
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    SettingsItem(
                        icon = Icons.Default.Help,
                        title = "مركز المساعدة",
                        description = "الدعم الفني والأسئلة الشائعة",
                        onClick = { activeDialog = "help" }
                    )
                }
            }
        }
    }

    when (activeDialog) {
        "notifications" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("إعدادات الإشعارات", fontWeight = FontWeight.Bold) },
                text = { Text("الإشعارات مفعلة تلقائياً لتنبيهك بحالة الطلبات، العروض الجديدة، والرسائل الفورية.") },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) { Text("حسناً") }
                }
            )
        }
        "security" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("الخصوصية والأمان", fontWeight = FontWeight.Bold) },
                text = { Text("حسابك محمي باستخدام مصادقة Firebase الآمنة وسياسات RLS المتطورة على Supabase Storage لضمان سرية صورك وبیاناتك.") },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) { Text("حسناً") }
                }
            )
        }
        "language" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("لغة التطبيق", fontWeight = FontWeight.Bold) },
                text = { Text("اللغة الحالية والمعتمدة في التطبيق هي اللغة العربية (الجزائر).") },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) { Text("حسناً") }
                }
            )
        }
        "about" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("عن تطبيق خدمتي", fontWeight = FontWeight.Bold) },
                text = { Text("تطبيق خدمتي (Khedmati DZ)\nالإصدار: 1.0.0\nالمطور: Huossam_07\n\nمنصة رقمية موثوقة لربط الزبائن بأفضل الحرفيين ومقدمي الخدمات في جميع ولايات الجزائر 🇩🇿.") },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) { Text("إغلاق") }
                }
            )
        }
        "help" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                title = { Text("مركز المساعدة والدعم", fontWeight = FontWeight.Bold) },
                text = { Text("لأي استفسار أو مساعدة فنية في استخدام تطبيق خدمتي DZ، يرجى التواصل عبر قنوات الدعم المعتمدة داخل التطبيق.") },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) { Text("حسناً") }
                }
            )
        }
    }
}

@Composable
private fun SettingsItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(40.dp),
            shape = RoundedCornerShape(10.dp),
            color = BluePrimary.copy(alpha = 0.08f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = BluePrimary, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BlueDark)
            Text(text = description, style = MaterialTheme.typography.labelSmall, color = TextTertiaryLight)
        }
        Icon(Icons.Default.ChevronLeft, null, tint = OutlineLight, modifier = Modifier.size(20.dp))
    }
}

