package com.example.ui.screens.profile

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Report
import com.example.data.model.ReportStatus
import com.example.data.model.ReportType
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class UserReportsTab {
    NEW_REPORT,
    MY_REPORTS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserReportsScreen(
    authViewModel: AuthViewModel,
    prefilledRequestId: String? = null,
    onNavigateBack: () -> Unit
) {
    val myReportsState by authViewModel.myReportsState.collectAsState()
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()

    var selectedTab by remember { mutableStateOf(UserReportsTab.NEW_REPORT) }
    
    // Form fields
    var selectedCategory by remember { mutableStateOf("خلل فني") }
    val categories = listOf("خلل فني", "شكوى ضد مستخدم", "مشكلة في الدفع", "مشكلة في الحساب", "أخرى")
    var categoryExpanded by remember { mutableStateOf(false) }

    var detailsText by remember { mutableStateOf("") }
    var requestIdText by remember { mutableStateOf(prefilledRequestId ?: "") }

    var isSubmitting by remember { mutableStateOf(false) }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Prefill category if prefilledRequestId exists
    LaunchedEffect(prefilledRequestId) {
        if (!prefilledRequestId.isNullOrEmpty()) {
            requestIdText = prefilledRequestId
            selectedCategory = "شكوى ضد مستخدم"
            selectedTab = UserReportsTab.NEW_REPORT
        }
    }

    LaunchedEffect(Unit) {
        authViewModel.loadMyReports()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                KhedmatiTopBar(
                    title = "الإبلاغ عن مشكلة",
                    onNavigateBack = onNavigateBack
                )
            },
            containerColor = BackgroundLight
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Tab Selection
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = BluePrimary
                ) {
                    Tab(
                        selected = selectedTab == UserReportsTab.NEW_REPORT,
                        onClick = { selectedTab = UserReportsTab.NEW_REPORT },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AddComment,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إرسال شكوى جديدة", fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("new_report_tab")
                    )
                    Tab(
                        selected = selectedTab == UserReportsTab.MY_REPORTS,
                        onClick = { selectedTab = UserReportsTab.MY_REPORTS },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.History,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val reportsCount = (myReportsState as? AuthResult.Success)?.data?.size ?: 0
                                Text("بلاغاتي السابقة ($reportsCount)", fontWeight = FontWeight.Bold)
                            }
                        },
                        modifier = Modifier.testTag("my_reports_tab")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                when (selectedTab) {
                    UserReportsTab.NEW_REPORT -> {
                        NewReportFormSection(
                            categories = categories,
                            selectedCategory = selectedCategory,
                            categoryExpanded = categoryExpanded,
                            onCategorySelect = { selectedCategory = it },
                            onCategoryExpandedChange = { categoryExpanded = it },
                            detailsText = detailsText,
                            onDetailsChange = { detailsText = it },
                            requestIdText = requestIdText,
                            onRequestIdChange = { requestIdText = it },
                            isSubmitting = isSubmitting,
                            successMessage = successMessage,
                            errorMessage = errorMessage,
                            onSubmit = {
                                if (detailsText.trim().isEmpty()) {
                                    errorMessage = "يرجى كتابة تفاصيل المشكلة أولاً"
                                    return@NewReportFormSection
                                }
                                isSubmitting = true
                                errorMessage = null
                                successMessage = null

                                val reportType = when (selectedCategory) {
                                    "شكوى ضد مستخدم" -> ReportType.USER
                                    "خلل فني" -> ReportType.OTHER
                                    "مشكلة في الدفع" -> ReportType.SERVICE_REQUEST
                                    "مشكلة في الحساب" -> ReportType.USER
                                    else -> ReportType.OTHER
                                }

                                val report = Report(
                                    reporterId = currentUserProfile?.uid ?: "",
                                    reporterName = currentUserProfile?.fullName ?: "مستخدم خدمتي",
                                    reporterRole = currentUserProfile?.role?.name ?: "CUSTOMER",
                                    type = reportType,
                                    targetId = requestIdText.trim(),
                                    reason = selectedCategory,
                                    details = detailsText.trim(),
                                    status = ReportStatus.PENDING
                                )

                                authViewModel.submitReport(report) { success, errorMsg ->
                                    isSubmitting = false
                                    if (success) {
                                        successMessage = "تم إرسال بلاغك بنجاح. سيقوم فريق الدعم بمراجعته في أقرب وقت."
                                        detailsText = ""
                                        requestIdText = ""
                                    } else {
                                        errorMessage = errorMsg ?: "حدث خطأ أثناء إرسال البلاغ. يرجى المحاولة لاحقاً."
                                    }
                                }
                            }
                        )
                    }
                    UserReportsTab.MY_REPORTS -> {
                        MyReportsListSection(
                            myReportsState = myReportsState,
                            onRefresh = { authViewModel.loadMyReports() }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewReportFormSection(
    categories: List<String>,
    selectedCategory: String,
    categoryExpanded: Boolean,
    onCategorySelect: (String) -> Unit,
    onCategoryExpandedChange: (Boolean) -> Unit,
    detailsText: String,
    onDetailsChange: (String) -> Unit,
    requestIdText: String,
    onRequestIdChange: (String) -> Unit,
    isSubmitting: Boolean,
    successMessage: String?,
    errorMessage: String?,
    onSubmit: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "تفاصيل البلاغ والشكوى",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryLight
                    )

                    Text(
                        text = "نحن هنا لمساعدتك وحل أي مشكلة تواجهك في تطبيق خدمتي. يرجى ملء النموذج أدناه بدقة وسيتم مراجعة البلاغ من قبل الإدارة.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondaryLight,
                        lineHeight = 22.sp
                    )

                    // Success Message Banner
                    AnimatedVisibility(visible = successMessage != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = EmeraldPrimary.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = successMessage ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Error Message Banner
                    AnimatedVisibility(visible = errorMessage != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = ErrorRedContainer.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Error,
                                    contentDescription = null,
                                    tint = ErrorRed
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = errorMessage ?: "",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ErrorRed,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Category Selector
                    Column {
                        Text(
                            text = "فئة المشكلة *",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        ExposedDropdownMenuBox(
                            expanded = categoryExpanded,
                            onExpandedChange = onCategoryExpandedChange
                        ) {
                            OutlinedTextField(
                                value = selectedCategory,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                                    .testTag("report_category_input"),
                                shape = RoundedCornerShape(12.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = categoryExpanded,
                                onDismissRequest = { onCategoryExpandedChange(false) }
                            ) {
                                categories.forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = {
                                            onCategorySelect(category)
                                            onCategoryExpandedChange(false)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Request ID Field (Optional)
                    Column {
                        Text(
                            text = "معرف الطلب أو رقم الخدمة (اختياري)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        OutlinedTextField(
                            value = requestIdText,
                            onValueChange = onRequestIdChange,
                            placeholder = { Text("مثال: ID-12345 (إذا كانت المشكلة تخص طلباً معيناً)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("report_request_id_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )
                    }

                    // Problem Details Field
                    Column {
                        Text(
                            text = "تفاصيل الشكوى والمشكلة *",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        OutlinedTextField(
                            value = detailsText,
                            onValueChange = onDetailsChange,
                            placeholder = { Text("يرجى شرح المشكلة بوضوح لضمان سرعة المعالجة والمساعدة...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .testTag("report_details_input"),
                            shape = RoundedCornerShape(12.dp),
                            minLines = 4
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Submit Button
                    Button(
                        onClick = onSubmit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_report_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        shape = RoundedCornerShape(12.dp),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(imageVector = Icons.Default.Send, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إرسال الشكوى", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyReportsListSection(
    myReportsState: AuthResult<List<Report>>?,
    onRefresh: () -> Unit
) {
    when (myReportsState) {
        is AuthResult.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BluePrimary)
            }
        }
        is AuthResult.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.ErrorOutline, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(48.dp))
                    Text(text = myReportsState.messageAr, style = MaterialTheme.typography.bodyMedium, color = ErrorRed, textAlign = TextAlign.Center)
                    Button(onClick = onRefresh, colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)) {
                        Text("إعادة المحاولة")
                    }
                }
            }
        }
        is AuthResult.Success -> {
            val list = myReportsState.data
            if (list.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AssignmentLate,
                            contentDescription = null,
                            tint = TextSecondaryLight.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = "لا توجد أي شكاوى أو بلاغات سابقة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        Text(
                            text = "شكاويك وبلاغاتك المرسلة ستظهر هنا لتتابع حالتها ورد الإدارة عليها.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(list) { report ->
                        ReportItemCard(report = report)
                    }
                }
            }
        }
        else -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("جاري تحميل البلاغات...")
            }
        }
    }
}

@Composable
fun ReportItemCard(report: Report) {
    val formatter = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }
    val dateStr = formatter.format(Date(report.createdAt))

    val statusTriple = when (report.status) {
        ReportStatus.PENDING -> Triple(AmberPrimary, Color(0xFFFFF8E1), "قيد الانتظار")
        ReportStatus.IN_REVIEW -> Triple(BluePrimary, Color(0xFFE3F2FD), "قيد المراجعة")
        ReportStatus.RESOLVED -> Triple(EmeraldPrimary, Color(0xFFE8F5E9), "تم حل المشكلة")
        else -> Triple(Color.Gray, Color(0xFFF5F5F5), "ملغاة")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = statusTriple.second,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = statusTriple.third,
                        style = MaterialTheme.typography.labelMedium,
                        color = statusTriple.first,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "الفئة: ${report.reason}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            if (report.targetId.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "معرف الطلب المرتبط: ${report.targetId}",
                    style = MaterialTheme.typography.bodySmall,
                    color = BluePrimary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = report.details,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                lineHeight = 20.sp
            )

            // Admin response section
            if (report.adminNotes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = OutlineLight.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFF0F4F8), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "رد الإدارة المباشر:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = report.adminNotes,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimaryLight,
                        lineHeight = 20.sp
                    )
                }
            }
        }
    }
}
