package com.example.ui.screens.public_request

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlgerianLocationData
import com.example.data.model.Profession
import com.example.data.model.ProfessionData
import com.example.data.model.PublicServiceRequest
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePublicServiceRequestScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()
    val createRequestState by authViewModel.createPublicRequestState.collectAsState()

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var addressDetails by remember { mutableStateOf("") }
    var budgetDzdText by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Profession selection
    var selectedProfession by remember { mutableStateOf<Profession?>(null) }
    var showProfessionDialog by remember { mutableStateOf(false) }

    // Wilaya & Commune
    var selectedWilayaIndex by remember {
        val initialCode = currentUserProfile?.wilayaCode ?: 16
        val idx = AlgerianLocationData.wilayas.indexOfFirst { it.code == initialCode }
        mutableIntStateOf(if (idx >= 0) idx else 15) // default Alger (index 15)
    }
    val currentWilaya = AlgerianLocationData.wilayas.getOrElse(selectedWilayaIndex) { AlgerianLocationData.wilayas[15] }
    var selectedCommune by remember(currentWilaya) {
        val defaultCommune = currentUserProfile?.communeName
        mutableStateOf(
            if (!defaultCommune.isNullOrBlank() && currentWilaya.communes.contains(defaultCommune)) {
                defaultCommune
            } else {
                currentWilaya.communes.firstOrNull() ?: "الجزائر الوسطى"
            }
        )
    }

    var wilayaExpanded by remember { mutableStateOf(false) }
    var communeExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        authViewModel.resetCreatePublicRequestState()
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "نشر طلب خدمة عام",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = createRequestState) {
                is AuthResult.Success -> {
                    val created = state.data
                    SuccessRequestView(
                        request = created,
                        onViewDetails = { onNavigateToRequestDetails(created.id) },
                        onDone = onNavigateBack
                    )
                }
                else -> {
                    val scrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                            .padding(16.dp)
                    ) {
                        // Explanatory Banner
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = BlueContainer.copy(alpha = 0.6f))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(BluePrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "انشر طلبك وسيصل إلى جميع الحرفيين المعتمدين",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = BlueDark
                                    )
                                    Text(
                                        text = "سيقوم المهنيون في منطقتك بتقديم عروض أسعار منافسة لتختار منها الأنسب لك.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BlueDark.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Request Title
                        Text(
                            text = "عنوان الطلب *",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = title,
                            onValueChange = {
                                title = it
                                validationError = null
                            },
                            placeholder = { Text("مثال: تصليح تسرب ماء تحت حوض المطبخ") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("public_request_title_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.Title, contentDescription = null, tint = BluePrimary)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Required Profession Selector
                        Text(
                            text = "التخصص / المهنة المطلوبة *",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showProfessionDialog = true }
                                .testTag("select_profession_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (selectedProfession != null) BlueContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                width = 1.dp,
                                color = if (selectedProfession != null) BluePrimary else MaterialTheme.colorScheme.outline
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = Icons.Default.Handyman,
                                        contentDescription = null,
                                        tint = BluePrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = selectedProfession?.nameAr ?: "اضغط لاختيار تخصص الحرفي المطلوب",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (selectedProfession != null) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedProfession != null) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (selectedProfession != null) {
                                            Text(
                                                text = selectedProfession!!.categoryAr,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = BluePrimary
                                            )
                                        }
                                    }
                                }
                                Icon(
                                    imageVector = Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = BluePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Wilaya Selector
                        Text(
                            text = "الولاية *",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        ExposedDropdownMenuBox(
                            expanded = wilayaExpanded,
                            onExpandedChange = { wilayaExpanded = !wilayaExpanded }
                        ) {
                            OutlinedTextField(
                                value = currentWilaya.displayName,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = wilayaExpanded) },
                                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = BluePrimary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = wilayaExpanded,
                                onDismissRequest = { wilayaExpanded = false }
                            ) {
                                AlgerianLocationData.wilayas.forEachIndexed { index, wilaya ->
                                    DropdownMenuItem(
                                        text = { Text(wilaya.displayName) },
                                        onClick = {
                                            selectedWilayaIndex = index
                                            wilayaExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Commune Selector
                        Text(
                            text = "البلدية *",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        ExposedDropdownMenuBox(
                            expanded = communeExpanded,
                            onExpandedChange = { communeExpanded = !communeExpanded }
                        ) {
                            OutlinedTextField(
                                value = selectedCommune,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = communeExpanded) },
                                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = BluePrimary) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = communeExpanded,
                                onDismissRequest = { communeExpanded = false }
                            ) {
                                currentWilaya.communes.forEach { commune ->
                                    DropdownMenuItem(
                                        text = { Text(commune) },
                                        onClick = {
                                            selectedCommune = commune
                                            communeExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Description
                        Text(
                            text = "وصف المشكلة وتفاصيل الخدمة المطلوبة *",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = description,
                            onValueChange = {
                                description = it
                                validationError = null
                            },
                            placeholder = { Text("اشرح المشكلة بالتفصيل لمساعدة الحرفيين على تقديم عروض دقيقة...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .testTag("public_request_description_input"),
                            shape = RoundedCornerShape(12.dp),
                            maxLines = 5,
                            leadingIcon = {
                                Icon(Icons.Default.Description, contentDescription = null, tint = BluePrimary)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Optional Budget
                        Text(
                            text = "الميزانية المتوقعة (اختياري)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = budgetDzdText,
                            onValueChange = { input ->
                                if (input.all { it.isDigit() }) {
                                    budgetDzdText = input
                                }
                            },
                            placeholder = { Text("مثال: 3000 د.ج") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("public_request_budget_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            leadingIcon = {
                                Icon(Icons.Default.Payments, contentDescription = null, tint = AmberPrimary)
                            },
                            trailingIcon = {
                                Text(
                                    text = "د.ج",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(end = 12.dp)
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // Optional Address Details
                        Text(
                            text = "تفاصيل الحي / الشارع (اختياري)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = addressDetails,
                            onValueChange = { addressDetails = it },
                            placeholder = { Text("مثال: حي 500 مسكن، عمارة ب") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("public_request_address_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            leadingIcon = {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        // Validation / Backend Errors
                        if (validationError != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = validationError!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = ErrorRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        } else if (state is AuthResult.Error) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = state.messageAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = ErrorRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Submit Button
                        KhedmatiPrimaryButton(
                            text = "نشر طلب الخدمة الآن 📢",
                            isLoading = state is AuthResult.Loading,
                            onClick = {
                                if (title.trim().length < 5) {
                                    validationError = "يرجى كتابة عنوان واضح ومفهوم (5 أحرف على الأقل)"
                                    return@KhedmatiPrimaryButton
                                }
                                if (selectedProfession == null) {
                                    validationError = "يرجى اختيار التخصص المهني المطلوب"
                                    return@KhedmatiPrimaryButton
                                }
                                if (description.trim().length < 10) {
                                    validationError = "يرجى كتابة تفاصيل المشكلة (10 أحرف على الأقل)"
                                    return@KhedmatiPrimaryButton
                                }

                                val budget = budgetDzdText.toLongOrNull()

                                authViewModel.createPublicServiceRequest(
                                    title = title,
                                    description = description,
                                    professionId = selectedProfession!!.id,
                                    professionNameAr = selectedProfession!!.nameAr,
                                    professionCategoryAr = selectedProfession!!.categoryAr,
                                    wilayaCode = currentWilaya.code,
                                    wilayaName = currentWilaya.nameAr,
                                    communeName = selectedCommune,
                                    addressDetails = addressDetails,
                                    budgetDzd = budget
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("publish_public_request_submit_button")
                        )

                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }

    // Profession Selection Dialog
    if (showProfessionDialog) {
        ProfessionSelectionDialog(
            onProfessionSelected = { prof ->
                selectedProfession = prof
                validationError = null
                showProfessionDialog = false
            },
            onDismiss = { showProfessionDialog = false }
        )
    }
}

@Composable
private fun ProfessionSelectionDialog(
    onProfessionSelected: (Profession) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val allProfessions = ProfessionData.professions
    val filtered = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            allProfessions
        } else {
            val q = searchQuery.trim().lowercase()
            allProfessions.filter {
                it.nameAr.lowercase().contains(q) ||
                it.nameFr.lowercase().contains(q) ||
                it.categoryAr.lowercase().contains(q) ||
                it.descriptionAr.lowercase().contains(q)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "اختر مهنة / تخصص الحرفي",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن مهنة (سباك، كهربائي...)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered.size) { index ->
                        val prof = filtered[index]
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onProfessionSelected(prof) },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = prof.nameAr,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = prof.categoryAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BluePrimary
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun SuccessRequestView(
    request: PublicServiceRequest,
    onViewDetails: () -> Unit,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(BlueContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = BluePrimary,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "تم نشر طلبك بنجاح! 📢",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "أصبح طلبك معروضاً الآن للحرفيين المعتمدين في ولاية ${request.wilayaName} (${request.communeName}). ستتلقى عروض الأسعار قريباً وتستطيع اختيار الأنسب.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = onViewDetails,
            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("view_published_request_details_button")
        ) {
            Text(
                text = "متابعة العروض الواردة على الطلب",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        androidx.compose.material3.OutlinedButton(
            onClick = onDone,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text(
                text = "العودة للرئيسية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
