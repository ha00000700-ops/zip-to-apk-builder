package com.example.ui.screens.public_request

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlgerianLocationData
import com.example.data.model.Profession
import com.example.data.model.ProfessionData
import com.example.data.model.PublicServiceRequest
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePublicServiceRequestScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()
    val createRequestState by authViewModel.createPublicRequestState.collectAsState()

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var addressDetails by remember { mutableStateOf("") }
    var budgetDzdText by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    var selectedProfession by remember { mutableStateOf<Profession?>(null) }
    var showProfessionDialog by remember { mutableStateOf(false) }

    var selectedWilayaIndex by remember {
        val initialCode = currentUserProfile?.wilayaCode ?: 16
        val idx = AlgerianLocationData.wilayas.indexOfFirst { it.code == initialCode }
        mutableIntStateOf(if (idx >= 0) idx else 15)
    }
    val currentWilaya = AlgerianLocationData.wilayas.getOrElse(selectedWilayaIndex) { AlgerianLocationData.wilayas[15] }
    var selectedCommune by remember(currentWilaya) {
        val defaultCommune = currentUserProfile?.communeName
        mutableStateOf(
            if (!defaultCommune.isNullOrBlank() && currentWilaya.communes.contains(defaultCommune)) {
                defaultCommune
            } else {
                currentWilaya.communes.firstOrNull() ?: "الجزائر الوسطى"
            }
        )
    }

    var wilayaExpanded by remember { mutableStateOf(false) }
    var communeExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        authViewModel.resetCreatePublicRequestState()
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "نشر طلب عام",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = createRequestState) {
                is AuthResult.Success -> {
                    val created = state.data
                    SuccessRequestView(
                        request = created,
                        onViewDetails = { onNavigateToRequestDetails(created.id) },
                        onDone = onNavigateBack
                    )
                }
                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Banner
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                            color = BlueContainer.copy(alpha = 0.4f),
                        ) {
                            Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(modifier = Modifier.size(48.dp), shape = RoundedCornerShape(12.dp), color = BluePrimary) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Campaign, null, tint = Color.White, modifier = Modifier.size(24.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(text = "طلبك سيصل لجميع الحرفيين", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = BlueDark)
                                    Text(text = "انشر تفاصيل الخدمة واستقبل عروض أسعار من محترفين في منطقتك.", style = MaterialTheme.typography.bodySmall, color = TextTertiaryLight)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Form
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(28.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                KhedmatiTextField(value = title, onValueChange = { title = it; validationError = null }, label = "عنوان الطلب", leadingIcon = Icons.Default.Title)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Profession
                                Text(text = "التخصص المطلوب", style = MaterialTheme.typography.labelSmall, color = BluePrimary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
                                Surface(
                                    modifier = Modifier.fillMaxWidth().clickable { showProfessionDialog = true },
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, if (selectedProfession != null) BluePrimary else OutlineLight)
                                ) {
                                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Handyman, null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(text = selectedProfession?.nameAr ?: "اختر تخصص الحرفي", style = MaterialTheme.typography.bodyMedium, color = if (selectedProfession != null) BlueDark else TextTertiaryLight)
                                        }
                                        Icon(Icons.Default.ArrowDropDown, null, tint = BluePrimary)
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Wilaya & Commune
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        ExposedDropdownMenuBox(expanded = wilayaExpanded, onExpandedChange = { wilayaExpanded = it }) {
                                            KhedmatiTextField(value = currentWilaya.displayName, onValueChange = {}, label = "الولاية", leadingIcon = Icons.Default.LocationOn, readOnly = true, modifier = Modifier.menuAnchor())
                                            ExposedDropdownMenu(expanded = wilayaExpanded, onDismissRequest = { wilayaExpanded = false }) {
                                                AlgerianLocationData.wilayas.forEachIndexed { index, w ->
                                                    DropdownMenuItem(text = { Text(w.displayName) }, onClick = { selectedWilayaIndex = index; wilayaExpanded = false })
                                                }
                                            }
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        ExposedDropdownMenuBox(expanded = communeExpanded, onExpandedChange = { communeExpanded = it }) {
                                            KhedmatiTextField(value = selectedCommune, onValueChange = {}, label = "البلدية", leadingIcon = Icons.Default.LocationOn, readOnly = true, modifier = Modifier.menuAnchor())
                                            ExposedDropdownMenu(expanded = communeExpanded, onDismissRequest = { communeExpanded = false }) {
                                                currentWilaya.communes.forEach { c ->
                                                    DropdownMenuItem(text = { Text(c) }, onClick = { selectedCommune = c; communeExpanded = false })
                                                }
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                KhedmatiTextField(value = description, onValueChange = { description = it; validationError = null }, label = "تفاصيل العمل المطلوب", leadingIcon = Icons.Default.Description, singleLine = false, maxLines = 4)
                                Spacer(modifier = Modifier.height(12.dp))
                                KhedmatiTextField(value = budgetDzdText, onValueChange = { if (it.all { c -> c.isDigit() }) budgetDzdText = it }, label = "الميزانية المتوقعة (اختياري)", leadingIcon = Icons.Default.Payments, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                                Spacer(modifier = Modifier.height(12.dp))
                                KhedmatiTextField(value = addressDetails, onValueChange = { addressDetails = it }, label = "العنوان بالتفصيل (اختياري)", leadingIcon = Icons.Default.LocationOn)

                                if (validationError != null) {
                                    Text(text = validationError!!, color = ErrorRed, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
                                }
                                if (state is AuthResult.Error) {
                                    Text(text = state.messageAr, color = ErrorRed, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
                                }

                                Spacer(modifier = Modifier.height(32.dp))
                                KhedmatiPrimaryButton(
                                    text = "نشر الطلب الآن",
                                    onClick = {
                                        if (title.trim().length < 5) { validationError = "يرجى كتابة عنوان واضح"; return@KhedmatiPrimaryButton }
                                        if (selectedProfession == null) { validationError = "يرجى اختيار التخصص"; return@KhedmatiPrimaryButton }
                                        if (description.trim().length < 10) { validationError = "يرجى كتابة تفاصيل المشكلة"; return@KhedmatiPrimaryButton }
                                        authViewModel.createPublicServiceRequest(title, description, selectedProfession!!.id, selectedProfession!!.nameAr, selectedProfession!!.categoryAr, currentWilaya.code, currentWilaya.nameAr, selectedCommune, addressDetails, budgetDzdText.toLongOrNull())
                                    },
                                    isLoading = state is AuthResult.Loading
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showProfessionDialog) {
        ProfessionSelectionDialog(
            onProfessionSelected = { prof ->
                selectedProfession = prof
                validationError = null
                showProfessionDialog = false
            },
            onDismiss = { showProfessionDialog = false }
        )
    }
}

@Composable
private fun ProfessionSelectionDialog(
    onProfessionSelected: (Profession) -> Unit,
    onDismiss: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var showCustomInput by remember { mutableStateOf(false) }
    var customInput by remember { mutableStateOf("") }
    var customError by remember { mutableStateOf<String?>(null) }

    val filtered = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            ProfessionData.professions
        } else {
            ProfessionData.searchProfessions(searchQuery)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "اختر مهنة / تخصص الحرفي",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (showCustomInput) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "إضافة مهنة أو تخصص غير مدرج",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customInput,
                            onValueChange = { customInput = it; customError = null },
                            placeholder = { Text("أدخل اسم المهنة (مثال: تصليح الساعات...)") },
                            isError = customError != null,
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                        if (customError != null) {
                            Text(
                                text = customError!!,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showCustomInput = false; customError = null }) {
                                Text("رجوع للقائمة")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val err = ProfessionData.validateCustomProfessionName(customInput)
                                    if (err != null) {
                                        customError = err
                                    } else {
                                        val customProf = ProfessionData.createCustomProfession(customInput)
                                        onProfessionSelected(customProf)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Text("تأكيد المهنة", color = Color.White)
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("ابحث عن مهنة (سباك، كهربائي...)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (searchQuery.trim().length >= 2) {
                            item {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            customInput = searchQuery.trim()
                                            showCustomInput = true
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(containerColor = BluePrimary.copy(alpha = 0.1f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null,
                                            tint = BluePrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "إضافة \"${searchQuery.trim()}\" كمهنة جديدة",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = BluePrimary
                                        )
                                    }
                                }
                            }
                        }

                        items(filtered.size) { index ->
                            val prof = filtered[index]
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onProfessionSelected(prof) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = prof.nameAr,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = prof.categoryAr,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = BluePrimary
                                    )
                                }
                            }
                        }

                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (searchQuery.isNotBlank()) customInput = searchQuery.trim()
                                        showCustomInput = true
                                    },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = null,
                                        tint = BluePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "مهنة أخرى / إضافة تخصص غير مدرج",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun SuccessRequestView(
    request: PublicServiceRequest,
    onViewDetails: () -> Unit,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(BlueContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = BluePrimary,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "تم نشر طلبك بنجاح! 📢",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "أصبح طلبك معروضاً الآن للحرفيين المعتمدين في ولاية ${request.wilayaName} (${request.communeName}). ستتلقى عروض الأسعار قريباً وتستطيع اختيار الأنسب.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = onViewDetails,
            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("view_published_request_details_button")
        ) {
            Text(
                text = "متابعة العروض الواردة على الطلب",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        androidx.compose.material3.OutlinedButton(
            onClick = onDone,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text(
                text = "العودة للرئيسية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
