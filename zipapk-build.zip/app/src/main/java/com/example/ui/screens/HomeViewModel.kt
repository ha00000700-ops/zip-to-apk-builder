package com.example.ui.screens

import android.app.Application
import android.location.Geocoder
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.batoulapps.adhan.Prayer
import com.batoulapps.adhan.PrayerTimes
import com.example.data.PrayerTimesHelper
import com.example.data.SettingsRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class HomeState(
    val prayerTimes: PrayerTimes? = null,
    val nextPrayerTimes: PrayerTimes? = null,
    val currentPrayer: Prayer = Prayer.NONE,
    val nextPrayer: Prayer = Prayer.NONE,
    val nextPrayerTime: Date? = null,
    val countdownText: String = "--:--:--",
    val cityName: String = "غير محدد",
    val timeZoneId: String = java.util.TimeZone.getDefault().id,
    val isLoadingLocation: Boolean = false,
    val locationError: String? = null,
    val useManualLocation: Boolean = false,
    val calcMethod: com.batoulapps.adhan.CalculationMethod = com.batoulapps.adhan.CalculationMethod.MUSLIM_WORLD_LEAGUE
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    
    private val _currentTime = MutableStateFlow(Date())
    private val _homeState = MutableStateFlow(HomeState())
    val homeState: StateFlow<HomeState> = _homeState

    init {
        startClock()
        observeSettings()
    }

    private fun startClock() {
        viewModelScope.launch {
            while (true) {
                _currentTime.value = Date()
                updateCountdown()
                delay(1000)
            }
        }
    }

    private fun observeSettings() {
        viewModelScope.launch {
            combine(
                settingsRepository.latitudeFlow,
                settingsRepository.longitudeFlow,
                settingsRepository.cityNameFlow,
                settingsRepository.calculationMethodFlow,
                settingsRepository.asrMethodFlow,
                settingsRepository.timeZoneIdFlow
            ) { args ->
                SettingsData(
                    args[0] as Double?,
                    args[1] as Double?,
                    args[2] as String?,
                    args[3] as com.batoulapps.adhan.CalculationMethod,
                    args[4] as com.batoulapps.adhan.Madhab,
                    args[5] as String
                )
            }.combine(settingsRepository.useManualLocationFlow) { settings, useManual ->
                settings.copy(useManual = useManual)
            }.combine(_currentTime) { settings, time ->
                if (settings.lat != null && settings.lng != null) {
                    val prayerTimes = PrayerTimesHelper.getPrayerTimes(settings.lat, settings.lng, time, settings.calcMethod, settings.asrMethod, settings.timeZoneId)
                    val nextPrayerTimes = PrayerTimesHelper.getNextPrayerTimes(settings.lat, settings.lng, time, settings.calcMethod, settings.asrMethod, settings.timeZoneId)
                    
                    val current = prayerTimes.currentPrayer()
                    var next = prayerTimes.nextPrayer()
                    var nextTime = prayerTimes.timeForPrayer(next)

                    if (next == Prayer.NONE) {
                        next = Prayer.FAJR
                        nextTime = nextPrayerTimes.fajr
                    }

                    _homeState.value = _homeState.value.copy(
                        prayerTimes = prayerTimes,
                        nextPrayerTimes = nextPrayerTimes,
                        currentPrayer = current,
                        nextPrayer = next,
                        nextPrayerTime = nextTime,
                        cityName = settings.city ?: "موقع محدد",
                        timeZoneId = settings.timeZoneId,
                        useManualLocation = settings.useManual,
                        calcMethod = settings.calcMethod
                    )
                    updateCountdown()
                } else {
                    _homeState.value = _homeState.value.copy(
                        cityName = "يرجى تحديد الموقع",
                        timeZoneId = settings.timeZoneId,
                        useManualLocation = settings.useManual
                    )
                }
            }.collect {}
        }
    }

    private data class SettingsData(
        val lat: Double?,
        val lng: Double?,
        val city: String?,
        val calcMethod: com.batoulapps.adhan.CalculationMethod,
        val asrMethod: com.batoulapps.adhan.Madhab,
        val timeZoneId: String,
        val useManual: Boolean = false
    )

    private fun updateCountdown() {
        val nextTime = _homeState.value.nextPrayerTime
        if (nextTime != null) {
            val diff = nextTime.time - _currentTime.value.time
            if (diff > 0) {
                val hours = TimeUnit.MILLISECONDS.toHours(diff)
                val minutes = TimeUnit.MILLISECONDS.toMinutes(diff) % 60
                val seconds = TimeUnit.MILLISECONDS.toSeconds(diff) % 60
                val countdown = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
                _homeState.value = _homeState.value.copy(countdownText = countdown)
            } else {
                _homeState.value = _homeState.value.copy(countdownText = "00:00:00")
                // A second later, observeSettings should re-calculate because _currentTime changes.
            }
        }
    }

    fun updateLocation(lat: Double, lng: Double, geocoder: Geocoder?) {
        viewModelScope.launch {
            _homeState.value = _homeState.value.copy(isLoadingLocation = true, locationError = null)
            try {
                var city = "موقع محدد"
                if (geocoder != null) {
                    try {
                        val addresses = geocoder.getFromLocation(lat, lng, 1)
                        if (!addresses.isNullOrEmpty()) {
                            val address = addresses[0]
                            city = address.locality ?: address.subAdminArea ?: address.adminArea ?: city
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                val tzId = com.example.data.TimeZoneHelper.getTimeZoneId(lat, lng)
                settingsRepository.updateLocation(lat, lng, city, tzId)
                sendUpdateBroadcast()
            } catch (e: Exception) {
                _homeState.value = _homeState.value.copy(locationError = "فشل في تحديث الموقع")
            } finally {
                _homeState.value = _homeState.value.copy(isLoadingLocation = false)
            }
        }
    }
    
    private fun sendUpdateBroadcast() {
        val intent = android.content.Intent(getApplication(), com.example.receivers.PrayerAlarmReceiver::class.java).apply {
            putExtra(com.example.receivers.PrayerAlarmReceiver.EXTRA_IS_UPDATE, true)
        }
        getApplication<Application>().sendBroadcast(intent)
    }
}
