package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlantDoctorViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminGuidanceScreen(viewModel: PlantDoctorViewModel) {
    val plants by viewModel.plants.collectAsState()
    val diagnoses by viewModel.diagnoses.collectAsState()
    val pendingTasks by viewModel.pendingTasks.collectAsState()

    var reportText by remember { mutableStateOf("") }
    var reportSubmitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "لوحة الإرشاد والمراجع الرسمية 🏛️",
                subtitle = "المصادر المعتمدة والسلامة الزراعية والبلاغات",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Usage Statistics Dashboard (Real Data from Room Database)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.BarChart, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إحصائيات نشاطك الزراعي الفعلي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        StatTile(label = "النباتات المسجلة", value = "${plants.size}")
                        StatTile(label = "الفحوصات المنفذة", value = "${diagnoses.size}")
                        StatTile(label = "مهام العناية القادمة", value = "${pendingTasks.size}")
                    }
                }
            }

            // Official Agricultural Sources in Algeria & Arab World
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("المصادر والمراجع العلمية المعتمدة", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    OfficialSourceItem(
                        name = "المعهد الوطني للبحث الزراعي بالجزائر (INRAA)",
                        role = "الأبحاث الزراعية، التنوع البيولوجي، وتحديد مسببات الأمراض النباتية ومكافحتها."
                    )
                    OfficialSourceItem(
                        name = "المعهد التقني للمحاصيل الكبرى (ITGC)",
                        role = "إرشادات زراعة الحبوب والبقوليات وحماية المزروعات في شمال أفريقيا."
                    )
                    OfficialSourceItem(
                        name = "المعهد التقني لتربية الأشجار المثمرة والكروم (ITAFV)",
                        role = "أمراض الحمضيات، الزيتون، النخيل، والأشجار المثمرة وبرامج الرش الوقائي."
                    )
                    OfficialSourceItem(
                        name = "منظمة الأغذية والزراعة للأمم المتحدة (FAO)",
                        role = "الدلائل الإرشادية لإدارة الآفات المتكاملة (IPM) والاستخدام الرشيد للمبيدات."
                    )
                }
            }

            // Safe Chemical Usage & Precautionary Principles
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AgriGreenMint.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = AgriGreenDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "مبادئ السلامة في استعمال المبيدات (Good Practice)",
                            fontWeight = FontWeight.Bold,
                            color = AgriGreenDark
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "1. الأولوية دائماً للمكافحة الوقائية والزراعية والبيولوجية قبل اللجوء للمبيدات الكيميائية.\n" +
                                "2. الالتزام الصارم بالجرعات المحددة في الملصق الرسمي لكل مادة فعالة وعدم مضاعفتها.\n" +
                                "3. احترام فترة الأمان قبل الحصاد (PHI): وهي المدة الإلزامية بين آخر رش وجني المحصول لحماية المستهلك.\n" +
                                "4. ارتداء معدات الوقاية الشخصية (كمامة، نظارات واقية، وقفازات) عند تحضير ورش المحاليل.\n" +
                                "5. تجنب الرش أوقات نشاط النحل صباحاً، أو في الأيام شديدة الرياح لحماية البيئة ومصادر المياه.",
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp,
                        color = Color(0xFF052E16)
                    )
                }
            }

            // Report an Issue or Discrepancy
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ReportProblem, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("الإبلاغ عن تشخيص غير دقيق أو خطأ في المحتوى", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "نحرص على أعلى درجات الموثوقية العلمية. إذا لاحظت أي توصية غير دقيقة، يرجى كتابة ملاحظتك هنا لمراجعتها مع المهندسين الزراعيين:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    if (reportSubmitted) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AgriGreenDark)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("شكراً لك! تم استلام بلاغك وسيقوم الفريق الزراعي بمراجعته.", color = AgriGreenDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    } else {
                        OutlinedTextField(
                            value = reportText,
                            onValueChange = { reportText = it },
                            placeholder = { Text("أدخل تفاصيل البلاغ أو الملاحظة الزراعية...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("report_issue_input"),
                            shape = RoundedCornerShape(12.dp),
                            maxLines = 3
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (reportText.isNotBlank()) {
                                    reportSubmitted = true
                                }
                            },
                            enabled = reportText.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("submit_report_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إرسال البلاغ للمراجعة")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = AgriGreenDark)
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
    }
}

@Composable
fun OfficialSourceItem(name: String, role: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = "• $name", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(text = role, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
