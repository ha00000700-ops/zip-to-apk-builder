package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import android.widget.Toast
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ProfessionData
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class RoleFilterTab(val titleAr: String, val role: UserRole?) {
    ALL("الكل", null),
    CUSTOMERS("العملاء", UserRole.CUSTOMER),
    PROVIDERS("الحرفيين", UserRole.SERVICE_PROVIDER),
    ADMINS("المديرين", UserRole.ADMIN)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUserManagementScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val allUsersState by authViewModel.allUsersState.collectAsState()
    var selectedFilterTab by remember { mutableStateOf(RoleFilterTab.ALL) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedUserForDetails by remember { mutableStateOf<UserProfile?>(null) }

    LaunchedEffect(Unit) {
        authViewModel.loadAllUsers()
    }

    val usersList = (allUsersState as? AuthResult.Success)?.data ?: emptyList()

    val filteredUsers = remember(usersList, selectedFilterTab, searchQuery) {
        val normQuery = ProfessionData.normalizeArabicText(searchQuery)
        usersList.filter { user ->
            val matchesRole = when (selectedFilterTab) {
                RoleFilterTab.ALL -> true
                RoleFilterTab.CUSTOMERS -> user.role == UserRole.CUSTOMER
                RoleFilterTab.PROVIDERS -> user.role == UserRole.SERVICE_PROVIDER
                RoleFilterTab.ADMINS -> user.role == UserRole.ADMIN
            }

            if (!matchesRole) return@filter false

            if (normQuery.isBlank()) {
                true
            } else {
                val nameNorm = ProfessionData.normalizeArabicText(user.fullName)
                val emailNorm = ProfessionData.normalizeArabicText(user.email)
                val phoneNorm = ProfessionData.normalizeArabicText(user.phone)
                val wilayaNorm = ProfessionData.normalizeArabicText(user.wilayaName)
                val communeNorm = ProfessionData.normalizeArabicText(user.communeName)

                nameNorm.contains(normQuery) ||
                        emailNorm.contains(normQuery) ||
                        phoneNorm.contains(normQuery) ||
                        wilayaNorm.contains(normQuery) ||
                        communeNorm.contains(normQuery)
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "إدارة المستخدمين",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { authViewModel.loadAllUsers() },
                            modifier = Modifier.testTag("refresh_users_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث بالاسم، البريد، الهاتف، أو المدينة...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_users_search_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Role Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(RoleFilterTab.values()) { tab ->
                        FilterChip(
                            selected = selectedFilterTab == tab,
                            onClick = { selectedFilterTab = tab },
                            label = {
                                val count = when (tab) {
                                    RoleFilterTab.ALL -> usersList.size
                                    RoleFilterTab.CUSTOMERS -> usersList.count { it.role == UserRole.CUSTOMER }
                                    RoleFilterTab.PROVIDERS -> usersList.count { it.role == UserRole.SERVICE_PROVIDER }
                                    RoleFilterTab.ADMINS -> usersList.count { it.role == UserRole.ADMIN }
                                }
                                Text("${tab.titleAr} ($count)")
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // User Count Overview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "عدد النتائج: ${filteredUsers.size}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Users List Content
                when (val state = allUsersState) {
                    is AuthResult.Loading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                    is AuthResult.Error -> {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = state.messageAr,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { authViewModel.loadAllUsers() },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    Text("إعادة المحاولة", color = Color.White)
                                }
                            }
                        }
                    }
                    is AuthResult.Success -> {
                        if (filteredUsers.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.PersonOff,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "لا يوجد مستخدمين يطابقون معايير البحث",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredUsers, key = { it.uid }) { user ->
                                    UserListItemCard(
                                        user = user,
                                        onClick = { selectedUserForDetails = user }
                                    )
                                }
                            }
                        }
                    }
                    else -> {}
                }
            }
        }

        // Details Modal Dialog
        selectedUserForDetails?.let { user ->
            UserDetailDialog(
                user = user,
                authViewModel = authViewModel,
                onDismiss = { selectedUserForDetails = null }
            )
        }
    }
}

@Composable
private fun UserListItemCard(
    user: UserProfile,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // User Avatar
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val avatar = user.resolvedAvatarUrl()
                if (avatar.isNotBlank()) {
                    AsyncImage(
                        model = avatar,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = when (user.role) {
                            UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                            UserRole.SERVICE_PROVIDER -> Icons.Default.Engineering
                            UserRole.CUSTOMER -> Icons.Default.Person
                        },
                        contentDescription = null,
                        tint = when (user.role) {
                            UserRole.ADMIN -> Color(0xFF7B1FA2)
                            UserRole.SERVICE_PROVIDER -> Color(0xFFE65100)
                            UserRole.CUSTOMER -> BluePrimary
                        },
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // User Info Column
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = user.fullName.ifBlank { "مستخدم بدون اسم" },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        SubscriptionStatusBadge(user = user)
                        AccountStatusBadge(user = user)
                        RoleBadge(role = user.role)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (user.email.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Email,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = user.email,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (user.phone.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = user.phone,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${user.wilayaName} — ${user.communeName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun RoleBadge(role: UserRole) {
    val (bgColor, textColor, label) = when (role) {
        UserRole.ADMIN -> Triple(Color(0xFFF3E5F5), Color(0xFF7B1FA2), "مدير النظام")
        UserRole.SERVICE_PROVIDER -> Triple(Color(0xFFFFF3E0), Color(0xFFE65100), "حرفي")
        UserRole.CUSTOMER -> Triple(Color(0xFFE3F2FD), BluePrimary, "زبون")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun SubscriptionStatusBadge(user: UserProfile) {
    val sub = user.subscription
    val (bgColor, textColor, label) = if (sub.isSubscribed) {
        when (sub.plan) {
            com.example.data.model.SubscriptionPlan.PREMIUM -> Triple(Color(0xFFFFF8E1), Color(0xFFB78103), "مميز ⭐⭐⭐")
            com.example.data.model.SubscriptionPlan.STANDARD -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), "قياسي 🥈")
            com.example.data.model.SubscriptionPlan.BASIC -> Triple(Color(0xFFF1F5F9), Color(0xFF475569), "أساسي")
            else -> Triple(Color(0xFFFFF8E1), Color(0xFFB78103), "مشترك ⭐")
        }
    } else {
        Triple(Color(0xFFE3F2FD), Color(0xFF1565C0), "المجانية")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun AccountStatusBadge(user: UserProfile) {
    val isRestrictedActive = user.isRestricted && (user.restrictionUntil == -1L || System.currentTimeMillis() < user.restrictionUntil)
    val (bgColor, textColor, label) = when {
        user.isDeleted -> Triple(Color(0xFFFFEBEE), Color(0xFFC62828), "محذوف")
        isRestrictedActive -> Triple(Color(0xFFFFF3E0), Color(0xFFEF6C00), "مقيّد")
        else -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "نشط")
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun UserDetailDialog(
    user: UserProfile,
    authViewModel: AuthViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var providerProfileState by remember { mutableStateOf<AuthResult<ServiceProviderProfile>?>(null) }

    LaunchedEffect(user.uid) {
        if (user.role == UserRole.SERVICE_PROVIDER) {
            providerProfileState = AuthResult.Loading
            providerProfileState = authViewModel.fetchServiceProviderProfileForAdmin(user.uid)
        }
    }

    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()) }
    val formattedCreatedDate = remember(user.createdAt) {
        try {
            dateFormatter.format(Date(user.createdAt))
        } catch (e: Exception) {
            "—"
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
            ) {
                Text("إغلاق", color = Color.White)
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "تفاصيل الحساب",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                RoleBadge(role = user.role)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                // Header Avatar & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        val avatar = user.resolvedAvatarUrl()
                        if (avatar.isNotBlank()) {
                            AsyncImage(
                                model = avatar,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = user.fullName.ifBlank { "مستخدم بدون اسم" },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SubscriptionStatusBadge(user = user)
                            AccountStatusBadge(user = user)
                            Text(
                                text = "المعرف: ${user.uid.take(8)}...",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Divider()

                Spacer(modifier = Modifier.height(12.dp))

                // Account Management Actions Section
                Text(
                    text = "إدارة الحساب الإدارية",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFC62828)
                )

                Spacer(modifier = Modifier.height(6.dp))

                var showRestrictDialog by remember { mutableStateOf(false) }
                var showDeleteDialog by remember { mutableStateOf(false) }

                val isSelf = user.uid == authViewModel.currentUserId
                if (isSelf) {
                    Text(
                        text = "⚠️ هذا هو حسابك الإداري الحالي. لا يمكنك تقييده أو حذفه.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFC62828)
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isRestrictedActive = user.isRestricted && (user.restrictionUntil == -1L || System.currentTimeMillis() < user.restrictionUntil)
                        if (isRestrictedActive) {
                            Button(
                                onClick = {
                                    authViewModel.restrictUser(user.uid, false, 0L) { success, errMsg ->
                                        if (success) {
                                            Toast.makeText(context, "تم إلغاء تقييد الحساب بنجاح", Toast.LENGTH_SHORT).show()
                                            authViewModel.loadAllUsers()
                                            onDismiss()
                                        } else {
                                            Toast.makeText(context, errMsg ?: "فشل إلغاء التقييد", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إلغاء التقييد", color = Color.White, fontSize = 12.sp)
                            }
                        } else {
                            Button(
                                onClick = { showRestrictDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF6C00)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("تقييد الحساب", color = Color.White, fontSize = 12.sp)
                            }
                        }

                        Button(
                            onClick = { showDeleteDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("حذف الحساب", color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                if (showRestrictDialog) {
                    AlertDialog(
                        onDismissRequest = { showRestrictDialog = false },
                        title = { Text("تقييد الحساب") },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("اختر مدة التقييد لهذا المستخدم:")
                                Button(
                                    onClick = {
                                        val until = System.currentTimeMillis() + 24 * 3600 * 1000L
                                        authViewModel.restrictUser(user.uid, true, until) { success, errMsg ->
                                            showRestrictDialog = false
                                            if (success) {
                                                Toast.makeText(context, "تم تقييد الحساب لمدة 24 ساعة", Toast.LENGTH_SHORT).show()
                                                authViewModel.loadAllUsers()
                                                onDismiss()
                                            } else {
                                                Toast.makeText(context, errMsg ?: "فشل تقييد الحساب", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("تقييد لمدة 24 ساعة") }

                                Button(
                                    onClick = {
                                        val until = System.currentTimeMillis() + 7 * 24 * 3600 * 1000L
                                        authViewModel.restrictUser(user.uid, true, until) { success, errMsg ->
                                            showRestrictDialog = false
                                            if (success) {
                                                Toast.makeText(context, "تم تقييد الحساب لمدة 7 أيام", Toast.LENGTH_SHORT).show()
                                                authViewModel.loadAllUsers()
                                                onDismiss()
                                            } else {
                                                Toast.makeText(context, errMsg ?: "فشل تقييد الحساب", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("تقييد لمدة 7 أيام") }

                                Button(
                                    onClick = {
                                        val until = System.currentTimeMillis() + 30 * 24 * 3600 * 1000L
                                        authViewModel.restrictUser(user.uid, true, until) { success, errMsg ->
                                            showRestrictDialog = false
                                            if (success) {
                                                Toast.makeText(context, "تم تقييد الحساب لمدة 30 يوماً", Toast.LENGTH_SHORT).show()
                                                authViewModel.loadAllUsers()
                                                onDismiss()
                                            } else {
                                                Toast.makeText(context, errMsg ?: "فشل تقييد الحساب", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("تقييد لمدة 30 يوماً") }

                                Button(
                                    onClick = {
                                        authViewModel.restrictUser(user.uid, true, -1L) { success, errMsg ->
                                            showRestrictDialog = false
                                            if (success) {
                                                Toast.makeText(context, "تم تقييد الحساب دائمياً", Toast.LENGTH_SHORT).show()
                                                authViewModel.loadAllUsers()
                                                onDismiss()
                                            } else {
                                                Toast.makeText(context, errMsg ?: "فشل تقييد الحساب", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("تقييد دائم (حتى إلغائه من الإدارة)", color = Color.White) }
                            }
                        },
                        confirmButton = {},
                        dismissButton = {
                            TextButton(onClick = { showRestrictDialog = false }) { Text("إلغاء") }
                        }
                    )
                }

                if (showDeleteDialog) {
                    AlertDialog(
                        onDismissRequest = { showDeleteDialog = false },
                        title = { Text("تأكيد حذف الحساب") },
                        text = { Text("هل أنت متأكد من حذف حساب المستخدم '${user.fullName}' نهائياً؟") },
                        confirmButton = {
                            Button(
                                onClick = {
                                    authViewModel.deleteUserAccount(user.uid) { success, errMsg ->
                                        showDeleteDialog = false
                                        if (success) {
                                            Toast.makeText(context, "تم حذف الحساب بنجاح", Toast.LENGTH_SHORT).show()
                                            authViewModel.loadAllUsers()
                                            onDismiss()
                                        } else {
                                            Toast.makeText(context, errMsg ?: "فشل حذف الحساب", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                            ) {
                                Text("حذف نهائي", color = Color.White)
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDeleteDialog = false }) { Text("إلغاء") }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Divider()

                Spacer(modifier = Modifier.height(12.dp))

                // Account Information Section
                Text(
                    text = "بيانات الحساب العامة",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = BluePrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                DetailRow(label = "البريد الإلكتروني", value = user.email.ifBlank { "غير مسجل" })
                DetailRow(label = "رقم الهاتف", value = user.phone.ifBlank { "غير مسجل" })
                DetailRow(label = "الولاية / البلدية", value = "${user.wilayaName} — ${user.communeName}")
                DetailRow(label = "تاريخ الإنشاء", value = formattedCreatedDate)

                // Service Provider Extra Info
                if (user.role == UserRole.SERVICE_PROVIDER) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "بيانات ملف الحرفي / مقدم الخدمة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE65100)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    when (val st = providerProfileState) {
                        is AuthResult.Loading -> {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري تحميل تفاصيل الحرفي...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        is AuthResult.Success -> {
                            val prov = st.data
                            DetailRow(label = "المهنة الرئيسيّة", value = prov.professionNameAr.ifBlank { "غير معددة" })
                            DetailRow(label = "التصنيف", value = prov.professionCategoryAr.ifBlank { "عام" })
                            if (prov.specialization.isNotBlank()) {
                                DetailRow(label = "التخصص الدقيق", value = prov.specialization)
                            }
                            DetailRow(label = "سنوات الخبرة", value = "${prov.experienceYears} سنة")
                            DetailRow(
                                label = "حالة التوثيق",
                                value = if (prov.isVerified) "موثق ✓" else "غير موثق"
                            )
                            DetailRow(
                                label = "الجاهزية للعمل",
                                value = if (prov.isAvailable) "متاح للعمل" else "غير متاح حالياً"
                            )
                            DetailRow(
                                label = "التقييم",
                                value = "★ ${prov.rating} (${prov.reviewCount} تقييم)"
                            )
                            DetailRow(
                                label = "الخدمات المكتملة",
                                value = "${prov.effectiveCompletedJobs()} خدمة"
                            )
                            if (prov.effectiveBio().isNotBlank()) {
                                DetailRow(label = "الوصف/النبذة", value = prov.effectiveBio())
                            }
                        }
                        is AuthResult.Error -> {
                            Text(
                                text = "تعذر تحميل تفاصيل الحرفي الأطول",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        else -> {}
                    }
                }
            }
        }
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.4f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(0.6f)
        )
    }
}
