package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppBackground = Color(0xFF09140F)
val AppSurface = Color(0xFF102118)
val AppPrimary = Color(0xFFE5C05C) // Gold
val AppOnPrimary = Color(0xFF1A1A1A)
val CardBorder = Color(0xFF1D3528)
val BottomNavBackground = Color(0xFF070D0A)
val HighlightBackground = Color(0xFF162215)
val NavActiveColor = Color(0xFF4ADE80)
