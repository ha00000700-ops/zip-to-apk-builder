package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Elegant Mediterranean Blue Palette
val BluePrimary = Color(0xFF0369A1)
val BlueDark = Color(0xFF075985)
val BlueNavy = Color(0xFF082F49)
val BlueLight = Color(0xFF38BDF8)
val BlueContainer = Color(0xFFE0F2FE)
val OnBlueContainer = Color(0xFF075985)

// Elegant Algerian Emerald Palette
val EmeraldPrimary = Color(0xFF059669)
val EmeraldDark = Color(0xFF047857)
val EmeraldLight = Color(0xFF34D399)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF064E3B)

// Accent Amber / Gold Palette
val AmberPrimary = Color(0xFFD97706)
val AmberLight = Color(0xFFFBBF24)
val AmberContainer = Color(0xFFFEF3C7)

// Clean Premium Neutral Palette
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF8FAFC)
val BackgroundLight = Color(0xFFF4F4F5)
val OutlineLight = Color(0xFFE4E4E7)
val TextPrimaryLight = Color(0xFF18181B)
val TextSecondaryLight = Color(0xFF52525B)
val TextTertiaryLight = Color(0xFFA1A1AA)

// Status & Functional Colors
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenContainer = Color(0xFFDCFCE7)
val ErrorRed = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFFFEE2E2)
val WarningOrange = Color(0xFFEA580C)
val InfoBlue = Color(0xFF0284C7)
val InfoBlueContainer = Color(0xFFE0F2FE)

// Dark Theme Palette
val BluePrimaryDark = Color(0xFF38BDF8)
val BlueContainerDark = Color(0xFF075985)
val BackgroundDark = Color(0xFF18181B)
val SurfaceDark = Color(0xFF27272A)
val SurfaceVariantDark = Color(0xFF3F3F46)
val TextPrimaryDark = Color(0xFFFAFAFA)
val TextSecondaryDark = Color(0xFFA1A1AA)
