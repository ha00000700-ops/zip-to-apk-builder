package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Modern Brand Palette (#2D5BD0 Cobalt Theme)
val SleekBluePrimary = Color(0xFF2D5BD0)
val SleekBlueDark = Color(0xFF1E40AF)
val SleekBlueLight = Color(0xFFF0F4FF)
val SleekBlueContainer = Color(0xFFE2EAFE)
val SleekBlueOnContainer = Color(0xFF173B9E)

val SleekRedAccent = Color(0xFFEF4444)
val SleekRedContainer = Color(0xFFFEF2F2)
val SleekRedOnContainer = Color(0xFF991B1B)

val SleekGold = Color(0xFFF59E0B)
val SleekGoldContainer = Color(0xFFFEF3C7)
val SleekGoldOnContainer = Color(0xFF92400E)

val SleekEmerald = Color(0xFF059669)
val SleekEmeraldContainer = Color(0xFFECFDF5)
val SleekEmeraldOnContainer = Color(0xFF065F46)

val SleekOrange = Color(0xFFEA580C)
val SleekOrangeContainer = Color(0xFFFFF7ED)

val SleekPurple = Color(0xFF7C3AED)
val SleekPurpleContainer = Color(0xFFF5F3FF)

// Background & Surfaces for Sleek Theme
val SleekLightBg = Color(0xFFF8F9FF)
val SleekLightSurface = Color(0xFFFFFFFF)
val SleekLightSurfaceVariant = Color(0xFFF0F4FF)

val SleekDarkBg = Color(0xFF0B1120)
val SleekDarkSurface = Color(0xFF151E32)
val SleekDarkSurfaceVariant = Color(0xFF1E293B)

val SleekTextPrimary = Color(0xFF1C1B1F)
val SleekTextSecondary = Color(0xFF4A4C50)
val SleekBorderLight = Color(0xFFE2E8F0)
val SleekBorderDark = Color(0xFF334155)

// Status Colors
val StatusNew = Color(0xFF2D5BD0)
val StatusReview = Color(0xFFF59E0B)
val StatusAccepted = Color(0xFF10B981)
val StatusOnTheWay = Color(0xFF8B5CF6)
val StatusInProgress = Color(0xFF0284C7)
val StatusCompleted = Color(0xFF059669)
val StatusCancelled = Color(0xFFEF4444)

// Compatibility aliases mapped to the Sleek Interface palette
val DzGreenPrimary = SleekBluePrimary
val DzGreenDark = SleekBlueDark
val DzGreenLight = SleekBlueLight
val DzGreenAccent = SleekBluePrimary
val DzGreenContainer = SleekBlueContainer
val DzGreenOnContainer = SleekBlueOnContainer

val DzRedAccent = SleekRedAccent
val DzRedDark = Color(0xFFB91C1C)
val DzRedLight = Color(0xFFFEF2F2)
val DzRedContainer = SleekRedContainer
val DzRedOnContainer = SleekRedOnContainer

val DzGold = SleekGold
val DzGoldContainer = SleekGoldContainer
val DzGoldOnContainer = SleekGoldOnContainer


