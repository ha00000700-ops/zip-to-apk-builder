package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090E17)
val DarkSurface = Color(0xFF111A29)
val DarkSurfaceVariant = Color(0xFF1B283D)
val DarkSurfaceElevated = Color(0xFF24344D)

val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryVariant = Color(0xFF00B0FF)
val ElectricBlue = Color(0xFF2979FF)
val AmberWarning = Color(0xFFFFB300)
val RedAlert = Color(0xFFFF5252)
val GreenSuccess = Color(0xFF00E676)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val CardBorder = Color(0xFF23354E)
