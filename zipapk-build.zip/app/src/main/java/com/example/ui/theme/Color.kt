package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Botanical Color Palette
val EmeraldPrimary = Color(0xFF1B4D3E)
val EmeraldLight = Color(0xFF2D6A4F)
val MintSecondary = Color(0xFF40916C)
val MintLight = Color(0xFF74C69D)
val MintSoft = Color(0xFFD8F3DC)
val PaleBg = Color(0xFFF7FAF7)
val CardSurface = Color(0xFFFFFFFF)
val SurfaceTint = Color(0xFFEEF5EE)

val WarmAmber = Color(0xFFD4A373)
val DangerRed = Color(0xFFD9453B)
val DangerRedBg = Color(0xFFFFECEB)
val WarningOrange = Color(0xFFE76F51)
val WarningOrangeBg = Color(0xFFFDF0ED)
val SuccessGreen = Color(0xFF2B8A3E)
val SuccessGreenBg = Color(0xFFEBFBEE)

val DarkBackground = Color(0xFF0F1E17)
val DarkSurface = Color(0xFF162D23)
val DarkSurfaceVariant = Color(0xFF1E3A2F)
val DarkPrimary = Color(0xFF52B788)
val DarkSecondary = Color(0xFF74C69D)
