package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary brand colors specified for "طبيب النباتات"
val AgriGreenDark = Color(0xFF166534) // أخضر داكن
val AgriGreenMint = Color(0xFFDCFCE7) // أخضر فاتح ناعم
val AgriGreenLight = Color(0xFF22C55E) // أخضر حيوي
val AgriGreenEmerald = Color(0xFF15803D)
val AgriGreenContainer = Color(0xFFBBF7D0)
val AgriGreenBackground = Color(0xFFF8FAF7) // خلفية فاتحة طبيعية
val AgriSurface = Color(0xFFFFFFFF)

// Earth & Accent colors
val SoilAmber = Color(0xFFB45309)
val SoilAmberLight = Color(0xFFFEF3C7)
val AlertRed = Color(0xFFDC2626)
val AlertRedLight = Color(0xFFFEE2E2)
val WarningOrange = Color(0xFFEA580C)
val WarningOrangeLight = Color(0xFFFFEDD5)
val InfoBlue = Color(0xFF0284C7)
val InfoBlueLight = Color(0xFFE0F2FE)

// Dark Theme colors
val DarkBackground = Color(0xFF0C140F)
val DarkSurface = Color(0xFF142018)
val DarkSurfaceVariant = Color(0xFF1C2C23)
val DarkPrimary = Color(0xFF4ADE80)
val DarkPrimaryContainer = Color(0xFF166534)
val DarkOnPrimary = Color(0xFF052E16)
