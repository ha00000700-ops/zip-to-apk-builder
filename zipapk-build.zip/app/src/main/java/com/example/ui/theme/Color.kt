package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Blue Palette (Modern Algerian Service Marketplace Brand)
val BluePrimary = Color(0xFF1E40AF)
val BlueDark = Color(0xFF172554)
val BlueLight = Color(0xFF3B82F6)
val BlueContainer = Color(0xFFEFF6FF)
val OnBlueContainer = Color(0xFF1E3A8A)

// Secondary Emerald Palette
val EmeraldPrimary = Color(0xFF059669)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFECFDF5)
val OnEmeraldContainer = Color(0xFF064E3B)

// Accent Amber / Gold Palette
val AmberPrimary = Color(0xFFD97706)
val AmberLight = Color(0xFFFFF7ED)
val AmberContainer = Color(0xFFFEF3C7)

// Neutral & Surface Palette
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF8FAFC)
val BackgroundLight = Color(0xFFF1F5F9)
val OutlineLight = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
val TextTertiaryLight = Color(0xFF94A3B8)

// Status & Functional Colors
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenContainer = Color(0xFFDCFCE7)
val ErrorRed = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFFFEE2E2)
val WarningOrange = Color(0xFFEA580C)
val InfoBlue = Color(0xFF0284C7)
val InfoBlueContainer = Color(0xFFE0F2FE)

// Dark Theme Palette
val BluePrimaryDark = Color(0xFF60A5FA)
val BlueContainerDark = Color(0xFF1E3A8A)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
