package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Emerald Palette (Algerian Heritage & Modern Trust)
val EmeraldPrimary = Color(0xFF00695C)
val EmeraldDark = Color(0xFF004D40)
val EmeraldLight = Color(0xFF439889)
val EmeraldContainer = Color(0xFFE0F2F1)
val OnEmeraldContainer = Color(0xFF004D40)

// Secondary Warm Amber / Gold Palette (Craftsmanship, Quality, Warmth)
val AmberPrimary = Color(0xFFF57F17)
val AmberSecondary = Color(0xFFFFB300)
val AmberLight = Color(0xFFFFF8E1)
val OnAmberContainer = Color(0xFFE65100)

// Neutral & Surface Palette
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF4F7F5)
val BackgroundLight = Color(0xFFF8FAF9)
val OutlineLight = Color(0xFFD1DBD5)
val TextPrimaryLight = Color(0xFF1B2421)
val TextSecondaryLight = Color(0xFF53635E)
val TextTertiaryLight = Color(0xFF869993)

// Status & Functional Colors
val SuccessGreen = Color(0xFF2E7D32)
val SuccessGreenContainer = Color(0xFFE8F5E9)
val ErrorRed = Color(0xFFD32F2F)
val ErrorRedContainer = Color(0xFFFFEBEE)
val WarningOrange = Color(0xFFED6C02)
val InfoBlue = Color(0xFF0288D1)
val InfoBlueContainer = Color(0xFFE1F5FE)

// Dark Theme Palette
val EmeraldPrimaryDark = Color(0xFF80CBC4)
val EmeraldContainerDark = Color(0xFF004D40)
val AmberPrimaryDark = Color(0xFFFFD54F)
val BackgroundDark = Color(0xFF121514)
val SurfaceDark = Color(0xFF1A1F1D)
val SurfaceVariantDark = Color(0xFF242C29)
val TextPrimaryDark = Color(0xFFE8ECEB)
val TextSecondaryDark = Color(0xFFA5B2AE)
