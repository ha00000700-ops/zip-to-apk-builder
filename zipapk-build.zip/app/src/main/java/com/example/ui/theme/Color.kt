package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Romantic Rose & Blush Palette
val RosePrimary = Color(0xFFF43F5E)
val RoseDark = Color(0xFFBE123C)
val RoseLight = Color(0xFFFB7185)
val RoseSurface = Color(0xFFFFF1F2)

val BlushSecondary = Color(0xFFFB923C)
val PeachTertiary = Color(0xFFEC4899)
val WineBackground = Color(0xFF1E1118)
val WineSurface = Color(0xFF2C1822)
val WineSurfaceVariant = Color(0xFF3D2132)

val SoftPinkText = Color(0xFFFFD1DC)
val TextDark = Color(0xFF1F2937)
val TextMuted = Color(0xFF6B7280)

// Weather Mood Colors
val SunnyGold = Color(0xFFF59E0B)
val SunsetPurple = Color(0xFF8B5CF6)
val RainBlue = Color(0xFF38BDF8)
val NightStarry = Color(0xFF1E1B4B)
val CloudGray = Color(0xFF94A3B8)
