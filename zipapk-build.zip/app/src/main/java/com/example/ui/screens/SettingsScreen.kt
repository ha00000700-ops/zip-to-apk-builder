package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Madhab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = viewModel()) {
    val state by viewModel.settingsState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            item {
                Text(
                    "طريقة حساب المواقيت",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                CalculationMethodItem(
                    title = "رابطة العالم الإسلامي",
                    selected = state.calculationMethod == CalculationMethod.MUSLIM_WORLD_LEAGUE,
                    onClick = { viewModel.setCalculationMethod(CalculationMethod.MUSLIM_WORLD_LEAGUE) }
                )
                CalculationMethodItem(
                    title = "الهيئة المصرية العامة للمساحة",
                    selected = state.calculationMethod == CalculationMethod.EGYPTIAN,
                    onClick = { viewModel.setCalculationMethod(CalculationMethod.EGYPTIAN) }
                )
                CalculationMethodItem(
                    title = "جامعة أم القرى، مكة المكرمة",
                    selected = state.calculationMethod == CalculationMethod.UMM_AL_QURA,
                    onClick = { viewModel.setCalculationMethod(CalculationMethod.UMM_AL_QURA) }
                )
                CalculationMethodItem(
                    title = "الجمعية الإسلامية لأمريكا الشمالية (ISNA)",
                    selected = state.calculationMethod == CalculationMethod.NORTH_AMERICA,
                    onClick = { viewModel.setCalculationMethod(CalculationMethod.NORTH_AMERICA) }
                )
                
                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                Text(
                    "المذهب (لصلاة العصر)",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                CalculationMethodItem(
                    title = "قياسي (شافعي، مالكي، حنبلي)",
                    selected = state.asrMethod == Madhab.SHAFI,
                    onClick = { viewModel.setAsrMethod(Madhab.SHAFI) }
                )
                CalculationMethodItem(
                    title = "حنفي",
                    selected = state.asrMethod == Madhab.HANAFI,
                    onClick = { viewModel.setAsrMethod(Madhab.HANAFI) }
                )
                
                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                Text(
                    "الموقع",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Switch(
                        checked = !state.useManualLocation,
                        onCheckedChange = { viewModel.setUseManualLocation(!it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.secondary)
                    )
                    Text(
                        "استخدام GPS لتحديد الموقع تلقائيًا",
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }

                if (state.useManualLocation) {
                    val searchQuery by viewModel.searchQuery.collectAsState()
                    val searchResults by viewModel.searchResults.collectAsState()
                    val isSearching by viewModel.isSearching.collectAsState()
                    val searchError by viewModel.searchError.collectAsState()

                    if (state.cityName != null) {
                        Text(
                            "المدينة المحددة حاليًا: ${state.cityName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                        )
                    }

                    Text(
                        "البحث عن مدينة:",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                    
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.updateSearchQuery(it) },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("أدخل اسم المدينة...") },
                        singleLine = true,
                        trailingIcon = {
                            Button(
                                onClick = { viewModel.searchCity() },
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text("بحث")
                            }
                        }
                    )
                    
                    if (isSearching) {
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 16.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    } else if (searchError != null) {
                        Text(
                            text = searchError!!,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 16.dp)
                        )
                    } else if (searchResults.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(16.dp))
                        searchResults.forEach { city ->
                            CalculationMethodItem(city.name, false) { 
                                viewModel.setManualLocation(city.lat, city.lng, city.name.split("،").first())
                            }
                        }
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    "التنبيهات والأذان",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                SettingsSwitchItem("إشعارات الصلاة", state.notificationsEnabled) { 
                    viewModel.setNotificationsEnabled(it) 
                }

                SettingsSwitchItem("التنبيه المسبق", state.preAlertEnabled) { 
                    viewModel.setPreAlertEnabled(it) 
                }

                if (state.preAlertEnabled) {
                    Text(
                        "مدة التنبيه المسبق (بالدقائق):",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        FilterChip(
                            selected = state.preAlertDuration == 10,
                            onClick = { viewModel.setPreAlertDuration(10) },
                            label = { Text("10") }
                        )
                        FilterChip(
                            selected = state.preAlertDuration == 15,
                            onClick = { viewModel.setPreAlertDuration(15) },
                            label = { Text("15") }
                        )
                        FilterChip(
                            selected = state.preAlertDuration == 30,
                            onClick = { viewModel.setPreAlertDuration(30) },
                            label = { Text("30") }
                        )
                    }
                }

                SettingsSwitchItem("الأذان", state.adhanEnabled) { 
                    viewModel.setAdhanEnabled(it) 
                }

                SettingsSwitchItem("الاهتزاز", state.vibrationEnabled) { 
                    viewModel.setVibrationEnabled(it) 
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun SettingsSwitchItem(title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.secondary)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 16.dp)
        )
    }
}

@Composable
fun CalculationMethodItem(title: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.secondary)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}
