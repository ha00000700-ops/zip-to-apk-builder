package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CastStatus
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedAlert

@Composable
fun StatusCard(
    status: CastStatus,
    interruptionReason: String?,
    onResumeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (statusTitle, statusColor, statusDesc) = when (status) {
        CastStatus.IDLE -> Triple(
            "جاهز للبث (Idle)",
            Color.Gray,
            "اضغط على زر 'بدء البث' لمنح إذن التقاط الشاشة وبدء الإرسال للتلفزيون"
        )
        CastStatus.STARTING -> Triple(
            "جاري التهيئة...",
            CyanPrimary,
            "يتم إعداد سيرفر البث المحلي والـ VirtualDisplay"
        )
        CastStatus.STREAMING -> Triple(
            "البث نشط ومباشر (Live)",
            GreenSuccess,
            "يتم التقاط شاشة الهاتف وبثها عبر Wi-Fi إلى شاشة التلفزيون بدقة عالية وتأخير فائق الانخفاض"
        )
        CastStatus.PAUSED_BY_SYSTEM -> Triple(
            "توقف البث بسبب تعارض نظامي (Messenger Conflict)",
            AmberWarning,
            interruptionReason ?: "قام تطبيق آخر (مثل Messenger) ببدء مشاركة الشاشة، مما دفع نظام Android لإلغاء جلسة التقاط تطبيقنا."
        )
        CastStatus.STOPPED -> Triple(
            "تم إيقاف البث",
            Color.LightGray,
            "انتهت جلسة البث وتم تحرير الـ VirtualDisplay ومصادر النظام"
        )
        CastStatus.ERROR -> Triple(
            "حدث خطأ في البث",
            RedAlert,
            "تعذر بدء التقاط الشاشة أو الخادم المحلي"
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("status_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(statusColor.copy(alpha = 0.5f))
        )
    ) {
        Column(
            modifier = Modifier.padding(18.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = statusTitle,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Icon(
                    imageVector = if (status == CastStatus.PAUSED_BY_SYSTEM) Icons.Default.Warning else Icons.Default.Tv,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = statusDesc,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 20.sp
            )

            AnimatedVisibility(visible = status == CastStatus.PAUSED_BY_SYSTEM) {
                Column(modifier = Modifier.padding(top = 14.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AmberWarning.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                            .border(1.dp, AmberWarning.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تفسير قيد Android OS المعماري:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = AmberWarning
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "حقل mProjectionGrant في نظام Android يسمح بتطبيق واحد فقط للالتقاط. عند إنهاء مكالمة Messenger، اضغط الزر أدناه لاستئناف البث فوراً.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                lineHeight = 18.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onResumeClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color(0xFF001E2B)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("resume_cast_button")
                    ) {
                        Text("استئناف البث إلى التلفزيون (One-Tap Resume)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
