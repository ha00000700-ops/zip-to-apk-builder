package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PreferencesManager
import com.example.data.model.CityInfo
import com.example.data.model.CityWeatherData
import com.example.data.model.EventType
import com.example.data.model.LoveCategory
import com.example.data.model.LoveQuote
import com.example.data.model.LoveQuotesRepository
import com.example.data.model.SpecialEvent
import com.example.data.model.UserLoveNote
import com.example.data.model.WeatherConditionType
import com.example.data.network.WeatherApiClient
import com.example.ui.theme.CardTransparencyStyle
import com.example.ui.theme.RomanticTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class CoupleWeatherUiState(
    val userWeather: CityWeatherData? = null,
    val partnerWeather: CityWeatherData? = null,
    val userName: String = "حسام",
    val partnerName: String = "حبيبتي",
    val userAvatarUri: String? = null,
    val partnerAvatarUri: String? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val dailyWhisper: LoveQuote = LoveQuotesRepository.getDailyQuote(),
    val activeLoveCategory: LoveCategory = LoveCategory.ALL,
    val anniversaries: List<SpecialEvent> = emptyList(),
    val loveNotes: List<UserLoveNote> = emptyList(),
    val searchResults: List<CityInfo> = emptyList(),
    val isSearching: Boolean = false,
    val currentTab: Int = 0, // 0: طقسنا, 1: رسائل الغرام, 2: مناسباتنا, 3: الإعدادات
    val romanticTheme: RomanticTheme = RomanticTheme.ROSE_RUBY,
    val cardStyle: CardTransparencyStyle = CardTransparencyStyle.TRANSLUCENT_GLASS,
    val weatherEffectOverride: WeatherConditionType? = null,
    val particlesEnabled: Boolean = true
)

class CoupleWeatherViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PreferencesManager(application)
    private val weatherApi = WeatherApiClient()

    private val _uiState = MutableStateFlow(
        CoupleWeatherUiState(
            userName = prefs.userName,
            partnerName = prefs.partnerName,
            userAvatarUri = prefs.userAvatarUri,
            partnerAvatarUri = prefs.partnerAvatarUri,
            anniversaries = prefs.getAnniversaries(),
            loveNotes = prefs.getLoveNotes(),
            dailyWhisper = LoveQuotesRepository.getDailyQuote(),
            romanticTheme = RomanticTheme.fromId(prefs.selectedThemeId),
            cardStyle = CardTransparencyStyle.fromId(prefs.cardStyleId),
            weatherEffectOverride = prefs.weatherEffectOverride?.let {
                try { WeatherConditionType.valueOf(it) } catch (_: Exception) { null }
            },
            particlesEnabled = prefs.particlesEnabled
        )
    )
    val uiState: StateFlow<CoupleWeatherUiState> = _uiState.asStateFlow()

    init {
        loadWeatherData()
    }

    fun selectTab(tabIndex: Int) {
        _uiState.update { it.copy(currentTab = tabIndex) }
    }

    fun loadWeatherData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val userCity = prefs.getUserCity()
            val partnerCity = prefs.getPartnerCity()

            val userResult = weatherApi.fetchWeather(userCity)
            val partnerResult = weatherApi.fetchWeather(partnerCity)

            _uiState.update { current ->
                current.copy(
                    isLoading = false,
                    userWeather = userResult.getOrNull() ?: current.userWeather,
                    partnerWeather = partnerResult.getOrNull() ?: current.partnerWeather
                )
            }
        }
    }

    fun updateUserCity(city: CityInfo) {
        prefs.saveUserCity(city)
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val res = weatherApi.fetchWeather(city)
            _uiState.update {
                it.copy(
                    isLoading = false,
                    userWeather = res.getOrNull() ?: it.userWeather
                )
            }
        }
    }

    fun updatePartnerCity(city: CityInfo) {
        prefs.savePartnerCity(city)
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val res = weatherApi.fetchWeather(city)
            _uiState.update {
                it.copy(
                    isLoading = false,
                    partnerWeather = res.getOrNull() ?: it.partnerWeather
                )
            }
        }
    }

    fun updateUserName(name: String) {
        if (name.isNotBlank()) {
            prefs.userName = name.trim()
            _uiState.update { it.copy(userName = name.trim()) }
        }
    }

    fun updatePartnerName(name: String) {
        if (name.isNotBlank()) {
            prefs.partnerName = name.trim()
            _uiState.update { it.copy(partnerName = name.trim()) }
        }
    }

    fun updateUserAvatar(uriString: String?) {
        prefs.userAvatarUri = uriString
        _uiState.update { it.copy(userAvatarUri = uriString) }
    }

    fun updatePartnerAvatar(uriString: String?) {
        prefs.partnerAvatarUri = uriString
        _uiState.update { it.copy(partnerAvatarUri = uriString) }
    }

    fun shuffleWhisper(category: LoveCategory = _uiState.value.activeLoveCategory) {
        val newQuote = LoveQuotesRepository.getRandomQuote(category)
        _uiState.update { it.copy(dailyWhisper = newQuote, activeLoveCategory = category) }
    }

    fun setCategory(category: LoveCategory) {
        _uiState.update { it.copy(activeLoveCategory = category) }
        shuffleWhisper(category)
    }

    fun searchCities(query: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true) }
            val results = weatherApi.searchCities(query)
            _uiState.update { it.copy(searchResults = results, isSearching = false) }
        }
    }

    fun addAnniversary(title: String, year: Int, month: Int, day: Int, type: EventType, note: String) {
        val newEvent = SpecialEvent(
            id = System.currentTimeMillis().toString(),
            title = title,
            year = year,
            month = month,
            day = day,
            eventType = type,
            note = note
        )
        val updated = _uiState.value.anniversaries + newEvent
        prefs.saveAnniversaries(updated)
        _uiState.update { it.copy(anniversaries = updated) }
    }

    fun deleteAnniversary(id: String) {
        val updated = _uiState.value.anniversaries.filterNot { it.id == id }
        prefs.saveAnniversaries(updated)
        _uiState.update { it.copy(anniversaries = updated) }
    }

    fun addLoveNote(text: String) {
        if (text.isBlank()) return
        val note = UserLoveNote(
            id = System.currentTimeMillis().toString(),
            content = text.trim()
        )
        val updated = listOf(note) + _uiState.value.loveNotes
        prefs.saveLoveNotes(updated)
        _uiState.update { it.copy(loveNotes = updated) }
    }

    fun deleteLoveNote(id: String) {
        val updated = _uiState.value.loveNotes.filterNot { it.id == id }
        prefs.saveLoveNotes(updated)
        _uiState.update { it.copy(loveNotes = updated) }
    }

    fun toggleFavoriteNote(id: String) {
        val updated = _uiState.value.loveNotes.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
        prefs.saveLoveNotes(updated)
        _uiState.update { it.copy(loveNotes = updated) }
    }

    fun setRomanticTheme(theme: RomanticTheme) {
        prefs.selectedThemeId = theme.id
        _uiState.update { it.copy(romanticTheme = theme) }
    }

    fun setCardStyle(style: CardTransparencyStyle) {
        prefs.cardStyleId = style.id
        _uiState.update { it.copy(cardStyle = style) }
    }

    fun setWeatherEffectOverride(condition: WeatherConditionType?) {
        prefs.weatherEffectOverride = condition?.name
        _uiState.update { it.copy(weatherEffectOverride = condition) }
    }

    fun toggleParticlesEnabled(enabled: Boolean) {
        prefs.particlesEnabled = enabled
        _uiState.update { it.copy(particlesEnabled = enabled) }
    }
}
