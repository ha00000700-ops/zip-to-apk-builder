package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import android.widget.Toast
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ProfessionData
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.VerificationRequest
import com.example.data.model.VerificationStatus
import com.example.data.repository.AuthResult
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel

enum class ProviderFilterTab(val titleAr: String) {
    PENDING_REQUESTS("طلبات التوثيق المعلقة ⏳"),
    ALL("كل الحرفيين"),
    VERIFIED("موثق ✓"),
    UNVERIFIED("غير موثق"),
    AVAILABLE("متاح للعمل"),
    UNAVAILABLE("غير متاح")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminProviderManagementScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val providersState by authViewModel.allServiceProvidersAdminState.collectAsState()
    val verificationState by authViewModel.verificationUpdateState.collectAsState()
    val pendingRequestsState by authViewModel.pendingVerificationRequestsState.collectAsState()
    val reviewVerificationState by authViewModel.reviewVerificationState.collectAsState()

    var selectedFilterTab by remember { mutableStateOf(ProviderFilterTab.PENDING_REQUESTS) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedProviderForDetails by remember { mutableStateOf<ServiceProviderProfile?>(null) }
    var selectedRequestForReview by remember { mutableStateOf<VerificationRequest?>(null) }
    var rejectionReasonInput by remember { mutableStateOf("") }
    var showRejectDialog by remember { mutableStateOf(false) }
    var showApproveDialog by remember { mutableStateOf(false) }

    var showConfirmDialog by remember { mutableStateOf(false) }
    var targetVerificationValue by remember { mutableStateOf(false) }

    val context = LocalContext.current

    LaunchedEffect(Unit) {
        authViewModel.loadAllServiceProvidersForAdmin()
        authViewModel.loadPendingVerificationRequests()
    }

    val providersList = (providersState as? AuthResult.Success)?.data ?: emptyList()
    val pendingRequestsList = (pendingRequestsState as? AuthResult.Success)?.data ?: emptyList()

    val filteredProviders = remember(providersList, selectedFilterTab, searchQuery) {
        if (selectedFilterTab == ProviderFilterTab.PENDING_REQUESTS) return@remember emptyList()
        val normQuery = ProfessionData.normalizeArabicText(searchQuery)
        providersList.filter { provider ->
            val matchesFilter = when (selectedFilterTab) {
                ProviderFilterTab.PENDING_REQUESTS -> false
                ProviderFilterTab.ALL -> true
                ProviderFilterTab.VERIFIED -> provider.isVerified
                ProviderFilterTab.UNVERIFIED -> !provider.isVerified
                ProviderFilterTab.AVAILABLE -> provider.isAvailable
                ProviderFilterTab.UNAVAILABLE -> !provider.isAvailable
            }

            if (!matchesFilter) return@filter false

            if (normQuery.isBlank()) {
                true
            } else {
                val nameNorm = ProfessionData.normalizeArabicText(provider.fullName)
                val emailNorm = ProfessionData.normalizeArabicText(provider.email)
                val phoneNorm = ProfessionData.normalizeArabicText(provider.phone)
                val professionNorm = ProfessionData.normalizeArabicText(provider.professionNameAr)
                val specializationNorm = ProfessionData.normalizeArabicText(provider.specialization)
                val wilayaNorm = ProfessionData.normalizeArabicText(provider.wilayaName)
                val communeNorm = ProfessionData.normalizeArabicText(provider.communeName)

                nameNorm.contains(normQuery) ||
                        emailNorm.contains(normQuery) ||
                        phoneNorm.contains(normQuery) ||
                        professionNorm.contains(normQuery) ||
                        specializationNorm.contains(normQuery) ||
                        wilayaNorm.contains(normQuery) ||
                        communeNorm.contains(normQuery)
            }
        }
    }

    val filteredRequests = remember(pendingRequestsList, searchQuery) {
        val normQuery = ProfessionData.normalizeArabicText(searchQuery)
        if (normQuery.isBlank()) {
            pendingRequestsList
        } else {
            pendingRequestsList.filter { req ->
                val nameNorm = ProfessionData.normalizeArabicText(req.providerName)
                val phoneNorm = ProfessionData.normalizeArabicText(req.providerPhone)
                val professionNorm = ProfessionData.normalizeArabicText(req.professionNameAr)
                val wilayaNorm = ProfessionData.normalizeArabicText(req.wilayaName)
                val communeNorm = ProfessionData.normalizeArabicText(req.communeName)
                val notesNorm = ProfessionData.normalizeArabicText(req.notes)

                nameNorm.contains(normQuery) ||
                        phoneNorm.contains(normQuery) ||
                        professionNorm.contains(normQuery) ||
                        wilayaNorm.contains(normQuery) ||
                        communeNorm.contains(normQuery) ||
                        notesNorm.contains(normQuery)
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "إدارة وتوثيق الحرفيين",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                authViewModel.loadAllServiceProvidersForAdmin()
                                authViewModel.loadPendingVerificationRequests()
                            },
                            modifier = Modifier.testTag("refresh_providers_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Search Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث بالحرفي، المهنة، التخصص، أو المدينة...") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_providers_search_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Filters Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(ProviderFilterTab.values()) { tab ->
                        FilterChip(
                            selected = selectedFilterTab == tab,
                            onClick = { selectedFilterTab = tab },
                            label = {
                                val count = when (tab) {
                                    ProviderFilterTab.PENDING_REQUESTS -> pendingRequestsList.size
                                    ProviderFilterTab.ALL -> providersList.size
                                    ProviderFilterTab.VERIFIED -> providersList.count { it.isVerified }
                                    ProviderFilterTab.UNVERIFIED -> providersList.count { !it.isVerified }
                                    ProviderFilterTab.AVAILABLE -> providersList.count { it.isAvailable }
                                    ProviderFilterTab.UNAVAILABLE -> providersList.count { !it.isAvailable }
                                }
                                Text("${tab.titleAr} ($count)")
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFFE65100),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val resultCount = if (selectedFilterTab == ProviderFilterTab.PENDING_REQUESTS) {
                    filteredRequests.size
                } else {
                    filteredProviders.size
                }

                Text(
                    text = "عدد النتائج: $resultCount",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Render Content based on active tab
                if (selectedFilterTab == ProviderFilterTab.PENDING_REQUESTS) {
                    when (val state = pendingRequestsState) {
                        null, is AuthResult.Loading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = Color(0xFFE65100))
                            }
                        }
                        is AuthResult.Error -> {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = state.messageAr,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { authViewModel.loadPendingVerificationRequests() },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                    ) {
                                        Text("إعادة المحاولة", color = Color.White)
                                    }
                                }
                            }
                        }
                        is AuthResult.Success -> {
                            if (filteredRequests.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircleOutline,
                                            contentDescription = null,
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "لا توجد طلبات توثيق معلقة حالياً",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "جميع طلبات التوثيق تمت مراجعتها بالكامل",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(filteredRequests, key = { it.providerUid }) { request ->
                                        VerificationRequestCard(
                                            request = request,
                                            onApprove = {
                                                selectedRequestForReview = request
                                                showApproveDialog = true
                                            },
                                            onReject = {
                                                selectedRequestForReview = request
                                                rejectionReasonInput = ""
                                                showRejectDialog = true
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        else -> {}
                    }
                } else {
                    // List of Providers
                    when (val state = providersState) {
                        null, is AuthResult.Loading -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = Color(0xFFE65100))
                            }
                        }
                        is AuthResult.Error -> {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ErrorOutline,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = state.messageAr,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { authViewModel.loadAllServiceProvidersForAdmin() },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                    ) {
                                        Text("إعادة المحاولة", color = Color.White)
                                    }
                                }
                            }
                        }
                        is AuthResult.Success -> {
                            if (filteredProviders.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(32.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Default.Engineering,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "لا يوجد حرفيين يطابقون معايير البحث",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(filteredProviders, key = { it.uid }) { provider ->
                                        ProviderListItemCard(
                                            provider = provider,
                                            onClick = { selectedProviderForDetails = provider }
                                        )
                                    }
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        // Detailed View Dialog
        selectedProviderForDetails?.let { provider ->
            ProviderDetailAdminDialog(
                provider = provider,
                verificationState = verificationState,
                onDismiss = { selectedProviderForDetails = null },
                onToggleVerificationClick = { isVerified ->
                    targetVerificationValue = isVerified
                    showConfirmDialog = true
                }
            )
        }

        // Verification Confirmation Dialog
        if (showConfirmDialog && selectedProviderForDetails != null) {
            val p = selectedProviderForDetails!!
            AlertDialog(
                onDismissRequest = { showConfirmDialog = false },
                title = {
                    Text(
                        text = if (targetVerificationValue) "تأكيد توثيق الحساب" else "إلغاء توثيق الحساب",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = if (targetVerificationValue) {
                            "هل أنت متأكد من رغبتك في توثيق حساب الحرفي ${p.fullName}؟ سيتم عرض شارة توثيق الحساب الخضراء للزبائن لتأكيد موثوقيته."
                        } else {
                            "هل أنت متأكد من رغبتك في إلغاء توثيق حساب الحرفي ${p.fullName}؟ ستتم إزالة شارة التوثيق من حسابه."
                        }
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showConfirmDialog = false
                            authViewModel.toggleProviderVerification(p.uid, targetVerificationValue) { success ->
                                if (success) {
                                    // Refresh the dialog data with updated values
                                    selectedProviderForDetails = selectedProviderForDetails?.copy(isVerified = targetVerificationValue)
                                } else {
                                    // Show error toast if available in verificationState
                                    val error = authViewModel.verificationUpdateState.value
                                    if (error is AuthResult.Error) {
                                        Toast.makeText(context, error.messageAr, Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "حدث خطأ أثناء تحديث حالة التوثيق", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (targetVerificationValue) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text(if (targetVerificationValue) "توثيق الحساب" else "إلغاء التوثيق", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showConfirmDialog = false }) {
                        Text("تراجع")
                    }
                }
            )
        }

        // Approve Verification Request Dialog
        if (showApproveDialog && selectedRequestForReview != null) {
            val req = selectedRequestForReview!!
            val isReviewing = reviewVerificationState is AuthResult.Loading
            AlertDialog(
                onDismissRequest = { if (!isReviewing) showApproveDialog = false },
                title = {
                    Text(
                        text = "قبول وتوثيق الحساب",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text("هل أنت متأكد من رغبتك في قبول طلب توثيق الحساب للحرفي:")
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${req.providerName} (${req.professionNameAr})",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سيتم تفعيل شارة التوثيق الرسمية وإرسال إشعار فوري للحرفي باعتماد حسابه.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            authViewModel.reviewVerificationRequest(
                                providerUid = req.providerUid,
                                approve = true,
                                rejectionReason = ""
                            ) { success ->
                                showApproveDialog = false
                                if (success) {
                                    Toast.makeText(context, "تم قبول طلب التوثيق وتفعيل الشارة بنجاح", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "فشل في معالجة طلب التوثيق", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        enabled = !isReviewing,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        if (isReviewing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("تأكيد القبول والتوثيق ✓", color = Color.White)
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showApproveDialog = false },
                        enabled = !isReviewing
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // Reject Verification Request Dialog
        if (showRejectDialog && selectedRequestForReview != null) {
            val req = selectedRequestForReview!!
            val isReviewing = reviewVerificationState is AuthResult.Loading
            AlertDialog(
                onDismissRequest = { if (!isReviewing) showRejectDialog = false },
                title = {
                    Text(
                        text = "رفض طلب التوثيق",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column {
                        Text("يرجى كتابة سبب رفض طلب التوثيق للحرفي:")
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${req.providerName} (${req.professionNameAr})",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = rejectionReasonInput,
                            onValueChange = { rejectionReasonInput = it },
                            label = { Text("سبب الرفض (مطلوب)") },
                            placeholder = { Text("مثال: صورة بطاقة الهوية غير واضحة، أو نقص في معلومات الخبرة") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            maxLines = 5,
                            isError = rejectionReasonInput.isBlank()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "سيصل هذا السبب كإشعار للحرفي ليتمكن من تصحيح بياناته وإعادة تقديم الطلب.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (rejectionReasonInput.isBlank()) {
                                Toast.makeText(context, "يرجى كتابة سبب الرفض لتوضيحه للحرفي", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            authViewModel.reviewVerificationRequest(
                                providerUid = req.providerUid,
                                approve = false,
                                rejectionReason = rejectionReasonInput.trim()
                            ) { success ->
                                showRejectDialog = false
                                if (success) {
                                    Toast.makeText(context, "تم رفض الطلب وإرسال السبب للحرفي", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "فشل في معالجة طلب الرفض", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        enabled = !isReviewing && rejectionReasonInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        if (isReviewing) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("تأكيد الرفض", color = Color.White)
                        }
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showRejectDialog = false },
                        enabled = !isReviewing
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
private fun ProviderListItemCard(
    provider: ServiceProviderProfile,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val avatar = provider.effectiveAvatarUrl()
                if (avatar.isNotBlank()) {
                    AsyncImage(
                        model = avatar,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Engineering,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = provider.fullName.ifBlank { "حرفي بدون اسم" },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    ProviderVerificationBadge(isVerified = provider.isVerified)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFFF3E0))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = provider.professionNameAr.ifBlank { "مهنة غير محددة" },
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFE65100),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (provider.specialization.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = provider.specialization,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${provider.wilayaName} — ${provider.communeName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "الخبرة: ${provider.experienceYears} سنة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "${provider.rating} (${provider.reviewCount})",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronLeft,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ProviderVerificationBadge(isVerified: Boolean) {
    val bgColor = if (isVerified) Color(0xFFE8F5E9) else Color(0xFFECEFF1)
    val textColor = if (isVerified) Color(0xFF2E7D32) else Color(0xFF546E7A)
    val label = if (isVerified) "موثق ✓" else "غير موثق"

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = textColor,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ProviderDetailAdminDialog(
    provider: ServiceProviderProfile,
    verificationState: AuthResult<Boolean>?,
    onDismiss: () -> Unit,
    onToggleVerificationClick: (Boolean) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "تفاصيل الحرفي المعتمد",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                ProviderVerificationBadge(isVerified = provider.isVerified)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp)
            ) {
                // Header card
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        val avatar = provider.effectiveAvatarUrl()
                        if (avatar.isNotBlank()) {
                            AsyncImage(
                                model = avatar,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Engineering,
                                contentDescription = null,
                                tint = Color(0xFFE65100),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = provider.fullName.ifBlank { "حرفي بدون اسم" },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = provider.email.ifBlank { "البريد الإلكتروني غير متوفر" },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(12.dp))

                // Professional Data
                Text(
                    text = "البيانات المهنية والاتصال",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE65100)
                )

                Spacer(modifier = Modifier.height(8.dp))

                DetailItemRow(label = "المهنة الرئيسيّة", value = provider.professionNameAr.ifBlank { "غير معددة" })
                DetailItemRow(label = "التصنيف الرئيسي", value = provider.professionCategoryAr.ifBlank { "عام" })
                if (provider.specialization.isNotBlank()) {
                    DetailItemRow(label = "التخصص الدقيق", value = provider.specialization)
                }
                DetailItemRow(label = "رقم الهاتف", value = provider.phone.ifBlank { "غير مسجل" })
                DetailItemRow(label = "الولاية / البلدية", value = "${provider.wilayaName} — ${provider.communeName}")
                DetailItemRow(label = "سنوات الخبرة", value = "${provider.experienceYears} سنة")
                DetailItemRow(label = "الجاهزية للعمل", value = if (provider.isAvailable) "متاح لاستقبال الطلبات" else "غير متاح")
                DetailItemRow(label = "التقييم العام", value = "★ ${provider.rating} (${provider.reviewCount} تقييم)")
                DetailItemRow(label = "الخدمات المكتملة", value = "${provider.effectiveCompletedJobs()} خدمة")

                if (provider.effectiveBio().isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "نبذة تعريفية:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = provider.effectiveBio(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(16.dp))

                // Verification Action Panel
                Text(
                    text = "إجراءات التوثيق والتحقق",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                if (verificationState is AuthResult.Loading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    }
                } else {
                    if (verificationState is AuthResult.Error) {
                        Text(
                            text = (verificationState as AuthResult.Error).messageAr,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    if (provider.isVerified) {
                        Button(
                            onClick = { onToggleVerificationClick(false) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إلغاء توثيق الحساب", color = Color.White)
                        }
                    } else {
                        Button(
                            onClick = { onToggleVerificationClick(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Verified, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("توثيق حساب الحرفي ✓", color = Color.White)
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun DetailItemRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.4f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(0.6f)
        )
    }
}

@Composable
private fun VerificationRequestCard(
    request: VerificationRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Avatar/Icon + Name + Profession + Time
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFF3E0)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFFE65100),
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = request.providerName.ifBlank { "حرفي" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = request.professionNameAr.ifBlank { "مهنة عامة" },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE65100),
                        fontWeight = FontWeight.Medium
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFFF8E1)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "قيد المراجعة ⏳",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFF57F17),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            )

            // Info Details Grid
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (request.providerPhone.isNotBlank()) {
                    DetailItemRow(label = "رقم الهاتف:", value = request.providerPhone)
                }

                if (request.wilayaName.isNotBlank() || request.communeName.isNotBlank()) {
                    val loc = listOf(request.wilayaName, request.communeName).filter { it.isNotBlank() }.joinToString(" - ")
                    DetailItemRow(label = "المنطقة والولاية:", value = loc)
                }

                if (request.experienceYears > 0) {
                    DetailItemRow(label = "سنوات الخبرة:", value = "${request.experienceYears} سنوات")
                }

                if (request.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ملاحظات وتفاصيل الحرفي:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = request.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons: Approve & Reject
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("قبول التوثيق ✓", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = onReject,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رفض الطلب", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
