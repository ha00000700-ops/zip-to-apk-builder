package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun StatusBadge(status: RequestStatus, modifier: Modifier = Modifier) {
    val (bg, fg, icon) = when (status) {
        RequestStatus.NEW -> Triple(StatusNew.copy(alpha = 0.15f), StatusNew, Icons.Default.FiberNew)
        RequestStatus.REVIEWING -> Triple(StatusReview.copy(alpha = 0.15f), StatusReview, Icons.Default.Pending)
        RequestStatus.ACCEPTED -> Triple(StatusAccepted.copy(alpha = 0.15f), StatusAccepted, Icons.Default.CheckCircle)
        RequestStatus.ON_THE_WAY -> Triple(StatusOnTheWay.copy(alpha = 0.15f), StatusOnTheWay, Icons.Default.DirectionsCar)
        RequestStatus.IN_PROGRESS -> Triple(StatusInProgress.copy(alpha = 0.15f), StatusInProgress, Icons.Default.Build)
        RequestStatus.COMPLETED -> Triple(StatusCompleted.copy(alpha = 0.15f), StatusCompleted, Icons.Default.DoneAll)
        RequestStatus.CANCELLED -> Triple(StatusCancelled.copy(alpha = 0.15f), StatusCancelled, Icons.Default.Cancel)
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = fg, modifier = Modifier.size(14.dp))
            Text(
                text = status.labelAr,
                color = fg,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun UrgencyBadge(urgency: RequestUrgency, modifier: Modifier = Modifier) {
    val (bg, fg) = when (urgency) {
        RequestUrgency.NORMAL -> Pair(Color(0xFFEFF6FF), Color(0xFF1D4ED8))
        RequestUrgency.URGENT -> Pair(Color(0xFFFFF7ED), Color(0xFFC2410C))
        RequestUrgency.EMERGENCY -> Pair(Color(0xFFFEF2F2), Color(0xFFB91C1C))
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, fg.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Text(
            text = urgency.labelAr,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun AvailabilityBadge(isAvailable: Boolean, modifier: Modifier = Modifier) {
    val bg = if (isAvailable) SleekEmeraldContainer else Color(0xFFF1F5F9)
    val fg = if (isAvailable) SleekEmerald else Color(0xFF64748B)
    val text = if (isAvailable) "متاح الآن" else "مشغول"

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(fg)
        )
        Text(
            text = text,
            color = fg,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun VerifiedBadge(modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(SleekEmeraldContainer)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Verified,
            contentDescription = "موثوق",
            tint = SleekEmerald,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = "موثوق",
            color = SleekEmerald,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun RatingStars(
    rating: Double,
    count: Int? = null,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SleekGoldContainer)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Star,
            contentDescription = null,
            tint = SleekGold,
            modifier = Modifier.size(13.dp)
        )
        Text(
            text = String.format("%.1f", rating),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = SleekGoldOnContainer
        )
        if (count != null && count > 0) {
            Text(
                text = "($count)",
                fontSize = 10.sp,
                color = SleekGoldOnContainer.copy(alpha = 0.8f)
            )
        }
    }
}

@Composable
fun CraftsmanCard(
    craftsman: ProfessionalEntity,
    onClick: () -> Unit,
    onRequestService: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("craftsman_card_${craftsman.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Sleek Avatar with Initials + Verified Floating Indicator
                Box(
                    modifier = Modifier.size(56.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = craftsman.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 17.sp
                        )
                    }

                    if (craftsman.isVerified) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .align(Alignment.TopStart)
                                .clip(CircleShape)
                                .background(SleekEmerald)
                                .border(1.5.dp, MaterialTheme.colorScheme.surface, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "موثوق",
                                tint = Color.White,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = craftsman.fullName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 15.sp
                        )
                        RatingStars(rating = craftsman.ratingAverage, count = craftsman.ratingCount)
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${craftsman.professionNameAr} • ${craftsman.experienceYears} سنوات خبرة",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${craftsman.wilayaNameAr} • ${craftsman.communeNameAr}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (craftsman.bio.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = craftsman.bio,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(8.dp))

            // Metrics & Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AvailabilityBadge(isAvailable = craftsman.isAvailable)
                    
                    Text(
                        text = "${craftsman.completedJobsCount} خدمة منجزة",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Call button
                    IconButton(
                        onClick = {
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${craftsman.phone}"))
                            try {
                                context.startActivity(dialIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "الهاتف: ${craftsman.phone}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .testTag("call_btn_${craftsman.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    // Direct Request Button
                    Button(
                        onClick = onRequestService,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("request_service_btn_${craftsman.id}")
                    ) {
                        Text("اطلب خدمة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun WilayaCommuneSelector(
    selectedWilayaCode: Int,
    selectedCommuneName: String,
    onLocationSelected: (wilayaCode: Int, wilayaName: String, communeName: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    
    val selectedWilaya = remember(selectedWilayaCode) {
        AlgeriaWilayasData.getWilayaByCode(selectedWilayaCode) ?: AlgeriaWilayasData.allWilayas.first()
    }

    Surface(
        onClick = { showDialog = true },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocationCity,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = "الولاية والبلدية",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${selectedWilaya.code} - ${selectedWilaya.nameAr} (${selectedCommuneName.ifBlank { selectedWilaya.communes.firstOrNull() ?: "الكل" }})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (showDialog) {
        var activeWilayaCode by remember { mutableStateOf(selectedWilayaCode) }
        var activeWilaya by remember { mutableStateOf(selectedWilaya) }

        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    text = "اختر الولاية والبلدية (58 ولاية)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("ابحث عن الولاية بالاسم أو الرقم...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    )

                    val filteredWilayas = remember(searchQuery) {
                        if (searchQuery.isBlank()) AlgeriaWilayasData.allWilayas
                        else AlgeriaWilayasData.allWilayas.filter {
                            it.nameAr.contains(searchQuery, ignoreCase = true) ||
                            it.nameFr.contains(searchQuery, ignoreCase = true) ||
                            it.code.toString().contains(searchQuery)
                        }
                    }

                    Text("اختر الولاية:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(160.dp)
                    ) {
                        items(filteredWilayas.size) { index ->
                            val w = filteredWilayas[index]
                            val isSelected = w.code == activeWilayaCode
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .clickable {
                                        activeWilayaCode = w.code
                                        activeWilaya = w
                                    }
                                    .padding(horizontal = 10.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${w.code}. ${w.nameAr} - ${w.nameFr}",
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("اختر البلدية:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                    val communes = activeWilaya.communes
                    androidx.compose.foundation.lazy.LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(communes.size) { index ->
                            val commune = communes[index]
                            val isSel = commune == selectedCommuneName
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    onLocationSelected(activeWilaya.code, activeWilaya.nameAr, commune)
                                    showDialog = false
                                },
                                label = { Text(commune, fontSize = 12.sp) },
                                leadingIcon = if (isSel) { { Icon(Icons.Default.Check, null, modifier = Modifier.size(14.dp)) } } else null
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val defaultCommune = activeWilaya.communes.firstOrNull() ?: "وسط المدينة"
                    onLocationSelected(activeWilaya.code, activeWilaya.nameAr, defaultCommune)
                    showDialog = false
                }) {
                    Text("تأكيد الولاية")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun ServiceIcon(iconName: String, modifier: Modifier = Modifier, tint: Color = MaterialTheme.colorScheme.primary) {
    val vector = when (iconName) {
        "plumbing" -> Icons.Default.Plumbing
        "electric_bolt" -> Icons.Default.ElectricBolt
        "ac_unit" -> Icons.Default.AcUnit
        "car_repair" -> Icons.Default.DirectionsCar
        "carpenter" -> Icons.Default.Handyman
        "format_paint" -> Icons.Default.FormatPaint
        "hardware" -> Icons.Default.Hardware
        "foundation" -> Icons.Default.Foundation
        "kitchen" -> Icons.Default.Kitchen
        "smartphone" -> Icons.Default.PhoneAndroid
        "computer" -> Icons.Default.Computer
        "cleaning_services" -> Icons.Default.CleaningServices
        "local_shipping" -> Icons.Default.LocalShipping
        "videocam" -> Icons.Default.Videocam
        "key" -> Icons.Default.Key
        "yard" -> Icons.Default.Yard
        else -> Icons.Default.Construction
    }
    Icon(imageVector = vector, contentDescription = null, modifier = modifier, tint = tint)
}

@Composable
fun EmptyState(
    title: String,
    description: String,
    icon: ImageVector = Icons.Outlined.SearchOff,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(36.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        if (actionLabel != null && onAction != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onAction,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(actionLabel)
            }
        }
    }
}
