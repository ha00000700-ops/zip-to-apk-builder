package com.example.ui.screens.ads

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromoteServiceScreen(
    authViewModel: AuthViewModel,
    onNavigateToPaymentWeb: (checkoutUrl: String, methodCode: String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    val userProfile by authViewModel.currentUserProfile.collectAsState()
    val myAds by authViewModel.myPromotedAds.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: New Ad, 1: My Ads
    var selectedPackage by remember { mutableStateOf(AdBoostPackage.PREMIUM) }
    
    // Form fields
    var adTitle by remember { mutableStateOf(providerProfile?.professionNameAr ?: "") }
    var adDescription by remember { mutableStateOf(providerProfile?.serviceDescription ?: "") }
    var adImageUrl by remember { mutableStateOf(providerProfile?.effectiveAvatarUrl() ?: "") }
    var showPreviewDialog by remember { mutableStateOf(false) }
    var showPaymentSheet by remember { mutableStateOf(false) }
    var currentCreatedAdId by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    LaunchedEffect(userProfile?.uid) {
        userProfile?.uid?.let { uid ->
            authViewModel.observeMyPromotedAds(uid)
        }
    }

    LaunchedEffect(providerProfile) {
        if (adTitle.isBlank() && providerProfile != null) {
            adTitle = "خدمات ${providerProfile?.professionNameAr ?: ""} — ${providerProfile?.fullName ?: ""}"
        }
        if (adDescription.isBlank() && providerProfile != null) {
            adDescription = providerProfile?.serviceDescription ?: ""
        }
        if (adImageUrl.isBlank() && providerProfile != null) {
            adImageUrl = providerProfile?.effectiveAvatarUrl() ?: ""
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "ترويج خدماتي 🚀",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = BluePrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = BluePrimary
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "إنشاء إعلان ترويجي 🚀",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "إعلاناتي المروّجة",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                style = MaterialTheme.typography.titleSmall
                            )
                            if (myAds.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Badge(containerColor = AmberPrimary) {
                                    Text("${myAds.size}", color = BlueDark, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                )
            }

            if (selectedTab == 0) {
                // Tab 0: Create & Boost Ad
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Banner explaining promotional boost vs subscription
                    PromoteHeroBanner()

                    Spacer(modifier = Modifier.height(20.dp))

                    // Packages Selection Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = BluePrimary.copy(alpha = 0.12f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.RocketLaunch,
                                    contentDescription = null,
                                    tint = BluePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "1. اختر باقة الترويج (Boost Package)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = BlueDark
                            )
                            Text(
                                text = "باقات مستقلة ومؤقتة لمضاعفة ظهورك لدى الزبائن",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Boost Packages Cards
                    AdBoostPackage.values().forEach { pkg ->
                        BoostPackageCard(
                            pkg = pkg,
                            isSelected = selectedPackage == pkg,
                            onSelect = { selectedPackage = pkg }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Ad Content Section
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AmberPrimary.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.EditNote,
                                    contentDescription = null,
                                    tint = AmberDark,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "2. تفاصيل الإعلان الترويجي",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = BlueDark
                            )
                            Text(
                                text = "يمكنك تخصيص عنوان ووصف الإعلان أو استخدام بيانات ملفك",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            OutlinedTextField(
                                value = adTitle,
                                onValueChange = { adTitle = it },
                                label = { Text("عنوان الإعلان الترويجي") },
                                placeholder = { Text("مثال: خدمات سباكة احترافية وسريعة") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("ad_title_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = adDescription,
                                onValueChange = { adDescription = it },
                                label = { Text("وصف الخدمة الترويجية") },
                                placeholder = { Text("اذكر الميزات، الخبرة، وضمان العمل لجذب الزبائن...") },
                                minLines = 3,
                                maxLines = 5,
                                modifier = Modifier.fillMaxWidth().testTag("ad_desc_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Provider info summary (Read-only tags)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BackgroundLight,
                                    border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.4f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.LocationOn, null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${providerProfile?.wilayaName ?: ""}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = BlueDark,
                                            maxLines = 1
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BackgroundLight,
                                    border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.4f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Handyman, null, tint = AmberDark, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${providerProfile?.professionNameAr ?: ""}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = BlueDark,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    // Buttons: Preview and Continue to Payment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showPreviewDialog = true },
                            modifier = Modifier.weight(1f).height(52.dp).testTag("preview_ad_button"),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, BluePrimary)
                        ) {
                            Icon(Icons.Default.Visibility, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("معاينة الإعلان 👁️", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                if (adTitle.isBlank()) {
                                    Toast.makeText(context, "يرجى كتابة عنوان للإعلان الترويجي", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                isSubmitting = true
                                authViewModel.createPromotedAd(
                                    adTitle = adTitle,
                                    adDescription = adDescription,
                                    adImageUrl = adImageUrl,
                                    packageChoice = selectedPackage
                                ) { res ->
                                    isSubmitting = false
                                    when (res) {
                                        is AuthResult.Success -> {
                                            currentCreatedAdId = res.data.id
                                            showPaymentSheet = true
                                        }
                                        is AuthResult.Error -> {
                                            Toast.makeText(context, res.messageAr, Toast.LENGTH_LONG).show()
                                        }
                                        else -> {}
                                    }
                                }
                            },
                            enabled = !isSubmitting,
                            modifier = Modifier.weight(1.4f).height(52.dp).testTag("submit_ad_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Payment, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("متابعة الدفع (${selectedPackage.priceDzd} دج) 💳", fontWeight = FontWeight.Black)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            } else {
                // Tab 1: My Promoted Advertisements List
                if (myAds.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Surface(
                                shape = CircleShape,
                                color = BluePrimary.copy(alpha = 0.1f),
                                modifier = Modifier.size(80.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Campaign,
                                        contentDescription = null,
                                        tint = BluePrimary,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "ليس لديك إعلانات مروّجة بعد",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BlueDark
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "قم بترويج خدماتك لتظهر في مقدمة نتائج البحث وتضاعف اتصالات الزبائن.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = { selectedTab = 0 },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إنشاء أول إعلان الآن 🚀", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(myAds, key = { it.id }) { ad ->
                            MyPromotedAdItemCard(
                                ad = ad,
                                onPayPending = {
                                    currentCreatedAdId = ad.id
                                    selectedPackage = ad.boostPackage
                                    showPaymentSheet = true
                                },
                                onRefresh = {
                                    userProfile?.uid?.let { uid ->
                                        authViewModel.observeMyPromotedAds(uid)
                                    }
                                    Toast.makeText(context, "جاري تحديث حالة الإعلانات المروّجة 🔄", Toast.LENGTH_SHORT).show()
                                },
                                onCancel = {
                                    authViewModel.cancelPromotedAd(ad.id) { res ->
                                        if (res is AuthResult.Success) {
                                            Toast.makeText(context, "تم إلغاء الإعلان بنجاح", Toast.LENGTH_SHORT).show()
                                        } else if (res is AuthResult.Error) {
                                            Toast.makeText(context, res.messageAr, Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Preview Dialog
    if (showPreviewDialog) {
        AdPreviewDialog(
            title = adTitle,
            description = adDescription,
            providerProfile = providerProfile,
            boostPackage = selectedPackage,
            onDismiss = { showPreviewDialog = false }
        )
    }

    // Payment Bottom Sheet
    if (showPaymentSheet && currentCreatedAdId != null) {
        AdPaymentBottomSheet(
            adId = currentCreatedAdId!!,
            boostPackage = selectedPackage,
            authViewModel = authViewModel,
            onNavigateToPaymentWeb = { checkoutUrl, methodCode ->
                showPaymentSheet = false
                onNavigateToPaymentWeb(checkoutUrl, methodCode)
            },
            onDismiss = { showPaymentSheet = false }
        )
    }
}

@Composable
fun PromoteHeroBanner() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        colors = listOf(BlueDark, BluePrimary)
                    )
                )
                .padding(20.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AmberPrimary
                    ) {
                        Text(
                            text = "نظام الترويج المدفوع 🚀",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = BlueDark
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "روّج خدماتك وتصدّر نتائج البحث في ولايتك",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "نظام باقات ترويجي مرن ومستقل عن الاشتراك الشهري، يمنحك شارة (مروّج) وأولوية عرض قصوى للزبائن.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                        lineHeight = 18.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BoostPackageCard(
    pkg: AdBoostPackage,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val borderColor = if (isSelected) {
        if (pkg.isRecommended) AmberDark else BluePrimary
    } else {
        OutlineLight.copy(alpha = 0.5f)
    }

    val backgroundColor = if (isSelected) {
        if (pkg.isRecommended) AmberPrimary.copy(alpha = 0.12f) else BluePrimary.copy(alpha = 0.06f)
    } else {
        Color.White
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onSelect() }
            .testTag("package_${pkg.name.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        color = backgroundColor,
        border = BorderStroke(if (isSelected) 2.dp else 1.dp, borderColor),
        shadowElevation = if (isSelected) 3.dp else 1.dp
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = { onSelect() },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = if (pkg.isRecommended) AmberDark else BluePrimary
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = pkg.titleAr,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = BlueDark
                            )
                            if (pkg.isRecommended) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AmberPrimary
                                ) {
                                    Text(
                                        text = "موصى به ⭐",
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Black,
                                        color = BlueDark,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = pkg.subtitleAr,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryLight,
                            fontSize = 12.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (pkg.isRecommended) AmberPrimary.copy(alpha = 0.2f) else BluePrimary.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, if (pkg.isRecommended) AmberDark.copy(alpha = 0.4f) else BluePrimary.copy(alpha = 0.3f))
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "${pkg.priceDzd} دج",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = if (pkg.isRecommended) AmberDark else BluePrimary
                        )
                        Text(
                            text = "${pkg.durationDays} أيام ⏱️",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = BlueDark,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdPreviewDialog(
    title: String,
    description: String,
    providerProfile: ServiceProviderProfile?,
    boostPackage: AdBoostPackage,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Visibility, null, tint = BluePrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("معاينة ظهور الإعلان للزبائن", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "هكذا سيظهر إعلانك الترويجي في أعلى نتائج البحث للزبائن في ولايتك:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight
                )
                Spacer(modifier = Modifier.height(14.dp))

                // Simulated Promoted Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = Color.White,
                    shadowElevation = 3.dp,
                    border = BorderStroke(1.5.dp, AmberPrimary)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AmberPrimary
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Campaign, null, tint = BlueDark, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "مروّج 🚀 (${boostPackage.badgeLabelAr})",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Black,
                                        color = BlueDark
                                    )
                                }
                            }

                            Text(
                                text = "${providerProfile?.wilayaName ?: ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryLight,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(54.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = BackgroundLight
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    val avatar = providerProfile?.effectiveAvatarUrl() ?: ""
                                    if (avatar.isNotBlank()) {
                                        AsyncImage(
                                            model = avatar,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(Icons.Default.Person, null, tint = BluePrimary, modifier = Modifier.size(28.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (title.isNotBlank()) title else "عنوان الإعلان الترويجي",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Black,
                                    color = BlueDark
                                )
                                Text(
                                    text = "${providerProfile?.fullName ?: ""} • ${providerProfile?.professionNameAr ?: ""}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BluePrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (description.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryLight,
                                maxLines = 3
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
            ) {
                Text("إغلاق المعاينة", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun MyPromotedAdItemCard(
    ad: PromotedAd,
    onPayPending: () -> Unit,
    onCancel: () -> Unit,
    onRefresh: (() -> Unit)? = null
) {
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")) }

    val statusColor = when (ad.status) {
        AdStatus.ACTIVE -> EmeraldPrimary
        AdStatus.PENDING_PAYMENT, AdStatus.PENDING_VERIFICATION -> AmberPrimary
        AdStatus.EXPIRED -> Color.Gray
        AdStatus.CANCELLED, AdStatus.REJECTED -> Color(0xFFE53935)
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f)),
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = ad.adTitle.ifBlank { "إعلان ترويجي" },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = BlueDark,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = ad.status.displayNameAr,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "الباقة: ${ad.boostPackage.titleAr} (${ad.priceDzd} دج)",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = BluePrimary
            )

            if (ad.adDescription.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = ad.adDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = OutlineLight.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (ad.status == AdStatus.ACTIVE && ad.endDate > 0L) {
                        Text(
                            text = "ينتهي في: ${dateFormat.format(Date(ad.endDate))}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                    } else {
                        Text(
                            text = "تاريخ الإنشاء: ${dateFormat.format(Date(ad.createdAt))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextTertiaryLight
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (ad.status == AdStatus.PENDING_PAYMENT) {
                        if (onRefresh != null) {
                            IconButton(
                                onClick = onRefresh,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "تحديث حالة الدفع",
                                    tint = BluePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Button(
                            onClick = onPayPending,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("دفع الآن 💳", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (ad.status == AdStatus.ACTIVE || ad.status == AdStatus.PENDING_PAYMENT) {
                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE53935)),
                            border = BorderStroke(1.dp, Color(0xFFE53935)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("إلغاء", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdPaymentBottomSheet(
    adId: String,
    boostPackage: AdBoostPackage,
    authViewModel: AuthViewModel,
    onNavigateToPaymentWeb: (checkoutUrl: String, methodCode: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.EDAHABIA) }
    var isProcessing by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = CircleShape,
                color = EmeraldPrimary.copy(alpha = 0.12f),
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "دفع رسوم الإعلان الترويجي",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = BlueDark
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "باقة ${boostPackage.titleAr} • المبلغ: ${boostPackage.priceDzd} دج",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = BluePrimary
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Payment Methods Selector (EDAHABIA vs CIB)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // EDAHABIA Option
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { selectedPaymentMethod = PaymentMethod.EDAHABIA }
                        .testTag("pay_edahabia_boost"),
                    shape = RoundedCornerShape(16.dp),
                    color = if (selectedPaymentMethod == PaymentMethod.EDAHABIA) AmberPrimary.copy(alpha = 0.12f) else BackgroundLight,
                    border = BorderStroke(
                        if (selectedPaymentMethod == PaymentMethod.EDAHABIA) 2.dp else 1.dp,
                        if (selectedPaymentMethod == PaymentMethod.EDAHABIA) AmberPrimary else OutlineLight.copy(alpha = 0.4f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = AmberDark,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "البطاقة الذهبية",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = BlueDark
                        )
                        Text(
                            text = "بريد الجزائر 💳",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                    }
                }

                // CIB Option
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { selectedPaymentMethod = PaymentMethod.CIB }
                        .testTag("pay_cib_boost"),
                    shape = RoundedCornerShape(16.dp),
                    color = if (selectedPaymentMethod == PaymentMethod.CIB) BluePrimary.copy(alpha = 0.1f) else BackgroundLight,
                    border = BorderStroke(
                        if (selectedPaymentMethod == PaymentMethod.CIB) 2.dp else 1.dp,
                        if (selectedPaymentMethod == PaymentMethod.CIB) BluePrimary else OutlineLight.copy(alpha = 0.4f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "بطاقة CIB البنكية",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Black,
                            color = BlueDark
                        )
                        Text(
                            text = "البنوك الجزائرية 🏦",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Pay Button
            Button(
                onClick = {
                    isProcessing = true
                    authViewModel.initiateAdBoostPayment(
                        adId = adId,
                        paymentMethod = selectedPaymentMethod
                    ) { res ->
                        isProcessing = false
                        when (res) {
                            is AuthResult.Success -> {
                                onNavigateToPaymentWeb(res.data.checkoutUrl, selectedPaymentMethod.code)
                            }
                            is AuthResult.Error -> {
                                Toast.makeText(context, res.messageAr, Toast.LENGTH_LONG).show()
                            }
                            else -> {}
                        }
                    }
                },
                enabled = !isProcessing,
                modifier = Modifier.fillMaxWidth().height(54.dp).testTag("confirm_ad_payment_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Lock, null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("الانتقال لبوابة الدفع الآمنة (${boostPackage.priceDzd} دج) 🔒", fontWeight = FontWeight.Black)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
