package com.example.ui.screens.public_request

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.material3.Surface
import androidx.compose.foundation.BorderStroke
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextTertiaryLight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.OfferStatus
import com.example.data.model.PublicRequestOffer
import com.example.data.model.PublicRequestStatus
import com.example.data.model.PublicServiceRequest
import com.example.data.model.Review
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicRequestDetailsScreen(
    requestId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChat: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()
    val currentProviderProfile by authViewModel.currentProviderProfile.collectAsState()
    val offersState by authViewModel.publicRequestOffersState.collectAsState()

    var requestState by remember { mutableStateOf<AuthResult<PublicServiceRequest?>>(AuthResult.Loading) }
    var showOfferSheet by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showCompleteDialog by remember { mutableStateOf(false) }
    var isCompletingRequest by remember { mutableStateOf(false) }
    var offerToAccept by remember { mutableStateOf<PublicRequestOffer?>(null) }
    var isAcceptingOffer by remember { mutableStateOf(false) }
    var requestReview by remember { mutableStateOf<Review?>(null) }
    var isSubmittingReview by remember { mutableStateOf(false) }

    val currentUid = currentUserProfile?.uid ?: ""
    val isCustomer = currentUserProfile?.role == UserRole.CUSTOMER
    val isProvider = currentUserProfile?.role == UserRole.SERVICE_PROVIDER

    LaunchedEffect(requestId) {
        authViewModel.getPublicServiceRequestFlow(requestId).collect { res ->
            requestState = res
            if (res is AuthResult.Success && res.data?.status == PublicRequestStatus.COMPLETED) {
                authViewModel.getReviewForPublicRequest(requestId) { rev ->
                    requestReview = rev
                }
            }
        }
    }

    var observedOffersKey by remember { mutableStateOf<String?>(null) }
    val currentRequest = (requestState as? AuthResult.Success)?.data
    LaunchedEffect(requestId, currentUid, currentRequest?.customerId) {
        if (currentRequest != null && currentUid.isNotBlank()) {
            val key = "${requestId}_${currentUid}_${currentRequest.customerId == currentUid}"
            if (observedOffersKey != key) {
                observedOffersKey = key
                if (currentRequest.customerId == currentUid) {
                    authViewModel.observePublicRequestOffers(requestId)
                } else {
                    authViewModel.observeMyPublicRequestOffer(requestId, currentUid)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(listOf(BlueDark, BluePrimary)),
                            shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
                        )
                        .padding(top = 48.dp, bottom = 40.dp, start = 24.dp, end = 24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(18.dp))
                        
                        Column {
                            Text(
                                text = "تفاصيل الطلب العام",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "متابعة حالة الطلب وعروض الحرفيين",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = com.example.ui.theme.BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = requestState) {
                is AuthResult.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = BluePrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "جاري تحميل تفاصيل الطلب والعروض...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is AuthResult.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "تعذر تحميل الطلب",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ErrorRed
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = state.messageAr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is AuthResult.ProfileMissing -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("يرجى إكمال الملف الشخصي")
                    }
                }
                is AuthResult.Success -> {
                    val request = state.data
                    if (request == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("الطلب غير موجود أو تم حذفه")
                        }
                    } else {
                        val isOwner = request.customerId == currentUid
                        val offersList = (offersState as? AuthResult.Success)?.data ?: emptyList()
                        val myOffer = offersList.firstOrNull { it.providerId == currentUid }

                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Header Card with Title and Status
                            item {
                                RequestHeaderCard(
                                    request = request,
                                    isOwner = isOwner,
                                    onCancelClick = { showCancelDialog = true }
                                )
                            }

                            // Request Details Description Card
                            item {
                                RequestDescriptionCard(request = request)
                            }

                            // Section: If status == ASSIGNED -> Assigned Service Card with Chat and Complete actions
                            if (request.status == PublicRequestStatus.ASSIGNED && (isOwner || currentUid == request.assignedProviderId)) {
                                item {
                                    AssignedServiceCard(
                                        request = request,
                                        isOwner = isOwner,
                                        isAssignedProvider = currentUid == request.assignedProviderId,
                                        onOpenChat = {
                                            authViewModel.openOrCreateConversation(
                                                customerId = request.customerId,
                                                customerName = request.customerName,
                                                customerPhotoUrl = "",
                                                providerId = request.assignedProviderId ?: "",
                                                providerName = request.assignedProviderName ?: "الحرفي",
                                                providerPhotoUrl = "",
                                                providerProfession = request.professionNameAr,
                                                serviceRequestId = request.id,
                                                serviceRequestTitle = request.title,
                                                isPublicRequest = true
                                            ) { convId, _ ->
                                                if (convId != null) onNavigateToChat(convId)
                                            }
                                        },
                                        onCompleteClick = { showCompleteDialog = true }
                                    )
                                }
                            }

                            // Section: If status == COMPLETED -> Review Card (Customer) or Success badge (Provider)
                            if (request.status == PublicRequestStatus.COMPLETED) {
                                if (isOwner) {
                                    item {
                                        PublicRequestReviewCard(
                                            review = requestReview,
                                            isSubmitting = isSubmittingReview,
                                            onSubmitReview = { rating, comment ->
                                                isSubmittingReview = true
                                                authViewModel.submitPublicRequestReview(
                                                    requestId = request.id,
                                                    rating = rating,
                                                    comment = comment
                                                ) { success, error ->
                                                    isSubmittingReview = false
                                                    if (success) {
                                                        scope.launch { snackbarHostState.showSnackbar("تم إرسال تقييمك بنجاح ⭐") }
                                                        authViewModel.getReviewForPublicRequest(requestId) { rev ->
                                                            requestReview = rev
                                                        }
                                                    } else if (!error.isNullOrBlank()) {
                                                        scope.launch { snackbarHostState.showSnackbar(error) }
                                                    }
                                                }
                                            }
                                        )
                                    }
                                } else if (currentUid == request.assignedProviderId) {
                                    item {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = SuccessGreenContainer.copy(alpha = 0.5f)),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen)
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(16.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = SuccessGreen,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "تم إتمام الخدمة بنجاح ✅",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SuccessGreen
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "تم تسجيل هذه الخدمة في رصيد خدماتك المنجزة بنجاح.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Section: If Provider -> Offer Action / Status
                            if (isProvider && !isOwner && (request.status == PublicRequestStatus.OPEN || myOffer != null)) {
                                item {
                                    ProviderOfferSection(
                                        request = request,
                                        myOffer = myOffer,
                                        onOpenSubmitSheet = { showOfferSheet = true },
                                        onNavigateToChat = onNavigateToChat
                                    )
                                }
                            }

                            // Section: If Customer / Owner -> Offers List
                            if (isOwner) {
                                item {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "عروض الأسعار المستلمة (${offersList.size})",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )

                                        if (request.status == PublicRequestStatus.OPEN) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(AmberLight)
                                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                                            ) {
                                                Text(
                                                    text = "في انتظار عروض جديدة ⏳",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = AmberPrimary
                                                )
                                            }
                                        }
                                    }
                                }

                                if (offersList.isEmpty()) {
                                    item {
                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        ) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.HourglassEmpty,
                                                    contentDescription = null,
                                                    tint = BluePrimary,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                                Text(
                                                    text = "لم يتم تقديم أي عروض بعد",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "طلبك معروض الآن لحرفيي ولاية ${request.wilayaName}. ستظهر عروضهم هنا بمجرد إرسالها.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    items(offersList, key = { it.id }) { offer ->
                                        CustomerOfferViewItem(
                                            offer = offer,
                                            request = request,
                                            onAccept = { offerToAccept = offer },
                                            onOpenChat = onNavigateToChat
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Submit Offer Bottom Sheet (for Providers)
    if (showOfferSheet) {
        SubmitOfferBottomSheet(
            requestId = requestId,
            existingOffer = (offersState as? AuthResult.Success)?.data?.firstOrNull { it.providerId == currentUid },
            authViewModel = authViewModel,
            onDismiss = { showOfferSheet = false },
            onOfferSubmitted = {
                showOfferSheet = false
                scope.launch {
                    snackbarHostState.showSnackbar("تم إرسال عرضك بنجاح للزبون ✅")
                }
            }
        )
    }

    // Accept Offer Confirmation Dialog (for Customer)
    if (offerToAccept != null) {
        AlertDialog(
            onDismissRequest = { if (!isAcceptingOffer) offerToAccept = null },
            title = {
                Text(
                    text = "تأكيد اختيار الحرفي",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "هل أنت متأكد من قبول عرض الحرفي ${offerToAccept!!.providerName} بسعر ${offerToAccept!!.priceDzd} د.ج؟",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "سيتم فتح محادثة فورية مع الحرفي وإغلاق استقبال العروض الأخرى لهذا الطلب.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isAcceptingOffer = true
                        authViewModel.acceptPublicRequestOffer(
                            requestId = requestId,
                            offer = offerToAccept!!
                        ) { success, conversation, error ->
                            isAcceptingOffer = false
                            val accepted = offerToAccept
                            offerToAccept = null
                            if (success && conversation != null) {
                                onNavigateToChat(conversation.id)
                            } else if (!error.isNullOrBlank()) {
                                scope.launch { snackbarHostState.showSnackbar(error) }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    enabled = !isAcceptingOffer
                ) {
                    if (isAcceptingOffer) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    } else {
                        Text("نعم، قبول العرض")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { offerToAccept = null },
                    enabled = !isAcceptingOffer
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Cancel Request Dialog
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("إلغاء طلب الخدمة", fontWeight = FontWeight.Bold) },
            text = { Text("هل أنت متأكد من رغبتك في إلغاء هذا الطلب؟ لن يتمكن الحرفيون من تقديم عروض جديدة.") },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelDialog = false
                        authViewModel.cancelPublicServiceRequest(requestId) { success, error ->
                            if (success) {
                                scope.launch { snackbarHostState.showSnackbar("تم إلغاء الطلب بنجاح") }
                            } else if (!error.isNullOrBlank()) {
                                scope.launch { snackbarHostState.showSnackbar(error) }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("نعم، إلغاء الطلب")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("تراجع")
                }
            }
        )
    }

    // Complete Request Confirmation Dialog
    if (showCompleteDialog) {
        AlertDialog(
            onDismissRequest = { if (!isCompletingRequest) showCompleteDialog = false },
            title = {
                Text(text = "تأكيد إتمام الخدمة", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(text = "هل تم تنفيذ الخدمة وإنجاز العمل بنجاح؟\nعند التأكيد، سيتم تحويل حالة الطلب إلى مكتمل وإتاحة تقييم الخدمة.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        isCompletingRequest = true
                        authViewModel.completePublicServiceRequest(requestId) { success, error ->
                            isCompletingRequest = false
                            showCompleteDialog = false
                            if (success) {
                                scope.launch { snackbarHostState.showSnackbar("تم إتمام الخدمة بنجاح.") }
                            } else if (!error.isNullOrBlank()) {
                                scope.launch { snackbarHostState.showSnackbar(error) }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    enabled = !isCompletingRequest,
                    modifier = Modifier.testTag("confirm_complete_button")
                ) {
                    if (isCompletingRequest) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp))
                    } else {
                        Text("نعم، تأكيد إتمام الخدمة")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCompleteDialog = false },
                    enabled = !isCompletingRequest
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun RequestHeaderCard(
    request: PublicServiceRequest,
    isOwner: Boolean,
    onCancelClick: () -> Unit
) {
    val (statusBg, statusText, statusLabel) = when (request.status) {
        PublicRequestStatus.OPEN -> Triple(AmberLight, AmberPrimary, "مفتوح لاستقبال العروض 📢")
        PublicRequestStatus.ASSIGNED -> Triple(SuccessGreenContainer, SuccessGreen, "تم اختيار الحرفي 🤝")
        PublicRequestStatus.COMPLETED -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "مكتمل ✅")
        PublicRequestStatus.CANCELLED -> Triple(OutlineLight.copy(alpha = 0.1f), TextSecondaryLight, "ملغى 🚫")
    }

    val dateFormat = remember { SimpleDateFormat("dd MMMM yyyy - HH:mm", Locale("ar")) }
    val formattedDate = remember(request.createdAt) { dateFormat.format(Date(request.createdAt)) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = statusBg,
                    border = BorderStroke(1.dp, statusText.copy(alpha = 0.15f))
                ) {
                    Text(
                        text = statusLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = statusText,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                if (isOwner && request.status == PublicRequestStatus.OPEN) {
                    TextButton(
                        onClick = onCancelClick,
                        colors = ButtonDefaults.textButtonColors(contentColor = ErrorRed)
                    ) {
                        Text(
                            text = "إلغاء الطلب",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = request.title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(32.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = BlueContainer.copy(alpha = 0.3f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Work,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "${request.professionNameAr} • ${request.professionCategoryAr}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = BluePrimary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = TextTertiaryLight,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${request.communeName}، ${request.wilayaName}" + if (request.addressDetails.isNotBlank()) " • ${request.addressDetails}" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryLight
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = null,
                    tint = TextTertiaryLight,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "نشر في: $formattedDate",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryLight
                )
            }
        }
    }
}

@Composable
private fun RequestDescriptionCard(request: PublicServiceRequest) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "وصف المهمة المطلوبة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = com.example.ui.theme.BackgroundLight,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = request.description,
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight,
                    lineHeight = 22.sp
                )
            }

            if (request.budgetDzd != null && request.budgetDzd > 0) {
                Spacer(modifier = Modifier.height(20.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AmberLight,
                    border = BorderStroke(1.dp, AmberPrimary.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                tint = AmberPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "الميزانية المتوقعة:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                        }
                        Text(
                            text = "${request.budgetDzd} د.ج",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderOfferSection(
    request: PublicServiceRequest,
    myOffer: PublicRequestOffer?,
    onOpenSubmitSheet: () -> Unit,
    onNavigateToChat: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (myOffer != null) BlueContainer.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (myOffer != null) {
                // Provider already sent an offer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "عرض السعر الذي قدمته",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val (badgeBg, badgeText, badgeLabel) = when (myOffer.status) {
                        OfferStatus.PENDING -> Triple(AmberLight, AmberPrimary, "قيد المراجعة ⏳")
                        OfferStatus.ACCEPTED -> Triple(SuccessGreenContainer, SuccessGreen, "تم قبول عرضك! 🎉")
                        OfferStatus.REJECTED -> Triple(Color(0xFFFFEBEE), ErrorRed, "تم اختيار عرض آخر")
                        OfferStatus.CANCELLED -> Triple(Color(0xFFF5F5F5), Color(0xFF757575), "ملغى")
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(badgeBg)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = badgeText
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "السعر المقترح:", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = "${myOffer.priceDzd} د.ج",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }

                if (myOffer.estimatedTime.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "الوقت التقديري:", style = MaterialTheme.typography.bodySmall)
                        Text(text = myOffer.estimatedTime, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    }
                }

                if (myOffer.message.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ملاحظتك: ${myOffer.message}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (request.status == PublicRequestStatus.OPEN && myOffer.status == OfferStatus.PENDING) {
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedButton(
                        onClick = onOpenSubmitSheet,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تعديل عرض السعر")
                    }
                }
            } else {
                // Provider has NOT submitted offer
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "عرض السعر الخاص بك",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFF5F5F5))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "لم ترسل عرضًا بعد",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF757575)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                if (request.status == PublicRequestStatus.OPEN) {
                    Text(
                        text = "هل أنت مهتم بتقديم هذه الخدمة؟",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "قدّم عرض سعر منافس ومناسب للزبون لتتمكن من الفوز بالطلب والتواصل معه مباشرة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = onOpenSubmitSheet,
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("submit_provider_offer_button")
                    ) {
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تقديم عرض سعر للزبون", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(
                        text = "تم تعيين حرفي لهذا الطلب وإغلاقه",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun CustomerOfferViewItem(
    offer: PublicRequestOffer,
    request: PublicServiceRequest,
    onAccept: () -> Unit,
    onOpenChat: (String) -> Unit
) {
    val isAccepted = offer.status == OfferStatus.ACCEPTED || request.assignedOfferId == offer.id
    val isAssignedToOther = request.status == PublicRequestStatus.ASSIGNED && !isAccepted

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        color = if (isAccepted) SuccessGreenContainer.copy(alpha = 0.4f) else Color.White,
        border = BorderStroke(
            width = if (isAccepted) 1.5.dp else 1.dp,
            color = if (isAccepted) SuccessGreen.copy(alpha = 0.3f) else BluePrimary.copy(alpha = 0.05f)
        ),
        shadowElevation = if (isAccepted) 8.dp else 2.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Avatar
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(BlueContainer.copy(alpha = 0.5f))
                        .border(1.5.dp, BluePrimary.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (offer.providerAvatarUrl.isNotBlank()) {
                        AsyncImage(
                            model = offer.providerAvatarUrl,
                            contentDescription = offer.providerName,
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Text(
                            text = offer.providerName.take(1).ifBlank { "ح" },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = BluePrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = offer.providerName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlueDark
                    )
                    Text(
                        text = offer.providerProfession,
                        style = MaterialTheme.typography.labelSmall,
                        color = BluePrimary,
                        fontWeight = FontWeight.Bold
                    )
                    if (offer.providerRating > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = AmberPrimary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format(Locale.US, "%.1f", offer.providerRating),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = BlueDark
                            )
                            Text(
                                text = " (${offer.providerRatingCount} تقييم)",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryLight
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${offer.priceDzd} د.ج",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isAccepted) SuccessGreen else BluePrimary
                    )
                    if (offer.estimatedTime.isNotBlank()) {
                        Text(
                            text = offer.estimatedTime,
                            style = MaterialTheme.typography.labelSmall,
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (offer.message.isNotBlank()) {
                Spacer(modifier = Modifier.height(16.dp))
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = com.example.ui.theme.BackgroundLight.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "رسالة الحرفي: ${offer.message}",
                        modifier = Modifier.padding(14.dp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondaryLight,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isAccepted) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = SuccessGreen.copy(alpha = 0.1f)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تم اختيار هذا الحرفي",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = SuccessGreen
                        )
                    }
                }
            } else if (request.status == PublicRequestStatus.OPEN && !isAssignedToOther) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onOpenChat(offer.providerId)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.2.dp, BluePrimary)
                    ) {
                        Icon(Icons.Default.Forum, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("دردشة", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onAccept,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                    ) {
                        Text("قبول العرض", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubmitOfferBottomSheet(
    requestId: String,
    existingOffer: PublicRequestOffer?,
    authViewModel: AuthViewModel,
    onDismiss: () -> Unit,
    onOfferSubmitted: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var priceText by remember { mutableStateOf(existingOffer?.priceDzd?.toString() ?: "") }
    var estimatedTime by remember { mutableStateOf(existingOffer?.estimatedTime ?: "") }
    var message by remember { mutableStateOf(existingOffer?.message ?: "") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (existingOffer != null) "تعديل عرض السعر" else "تقديم عرض سعر للزبون",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "السعر المقترح بالدينار الجزائري (د.ج) *",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = priceText,
                onValueChange = { input ->
                    if (input.all { it.isDigit() }) {
                        priceText = input
                        errorMessage = null
                    }
                },
                placeholder = { Text("مثال: 2500") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("provider_offer_price_input"),
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Payments, contentDescription = null, tint = BluePrimary)
                },
                trailingIcon = {
                    Text(
                        text = "د.ج",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BluePrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "الوقت المتوقع للبدء أو الإنجاز (اختياري)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = estimatedTime,
                onValueChange = { estimatedTime = it },
                placeholder = { Text("مثال: اليوم بعد العصر، أو خلال 24 ساعة") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                leadingIcon = {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BluePrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "ملاحظات أو توضيحات إضافية (اختياري)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = message,
                onValueChange = { message = it },
                placeholder = { Text("مثال: السعر يشمل اليد العاملة بدون قطع الغيار...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                shape = RoundedCornerShape(12.dp),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BluePrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = ErrorRed,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val price = priceText.toLongOrNull() ?: 0L
                    if (price <= 0) {
                        errorMessage = "يرجى تحديد سعر مقترح صحيح بالدينار الجزائري"
                        return@Button
                    }
                    isSubmitting = true
                    authViewModel.submitPublicRequestOffer(
                        requestId = requestId,
                        priceDzd = price,
                        message = message,
                        estimatedTime = estimatedTime
                    ) { success, err ->
                        isSubmitting = false
                        if (success) {
                            onOfferSubmitted()
                        } else {
                            errorMessage = err ?: "حدث خطأ أثناء إرسال العرض"
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("submit_offer_sheet_button"),
                enabled = !isSubmitting
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                } else {
                    Text(
                        text = if (existingOffer != null) "حفظ التعديلات" else "إرسال العرض الآن 🚀",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
private fun AssignedServiceCard(
    request: PublicServiceRequest,
    isOwner: Boolean,
    isAssignedProvider: Boolean,
    onOpenChat: () -> Unit,
    onCompleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("assigned_service_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, SuccessGreen),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SuccessGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Handyman,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (isOwner) "الحرفي المكلّف بالعمل" else if (isAssignedProvider) "أنت الحرفي المكلّف بالعمل" else "الطلب قيد التنفيذ",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isOwner) (request.assignedProviderName ?: "حرفي خدمتي") else "الزبون: ${request.customerName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = BluePrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SuccessGreenContainer)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "قيد التنفيذ ⚙️",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons Row: Chat + Complete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onOpenChat,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("assigned_chat_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Forum, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isOwner) "مراسلة الحرفي" else "مراسلة الزبون",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onCompleteClick,
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("complete_service_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "إتمام الخدمة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PublicRequestReviewCard(
    review: Review?,
    isSubmitting: Boolean,
    onSubmitReview: (rating: Int, comment: String) -> Unit
) {
    var selectedRating by remember { mutableStateOf(5) }
    var commentText by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("public_request_review_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (review != null) BlueContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (review != null) BluePrimary.copy(alpha = 0.5f) else AmberPrimary.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (review != null) {
                // Review already submitted
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تقييمك للخدمة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(SuccessGreenContainer)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "تم التقييم بنجاح ✅",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    for (i in 1..5) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (i <= review.rating) AmberPrimary else MaterialTheme.colorScheme.outlineVariant,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${review.rating} من 5",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = AmberPrimary
                    )
                }

                if (review.comment.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = review.comment,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "تم تقييم الخدمة مسبقًا.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                // Form to submit review
                Text(
                    text = "قيّم الخدمة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "كيف كانت تجربتك مع الحرفي؟ تقييمك يساعد باقي الزبائن في اختيار الحرفي المناسب.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Star selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..5) {
                        IconButton(
                            onClick = { selectedRating = i },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "$i نجوم",
                                tint = if (i <= selectedRating) AmberPrimary else MaterialTheme.colorScheme.outlineVariant,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    label = { Text("رأيك وتعليقك (اختياري)") },
                    placeholder = { Text("أضف تعليقك حول جودة الخدمة والالتزام بالمواعيد...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("review_comment_input"),
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onSubmitReview(selectedRating, commentText) },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_review_button"),
                    enabled = !isSubmitting
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                    } else {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إرسال التقييم",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

