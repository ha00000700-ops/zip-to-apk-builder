package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.KhdemliRepository
import com.example.data.repository.SessionManager
import com.example.data.repository.SmartSearchEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: KhdemliRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    // Current Session State
    val currentUser: StateFlow<UserEntity?> = sessionManager.currentUser
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentProfessional: StateFlow<ProfessionalEntity?> = sessionManager.currentProfessional
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // App Preferences
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Filters State
    val selectedWilayaCode = MutableStateFlow(16) // Default Alger
    val selectedCommuneName = MutableStateFlow("الجزائر الوسطى")
    val selectedServiceId = MutableStateFlow(0L)
    val searchQuery = MutableStateFlow("")
    val onlyAvailable = MutableStateFlow(false)
    val sortByRating = MutableStateFlow(true)

    // Data Flows
    val services: StateFlow<List<ServiceCategoryEntity>> = repository.activeServices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val topCraftsmen: StateFlow<List<ProfessionalEntity>> = combine(
        repository.approvedProfessionals,
        selectedWilayaCode
    ) { list, wilaya ->
        val inWilaya = list.filter { it.wilayaCode == wilaya }
        val pool = if (inWilaya.isNotEmpty()) inWilaya else list
        SmartSearchEngine.rankProfessionals(pool, "", sortByRating = true).take(10)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filtered Craftsmen with Smart Search Engine
    @Suppress("UNCHECKED_CAST")
    val filteredCraftsmen: StateFlow<List<ProfessionalEntity>> = combine(
        repository.approvedProfessionals,
        searchQuery,
        selectedWilayaCode,
        selectedServiceId,
        onlyAvailable,
        sortByRating
    ) { args: Array<Any> ->
        val allPro = args[0] as List<ProfessionalEntity>
        val query = args[1] as String
        val wilaya = args[2] as Int
        val serviceId = args[3] as Long
        val availableOnly = args[4] as Boolean
        val sortRating = args[5] as Boolean

        val baseFiltered = allPro.filter { pro ->
            val matchWilaya = wilaya == 0 || pro.wilayaCode == wilaya
            val matchService = serviceId == 0L || pro.serviceCategoryId == serviceId
            val matchAvailable = !availableOnly || pro.isAvailable
            matchWilaya && matchService && matchAvailable
        }
        SmartSearchEngine.rankProfessionals(baseFiltered, query, sortRating)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Requests
    val userRequests: StateFlow<List<ServiceRequestEntity>> = combine(
        currentUser,
        currentProfessional,
        repository.allRequestsForAdmin
    ) { user, pro, allReqs ->
        when {
            user?.role == UserRole.ADMIN -> allReqs
            user?.role == UserRole.PROFESSIONAL || pro != null -> {
                val proId = pro?.id ?: user?.id ?: 0L
                allReqs.filter { it.professionalId == proId || (it.professionalId == null && it.wilayaCode == (pro?.wilayaCode ?: user?.wilayaCode)) }
            }
            user != null -> allReqs.filter { it.customerId == user.id }
            else -> allReqs.take(5)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notifications
    val notifications: StateFlow<List<NotificationEntity>> = currentUser.flatMapLatest { user ->
        val uid = user?.id ?: 0L
        repository.getNotificationsForUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userNotifications: StateFlow<List<NotificationEntity>> = notifications

    val unreadNotificationsCount: StateFlow<Int> = currentUser.flatMapLatest { user ->
        val uid = user?.id ?: 0L
        repository.getUnreadNotificationsCount(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Verification Flows
    val allVerificationRequests: StateFlow<List<VerificationRequestEntity>> = repository.allVerificationRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingVerificationRequests: StateFlow<List<VerificationRequestEntity>> = allVerificationRequests

    val currentProVerificationRequest: StateFlow<VerificationRequestEntity?> = currentProfessional.flatMapLatest { pro ->
        if (pro != null) repository.getVerificationRequestForPro(pro.id)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Admin Flows
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsersForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProfessionalsAdmin: StateFlow<List<ProfessionalEntity>> = repository.allProfessionalsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReportsAdmin: StateFlow<List<ReportEntity>> = repository.allReportsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviewsAdmin: StateFlow<List<ReviewEntity>> = repository.allReviewsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val flaggedReviewsAdmin: StateFlow<List<ReviewEntity>> = repository.flaggedReviewsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRequestsAdmin: StateFlow<List<ServiceRequestEntity>> = repository.allRequestsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }

    fun setLocation(wilayaCode: Int, wilayaName: String, communeName: String) {
        selectedWilayaCode.value = wilayaCode
        selectedCommuneName.value = communeName
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setServiceFilter(serviceId: Long) {
        selectedServiceId.value = serviceId
    }

    fun setWilayaFilter(wilayaCode: Int) {
        selectedWilayaCode.value = wilayaCode
    }

    fun toggleOnlyAvailable(enabled: Boolean) {
        onlyAvailable.value = enabled
    }

    fun toggleSortByRating(enabled: Boolean) {
        sortByRating.value = enabled
    }

    fun login(user: UserEntity) {
        viewModelScope.launch {
            sessionManager.loginAsUser(user)
            selectedWilayaCode.value = user.wilayaCode
            selectedCommuneName.value = user.communeNameAr
        }
    }

    fun logout() {
        sessionManager.logout()
    }

    fun registerCustomer(
        name: String,
        phone: String,
        email: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ) {
        viewModelScope.launch {
            val user = sessionManager.registerCustomer(
                fullName = name,
                phone = phone,
                email = email,
                wilayaCode = wilayaCode,
                wilayaNameAr = wilayaName,
                communeNameAr = communeName
            )
            login(user)
        }
    }

    fun registerProfessional(
        name: String,
        phone: String,
        whatsapp: String,
        serviceId: Long,
        serviceName: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        exp: Int,
        bio: String,
        workingHours: String,
        price: String
    ) {
        viewModelScope.launch {
            sessionManager.registerProfessional(
                fullName = name,
                phone = phone,
                whatsapp = whatsapp,
                serviceCategoryId = serviceId,
                professionNameAr = serviceName,
                wilayaCode = wilayaCode,
                wilayaNameAr = wilayaName,
                communeNameAr = communeName,
                experienceYears = exp,
                bio = bio,
                workingHours = workingHours,
                priceEstimate = price
            )
        }
    }

    fun toggleProAvailability(isAvailable: Boolean) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.updateProfessionalAvailability(pro.id, isAvailable)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value?.id)
        }
    }

    fun createServiceRequest(request: ServiceRequestEntity, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val reqId = repository.createServiceRequest(request)
            onDone(reqId)
        }
    }

    fun updateRequestStatus(requestId: Long, status: RequestStatus) {
        viewModelScope.launch {
            repository.updateRequestStatus(requestId, status)
        }
    }

    fun acceptRequestAsPro(request: ServiceRequestEntity) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.assignProfessionalToRequest(
                requestId = request.id,
                proId = pro.id,
                proName = pro.fullName,
                proPhone = pro.phone
            )
            repository.updateRequestStatus(request.id, RequestStatus.ACCEPTED)
        }
    }

    fun cancelRequest(requestId: Long, reason: String) {
        viewModelScope.launch {
            val userId = currentUser.value?.id ?: 0L
            repository.cancelRequest(requestId, reason, userId)
        }
    }

    fun getOffersForRequest(requestId: Long): StateFlow<List<RequestOfferEntity>> {
        return repository.getOffersForRequest(requestId).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun submitPriceOffer(requestId: Long, priceDzd: Double, note: String) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.submitPriceOffer(
                requestId = requestId,
                professionalId = pro.id,
                professionalName = pro.fullName,
                professionalPhone = pro.phone,
                priceDzd = priceDzd,
                note = note
            )
        }
    }

    fun acceptPriceOffer(offer: RequestOfferEntity) {
        viewModelScope.launch {
            repository.acceptPriceOffer(offer)
        }
    }

    fun rejectPriceOffer(offerId: Long) {
        viewModelScope.launch {
            repository.rejectPriceOffer(offerId)
        }
    }

    fun requestClarificationForOffer(offer: RequestOfferEntity) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.requestClarificationForOffer(
                offer = offer,
                customerId = user.id,
                customerName = user.fullName
            )
        }
    }


    // Craftsman Verification Submission
    fun submitCraftsmanVerification(
        idCardNumber: String,
        qualificationOrTradeRegister: String,
        documentNotes: String
    ) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            val user = currentUser.value ?: return@launch
            val request = VerificationRequestEntity(
                professionalId = pro.id,
                userId = user.id,
                professionalName = pro.fullName,
                professionNameAr = pro.professionNameAr,
                phone = pro.phone,
                wilayaCode = pro.wilayaCode,
                wilayaNameAr = pro.wilayaNameAr,
                communeNameAr = pro.communeNameAr,
                idCardNumber = idCardNumber,
                qualificationOrTradeRegister = qualificationOrTradeRegister,
                documentNotes = documentNotes,
                status = VerificationStatus.PENDING
            )
            repository.submitVerificationRequest(request)
            sessionManager.checkAndLoadProfessionalProfile(user.id)
        }
    }

    // Admin Verification Actions
    fun adminApproveVerification(requestId: Long, proId: Long) {
        viewModelScope.launch {
            repository.approveVerificationRequest(requestId, proId)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value?.id)
        }
    }

    fun adminRejectVerification(requestId: Long, proId: Long, reason: String) {
        viewModelScope.launch {
            repository.rejectVerificationRequest(requestId, proId, reason)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value?.id)
        }
    }

    fun adminRevokeVerification(proId: Long, reason: String) {
        viewModelScope.launch {
            repository.revokeVerification(proId, reason)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value?.id)
        }
    }

    fun submitReview(
        requestId: Long,
        professionalId: Long,
        rating: Int,
        comment: String,
        onResult: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val user = currentUser.value
            if (user == null) {
                onResult(false, "يجب تسجيل الدخول للتقييم")
                return@launch
            }
            val res = repository.submitReview(
                requestId = requestId,
                customerId = user.id,
                customerName = user.fullName,
                professionalId = professionalId,
                rating = rating,
                comment = comment
            )
            if (res.isSuccess) {
                onResult(true, "تم تسجيل التقييم بنجاح")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "فشل تسجيل التقييم")
            }
        }
    }

    fun flagReview(reviewId: Long, reason: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.flagReview(reviewId, reason, user.id, user.fullName)
        }
    }

    fun adminDeleteReview(reviewId: Long) {
        viewModelScope.launch {
            repository.deleteReviewByAdmin(reviewId)
        }
    }

    fun submitReport(report: ReportEntity) {
        viewModelScope.launch {
            repository.submitReport(report)
        }
    }

    fun adminUpdateReport(reportId: Long, status: ReportStatus, actionTaken: String = "") {
        viewModelScope.launch {
            repository.updateReportStatusAndAction(reportId, status, actionTaken)
        }
    }

    fun adminDeleteReport(reportId: Long) {
        viewModelScope.launch {
            repository.deleteReport(reportId)
        }
    }

    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            val uid = currentUser.value?.id ?: 0L
            repository.markAllNotificationsAsRead(uid)
        }
    }

    fun sendMessage(requestId: Long, content: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.sendMessage(
                requestId = requestId,
                senderId = user.id,
                senderName = user.fullName,
                recipientId = 0L,
                content = content
            )
        }
    }

    fun getMessagesForRequest(requestId: Long): Flow<List<MessageEntity>> {
        return repository.getMessagesForRequest(requestId)
    }

    fun getReviewsForPro(proId: Long): Flow<List<ReviewEntity>> {
        return repository.getReviewsForProfessional(proId)
    }

    // Admin User Management
    fun adminToggleBlockUser(user: UserEntity) {
        viewModelScope.launch {
            repository.setUserBlockedStatus(user.id, !user.isBlocked)
        }
    }

    fun adminDeleteUser(user: UserEntity) {
        viewModelScope.launch {
            repository.deleteUser(user.id)
        }
    }

    fun adminAddServiceCategory(nameAr: String, nameFr: String, iconName: String) {
        viewModelScope.launch {
            val cat = ServiceCategoryEntity(
                key = nameFr.lowercase().replace(" ", "_"),
                nameAr = nameAr,
                nameFr = nameFr,
                descriptionAr = nameAr,
                iconName = iconName
            )
            repository.saveServiceCategory(cat)
        }
    }
}

class MainViewModelFactory(
    private val repository: KhdemliRepository,
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository, sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
