package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.KhdemliRepository
import com.example.data.repository.SessionManager
import com.example.data.repository.SmartSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: KhdemliRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    // Current Session State
    val currentUser: StateFlow<UserEntity?> = sessionManager.currentUser
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val currentProfessional: StateFlow<ProfessionalEntity?> = sessionManager.currentProfessional
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    init {
        viewModelScope.launch {
            sessionManager.currentUser.collect { user ->
                val authUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: user?.firebaseUid
                if (!authUid.isNullOrBlank()) {
                    Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] AUTH_STATE_CHANGED UID=$authUid - Starting syncs...")
                    repository.startProfessionalsSync()
                    repository.startServiceRequestsSync()
                } else {
                    Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] AUTH_STATE_CHANGED NONE - Stopping syncs...")
                    repository.stopProfessionalsSync()
                    repository.stopServiceRequestsSync()
                }
            }
        }
    }

    // App Preferences
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // Filters State
    val selectedWilayaCode = MutableStateFlow(0) // Default 0 = All 58 wilayas!
    val selectedCommuneName = MutableStateFlow("الجزائر الوسطى")
    val selectedServiceId = MutableStateFlow(0L)
    val searchQuery = MutableStateFlow("")
    val onlyAvailable = MutableStateFlow(false)
    val sortByRating = MutableStateFlow(true)

    // Data Flows
    val services: StateFlow<List<ServiceCategoryEntity>> = repository.activeServices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val topCraftsmen: StateFlow<List<ProfessionalEntity>> = combine(
        repository.approvedProfessionals,
        selectedWilayaCode
    ) { list, wilaya ->
        val inWilaya = if (wilaya == 0) list else list.filter { it.wilayaCode == wilaya }
        val pool = if (inWilaya.isNotEmpty()) inWilaya else list
        SmartSearchEngine.rankProfessionals(pool, "", sortByRating = true).take(10)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filtered Craftsmen with Smart Search Engine
    val filteredCraftsmen: StateFlow<List<ProfessionalEntity>> = combine(
        repository.approvedProfessionals,
        searchQuery,
        selectedWilayaCode,
        selectedServiceId,
        onlyAvailable,
        sortByRating
    ) { flows: Array<Any?> ->
        @Suppress("UNCHECKED_CAST")
        val allPro = flows[0] as List<ProfessionalEntity>
        val query = flows[1] as String
        val wilaya = flows[2] as Int
        val serviceId = flows[3] as Long
        val availableOnly = flows[4] as Boolean
        val sortRating = flows[5] as Boolean

        val baseFiltered = allPro.filter { pro ->
            val matchWilaya = wilaya == 0 || pro.wilayaCode == wilaya
            val matchService = serviceId == 0L || pro.serviceCategoryId == serviceId
            val matchAvailable = !availableOnly || pro.isAvailable
            matchWilaya && matchService && matchAvailable
        }
        SmartSearchEngine.rankProfessionals(baseFiltered, query, sortRating)
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Requests
    val userRequests: StateFlow<List<ServiceRequestEntity>> = combine(
        currentUser,
        currentProfessional,
        repository.allRequestsForAdmin.distinctUntilChanged()
    ) { user, pro, allReqs ->
        val authUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
            ?: user?.firebaseUid?.ifBlank { null }
            ?: pro?.firebaseUid?.ifBlank { null }
            ?: ""

        when {
            user?.role == UserRole.ADMIN -> allReqs
            user?.role == UserRole.PROFESSIONAL || pro != null -> {
                val proUid = pro?.firebaseUid?.ifBlank { user?.firebaseUid } ?: authUid
                val proWilaya = pro?.wilayaCode ?: user?.wilayaCode ?: 0
                val proService = pro?.serviceCategoryId ?: 0L

                Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] CURRENT_PRO_UID=$proUid")
                Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] CURRENT_PRO_WILAYA=$proWilaya")
                Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] CURRENT_PRO_CATEGORY=$proService")

                allReqs.filter { req ->
                    val isMyOwnRequest = authUid.isNotBlank() && req.customerUid.isNotBlank() && req.customerUid == authUid
                    val isTargetedToMe = proUid.isNotBlank() && req.professionalUid.isNotBlank() && req.professionalUid == proUid
                    val isOpenBroadcast = req.professionalUid.isBlank()
                    val wilayaMatches = (proWilaya == 0 || req.wilayaCode == 0 || req.wilayaCode == proWilaya)
                    val categoryMatches = (proService == 0L || req.serviceCategoryId == 0L || req.serviceCategoryId == proService)
                    val statusAllows = req.status != RequestStatus.COMPLETED && req.status != RequestStatus.CANCELLED

                    val isMatch = isMyOwnRequest || isTargetedToMe || (isOpenBroadcast && wilayaMatches && categoryMatches && statusAllows)

                    if (isMatch) {
                        Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] REQUEST_MATCH=true (reqId=${req.id}, customerUid=${req.customerUid}, proUid=${req.professionalUid})")
                    } else {
                        val reason = when {
                            req.professionalUid.isNotBlank() && req.professionalUid != proUid -> "Targeted to another pro (${req.professionalUid} vs $proUid)"
                            isOpenBroadcast && !wilayaMatches -> "Wilaya mismatch (req:${req.wilayaCode} vs pro:$proWilaya)"
                            isOpenBroadcast && !categoryMatches -> "Category mismatch (req:${req.serviceCategoryId} vs pro:$proService)"
                            isOpenBroadcast && !statusAllows -> "Status not allowed (${req.status.name})"
                            else -> "Unknown mismatch"
                        }
                        Log.d("FIREBASE_SYNC", "[FIREBASE_SYNC] REQUEST_REJECT_REASON=$reason for reqId=${req.id}")
                    }

                    isMatch
                }
            }
            user != null -> {
                val cUid = user.firebaseUid.ifBlank { authUid }
                allReqs.filter { req ->
                    (cUid.isNotBlank() && req.customerUid == cUid)
                }
            }
            else -> emptyList()
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notifications
    val notifications: StateFlow<List<NotificationEntity>> = currentUser.flatMapLatest { user ->
        val uid = user?.id ?: 0L
        repository.getNotificationsForUser(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userNotifications: StateFlow<List<NotificationEntity>> = notifications

    val unreadNotificationsCount: StateFlow<Int> = currentUser.flatMapLatest { user ->
        val uid = user?.id ?: 0L
        repository.getUnreadNotificationsCount(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Verification Flows
    val allVerificationRequests: StateFlow<List<VerificationRequestEntity>> = repository.allVerificationRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingVerificationRequests: StateFlow<List<VerificationRequestEntity>> = allVerificationRequests

    val currentProVerificationRequest: StateFlow<VerificationRequestEntity?> = currentProfessional.flatMapLatest { pro ->
        if (pro != null) repository.getVerificationRequestForPro(pro.id)
        else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Admin Flows
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsersForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProfessionalsAdmin: StateFlow<List<ProfessionalEntity>> = repository.allProfessionalsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReportsAdmin: StateFlow<List<ReportEntity>> = repository.allReportsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviewsAdmin: StateFlow<List<ReviewEntity>> = repository.allReviewsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val flaggedReviewsAdmin: StateFlow<List<ReviewEntity>> = repository.flaggedReviewsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRequestsAdmin: StateFlow<List<ServiceRequestEntity>> = repository.allRequestsForAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun registerFcmToken() {
        viewModelScope.launch {
            sessionManager.registerCurrentFcmToken()
        }
    }

    fun toggleDarkMode(enabled: Boolean) {
        _isDarkMode.value = enabled
    }

    fun setLocation(wilayaCode: Int, wilayaName: String, communeName: String) {
        selectedWilayaCode.value = wilayaCode
        selectedCommuneName.value = communeName
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setServiceFilter(serviceId: Long) {
        selectedServiceId.value = serviceId
    }

    fun setWilayaFilter(wilayaCode: Int) {
        selectedWilayaCode.value = wilayaCode
    }

    fun toggleOnlyAvailable(enabled: Boolean) {
        onlyAvailable.value = enabled
    }

    fun toggleSortByRating(enabled: Boolean) {
        sortByRating.value = enabled
    }

    fun login(user: UserEntity) {
        viewModelScope.launch {
            sessionManager.loginAsUser(user)
            selectedWilayaCode.value = user.wilayaCode
            selectedCommuneName.value = user.communeNameAr
        }
    }

    fun loginWithEmailPassword(email: String, password: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = sessionManager.loginWithEmailPassword(email, password)
            if (success) {
                currentUser.value?.let { user ->
                    selectedWilayaCode.value = user.wilayaCode
                    selectedCommuneName.value = user.communeNameAr
                }
            }
            onResult(success)
        }
    }

    fun logout() {
        sessionManager.logout()
    }

    fun registerCustomer(
        name: String,
        phone: String,
        email: String,
        password: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        onResult: ((Result<Unit>) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val result = sessionManager.registerCustomer(
                fullName = name,
                phone = phone,
                email = email,
                password = password,
                wilayaCode = wilayaCode,
                wilayaNameAr = wilayaName,
                communeNameAr = communeName
            )
            result.onSuccess { user ->
                selectedWilayaCode.value = user.wilayaCode
                selectedCommuneName.value = user.communeNameAr
                onResult?.invoke(Result.success(Unit))
            }.onFailure { error ->
                onResult?.invoke(Result.failure(error))
            }
        }
    }

    fun registerProfessional(
        name: String,
        phone: String,
        email: String,
        password: String,
        whatsapp: String,
        serviceId: Long,
        serviceName: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        exp: Int,
        bio: String,
        workingHours: String,
        price: String,
        onResult: ((Result<Unit>) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val result = sessionManager.registerProfessional(
                fullName = name,
                phone = phone,
                email = email,
                password = password,
                whatsapp = whatsapp,
                serviceCategoryId = serviceId,
                professionNameAr = serviceName,
                wilayaCode = wilayaCode,
                wilayaNameAr = wilayaName,
                communeNameAr = communeName,
                experienceYears = exp,
                bio = bio,
                workingHours = workingHours,
                priceEstimate = price
            )
            result.onSuccess { pro ->
                selectedWilayaCode.value = pro.wilayaCode
                selectedCommuneName.value = pro.communeNameAr
                onResult?.invoke(Result.success(Unit))
            }.onFailure { error ->
                onResult?.invoke(Result.failure(error))
            }
        }
    }

    fun toggleProAvailability(isAvailable: Boolean) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.updateProfessionalAvailability(pro.id, isAvailable)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value)
        }
    }

    fun createServiceRequest(request: ServiceRequestEntity, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            val reqId = repository.createServiceRequest(request)
            onDone(reqId)
        }
    }

    fun updateRequestStatus(requestId: Long, status: RequestStatus) {
        viewModelScope.launch {
            repository.updateRequestStatus(requestId, status)
        }
    }

    fun acceptRequestAsPro(request: ServiceRequestEntity) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.assignProfessionalToRequest(
                requestId = request.id,
                proId = pro.id,
                proUid = pro.firebaseUid,
                proName = pro.fullName,
                proPhone = pro.phone
            )
            repository.updateRequestStatus(request.id, RequestStatus.ACCEPTED)
        }
    }

    fun cancelRequest(requestId: Long, reason: String) {
        viewModelScope.launch {
            val userId = currentUser.value?.id ?: 0L
            repository.cancelRequest(requestId, reason, userId)
        }
    }

    fun getOffersForRequest(requestId: Long): StateFlow<List<RequestOfferEntity>> {
        return repository.getOffersForRequest(requestId).stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun submitPriceOffer(requestId: Long, priceDzd: Double, note: String) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            repository.submitPriceOffer(
                requestId = requestId,
                professionalId = pro.id,
                professionalName = pro.fullName,
                professionalPhone = pro.phone,
                priceDzd = priceDzd,
                note = note
            )
        }
    }

    fun acceptPriceOffer(offer: RequestOfferEntity) {
        viewModelScope.launch {
            repository.acceptPriceOffer(offer)
        }
    }

    fun rejectPriceOffer(offerId: Long) {
        viewModelScope.launch {
            repository.rejectPriceOffer(offerId)
        }
    }

    fun requestClarificationForOffer(offer: RequestOfferEntity) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.requestClarificationForOffer(
                offer = offer,
                customerId = user.id,
                customerName = user.fullName
            )
        }
    }


    // Craftsman Verification Submission
    fun submitCraftsmanVerification(
        idCardNumber: String,
        qualificationOrTradeRegister: String,
        documentNotes: String
    ) {
        viewModelScope.launch {
            val pro = currentProfessional.value ?: return@launch
            val user = currentUser.value ?: return@launch
            val request = VerificationRequestEntity(
                professionalId = pro.id,
                userId = user.id,
                professionalName = pro.fullName,
                professionNameAr = pro.professionNameAr,
                phone = pro.phone,
                wilayaCode = pro.wilayaCode,
                wilayaNameAr = pro.wilayaNameAr,
                communeNameAr = pro.communeNameAr,
                idCardNumber = idCardNumber,
                qualificationOrTradeRegister = qualificationOrTradeRegister,
                documentNotes = documentNotes,
                status = VerificationStatus.PENDING
            )
            repository.submitVerificationRequest(request)
            sessionManager.checkAndLoadProfessionalProfile(user)
        }
    }

    // Admin Verification Actions
    fun adminApproveVerification(requestId: Long, proId: Long) {
        viewModelScope.launch {
            repository.approveVerificationRequest(requestId, proId)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value)
        }
    }

    fun adminRejectVerification(requestId: Long, proId: Long, reason: String) {
        viewModelScope.launch {
            repository.rejectVerificationRequest(requestId, proId, reason)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value)
        }
    }

    fun adminRevokeVerification(proId: Long, reason: String) {
        viewModelScope.launch {
            repository.revokeVerification(proId, reason)
            sessionManager.checkAndLoadProfessionalProfile(currentUser.value)
        }
    }

    fun submitReview(
        requestId: Long,
        professionalId: Long,
        rating: Int,
        comment: String,
        onResult: (Boolean, String) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val user = currentUser.value
            if (user == null) {
                onResult(false, "يجب تسجيل الدخول للتقييم")
                return@launch
            }
            val res = repository.submitReview(
                requestId = requestId,
                customerId = user.id,
                customerName = user.fullName,
                professionalId = professionalId,
                rating = rating,
                comment = comment
            )
            if (res.isSuccess) {
                onResult(true, "تم تسجيل التقييم بنجاح")
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "فشل تسجيل التقييم")
            }
        }
    }

    fun flagReview(reviewId: Long, reason: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.flagReview(reviewId, reason, user.id, user.fullName)
        }
    }

    fun adminDeleteReview(reviewId: Long) {
        viewModelScope.launch {
            repository.deleteReviewByAdmin(reviewId)
        }
    }

    fun submitReport(report: ReportEntity) {
        viewModelScope.launch {
            repository.submitReport(report)
        }
    }

    fun adminUpdateReport(reportId: Long, status: ReportStatus, actionTaken: String = "") {
        viewModelScope.launch {
            repository.updateReportStatusAndAction(reportId, status, actionTaken)
        }
    }

    fun adminDeleteReport(reportId: Long) {
        viewModelScope.launch {
            repository.deleteReport(reportId)
        }
    }

    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            val uid = currentUser.value?.id ?: 0L
            repository.markAllNotificationsAsRead(uid)
        }
    }

    fun sendMessage(requestId: Long, content: String) {
        viewModelScope.launch {
            val user = currentUser.value ?: return@launch
            repository.sendMessage(
                requestId = requestId,
                senderId = user.id,
                senderName = user.fullName,
                recipientId = 0L,
                content = content
            )
        }
    }

    fun getMessagesForRequest(requestId: Long): Flow<List<MessageEntity>> {
        return repository.getMessagesForRequest(requestId)
    }

    fun getReviewsForPro(proId: Long): Flow<List<ReviewEntity>> {
        return repository.getReviewsForProfessional(proId)
    }

    // Admin User Management
    fun adminToggleBlockUser(user: UserEntity) {
        viewModelScope.launch {
            repository.setUserBlockedStatus(user.id, !user.isBlocked)
        }
    }

    fun adminDeleteUser(user: UserEntity) {
        viewModelScope.launch {
            repository.deleteUser(user.id)
        }
    }

    fun adminAddServiceCategory(nameAr: String, nameFr: String, iconName: String) {
        viewModelScope.launch {
            val cat = ServiceCategoryEntity(
                key = nameFr.lowercase().replace(" ", "_"),
                nameAr = nameAr,
                nameFr = nameFr,
                descriptionAr = nameAr,
                iconName = iconName
            )
            repository.saveServiceCategory(cat)
        }
    }
}

class MainViewModelFactory(
    private val repository: KhdemliRepository,
    private val sessionManager: SessionManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository, sessionManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
