package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.data.AyahSearchResult
import com.example.data.Surah
import com.example.data.db.LastRead
import com.example.ui.theme.AppBackground
import com.example.ui.theme.AppPrimary
import com.example.ui.theme.AppSurface
import com.example.ui.theme.CardBorder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(modifier: Modifier = Modifier, navController: NavController) {
    val viewModel: QuranViewModel = viewModel()
    val surahs by viewModel.surahs.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val lastRead by viewModel.lastRead.collectAsState()
    
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("القرآن الكريم", color = Color.White, fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { navController.navigate("bookmarks") }) {
                        Icon(Icons.Outlined.BookmarkBorder, contentDescription = "العلامات المرجعية", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppBackground)
            )
        },
        containerColor = AppBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { 
                searchQuery = it
                if (it.isNotBlank()) {
                    isSearchActive = true
                    viewModel.search(it)
                } else {
                    isSearchActive = false
                    viewModel.clearSearch()
                }
            },
            placeholder = { Text("ابحث عن سورة أو آية...", color = Color.White.copy(alpha = 0.5f)) },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = "بحث", tint = AppPrimary) },
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AppPrimary,
                unfocusedBorderColor = CardBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                cursorColor = AppPrimary
            ),
            singleLine = true
        )

        if (isSearchActive) {
            if (isSearching) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AppPrimary)
                }
            } else if (searchResults.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد نتائج", color = Color.White.copy(alpha = 0.7f))
                }
            } else {
                LazyColumn {
                    items(searchResults) { result ->
                        SearchResultItem(result) {
                            navController.navigate("surah/${result.surah.number}")
                        }
                    }
                }
            }
        } else {
            // Last Read Card
            if (lastRead != null) {
                LastReadCard(lastRead!!) {
                    navController.navigate("surah/${lastRead!!.surahNumber}")
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            // Surahs List
            LazyColumn(
                contentPadding = PaddingValues(bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(surahs) { surah ->
                    SurahItem(surah) {
                        navController.navigate("surah/${surah.number}")
                    }
                }
            }
        }
    }
}
    }

@Composable
fun SearchResultItem(result: AyahSearchResult, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(result.surah.name, color = AppPrimary, fontWeight = FontWeight.Bold)
                Text("الآية ${result.ayah.numberInSurah}", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = result.ayah.text,
                color = Color.White,
                fontSize = 16.sp,
                textAlign = TextAlign.Right,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun LastReadCard(lastRead: LastRead, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = AppPrimary.copy(alpha = 0.1f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimary.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = AppPrimary, modifier = Modifier.size(32.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("متابعة القراءة", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                Text("سورة ${lastRead.surahName}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("الآية ${lastRead.ayahNumber}", color = Color.White.copy(alpha = 0.6f), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun SurahItem(surah: Surah, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(AppSurface)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(AppBackground, RoundedCornerShape(8.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(surah.number.toString(), color = AppPrimary, fontSize = 14.sp)
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column {
                Text(surah.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val typeArabic = if (surah.revelationType.lowercase() == "meccan") "مكية" else "مدنية"
                Text("${surah.numberOfAyahs} آيات • $typeArabic", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        }
    }
}
