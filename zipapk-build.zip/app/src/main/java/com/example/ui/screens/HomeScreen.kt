package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LoveQuotesRepository
import com.example.data.model.WeatherConditionType
import com.example.ui.components.AutomatedWeatherLovePopup
import com.example.ui.components.CoupleHeader
import com.example.ui.components.DailyWhisperCard
import com.example.ui.components.DynamicWeatherBackground
import com.example.ui.components.HourlyForecastSection
import com.example.ui.components.SideBySideWeatherCards
import com.example.ui.viewmodel.CoupleWeatherUiState
import com.example.ui.viewmodel.CoupleWeatherViewModel
import java.util.Calendar

@Composable
fun HomeScreen(
    uiState: CoupleWeatherUiState,
    viewModel: CoupleWeatherViewModel,
    onOpenEditUser: () -> Unit,
    onOpenEditPartner: () -> Unit,
    onOpenSelectUserCity: () -> Unit,
    onOpenSelectPartnerCity: () -> Unit,
    onNavigateToAnniversaries: () -> Unit,
    modifier: Modifier = Modifier
) {
    // AUTOMATIC: Live natural weather condition determined directly from telemetry
    val automaticCondition = uiState.partnerWeather?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: uiState.userWeather?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: WeatherConditionType.CLEAR_DAY

    // Weather-reactive automatic quote
    val weatherReactiveQuote = remember(automaticCondition) {
        LoveQuotesRepository.getWeatherReactiveQuote(automaticCondition)
    }

    var showWeatherPopup by remember { mutableStateOf(true) }

    // Dynamic greeting based on current hour
    val greetingText = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when (hour) {
            in 5..11 -> "صباح الورد والياسمين ☀️"
            in 12..17 -> "نهارك مبروك ودافي 🌤️"
            in 18..22 -> "مساء الشوق والغرام 🌆"
            else -> "ليلة هادئة وسعيدة 🌙"
        }
    }

    DynamicWeatherBackground(
        condition = automaticCondition,
        particlesEnabled = uiState.particlesEnabled,
        modifier = modifier
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_screen_content"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 95.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Modern Top Bar: Greeting & Live Weather Status
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "طقس القلوب 💖",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "$greetingText يا ${uiState.userName}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        IconButton(
                            onClick = {
                                viewModel.loadWeatherData()
                                showWeatherPopup = true
                            },
                            modifier = Modifier.testTag("refresh_weather_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث الطقس",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // AUTOMATIC WEATHER-REACTIVE POPUP BANNER
            item {
                AutomatedWeatherLovePopup(
                    quote = weatherReactiveQuote,
                    condition = automaticCondition,
                    partnerName = uiState.partnerName,
                    isVisible = showWeatherPopup,
                    onDismiss = { showWeatherPopup = false }
                )
            }

            // Modern Couple Header with Virtual Heartbeat Touch & Distance
            item {
                CoupleHeader(
                    userName = uiState.userName,
                    partnerName = uiState.partnerName,
                    userCity = uiState.userWeather?.city,
                    partnerCity = uiState.partnerWeather?.city,
                    userTemp = uiState.userWeather?.current?.temperature,
                    partnerTemp = uiState.partnerWeather?.current?.temperature,
                    userAvatarUri = uiState.userAvatarUri,
                    partnerAvatarUri = uiState.partnerAvatarUri,
                    onEditUser = onOpenEditUser,
                    onEditPartner = onOpenEditPartner
                )
            }

            // Nearest Anniversary Reminder Card
            item {
                val nearest = uiState.anniversaries.minByOrNull { it.daysUntilNext() }
                if (nearest != null) {
                    val daysUntil = nearest.daysUntilNext()
                    val reminderText = if (daysUntil == 0) {
                        "🎉 اليوم مناسبتنا السعيدة: ${nearest.title}!"
                    } else {
                        "⏳ باقي $daysUntil يوم على: ${nearest.title} (${nearest.eventType.iconEmoji})"
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onNavigateToAnniversaries)
                            .testTag("nearest_anniversary_banner"),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = uiState.cardStyle.surfaceAlpha),
                        tonalElevation = 4.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = reminderText,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )
                            }
                            Text(
                                text = "عرض 👈",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Dual Glassmorphic Weather Cards with Couple Outfit Advice
            item {
                SideBySideWeatherCards(
                    userWeather = uiState.userWeather,
                    partnerWeather = uiState.partnerWeather,
                    userName = uiState.userName,
                    partnerName = uiState.partnerName,
                    cardStyle = uiState.cardStyle,
                    onSelectUserCity = onOpenSelectUserCity,
                    onSelectPartnerCity = onOpenSelectPartnerCity
                )
            }

            // Daily Whisper Card with Algerian & Romantic quotes
            item {
                DailyWhisperCard(
                    quote = uiState.dailyWhisper,
                    onShuffle = { viewModel.shuffleWhisper() },
                    onSelectCategory = { viewModel.setCategory(it) },
                    activeCategory = uiState.activeLoveCategory
                )
            }

            // Hourly Forecast Timeline
            item {
                HourlyForecastSection(
                    userWeather = uiState.userWeather,
                    partnerWeather = uiState.partnerWeather,
                    userName = uiState.userName,
                    partnerName = uiState.partnerName
                )
            }
        }
    }
}
