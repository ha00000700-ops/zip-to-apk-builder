package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WeatherConditionType
import com.example.ui.components.CoupleHeader
import com.example.ui.components.DailyWhisperCard
import com.example.ui.components.DynamicWeatherBackground
import com.example.ui.components.HourlyForecastSection
import com.example.ui.components.SideBySideWeatherCards
import com.example.ui.theme.RosePrimary
import com.example.ui.viewmodel.CoupleWeatherUiState
import com.example.ui.viewmodel.CoupleWeatherViewModel

@Composable
fun HomeScreen(
    uiState: CoupleWeatherUiState,
    viewModel: CoupleWeatherViewModel,
    onOpenEditUser: () -> Unit,
    onOpenEditPartner: () -> Unit,
    onOpenSelectUserCity: () -> Unit,
    onOpenSelectPartnerCity: () -> Unit,
    onNavigateToAnniversaries: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Dominant weather condition for background atmosphere
    val primaryCondition = uiState.partnerWeather?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: uiState.userWeather?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: WeatherConditionType.CLEAR_DAY

    DynamicWeatherBackground(
        condition = primaryCondition,
        modifier = modifier
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_screen_content"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App Bar Title & Refresh
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = null,
                            tint = RosePrimary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "طقس القلوب 💖",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "أحوال جوّنا وسماء حبّنا المشتركة",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (uiState.isLoading) {
                        CircularProgressIndicator(
                            color = RosePrimary,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        IconButton(
                            onClick = { viewModel.loadWeatherData() },
                            modifier = Modifier.testTag("refresh_weather_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث الطقس",
                                tint = RosePrimary
                            )
                        }
                    }
                }
            }

            // Couple Header (Profiles + Heart Beat + Weather note)
            item {
                CoupleHeader(
                    userName = uiState.userName,
                    partnerName = uiState.partnerName,
                    userCityName = uiState.userWeather?.city?.name ?: "الجزائر",
                    partnerCityName = uiState.partnerWeather?.city?.name ?: "وهران",
                    userTemp = uiState.userWeather?.current?.temperature,
                    partnerTemp = uiState.partnerWeather?.current?.temperature,
                    userAvatarUri = uiState.userAvatarUri,
                    partnerAvatarUri = uiState.partnerAvatarUri,
                    onEditUser = onOpenEditUser,
                    onEditPartner = onOpenEditPartner
                )
            }

            // Nearest Anniversary Reminder Banner
            item {
                val nearest = uiState.anniversaries.minByOrNull { it.daysUntilNext() }
                if (nearest != null) {
                    val daysUntil = nearest.daysUntilNext()
                    val reminderText = if (daysUntil == 0) {
                        "🎉 اليوم هو: ${nearest.title}! نهارك سكر وحب!"
                    } else {
                        "⏳ باقي $daysUntil يوماً على: ${nearest.title} (${nearest.eventType.iconEmoji})"
                    }

                    ElevatedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onNavigateToAnniversaries)
                            .testTag("nearest_anniversary_banner"),
                        shape = RoundedCornerShape(16.dp),
                        colors = androidx.compose.material3.CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = RosePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = reminderText,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1
                                )
                            }
                            Text(
                                text = "عرض 👈",
                                fontSize = 12.sp,
                                color = RosePrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Side by Side Weather Cards
            item {
                SideBySideWeatherCards(
                    userWeather = uiState.userWeather,
                    partnerWeather = uiState.partnerWeather,
                    userName = uiState.userName,
                    partnerName = uiState.partnerName,
                    onSelectUserCity = onOpenSelectUserCity,
                    onSelectPartnerCity = onOpenSelectPartnerCity
                )
            }

            // Daily Whisper Card (عبارات لطيفة وفكاهية جزائرية)
            item {
                DailyWhisperCard(
                    quote = uiState.dailyWhisper,
                    onShuffle = { viewModel.shuffleWhisper() },
                    onSelectCategory = { viewModel.setCategory(it) },
                    activeCategory = uiState.activeLoveCategory
                )
            }

            // Hourly Forecast
            item {
                HourlyForecastSection(
                    userWeather = uiState.userWeather,
                    partnerWeather = uiState.partnerWeather,
                    userName = uiState.userName,
                    partnerName = uiState.partnerName
                )
            }
        }
    }
}
