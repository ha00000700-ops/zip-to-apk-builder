package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.location.Geocoder
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Prayer
import com.example.ui.theme.AppBackground
import com.example.ui.theme.AppPrimary
import com.example.ui.theme.AppSurface
import com.example.ui.theme.CardBorder
import com.example.ui.theme.HighlightBackground
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel()
) {
    val state by viewModel.homeState.collectAsState()

    if (!state.useManualLocation) {
        LocationProvider(
            onLocationReceived = { lat, lng, geocoder ->
                viewModel.updateLocation(lat, lng, geocoder)
            },
            onPermissionDenied = {
                // Default to Makkah if denied
                viewModel.updateLocation(21.4225, 39.8262, null)
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AppBackground)
    ) {
        // Optional background glow
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(
                    Brush.radialGradient(
                        colors = listOf(AppPrimary.copy(alpha = 0.15f), Color.Transparent),
                        center = Offset(x = Float.POSITIVE_INFINITY / 2, y = 200f),
                        radius = 600f
                    )
                )
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                NextPrayerHeader(state)
            }
            item {
                InfoPillsRow(state)
                Spacer(modifier = Modifier.height(16.dp))
            }
            item {
                DailyPrayersList(state)
                Spacer(modifier = Modifier.height(16.dp))
            }
            item {
                FridayPrayerCard()
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun NextPrayerHeader(state: HomeState) {
    val prayerName = getArabicPrayerName(state.nextPrayer)
    val timeString = state.nextPrayerTime?.let { formatTime(it, state.timeZoneId) } ?: "--:--"
    val countdownArabic = convertToArabicIndic(state.countdownText)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth().padding(top = 48.dp, bottom = 32.dp)
    ) {
        Text(
            text = "تبقى للصلاة القادمة",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 16.sp
        )
        Text(
            text = countdownArabic,
            color = AppPrimary,
            fontSize = 64.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        Text(
            text = "$prayerName — $timeString",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 18.sp
        )
    }
}

@Composable
fun InfoPillsRow(state: HomeState) {
    val calcMethodName = when(state.calcMethod) {
        CalculationMethod.MUSLIM_WORLD_LEAGUE -> "رابطة العالم الإسلامي"
        CalculationMethod.EGYPTIAN -> "هيئة المساحة المصرية"
        CalculationMethod.UMM_AL_QURA -> "أم القرى"
        CalculationMethod.NORTH_AMERICA -> "ISNA"
        else -> "رابطة العالم الإسلامي" // Fallback
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        InfoPill(
            text = "14 ربيع الأول 1448",
            icon = Icons.Outlined.DateRange,
            modifier = Modifier.weight(1f)
        )
        InfoPill(
            text = calcMethodName,
            icon = Icons.Outlined.Public,
            modifier = Modifier.weight(1.2f)
        )
        InfoPill(
            text = state.cityName,
            icon = Icons.Outlined.LocationOn,
            modifier = Modifier.weight(0.8f)
        )
    }
}

@Composable
fun InfoPill(text: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .border(1.dp, CardBorder, RoundedCornerShape(12.dp))
            .background(AppSurface, RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AppPrimary,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DailyPrayersList(state: HomeState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = BorderStroke(1.dp, CardBorder),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            val pt = state.prayerTimes
            val tz = state.timeZoneId
            
            PrayerItemRow("الفجر", pt?.fajr, Icons.Outlined.WbTwilight, state.nextPrayer == Prayer.FAJR || (state.currentPrayer == Prayer.NONE && state.nextPrayer == Prayer.FAJR), tz)
            HorizontalDivider(color = CardBorder, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
            
            PrayerItemRow("الشروق", pt?.sunrise, Icons.Outlined.WbSunny, state.nextPrayer == Prayer.SUNRISE, tz)
            HorizontalDivider(color = CardBorder, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
            
            PrayerItemRow("الظهر", pt?.dhuhr, Icons.Outlined.LightMode, state.nextPrayer == Prayer.DHUHR, tz)
            HorizontalDivider(color = CardBorder, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
            
            PrayerItemRow("العصر", pt?.asr, Icons.Outlined.LightMode, state.nextPrayer == Prayer.ASR, tz)
            HorizontalDivider(color = CardBorder, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
            
            // Using ModeNight for Maghrib as an alternative to Mosque dome
            PrayerItemRow("المغرب", pt?.maghrib, Icons.Outlined.ModeNight, state.nextPrayer == Prayer.MAGHRIB, tz)
            HorizontalDivider(color = CardBorder, thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))
            
            PrayerItemRow("العشاء", pt?.isha, Icons.Outlined.Nightlight, state.nextPrayer == Prayer.ISHA, tz)
        }
    }
}

@Composable
fun PrayerItemRow(name: String, time: Date?, icon: ImageVector, isHighlighted: Boolean, timeZoneId: String) {
    val timeString = time?.let { formatTime(it, timeZoneId) } ?: "--:--"
    val textColor = if (isHighlighted) AppPrimary else Color.White
    val bgColor = if (isHighlighted) HighlightBackground else Color.Transparent
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
    ) {
        if (isHighlighted) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .width(4.dp)
                    .fillMaxHeight()
                    .background(AppPrimary)
            )
        }
        
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = name,
                color = textColor,
                fontSize = 18.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Start
            )
            
            Text(
                text = timeString,
                color = textColor,
                fontSize = 18.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center
            )
            
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                 Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textColor,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun FridayPrayerCard() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CardBorder, RoundedCornerShape(16.dp))
            .background(AppSurface, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "صلاة الجمعة غدًا — الخطبة 12:30",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
            imageVector = Icons.Outlined.DateRange,
            contentDescription = null,
            tint = AppPrimary,
            modifier = Modifier.size(18.dp)
        )
    }
}

private fun formatTime(date: Date, timeZoneId: String): String {
    val formatter = SimpleDateFormat("h:mm a", Locale("ar"))
    formatter.timeZone = java.util.TimeZone.getTimeZone(timeZoneId)
    return formatter.format(date).replace("ص", "ص").replace("م", "م")
}

private fun getArabicPrayerName(prayer: Prayer): String {
    return when (prayer) {
        Prayer.FAJR -> "الفجر"
        Prayer.SUNRISE -> "الشروق"
        Prayer.DHUHR -> "الظهر"
        Prayer.ASR -> "العصر"
        Prayer.MAGHRIB -> "المغرب"
        Prayer.ISHA -> "العشاء"
        Prayer.NONE -> ""
    }
}

private fun convertToArabicIndic(timeString: String): String {
    val arabicDigits = arrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
    val builder = StringBuilder()
    for (char in timeString) {
        if (char.isDigit()) {
            builder.append(arabicDigits[char - '0'])
        } else {
            builder.append(char)
        }
    }
    return builder.toString()
}
