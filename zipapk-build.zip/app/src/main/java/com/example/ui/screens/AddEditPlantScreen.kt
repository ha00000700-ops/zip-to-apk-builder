package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlantDoctorViewModel
import com.example.ui.components.AppTopBar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditPlantScreen(viewModel: PlantDoctorViewModel) {
    val selectedPlant by viewModel.selectedPlant.collectAsState()

    var name by remember(selectedPlant) { mutableStateOf(selectedPlant?.name ?: "") }
    var scientificName by remember(selectedPlant) { mutableStateOf(selectedPlant?.scientificName ?: "") }
    var selectedCategory by remember(selectedPlant) { mutableStateOf(selectedPlant?.plantType ?: "خضروات") }
    var selectedLocation by remember(selectedPlant) { mutableStateOf(selectedPlant?.location ?: "حديقة") }
    var wateringDays by remember(selectedPlant) { mutableFloatStateOf((selectedPlant?.wateringIntervalDays ?: 3).toFloat()) }
    var fertilizingDays by remember(selectedPlant) { mutableFloatStateOf((selectedPlant?.fertilizingIntervalDays ?: 14).toFloat()) }
    var notes by remember(selectedPlant) { mutableStateOf(selectedPlant?.notes ?: "") }

    val categories = listOf("خضروات", "أشجار مثمرة", "نباتات زينة", "نباتات عطرية", "نخيل")
    val locations = listOf("حديقة", "حقل", "داخل المنزل", "شرفة", "دفيئة", "أصيص")

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (selectedPlant == null) "إضافة نبتة جديدة 🌱" else "تعديل بيانات النبتة",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("اسم النبتة *") },
                        placeholder = { Text("مثال: طماطم الشرفة، شجرة الليمون...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("plant_name_input"),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = scientificName,
                        onValueChange = { scientificName = it },
                        label = { Text("الاسم العلمي (اختياري)") },
                        placeholder = { Text("مثال: Solanum lycopersicum") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Text("تصنيف النبتة:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.take(3).forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.drop(3).forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer)
                            )
                        }
                    }

                    Text("الموقع:", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        locations.take(3).forEach { loc ->
                            FilterChip(
                                selected = selectedLocation == loc,
                                onClick = { selectedLocation = loc },
                                label = { Text(loc, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer)
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        locations.drop(3).forEach { loc ->
                            FilterChip(
                                selected = selectedLocation == loc,
                                onClick = { selectedLocation = loc },
                                label = { Text(loc, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer)
                            )
                        }
                    }
                }
            }

            // Watering and Fertilizing frequency sliders
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "جدول الري: كل ${wateringDays.toInt()} أيام",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Slider(
                        value = wateringDays,
                        onValueChange = { wateringDays = it },
                        valueRange = 1f..15f,
                        steps = 13
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "جدول التسميد: كل ${fertilizingDays.toInt()} يوماً",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Slider(
                        value = fertilizingDays,
                        onValueChange = { fertilizingDays = it },
                        valueRange = 5f..60f,
                        steps = 10
                    )
                }
            }

            // Notes
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("ملاحظات وتاريخ الزراعة") },
                placeholder = { Text("أصل الشتلة، نوع التربة، أسمدة مستخدمة...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                maxLines = 3
            )

            // Submit Button
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        viewModel.saveOrUpdatePlant(
                            id = selectedPlant?.id ?: 0L,
                            name = name.trim(),
                            scientificName = scientificName.trim(),
                            type = selectedCategory,
                            location = selectedLocation,
                            imagePath = selectedPlant?.imagePath ?: "",
                            wateringDays = wateringDays.toInt(),
                            fertilizingDays = fertilizingDays.toInt(),
                            notes = notes.trim()
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_plant_button"),
                shape = RoundedCornerShape(14.dp),
                enabled = name.isNotBlank()
            ) {
                Text(if (selectedPlant == null) "حفظ وإضافة النبتة" else "تحديث البيانات", fontWeight = FontWeight.Bold)
            }
        }
    }
}
