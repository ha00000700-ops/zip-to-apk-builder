package com.example.ui.screens.profile

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProviderProfileScreen(
    providerUid: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onRequestService: (providerUid: String) -> Unit,
    onNavigateToChat: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val selectedProviderState by authViewModel.selectedProviderState.collectAsState()
    var chatErrorDialogMessage by remember { mutableStateOf<String?>(null) }

    if (chatErrorDialogMessage != null) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { chatErrorDialogMessage = null },
            title = { Text("خطأ في المراسلة") },
            text = { Text(chatErrorDialogMessage ?: "") },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { chatErrorDialogMessage = null }) {
                    Text("حسناً")
                }
            }
        )
    }

    LaunchedEffect(providerUid) {
        authViewModel.loadSelectedProviderProfile(providerUid)
        authViewModel.loadCustomServices(providerUid)
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الملف الشخصي",
                onNavigateBack = onNavigateBack
            )
        },
        bottomBar = {
            if (selectedProviderState is AuthResult.Success) {
                val provider = (selectedProviderState as AuthResult.Success<ServiceProviderProfile>).data
                val currentCustomer = authViewModel.currentUserProfile.collectAsState().value
                
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color.White,
                    shadowElevation = 16.dp,
                    border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Chat Button
                        if (currentCustomer != null && currentCustomer.uid != provider.uid) {
                            IconButton(
                                onClick = {
                                    authViewModel.openOrCreateConversation(
                                        customerId = currentCustomer.uid,
                                        customerName = currentCustomer.fullName,
                                        customerPhotoUrl = "",
                                        providerId = provider.uid,
                                        providerName = provider.fullName,
                                        providerPhotoUrl = provider.effectiveAvatarUrl(),
                                        providerProfession = provider.professionNameAr
                                    ) { conversationId, errorMsg ->
                                        if (conversationId != null) {
                                            onNavigateToChat(conversationId)
                                        } else {
                                            chatErrorDialogMessage = errorMsg ?: "تعذر فتح المحادثة"
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(BackgroundLight, RoundedCornerShape(16.dp))
                                    .border(1.dp, OutlineLight.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Forum,
                                    contentDescription = "مراسلة",
                                    tint = BluePrimary
                                )
                            }
                        }

                        // Call Button
                        if (provider.phone.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    try {
                                        val intent = Intent(Intent.ACTION_DIAL).apply {
                                            data = Uri.parse("tel:${provider.phone}")
                                        }
                                        context.startActivity(intent)
                                    } catch (_: Exception) {}
                                },
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(AmberPrimary.copy(alpha = 0.1f), RoundedCornerShape(16.dp))
                                    .border(1.dp, AmberPrimary.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = "اتصال",
                                    tint = AmberPrimary
                                )
                            }
                        }

                        // Primary Action
                        Button(
                            onClick = { onRequestService(provider.uid) },
                            enabled = provider.isAvailable,
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp)
                                .testTag("request_service_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BluePrimary,
                                disabledContainerColor = OutlineLight
                            )
                        ) {
                            Text(
                                text = if (provider.isAvailable) "اطلب الخدمة الآن" else "غير متاح حالياً",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = selectedProviderState) {
                null -> {
                    // Do nothing or show loading
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = state.messageAr, color = Color.Red)
                    }
                }
                is AuthResult.ProfileMissing -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = "يرجى استكمال ملفك الشخصي أولاً", color = Color.Red)
                    }
                }
                is AuthResult.Success -> {
                    val provider = state.data
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Premium Header
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Avatar
                            Surface(
                                modifier = Modifier.size(120.dp),
                                shape = RoundedCornerShape(32.dp),
                                color = BackgroundLight,
                                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    val imgUrl = provider.effectiveAvatarUrl()
                                    if (imgUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = imgUrl,
                                            contentDescription = provider.fullName,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = BluePrimary,
                                            modifier = Modifier.size(60.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = provider.fullName,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Black,
                                    color = BlueDark
                                )
                                if (provider.isVerified) {
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "موثق",
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Text(
                                text = provider.professionNameAr,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = BluePrimary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Availability
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (provider.isAvailable) SuccessGreen.copy(alpha = 0.1f) else OutlineLight.copy(alpha = 0.1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .background(if (provider.isAvailable) SuccessGreen else Color.Gray, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (provider.isAvailable) "متاح للعمل" else "غير متاح",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Black,
                                        color = if (provider.isAvailable) SuccessGreen else TextSecondaryLight
                                    )
                                }
                            }
                        }

                        // Stats Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatCard(
                                icon = Icons.Default.Star,
                                value = "4.9",
                                label = "التقييم",
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                icon = Icons.Default.WorkHistory,
                                value = "${provider.experienceYears}+",
                                label = "سنة خبرة",
                                color = BluePrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                icon = Icons.Default.CheckCircle,
                                value = "${provider.effectiveCompletedJobs()}",
                                label = "خدمة",
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Info Cards
                        Column(
                            modifier = Modifier.padding(horizontal = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Location
                            InfoCard(
                                title = "الموقع والتغطية",
                                icon = Icons.Default.LocationOn,
                                content = {
                                    Text(
                                        text = "${provider.communeName}، ولاية ${provider.wilayaName}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = BlueDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            )

                            // Bio
                            InfoCard(
                                title = "نبذة عن الحرفي",
                                icon = Icons.Default.Info,
                                content = {
                                    Text(
                                        text = provider.effectiveBio().ifBlank { "لا يوجد وصف حالياً" },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextSecondaryLight,
                                        lineHeight = 22.sp
                                    )
                                }
                            )

                            // Services
                            val customServicesState by authViewModel.customServicesState.collectAsState()
                            if (customServicesState is AuthResult.Success) {
                                val services = (customServicesState as AuthResult.Success<List<com.example.data.model.CustomService>>).data
                                if (services.isNotEmpty()) {
                                    InfoCard(
                                        title = "الخدمات المقدمة",
                                        icon = Icons.Default.Handyman,
                                        content = {
                                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                                services.forEach { service ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text(text = service.name, style = MaterialTheme.typography.bodyMedium, color = BlueDark, fontWeight = FontWeight.Bold)
                                                        if (service.priceDzd != null) {
                                                            Text(text = "${service.priceDzd} د.ج", style = MaterialTheme.typography.bodyMedium, color = EmeraldPrimary, fontWeight = FontWeight.Black)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(100.dp))
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = state.messageAr, color = Color.Red)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = BlueDark)
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
        }
    }
}

@Composable
private fun InfoCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = BlueDark)
            }
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}
