package com.example.ui.screens.home

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import com.example.ui.screens.chat.ConversationsScreen
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.foundation.BorderStroke
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Profession
import com.example.data.model.ProfessionData
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.FirebaseStatusBanner
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun CustomerHomeScreen(
    authViewModel: AuthViewModel,
    onNavigateToProfile: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToProviderProfile: (String) -> Unit = {},
    onNavigateToRequestDetails: (String) -> Unit = {},
    onNavigateToChat: (String) -> Unit = {},
    onNavigateToCreatePublicRequest: () -> Unit = {},
    onNavigateToPublicRequestDetails: (String) -> Unit = {},
    onNavigateToNotifications: () -> Unit = {}
) {
    val currentUser by authViewModel.currentUserProfile.collectAsState()
    val providersListState by authViewModel.filteredProvidersListState.collectAsState()
    var selectedCategoryIndex by remember { mutableStateOf<String?>(null) }
    val searchQuery by authViewModel.searchQuery.collectAsState()
    var currentTab by remember { mutableIntStateOf(0) }
    val unreadNotifsCount by authViewModel.unreadNotificationsCount.collectAsState()
    val unreadChatCount by authViewModel.totalUnreadChatCount.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        authViewModel.loadServiceProviders()
        authViewModel.observeUserNotifications(context.applicationContext)
    }

    val filteredProfessions = remember(searchQuery, selectedCategoryIndex) {
        var list = if (searchQuery.trim().isEmpty()) {
            ProfessionData.professions
        } else {
            ProfessionData.searchProfessions(searchQuery)
        }
        if (selectedCategoryIndex != null) {
            list = list.filter { it.categoryId == selectedCategoryIndex }
        }
        list
    }

    Scaffold(
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 12.dp,
                border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.08f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val items = listOf(
                        Triple(Icons.Default.Home, "الرئيسية", 0),
                        Triple(Icons.Default.ListAlt, "طلباتي", 1),
                        Triple(Icons.Default.Forum, "الرسائل", 2),
                        Triple(Icons.Default.Person, "حسابي", 3)
                    )

                    items.forEach { (icon, label, index) ->
                        val isSelected = currentTab == index
                        val contentColor = if (isSelected) BluePrimary else TextSecondaryLight
                        
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { 
                                    if (index == 3) onNavigateToProfile() else currentTab = index 
                                }
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (index == 2) {
                                BadgedBox(
                                    badge = {
                                        if (unreadChatCount > 0) {
                                            Badge(
                                                containerColor = AmberPrimary,
                                                contentColor = Color.Black,
                                                modifier = Modifier.size(18.dp)
                                            ) {
                                                Text(
                                                    text = if (unreadChatCount > 9) "9+" else unreadChatCount.toString(),
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = contentColor,
                                        modifier = Modifier.size(if (isSelected) 28.dp else 24.dp)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = contentColor,
                                    modifier = Modifier.size(if (isSelected) 28.dp else 24.dp)
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(4.dp))
                            
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = contentColor,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        when (currentTab) {
            1 -> {
                MyRequestsTab(
                    paddingValues = paddingValues,
                    authViewModel = authViewModel,
                    onNewRequest = { currentTab = 0 },
                    onNavigateToRequestDetails = onNavigateToRequestDetails,
                    onNavigateToPublicRequestDetails = onNavigateToPublicRequestDetails,
                    onNavigateToCreatePublicRequest = onNavigateToCreatePublicRequest
                )
            }
            2 -> {
                Box(modifier = Modifier.padding(paddingValues)) {
                    ConversationsScreen(
                        authViewModel = authViewModel,
                        onNavigateToChat = onNavigateToChat,
                        onNavigateBack = null
                    )
                }
            }
            else -> {
                MarketplaceTab(
                    paddingValues = paddingValues,
                    authViewModel = authViewModel,
                    onNavigateToProviderProfile = onNavigateToProviderProfile,
                    onNavigateToCreatePublicRequest = onNavigateToCreatePublicRequest,
                    header = {
                        CustomerHeaderSection(
                            userName = currentUser?.fullName ?: "ضيف",
                            wilayaName = currentUser?.wilayaName ?: "غير محدد",
                            communeName = currentUser?.communeName ?: "غير محدد",
                            onProfileClick = onNavigateToProfile,
                            unreadCount = unreadNotifsCount,
                            onNotificationsClick = onNavigateToNotifications
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun CustomerHeaderSection(
    userName: String,
    wilayaName: String,
    communeName: String,
    onProfileClick: () -> Unit,
    unreadCount: Int = 0,
    onNotificationsClick: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(BlueDark, BluePrimary)
                ),
                shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
            )
            .padding(top = 32.dp, bottom = 48.dp, start = 24.dp, end = 24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Surface(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onProfileClick() },
                color = Color.White.copy(alpha = 0.2f),
                border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.3f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "الملف الشخصي",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(18.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "مرحباً بك،",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = userName,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    lineHeight = 28.sp
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = AmberPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "$communeName، $wilayaName",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.95f),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Box {
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "الإشعارات",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                if (unreadCount > 0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(AmberPrimary)
                            .border(2.dp, BluePrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (unreadCount > 9) "9+" else unreadCount.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

