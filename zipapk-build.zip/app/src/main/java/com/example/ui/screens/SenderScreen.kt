package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.architecture.XiaomiCompatibilityGuide
import com.example.model.CastStatus
import com.example.model.StreamStats
import com.example.service.ScreenCastService
import com.example.ui.components.StatusCard
import com.example.ui.components.StreamingMetricsGrid
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedAlert
import com.example.util.NetworkUtils

@Composable
fun SenderScreen(
    status: CastStatus,
    stats: StreamStats,
    streamUrl: String,
    interruptionReason: String?,
    onStartCastClick: () -> Unit,
    onStopCastClick: () -> Unit,
    onResumeCastClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    val isWifi = remember { NetworkUtils.isWifiConnected(context) }
    val localIp = remember { NetworkUtils.getLocalIpAddress(context) }
    val isXiaomi = remember { XiaomiCompatibilityGuide.isXiaomiDevice() }

    val currentPin by ScreenCastService.currentPairingPin.collectAsState()
    val isPinEnabled by ScreenCastService.isPinSecurityEnabled.collectAsState()
    val isAdaptiveEnabled by ScreenCastService.isAdaptiveQualityEnabled.collectAsState()
    val audioStats by ScreenCastService.audioStats.collectAsState()
    val isAudioMuted by ScreenCastService.isAudioMuted.collectAsState()

    var showXiaomiDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Card with Messenger Conflict Listener & 1-Tap Resume
        StatusCard(
            status = status,
            interruptionReason = interruptionReason,
            onResumeClick = onResumeCastClick
        )

        // TV Address Display Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("tv_address_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "عنوان البث المباشر لشاشة التلفزيون",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(if (isWifi) Color(0xFF00E676).copy(alpha = 0.15f) else RedAlert.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isWifi) "Wi-Fi متصل" else "Wi-Fi غير متصل",
                            fontSize = 11.sp,
                            color = if (isWifi) Color(0xFF00E676) else RedAlert,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                val displayUrl = if (streamUrl.isNotEmpty()) streamUrl else "http://$localIp:8080"

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(10.dp))
                        .border(1.dp, CyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "اكتب هذا الرابط في متصفح التلفزيون الذكي:",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = displayUrl,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = CyanPrimary
                            )
                        }

                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("CastDirect URL", displayUrl)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "تم نسخ الرابط!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("copy_url_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ الرابط", tint = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        // Security PIN Protection Card (Requirement 10)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("security_pin_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(CyanPrimary.copy(alpha = 0.35f))
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "رمز أمان التلفزيون (Pairing PIN)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Switch(
                        checked = isPinEnabled,
                        onCheckedChange = { ScreenCastService.isPinSecurityEnabled.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyanPrimary,
                            checkedTrackColor = CyanPrimary.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.testTag("pin_switch")
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يمنع أي جهاز غير مصرح به على شبكة الـ Wi-Fi من مشاهدة شاشة هاتفك.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (isPinEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.background, RoundedCornerShape(10.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("رمز PIN المطلوب على شاشة التلفزيون:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = currentPin,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 6.sp,
                                fontFamily = FontFamily.Monospace,
                                color = GreenSuccess
                            )
                        }

                        OutlinedButton(
                            onClick = { ScreenCastService.regeneratePin() },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("regenerate_pin_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("توليد جديد", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Audio Management & Privacy Card (Application & Media Audio Streaming)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("audio_management_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = if (isAudioMuted) AmberWarning else CyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بث صوت التطبيقات والوسائط",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Quick Mute / Unmute Button
                    OutlinedButton(
                        onClick = { ScreenCastService.toggleAudioMute() },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("toggle_audio_mute_btn")
                    ) {
                        Icon(
                            imageVector = if (isAudioMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = if (isAudioMuted) AmberWarning else CyanPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAudioMuted) "إلغاء الكتم" else "كتم الصوت",
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Audio Status Badge & Detail
                val (badgeColor, statusText) = when (audioStats.status) {
                    com.example.model.AudioStatus.STREAMING -> GreenSuccess to "🔊 بث صوت الوسائط نشط (48kHz Stereo)"
                    com.example.model.AudioStatus.SILENT -> CyanPrimary to "🎵 في انتظار تشغيل صوت في الهاتف"
                    com.example.model.AudioStatus.MUTED -> AmberWarning to "🔇 الصوت مكتوم من الهاتف"
                    com.example.model.AudioStatus.CALL_EXCLUDED -> AmberWarning to "🛡️ مكالمة نشطة (Messenger) - صوت المكالمة معزول ومحمي تلقائياً"
                    com.example.model.AudioStatus.BLOCKED_BY_APP -> AmberWarning to "⚠️ التطبيق الحالي يمنع مشاركة الصوت (ALLOW_CAPTURE_BY_NONE)"
                    com.example.model.AudioStatus.UNSUPPORTED -> Color.Gray to "ℹ️ يتطلب Android 10+"
                    else -> CyanPrimary to audioStats.statusMessage
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(badgeColor.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .border(1.dp, badgeColor.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = statusText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = badgeColor
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Strict Privacy Guarantee Notice
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "يتم نقل صوت التطبيقات والأفلام المسموحة فقط. لا يتم تسجيل الميكروفون أو مكالمات Messenger نهائياً.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Action Buttons: Start / Stop
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (status != CastStatus.STREAMING) {
                Button(
                    onClick = onStartCastClick,
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color(0xFF001E2B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_cast_button")
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "بدء التقاط الشاشة والبث إلى التلفزيون",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Button(
                    onClick = onStopCastClick,
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert, contentColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("stop_cast_button")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إيقاف البث فوراً",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live Performance Metrics
        AnimatedVisibility(visible = status == CastStatus.STREAMING || stats.uptimeSeconds > 0) {
            StreamingMetricsGrid(stats = stats)
        }

        // Adaptive Quality & Wi-Fi Latency (Requirements 4 & 5)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "التكيف التلقائي مع سرعة الـ Wi-Fi (Adaptive Latency)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Switch(
                        checked = isAdaptiveEnabled,
                        onCheckedChange = { ScreenCastService.isAdaptiveQualityEnabled.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyanPrimary,
                            checkedTrackColor = CyanPrimary.copy(alpha = 0.3f)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يضبط ضغط الصور تلقائياً بين 60% و 80% وفقاً لسرعة الإرسال لمنع التقطيع وضمان تأخير فائق الانخفاض (أقل من 50ms).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }

        // Xiaomi / Redmi Compatibility Assistant (Requirement 9)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isXiaomi) AmberWarning.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
            ),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(
                    if (isXiaomi) AmberWarning.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline
                )
            )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Smartphone, contentDescription = null, tint = if (isXiaomi) AmberWarning else CyanPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isXiaomi) "هاتف Xiaomi/Redmi تم رصده" else "دليل توافق أجهزة Xiaomi / Redmi",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    OutlinedButton(
                        onClick = { showXiaomiDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("open_xiaomi_guide_button")
                    ) {
                        Text("عرض الإعدادات", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يتطلب نظام MIUI / HyperOS ضبط إعداد 'لا توجد قيود' على البطارية وإذن البدء التلقائي لمنع إيقاف البث أثناء مكالمات Messenger.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }

    // Xiaomi Guide Dialog
    if (showXiaomiDialog) {
        AlertDialog(
            onDismissRequest = { showXiaomiDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = AmberWarning)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إعدادات هواتف Xiaomi / Redmi (MIUI / HyperOS)", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    XiaomiCompatibilityGuide.GUIDE_ITEMS.forEach { item ->
                        Column {
                            Text("${item.stepNumber}. ${item.title}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CyanPrimary)
                            Text(item.path, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text(item.whyNeeded, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        XiaomiCompatibilityGuide.openAppDetailsSettings(context)
                        showXiaomiDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color(0xFF001E2B))
                ) {
                    Text("فتح إعدادات التطبيق")
                }
            },
            dismissButton = {
                TextButton(onClick = { showXiaomiDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
