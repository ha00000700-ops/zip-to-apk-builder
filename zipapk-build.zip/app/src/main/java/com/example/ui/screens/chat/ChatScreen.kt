package com.example.ui.screens.chat

import android.Manifest
import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoCameraBack
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.BuildConfig
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.repository.AuthResult
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversationId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToRequestDetails: (String) -> Unit = {},
    onNavigateToPublicRequestDetails: (String) -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val currentUserId = authViewModel.currentUserProfile.collectAsState().value?.uid ?: ""

    val activeConvState by authViewModel.activeConversationState.collectAsState()
    val messagesState by authViewModel.currentChatMessagesState.collectAsState()

    val conversation = (activeConvState as? AuthResult.Success)?.data
    val isCustomer = conversation?.customerId == currentUserId
    val otherUserName = if (isCustomer) conversation?.providerName ?: "" else conversation?.customerName ?: ""
    val otherUserPhoto = if (isCustomer) conversation?.providerPhotoUrl ?: "" else conversation?.customerPhotoUrl ?: ""
    val otherUserSubtitle = if (isCustomer) conversation?.providerProfession ?: "حرفي معتمد" else "زبون خِدمتي"
    val receiverId = if (isCustomer) conversation?.providerId ?: "" else conversation?.customerId ?: ""

    var messageText by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }

    // Attachment BottomSheet State
    var showAttachmentSheet by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState()

    // Media Preview States before sending
    var pendingImageUri by remember { mutableStateOf<Uri?>(null) }
    var pendingVideoUri by remember { mutableStateOf<Uri?>(null) }
    var mediaCaption by remember { mutableStateOf("") }

    // Full screen media viewer state
    var fullScreenImageUrl by remember { mutableStateOf<String?>(null) }
    var fullScreenVideoUrl by remember { mutableStateOf<String?>(null) }

    // Voice recording states
    var isRecording by remember { mutableStateOf(false) }
    var recordingDuration by remember { mutableStateOf(0L) }
    var mediaRecorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordedFile by remember { mutableStateOf<File?>(null) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var playingMessageId by remember { mutableStateOf<String?>(null) }

    val listState = rememberLazyListState()

    // Photo pickers for Image and Video
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingImageUri = uri
            mediaCaption = ""
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingVideoUri = uri
            mediaCaption = ""
        }
    }

    // Camera Launchers
    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }
    var isRecordingVideoFromCamera by remember { mutableStateOf(false) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraUri != null) {
            pendingImageUri = tempCameraUri
            mediaCaption = ""
        }
    }

    val captureVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        if (success && tempCameraUri != null) {
            pendingVideoUri = tempCameraUri
            mediaCaption = ""
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val file = File.createTempFile("cam_", if (isRecordingVideoFromCamera) ".mp4" else ".jpg", context.cacheDir)
            val uri = FileProvider.getUriForFile(context, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
            tempCameraUri = uri
            if (isRecordingVideoFromCamera) {
                captureVideoLauncher.launch(uri)
            } else {
                takePictureLauncher.launch(uri)
            }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("يجب السماح بالوصول إلى الكاميرا لالتقاط الصور أو الفيديو")
            }
        }
    }

    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                val file = File.createTempFile("voice_", ".m4a", context.cacheDir)
                recordedFile = file
                val recorder = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                    MediaRecorder(context)
                } else {
                    @Suppress("DEPRECATION")
                    MediaRecorder()
                }.apply {
                    setAudioSource(MediaRecorder.AudioSource.MIC)
                    setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setOutputFile(file.absolutePath)
                    setMaxDuration(60000)
                    prepare()
                    start()
                }
                mediaRecorder = recorder
                isRecording = true
                recordingDuration = 0L
            } catch (e: Exception) {
                e.printStackTrace()
                scope.launch {
                    snackbarHostState.showSnackbar("تعذر بدء التسجيل الصوتي")
                }
            }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("يرجى السماح بالوصول إلى الميكروفون لتسجيل رسالة صوتية")
            }
        }
    }

    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingDuration = 0L
            while (isRecording && recordingDuration < 60) {
                delay(1000)
                recordingDuration++
            }
            if (isRecording && recordingDuration >= 60) {
                val file = recordedFile
                val duration = recordingDuration
                isRecording = false
                try {
                    mediaRecorder?.stop()
                    mediaRecorder?.release()
                } catch (_: Exception) {}
                mediaRecorder = null

                if (file != null && file.exists() && duration > 0 && receiverId.isNotBlank()) {
                    authViewModel.sendVoiceMessage(
                        conversationId = conversationId,
                        audioUrl = file.absolutePath,
                        duration = duration,
                        receiverId = receiverId
                    ) { success, errorMsg ->
                        if (!success) {
                            scope.launch {
                                snackbarHostState.showSnackbar(errorMsg ?: "تعذر إرسال الرسالة الصوتية")
                            }
                        }
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try { mediaRecorder?.release() } catch (_: Exception) {}
            try { mediaPlayer?.release() } catch (_: Exception) {}
        }
    }

    LaunchedEffect(conversationId) {
        authViewModel.loadConversationDetails(conversationId)
        authViewModel.observeChatMessages(conversationId)
        authViewModel.markMessagesAsRead(conversationId)
    }

    LaunchedEffect(messagesState) {
        if (messagesState is AuthResult.Success) {
            authViewModel.markMessagesAsRead(conversationId)
            val messages = (messagesState as AuthResult.Success<List<ChatMessage>>).data
            if (messages.isNotEmpty()) {
                listState.animateScrollToItem(messages.size - 1)
            }
        }
    }

    val playAudioMessage: (ChatMessage) -> Unit = { msg ->
        try {
            if (playingMessageId == msg.id) {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null
                playingMessageId = null
            } else {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null

                val file = File(msg.audioUrl)
                if (file.exists()) {
                    mediaPlayer = MediaPlayer().apply {
                        setDataSource(file.absolutePath)
                        prepare()
                        start()
                        playingMessageId = msg.id
                        setOnCompletionListener {
                            release()
                            mediaPlayer = null
                            playingMessageId = null
                        }
                    }
                } else {
                    scope.launch {
                        snackbarHostState.showSnackbar("ملف الصوت غير موجود محلياً")
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            playingMessageId = null
            scope.launch {
                snackbarHostState.showSnackbar("تعذر تشغيل التسجيل الصوتي")
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(BlueContainer)
                                .border(1.5.dp, BluePrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (otherUserPhoto.isNotBlank()) {
                                AsyncImage(
                                    model = otherUserPhoto,
                                    contentDescription = otherUserName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = otherUserName.take(1).ifBlank { "م" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BluePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = otherUserName.ifBlank { "مستخدم خِدمتي" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF4CAF50))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = otherUserSubtitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .fillMaxWidth()
                    .imePadding()
            ) {
                Column {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                    )

                    if (isRecording) {
                        // Voice Recording Banner
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(Color.Red)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                val mins = recordingDuration / 60
                                val secs = recordingDuration % 60
                                Text(
                                    text = String.format("%02d:%02d", mins, secs),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "جاري تسجيل صوتي (حد أقصى 60ث)...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        isRecording = false
                                        try {
                                            mediaRecorder?.stop()
                                            mediaRecorder?.release()
                                        } catch (_: Exception) {}
                                        mediaRecorder = null
                                        recordedFile?.delete()
                                        recordedFile = null
                                    },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف التسجيل",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(
                                    onClick = {
                                        val file = recordedFile
                                        val duration = recordingDuration
                                        isRecording = false
                                        try {
                                            mediaRecorder?.stop()
                                            mediaRecorder?.release()
                                        } catch (_: Exception) {}
                                        mediaRecorder = null

                                        if (file != null && file.exists() && duration > 0 && receiverId.isNotBlank()) {
                                            authViewModel.sendVoiceMessage(
                                                conversationId = conversationId,
                                                audioUrl = file.absolutePath,
                                                duration = duration,
                                                receiverId = receiverId
                                            ) { success, errorMsg ->
                                                if (!success) {
                                                    scope.launch {
                                                        snackbarHostState.showSnackbar(errorMsg ?: "تعذر إرسال الصوت")
                                                    }
                                                }
                                            }
                                        }
                                    },
                                     modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(BluePrimary)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "إرسال",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    } else {
                        // Standard Modern Composer with RTL support
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.Bottom
                            ) {
                                // Attachment Button (+)
                                IconButton(
                                    onClick = { showAttachmentSheet = true },
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                        .testTag("attachment_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "إرفاق وسائط",
                                        tint = BluePrimary
                                    )
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                OutlinedTextField(
                                    value = messageText,
                                    onValueChange = { messageText = it },
                                    placeholder = {
                                        Text(
                                            text = "اكتب رسالتك هنا...",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("chat_input_field"),
                                    shape = RoundedCornerShape(24.dp),
                                    maxLines = 4,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = BluePrimary,
                                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                                    )
                                )

                                Spacer(modifier = Modifier.width(6.dp))

                                val canSend = messageText.trim().isNotEmpty() && !isSending && receiverId.isNotBlank()

                                if (messageText.isBlank()) {
                                    IconButton(
                                        onClick = {
                                            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        },
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(BluePrimary)
                                            .testTag("mic_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Mic,
                                            contentDescription = "تسجيل صوتي",
                                            tint = Color.White
                                        )
                                    }
                                } else {
                                    IconButton(
                                        onClick = {
                                            val textToSend = messageText.trim()
                                            if (textToSend.isBlank() || isSending || receiverId.isBlank()) return@IconButton
                                            isSending = true
                                            authViewModel.sendMessage(
                                                conversationId = conversationId,
                                                text = textToSend,
                                                receiverId = receiverId
                                            ) { success, errorMsg ->
                                                isSending = false
                                                if (success) {
                                                    messageText = ""
                                                } else {
                                                    scope.launch {
                                                        snackbarHostState.showSnackbar(errorMsg ?: "تعذر إرسال الرسالة")
                                                    }
                                                }
                                            }
                                        },
                                        enabled = canSend,
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(if (canSend) BluePrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
                                            .testTag("send_message_button")
                                    ) {
                                        if (isSending) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(20.dp),
                                                color = Color.White,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.Send,
                                                contentDescription = "إرسال",
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Service Request Context Header if applicable
            if (conversation?.serviceRequestId != null && conversation.serviceRequestId.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .clickable {
                            if (conversation.isPublicRequest) {
                                onNavigateToPublicRequestDetails(conversation.serviceRequestId)
                            } else {
                                authViewModel.resolveRequestDestination(conversation.serviceRequestId) { isPublic ->
                                    if (isPublic) {
                                        onNavigateToPublicRequestDetails(conversation.serviceRequestId)
                                    } else {
                                        onNavigateToRequestDetails(conversation.serviceRequestId)
                                    }
                                }
                            }
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AmberLight),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = AmberPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "محادثة حول طلب الخدمة 🛠️",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = AmberPrimary
                            )
                            if (!conversation.serviceRequestTitle.isNullOrBlank()) {
                                Text(
                                    text = conversation.serviceRequestTitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Text(
                            text = "عرض التفاصيل ⬅️",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }
                }
            }

            // Messages List Body
            when (val state = messagesState) {
                is AuthResult.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = BluePrimary)
                    }
                }
                is AuthResult.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = state.messageAr,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is AuthResult.Success -> {
                    val messages = state.data
                    if (messages.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(BlueContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = BluePrimary,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "ابدأ المحادثة الآن 👋",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueDark
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "ناقش تفاصيل العمل والاتفاق مباشرة مع $otherUserName بكل أمان ويسر.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                val isMe = msg.senderId == currentUserId
                                ChatBubble(
                                    message = msg,
                                    isMe = isMe,
                                    playingMessageId = playingMessageId,
                                    onPlayAudio = playAudioMessage,
                                    onImageClick = { url -> fullScreenImageUrl = url },
                                    onVideoClick = { url -> fullScreenVideoUrl = url }
                                )
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }

    // Attachment Modal Bottom Sheet
    if (showAttachmentSheet) {
        ModalBottomSheet(
            onDismissRequest = { showAttachmentSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                Text(
                    text = "إرفاق وسائط",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachmentSheet = false
                            imagePickerLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BlueContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            tint = BluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "صورة من الاستوديو",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachmentSheet = false
                            isRecordingVideoFromCamera = false
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BluePrimary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = BluePrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "التقاط صورة بالكاميرا",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachmentSheet = false
                            videoPickerLauncher.launch(
                                androidx.activity.result.PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.VideoOnly
                                )
                            )
                        }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AmberLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoLibrary,
                            contentDescription = null,
                            tint = AmberPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "فيديو من الاستوديو",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showAttachmentSheet = false
                            isRecordingVideoFromCamera = true
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        }
                        .padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AmberPrimary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VideoCameraBack,
                            contentDescription = null,
                            tint = AmberPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = "تسجيل فيديو بالكاميرا",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Pending Image Preview Dialog
    if (pendingImageUri != null) {
        AlertDialog(
            onDismissRequest = { pendingImageUri = null },
            title = { Text(text = "معاينة الصورة قبل الإرسال", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    AsyncImage(
                        model = pendingImageUri,
                        contentDescription = "معاينة الصورة",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = mediaCaption,
                        onValueChange = { mediaCaption = it },
                        placeholder = { Text("أضف تعليقاً على الصورة (اختياري)...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uriStr = pendingImageUri.toString()
                        pendingImageUri = null
                        if (receiverId.isNotBlank()) {
                            isSending = true
                            authViewModel.sendMediaMessage(
                                conversationId = conversationId,
                                mediaUrl = uriStr,
                                type = "image",
                                caption = mediaCaption,
                                receiverId = receiverId
                            ) { success, errorMsg ->
                                isSending = false
                                if (!success) {
                                    scope.launch {
                                        snackbarHostState.showSnackbar(errorMsg ?: "تعذر إرسال الصورة")
                                    }
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("إرسال الصورة")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingImageUri = null }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.error)
                }
            }
        )
    }

    // Pending Video Preview Dialog
    if (pendingVideoUri != null) {
        AlertDialog(
            onDismissRequest = { pendingVideoUri = null },
            title = { Text(text = "معاينة الفيديو قبل الإرسال", fontWeight = FontWeight.Bold) },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "فيديو",
                            tint = Color.White,
                            modifier = Modifier.size(56.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = mediaCaption,
                        onValueChange = { mediaCaption = it },
                        placeholder = { Text("أضف تعليقاً على الفيديو (اختياري)...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uriStr = pendingVideoUri.toString()
                        pendingVideoUri = null
                        if (receiverId.isNotBlank()) {
                            isSending = true
                            authViewModel.sendMediaMessage(
                                conversationId = conversationId,
                                mediaUrl = uriStr,
                                type = "video",
                                caption = mediaCaption,
                                receiverId = receiverId
                            ) { success, errorMsg ->
                                isSending = false
                                if (!success) {
                                    scope.launch {
                                        snackbarHostState.showSnackbar(errorMsg ?: "تعذر إرسال الفيديو")
                                    }
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("إرسال الفيديو")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingVideoUri = null }) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.error)
                }
            }
        )
    }

    // Full Screen Image Viewer Dialog
    if (fullScreenImageUrl != null) {
        Dialog(
            onDismissRequest = { fullScreenImageUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = fullScreenImageUrl,
                    contentDescription = "عرض الصورة",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                IconButton(
                    onClick = { fullScreenImageUrl = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }
            }
        }
    }

    // Full Screen Video Player Dialog
    if (fullScreenVideoUrl != null) {
        Dialog(
            onDismissRequest = { fullScreenVideoUrl = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "تشغيل الفيديو (محلي)",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }

                IconButton(
                    onClick = { fullScreenVideoUrl = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    isMe: Boolean,
    playingMessageId: String?,
    onPlayAudio: (ChatMessage) -> Unit,
    onImageClick: (String) -> Unit,
    onVideoClick: (String) -> Unit
) {
    val formattedTime = remember(message.createdAt) {
        try {
            DateFormat.format("HH:mm", Date(message.createdAt)).toString()
        } catch (_: Exception) {
            ""
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.Start else Arrangement.End
    ) {
        Card(
            shape = if (isMe) {
                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 4.dp)
            } else {
                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp, bottomStart = 4.dp, bottomEnd = 16.dp)
            },
            colors = CardDefaults.cardColors(
                containerColor = if (isMe) BluePrimary else MaterialTheme.colorScheme.surfaceVariant
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth(0.82f)
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                when (message.type) {
                    "voice" -> {
                        val isPlaying = playingMessageId == message.id
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { onPlayAudio(message) },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isMe) Color.White.copy(alpha = 0.2f) else BluePrimary.copy(alpha = 0.1f))
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "إيقاف مؤقت" else "تشغيل",
                                    tint = if (isMe) Color.White else BluePrimary
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val barHeights = listOf(12.dp, 20.dp, 28.dp, 16.dp, 24.dp, 32.dp, 18.dp, 22.dp, 14.dp, 26.dp)
                                barHeights.forEach { h ->
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(h)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(if (isMe) Color.White.copy(alpha = if (isPlaying) 0.9f else 0.5f) else BluePrimary.copy(alpha = if (isPlaying) 0.9f else 0.4f))
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Text(
                                text = "${message.duration} ث",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    "image" -> {
                        Column {
                            if (message.mediaUrl.isNotBlank()) {
                                AsyncImage(
                                    model = message.mediaUrl,
                                    contentDescription = "صورة مرفقة",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { onImageClick(message.mediaUrl) }
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                            if (message.text.isNotBlank() && !message.text.startsWith("📷 صورة")) {
                                Text(
                                    text = message.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    "video" -> {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black.copy(alpha = 0.8f))
                                    .clickable { onVideoClick(message.mediaUrl) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "تشغيل الفيديو",
                                    tint = Color.White,
                                    modifier = Modifier.size(54.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            if (message.text.isNotBlank() && !message.text.startsWith("🎥 فيديو")) {
                                Text(
                                    text = message.text,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )

                    if (isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = if (message.read) Icons.Default.DoneAll else Icons.Default.Check,
                            contentDescription = if (message.read) "تمت القراءة" else "تم الإرسال",
                            tint = if (message.read) Color(0xFF80D8FF) else Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
