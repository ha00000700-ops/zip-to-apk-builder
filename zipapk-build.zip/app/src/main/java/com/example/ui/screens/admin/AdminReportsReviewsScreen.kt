package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.Report
import com.example.data.model.ReportStatus
import com.example.data.model.ReportType
import com.example.data.model.Review
import com.example.data.repository.AuthResult
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class ReportsReviewsTab {
    REPORTS,
    REVIEWS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminReportsReviewsScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val reportsState by authViewModel.adminReportsState.collectAsState()
    val reviewsState by authViewModel.adminReviewsState.collectAsState()
    val actionState by authViewModel.adminActionState.collectAsState()

    var selectedTab by remember { mutableStateOf(ReportsReviewsTab.REPORTS) }
    var searchQuery by remember { mutableStateOf("") }
    var reportStatusFilter by remember { mutableStateOf<String?>(null) }
    var reportTypeFilter by remember { mutableStateOf<String?>(null) }

    // Dialog state for viewing/acting on a report
    var selectedReport by remember { mutableStateOf<Report?>(null) }
    var selectedReviewToDelete by remember { mutableStateOf<Review?>(null) }

    LaunchedEffect(Unit) {
        authViewModel.loadAllReportsForAdmin()
        authViewModel.loadAllReviewsForAdmin()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "البلاغات والمراجعات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "معالجة الشكاوى وتقييمات الخدمات",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            authViewModel.loadAllReportsForAdmin()
                            authViewModel.loadAllReviewsForAdmin()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("بحث بالمبلغ، المشتكى عليه، السبب، أو المعرف...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "بحث")
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                // Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = BluePrimary
                ) {
                    Tab(
                        selected = selectedTab == ReportsReviewsTab.REPORTS,
                        onClick = { selectedTab = ReportsReviewsTab.REPORTS },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ReportProblem,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val count = (reportsState as? AuthResult.Success)?.data?.size ?: 0
                                Text("البلاغات والشكاوى ($count)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == ReportsReviewsTab.REVIEWS,
                        onClick = { selectedTab = ReportsReviewsTab.REVIEWS },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.RateReview,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val count = (reviewsState as? AuthResult.Success)?.data?.size ?: 0
                                Text("مراجعات وتقييمات الزبائن ($count)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (selectedTab == ReportsReviewsTab.REPORTS) {
                    // Filter Chips for reports
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = reportStatusFilter == null,
                                onClick = { reportStatusFilter = null },
                                label = { Text("جميع الحالات") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = reportStatusFilter == ReportStatus.PENDING,
                                onClick = { reportStatusFilter = if (reportStatusFilter == ReportStatus.PENDING) null else ReportStatus.PENDING },
                                label = { Text("قيد الانتظار ⏳") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = reportStatusFilter == ReportStatus.IN_REVIEW,
                                onClick = { reportStatusFilter = if (reportStatusFilter == ReportStatus.IN_REVIEW) null else ReportStatus.IN_REVIEW },
                                label = { Text("قيد المعالجة 🔍") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = reportStatusFilter == ReportStatus.RESOLVED,
                                onClick = { reportStatusFilter = if (reportStatusFilter == ReportStatus.RESOLVED) null else ReportStatus.RESOLVED },
                                label = { Text("تم الحل ✅") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = reportStatusFilter == ReportStatus.DISMISSED,
                                onClick = { reportStatusFilter = if (reportStatusFilter == ReportStatus.DISMISSED) null else ReportStatus.DISMISSED },
                                label = { Text("مرفوض/ملغى ❌") }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    ReportsListContent(
                        state = reportsState,
                        searchQuery = searchQuery,
                        statusFilter = reportStatusFilter,
                        onReportClick = { selectedReport = it }
                    )
                } else {
                    ReviewsListContent(
                        state = reviewsState,
                        searchQuery = searchQuery,
                        onDeleteClick = { selectedReviewToDelete = it }
                    )
                }
            }
        }

        // Report Action/Inspection Dialog
        selectedReport?.let { report ->
            AdminReportDetailsDialog(
                report = report,
                isActionLoading = actionState is AuthResult.Loading,
                onUpdateStatus = { newStatus, notes ->
                    authViewModel.updateReportStatus(report.id, newStatus, notes) { success ->
                        if (success) {
                            selectedReport = null
                        }
                    }
                },
                onDismiss = { selectedReport = null }
            )
        }

        // Delete Review Dialog
        selectedReviewToDelete?.let { review ->
            AlertDialog(
                onDismissRequest = { selectedReviewToDelete = null },
                title = { Text("حذف المراجعة", fontWeight = FontWeight.Bold) },
                text = {
                    Text("هل أنت متأكد من حذف هذه المراجعة؟ قد تكون مخالفة لسياسات المنظمة أو تحتوي على محتوى غير لائق.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            authViewModel.deleteReviewByAdmin(review.id) {
                                selectedReviewToDelete = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("حذف الآن", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedReviewToDelete = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
private fun ReportsListContent(
    state: AuthResult<List<Report>>?,
    searchQuery: String,
    statusFilter: String?,
    onReportClick: (Report) -> Unit
) {
    when (state) {
        is AuthResult.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BluePrimary)
            }
        }
        is AuthResult.Error -> {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(text = state.messageAr, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
        }
        is AuthResult.Success -> {
            val query = searchQuery.trim()
            val filtered = state.data.filter { r ->
                val matchesStatus = statusFilter == null || r.status == statusFilter
                val matchesQuery = query.isEmpty() ||
                        r.reporterName.contains(query, ignoreCase = true) ||
                        r.reportedUserName.contains(query, ignoreCase = true) ||
                        r.reason.contains(query, ignoreCase = true) ||
                        r.details.contains(query, ignoreCase = true) ||
                        r.id.contains(query, ignoreCase = true)
                matchesStatus && matchesQuery
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "لا توجد بلاغات تطابق معايير البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { report ->
                        ReportCard(report = report, onClick = { onReportClick(report) })
                    }
                }
            }
        }
        else -> {}
    }
}

@Composable
private fun ReportCard(
    report: Report,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "بلاغ #${report.id.take(8)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ReportStatusBadge(status = report.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = report.reason.ifBlank { "بلاغ عن مخالفة" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = report.details,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "المُبلِغ: ${report.reporterName.ifBlank { "مستخدم" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "المُبلَغ عنه: ${report.reportedUserName.ifBlank { "غير محدد" }}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun ReviewsListContent(
    state: AuthResult<List<Review>>?,
    searchQuery: String,
    onDeleteClick: (Review) -> Unit
) {
    when (state) {
        is AuthResult.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BluePrimary)
            }
        }
        is AuthResult.Error -> {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(text = state.messageAr, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
            }
        }
        is AuthResult.Success -> {
            val query = searchQuery.trim()
            val filtered = state.data.filter { rev ->
                query.isEmpty() ||
                        rev.customerName.contains(query, ignoreCase = true) ||
                        rev.comment.contains(query, ignoreCase = true) ||
                        rev.id.contains(query, ignoreCase = true) ||
                        rev.providerId.contains(query, ignoreCase = true)
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(text = "لا توجد مراجعات تطابق البحث", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { review ->
                        ReviewAdminCard(review = review, onDeleteClick = { onDeleteClick(review) })
                    }
                }
            }
        }
        else -> {}
    }
}

@Composable
private fun ReviewAdminCard(
    review: Review,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    repeat(5) { index ->
                        Icon(
                            imageVector = if (index < review.rating) Icons.Default.Star else Icons.Default.StarBorder,
                            contentDescription = null,
                            tint = if (index < review.rating) Color(0xFFFFB300) else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "(${review.rating}/5)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }

                IconButton(onClick = onDeleteClick) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف المراجعة", tint = MaterialTheme.colorScheme.error)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = review.comment.ifBlank { "(بدون تعليق مكتوب)" },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الزبون: ${review.customerName.ifBlank { "مجهول" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "معرف الحرفي: ${review.providerId.take(10)}...",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ReportStatusBadge(status: String) {
    val (color, bgColor, text) = when (status) {
        ReportStatus.PENDING -> Triple(Color(0xFFE65100), Color(0xFFFFE0B2), "قيد الانتظار")
        ReportStatus.IN_REVIEW -> Triple(Color(0xFF1565C0), Color(0xFFBBDEFB), "قيد المراجعة")
        ReportStatus.RESOLVED -> Triple(Color(0xFF2E7D32), Color(0xFFC8E6C9), "تم الحل")
        ReportStatus.DISMISSED -> Triple(Color(0xFF757575), Color(0xFFEEEEEE), "مرفوض/ملغى")
        else -> Triple(Color.Gray, Color.LightGray, status)
    }

    Surface(color = bgColor, shape = RoundedCornerShape(8.dp)) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun AdminReportDetailsDialog(
    report: Report,
    isActionLoading: Boolean,
    onUpdateStatus: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var adminNotes by remember { mutableStateOf(report.adminNotes) }
    var targetStatus by remember { mutableStateOf(report.status) }
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("معالجة البلاغ", fontWeight = FontWeight.Bold)
                ReportStatusBadge(status = report.status)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(text = "سبب البلاغ: ${report.reason}", fontWeight = FontWeight.Bold)
                    Text(text = "نوع البلاغ: ${report.type}", style = MaterialTheme.typography.bodySmall, color = BluePrimary)
                    Text(text = "المعرف المرجعي: ${report.targetId}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "تفاصيل الشكوى:", fontWeight = FontWeight.Bold)
                    Text(text = report.details, style = MaterialTheme.typography.bodyMedium)
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "بيانات الأطراف:", fontWeight = FontWeight.Bold)
                    Text(text = "المُبلِغ: ${report.reporterName} (${report.reporterRole})")
                    Text(text = "معرف المُبلِغ: ${report.reporterId}")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "المُبلَغ عنه: ${report.reportedUserName} (${report.reportedUserRole})", color = MaterialTheme.colorScheme.error)
                    Text(text = "معرف المُبلَغ عنه: ${report.reportedUserId}")
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "تغيير حالة البلاغ:", fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = targetStatus == ReportStatus.PENDING,
                            onClick = { targetStatus = ReportStatus.PENDING },
                            label = { Text("معلق", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = targetStatus == ReportStatus.IN_REVIEW,
                            onClick = { targetStatus = ReportStatus.IN_REVIEW },
                            label = { Text("قيد المراجعة", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = targetStatus == ReportStatus.RESOLVED,
                            onClick = { targetStatus = ReportStatus.RESOLVED },
                            label = { Text("تم الحل", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = targetStatus == ReportStatus.DISMISSED,
                            onClick = { targetStatus = ReportStatus.DISMISSED },
                            label = { Text("رفض", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = adminNotes,
                        onValueChange = { adminNotes = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("ملاحظات وقرار الإدارة") },
                        placeholder = { Text("أدخل الإجراء المتخذ مع البلاغ...") },
                        minLines = 2
                    )
                }

                item {
                    Text(
                        text = "تاريخ الإرسال: ${sdf.format(Date(report.createdAt))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (report.reviewedAt != null) {
                        Text(
                            text = "تاريخ المراجعة: ${sdf.format(Date(report.reviewedAt))}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onUpdateStatus(targetStatus, adminNotes) },
                enabled = !isActionLoading
            ) {
                if (isActionLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                } else {
                    Text("حفظ التغييرات")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
