package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.AuthResult
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.*

enum class RequestTab {
    DIRECT,
    PUBLIC
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminRequestManagementScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val directRequestsState by authViewModel.adminDirectRequestsState.collectAsState()
    val publicRequestsState by authViewModel.adminPublicRequestsState.collectAsState()
    val offersState by authViewModel.adminOffersState.collectAsState()

    var selectedTab by remember { mutableStateOf(RequestTab.DIRECT) }
    var searchQuery by remember { mutableStateOf("") }
    var directStatusFilter by remember { mutableStateOf<RequestStatus?>(null) }
    var publicStatusFilter by remember { mutableStateOf<PublicRequestStatus?>(null) }

    // Detail dialog states
    var selectedDirectRequest by remember { mutableStateOf<ServiceRequest?>(null) }
    var selectedPublicRequest by remember { mutableStateOf<PublicServiceRequest?>(null) }

    LaunchedEffect(Unit) {
        authViewModel.loadAllServiceRequestsForAdmin()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "إدارة طلبات الخدمة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "إشراف شامل على الطلبات الخاصة وسوق العروض",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { authViewModel.loadAllServiceRequestsForAdmin() }) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("بحث بالزبون، الحرفي، المهنة، الولاية، أو المعرف...") },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "بحث")
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                // Tab Selector
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = BluePrimary
                ) {
                    Tab(
                        selected = selectedTab == RequestTab.DIRECT,
                        onClick = { selectedTab = RequestTab.DIRECT },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.PersonSearch,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val count = (directRequestsState as? AuthResult.Success)?.data?.size ?: 0
                                Text("الطلبات المباشرة ($count)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == RequestTab.PUBLIC,
                        onClick = { selectedTab = RequestTab.PUBLIC },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Storefront,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                val count = (publicRequestsState as? AuthResult.Success)?.data?.size ?: 0
                                Text("طلبات السوق العامة ($count)", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Status Filter Chips
                if (selectedTab == RequestTab.DIRECT) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = directStatusFilter == null,
                                onClick = { directStatusFilter = null },
                                label = { Text("الكل") }
                            )
                        }
                        items(RequestStatus.values()) { status ->
                            FilterChip(
                                selected = directStatusFilter == status,
                                onClick = { directStatusFilter = if (directStatusFilter == status) null else status },
                                label = { Text(status.titleAr) }
                            )
                        }
                    }
                } else {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = publicStatusFilter == null,
                                onClick = { publicStatusFilter = null },
                                label = { Text("الكل") }
                            )
                        }
                        items(PublicRequestStatus.values()) { status ->
                            FilterChip(
                                selected = publicStatusFilter == status,
                                onClick = { publicStatusFilter = if (publicStatusFilter == status) null else status },
                                label = { Text(status.titleAr) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Content
                when (selectedTab) {
                    RequestTab.DIRECT -> {
                        DirectRequestsListContent(
                            state = directRequestsState,
                            searchQuery = searchQuery,
                            filterStatus = directStatusFilter,
                            onRequestClick = { selectedDirectRequest = it }
                        )
                    }
                    RequestTab.PUBLIC -> {
                        PublicRequestsListContent(
                            state = publicRequestsState,
                            searchQuery = searchQuery,
                            filterStatus = publicStatusFilter,
                            onRequestClick = { selectedPublicRequest = it }
                        )
                    }
                }
            }
        }

        // Direct Request Inspection Dialog
        selectedDirectRequest?.let { req ->
            DirectRequestDetailsDialog(
                request = req,
                onDismiss = { selectedDirectRequest = null }
            )
        }

        // Public Request Inspection Dialog with Offers
        selectedPublicRequest?.let { req ->
            PublicRequestDetailsDialog(
                request = req,
                offersState = offersState,
                onLoadOffers = { authViewModel.loadOffersForPublicRequestAdmin(req.id) },
                onDismiss = {
                    selectedPublicRequest = null
                    authViewModel.clearAdminOffers()
                }
            )
        }
    }
}

@Composable
private fun DirectRequestsListContent(
    state: AuthResult<List<ServiceRequest>>?,
    searchQuery: String,
    filterStatus: RequestStatus?,
    onRequestClick: (ServiceRequest) -> Unit
) {
    when (state) {
        is AuthResult.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BluePrimary)
            }
        }
        is AuthResult.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = state.messageAr,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        is AuthResult.Success -> {
            val query = searchQuery.trim()
            val filtered = state.data.filter { req ->
                val matchesFilter = filterStatus == null || req.status == filterStatus
                val matchesQuery = query.isEmpty() ||
                        req.customerName.contains(query, ignoreCase = true) ||
                        req.providerName.contains(query, ignoreCase = true) ||
                        req.professionNameAr.contains(query, ignoreCase = true) ||
                        req.wilayaName.contains(query, ignoreCase = true) ||
                        req.communeName.contains(query, ignoreCase = true) ||
                        req.id.contains(query, ignoreCase = true)
                matchesFilter && matchesQuery
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "لا توجد طلبات مباشرة مطابقة للبحث",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { request ->
                        DirectRequestCard(request = request, onClick = { onRequestClick(request) })
                    }
                }
            }
        }
        else -> {}
    }
}

@Composable
private fun DirectRequestCard(
    request: ServiceRequest,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "طلب رقم #${request.id.take(8)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                DirectStatusBadge(status = request.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = request.professionNameAr.ifBlank { "طلب خدمة" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = request.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الزبون: ${request.customerName.ifBlank { "غير محدد" }}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "الحرفي: ${request.providerName.ifBlank { "غير محدد" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    if (request.proposedPriceDzd != null && request.proposedPriceDzd > 0) {
                        Text(
                            text = "${request.proposedPriceDzd} دج",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }
                    Text(
                        text = "${request.wilayaName} ${if (request.communeName.isNotBlank()) "• " + request.communeName else ""}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun PublicRequestsListContent(
    state: AuthResult<List<PublicServiceRequest>>?,
    searchQuery: String,
    filterStatus: PublicRequestStatus?,
    onRequestClick: (PublicServiceRequest) -> Unit
) {
    when (state) {
        is AuthResult.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = BluePrimary)
            }
        }
        is AuthResult.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = state.messageAr,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
        is AuthResult.Success -> {
            val query = searchQuery.trim()
            val filtered = state.data.filter { req ->
                val matchesFilter = filterStatus == null || req.status == filterStatus
                val matchesQuery = query.isEmpty() ||
                        req.title.contains(query, ignoreCase = true) ||
                        req.customerName.contains(query, ignoreCase = true) ||
                        req.professionNameAr.contains(query, ignoreCase = true) ||
                        req.wilayaName.contains(query, ignoreCase = true) ||
                        req.communeName.contains(query, ignoreCase = true) ||
                        (req.assignedProviderName?.contains(query, ignoreCase = true) == true) ||
                        req.id.contains(query, ignoreCase = true)
                matchesFilter && matchesQuery
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "لا توجد طلبات عامة مطابقة للبحث",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered, key = { it.id }) { request ->
                        PublicRequestCard(request = request, onClick = { onRequestClick(request) })
                    }
                }
            }
        }
        else -> {}
    }
}

@Composable
private fun PublicRequestCard(
    request: PublicServiceRequest,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "طلب عام #${request.id.take(8)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                PublicStatusBadge(status = request.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = request.title.ifBlank { request.professionNameAr },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "المهنة: ${request.professionNameAr}",
                style = MaterialTheme.typography.bodySmall,
                color = BluePrimary,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = request.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "صاحب الطلب: ${request.customerName}",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${request.wilayaName} • ${request.communeName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(BluePrimary.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${request.offersCount} عروض",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectStatusBadge(status: RequestStatus) {
    val (color, bgColor) = when (status) {
        RequestStatus.PENDING -> Pair(Color(0xFFE65100), Color(0xFFFFE0B2))
        RequestStatus.ACCEPTED -> Pair(Color(0xFF1565C0), Color(0xFFBBDEFB))
        RequestStatus.IN_PROGRESS -> Pair(Color(0xFF6A1B9A), Color(0xFFE1BEE7))
        RequestStatus.COMPLETED -> Pair(Color(0xFF2E7D32), Color(0xFFC8E6C9))
        RequestStatus.REJECTED -> Pair(Color(0xFFC62828), Color(0xFFFFCDD2))
        RequestStatus.CANCELLED -> Pair(Color(0xFF424242), Color(0xFFE0E0E0))
    }
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = status.titleAr,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun PublicStatusBadge(status: PublicRequestStatus) {
    val (color, bgColor) = when (status) {
        PublicRequestStatus.OPEN -> Pair(Color(0xFF2E7D32), Color(0xFFC8E6C9))
        PublicRequestStatus.ASSIGNED -> Pair(Color(0xFF1565C0), Color(0xFFBBDEFB))
        PublicRequestStatus.COMPLETED -> Pair(Color(0xFF00695C), Color(0xFFB2DFDB))
        PublicRequestStatus.CANCELLED -> Pair(Color(0xFFC62828), Color(0xFFFFCDD2))
    }
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(
            text = status.titleAr,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun DirectRequestDetailsDialog(
    request: ServiceRequest,
    onDismiss: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تفاصيل الطلب المباشر",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                DirectStatusBadge(status = request.status)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "معرف الطلب: ${request.id}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "المهنة: ${request.professionNameAr}",
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "معلومات الزبون:", fontWeight = FontWeight.Bold)
                    Text(text = "الاسم: ${request.customerName}")
                    Text(text = "الهاتف: ${request.customerPhone.ifBlank { "غير متوفر" }}")
                    Text(text = "معرف الحساب: ${request.customerId}")
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "معلومات الحرفي:", fontWeight = FontWeight.Bold)
                    Text(text = "الاسم: ${request.providerName}")
                    Text(text = "معرف الحساب: ${request.providerId}")
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "الموقع والعنوان:", fontWeight = FontWeight.Bold)
                    Text(text = "الولاية: ${request.wilayaName} | البلدية: ${request.communeName}")
                    if (request.addressDetails.isNotBlank()) {
                        Text(text = "تفاصيل العنوان: ${request.addressDetails}")
                    }
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "وصف الطلب:", fontWeight = FontWeight.Bold)
                    Text(text = request.description, style = MaterialTheme.typography.bodyMedium)
                }

                if (request.proposedPriceDzd != null && request.proposedPriceDzd > 0) {
                    item {
                        Text(text = "السعر المقترح: ${request.proposedPriceDzd} دج", fontWeight = FontWeight.Bold, color = BluePrimary)
                    }
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "تاريخ الإنشاء: ${sdf.format(Date(request.createdAt))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "آخر تحديث: ${sdf.format(Date(request.updatedAt))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
private fun PublicRequestDetailsDialog(
    request: PublicServiceRequest,
    offersState: AuthResult<List<PublicRequestOffer>>?,
    onLoadOffers: () -> Unit,
    onDismiss: () -> Unit
) {
    val sdf = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }

    LaunchedEffect(request.id) {
        onLoadOffers()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تفاصيل الطلب العام",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                PublicStatusBadge(status = request.status)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Text(
                        text = "معرف الطلب: ${request.id}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = request.title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "التخصص: ${request.professionNameAr} (${request.professionCategoryAr})",
                        color = BluePrimary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "صاحب الطلب:", fontWeight = FontWeight.Bold)
                    Text(text = "الاسم: ${request.customerName}")
                    Text(text = "الهاتف: ${request.customerPhone.ifBlank { "غير متوفر" }}")
                    Text(text = "معرف الحساب: ${request.customerId}")
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "الموقع الجغرافي:", fontWeight = FontWeight.Bold)
                    Text(text = "الولاية: ${request.wilayaName} (${request.wilayaCode}) | البلدية: ${request.communeName}")
                    if (request.addressDetails.isNotBlank()) {
                        Text(text = "العنوان: ${request.addressDetails}")
                    }
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(text = "الوصف:", fontWeight = FontWeight.Bold)
                    Text(text = request.description, style = MaterialTheme.typography.bodyMedium)
                }

                if (request.budgetDzd != null && request.budgetDzd > 0) {
                    item {
                        Text(text = "الميزانية المقدرة: ${request.budgetDzd} دج", fontWeight = FontWeight.Bold, color = BluePrimary)
                    }
                }

                if (request.assignedProviderId != null) {
                    item {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text(text = "الحرفي المقبول عرضه (الفائز):", fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                        Text(text = "الاسم: ${request.assignedProviderName ?: "غير محدد"}")
                        Text(text = "معرف الحرفي: ${request.assignedProviderId}")
                    }
                }

                // Offers Section
                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "عروض الحرفيين المقدمة (${request.offersCount}):",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                when (offersState) {
                    is AuthResult.Loading -> {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = BluePrimary)
                            }
                        }
                    }
                    is AuthResult.Success -> {
                        if (offersState.data.isEmpty()) {
                            item {
                                Text(
                                    text = "لم يتم تقديم أي عروض بعد",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            items(offersState.data, key = { it.id }) { offer ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = offer.providerName,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                            Text(
                                                text = "${offer.priceDzd} دج",
                                                fontWeight = FontWeight.Bold,
                                                color = BluePrimary,
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                        if (offer.message.isNotBlank()) {
                                            Text(
                                                text = offer.message,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            text = "الحالة: ${offer.status.titleAr} • الهاتف: ${offer.providerPhone.ifBlank { "غير متوفر" }}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                    is AuthResult.Error -> {
                        item {
                            Text(
                                text = "تعذر تحميل العروض: ${offersState.messageAr}",
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    else -> {}
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                    Text(
                        text = "تاريخ النشر: ${sdf.format(Date(request.createdAt))}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}
