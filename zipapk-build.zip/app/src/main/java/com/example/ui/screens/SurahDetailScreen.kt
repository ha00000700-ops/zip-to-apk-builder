package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.ZoomIn
import androidx.compose.material.icons.outlined.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.data.Ayah
import com.example.ui.theme.AppBackground
import com.example.ui.theme.AppPrimary
import com.example.ui.theme.AppSurface
import com.example.ui.theme.CardBorder
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahDetailScreen(surahId: Int, navController: NavController) {
    val viewModel: SurahViewModel = viewModel()
    val surah by viewModel.surah.collectAsState()
    val fontSize by viewModel.fontSize.collectAsState()
    
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    
    var selectedAyah by remember { mutableStateOf<Ayah?>(null) }
    var showBottomSheet by remember { mutableStateOf(false) }

    LaunchedEffect(surahId) {
        viewModel.loadSurah(surahId)
    }
    
    // Save last read when the user scrolls or leaves
    DisposableEffect(surah, listState.firstVisibleItemIndex) {
        onDispose {
            surah?.let { s ->
                val visibleIndex = listState.firstVisibleItemIndex
                if (visibleIndex >= 0 && visibleIndex < s.ayahs.size) {
                    val ayah = s.ayahs[visibleIndex]
                    viewModel.saveLastRead(s.number, s.name, ayah.numberInSurah)
                }
            }
        }
    }

    if (surah == null) {
        Box(modifier = Modifier.fillMaxSize().background(AppBackground), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AppPrimary)
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(surah!!.name, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.decreaseFontSize() }) {
                        Icon(Icons.Outlined.ZoomOut, contentDescription = "تصغير الخط", tint = Color.White)
                    }
                    IconButton(onClick = { viewModel.increaseFontSize() }) {
                        Icon(Icons.Outlined.ZoomIn, contentDescription = "تكبير الخط", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppSurface)
            )
        },
        containerColor = AppBackground
    ) { paddingValues ->
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = paddingValues.calculateTopPadding() + 16.dp, bottom = 80.dp, start = 16.dp, end = 16.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "سُورَةُ ${surah!!.name}",
                        color = AppPrimary,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    
                    if (surah!!.number != 1 && surah!!.number != 9) {
                        Text(
                            text = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
                            color = Color.White,
                            fontSize = fontSize.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                    }
                }
            }
            
            items(surah!!.ayahs) { ayah ->
                AyahItem(ayah, fontSize) {
                    selectedAyah = ayah
                    showBottomSheet = true
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
    
    if (showBottomSheet && selectedAyah != null) {
        ModalBottomSheet(
            onDismissRequest = { showBottomSheet = false },
            containerColor = AppSurface,
            scrimColor = Color.Black.copy(alpha = 0.5f)
        ) {
            AyahActionsSheet(
                surah = surah!!,
                ayah = selectedAyah!!,
                viewModel = viewModel,
                onDismiss = { showBottomSheet = false }
            )
        }
    }
}

@Composable
fun AyahItem(ayah: Ayah, fontSize: Float, onClick: () -> Unit) {
    val numberSymbol = convertToArabicNumberSymbol(ayah.numberInSurah)
    Text(
        text = "${ayah.text} $numberSymbol",
        color = Color.White,
        fontSize = fontSize.sp,
        lineHeight = (fontSize * 1.8f).sp,
        textAlign = TextAlign.Justify,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(4.dp)
    )
}

fun convertToArabicNumberSymbol(number: Int): String {
    val arabicNumbers = arrayOf("٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩")
    val arabicNumberString = number.toString().map { char ->
        if (char.isDigit()) arabicNumbers[char.toString().toInt()] else char
    }.joinToString("")
    return "﴿$arabicNumberString﴾"
}

@Composable
fun AyahActionsSheet(
    surah: com.example.data.Surah,
    ayah: Ayah,
    viewModel: SurahViewModel,
    onDismiss: () -> Unit
) {
    val isBookmarked by viewModel.isBookmarked(surah.number, ayah.numberInSurah).collectAsState(initial = false)
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text("سورة ${surah.name} - الآية ${ayah.numberInSurah}", color = AppPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        
        ListItem(
            headlineContent = { Text(if (isBookmarked) "إزالة العلامة المرجعية" else "إضافة علامة مرجعية", color = Color.White) },
            leadingContent = { 
                Icon(
                    if (isBookmarked) Icons.Outlined.Bookmark else Icons.Outlined.BookmarkBorder, 
                    contentDescription = null, 
                    tint = AppPrimary
                ) 
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            modifier = Modifier.clickable {
                viewModel.toggleBookmark(surah.number, surah.name, ayah.numberInSurah, ayah.text, isBookmarked)
                onDismiss()
            }
        )
        
        ListItem(
            headlineContent = { Text("التفسير", color = Color.White) },
            supportingContent = { Text("بنية التفسير جاهزة للإضافة لاحقاً", color = Color.White.copy(alpha = 0.5f)) },
            leadingContent = { Icon(Icons.Outlined.MenuBook, contentDescription = null, tint = AppPrimary) },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            modifier = Modifier.clickable {
                // Placeholder for Tafsir feature
                onDismiss()
            }
        )
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}
