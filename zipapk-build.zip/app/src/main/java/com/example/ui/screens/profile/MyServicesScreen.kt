package com.example.ui.screens.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.CustomService
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun MyServicesScreen(
    providerId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val servicesState by authViewModel.customServicesState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var serviceToEdit by remember { mutableStateOf<CustomService?>(null) }

    LaunchedEffect(providerId) {
        authViewModel.loadCustomServices(providerId)
    }

    Scaffold(
        topBar = { KhedmatiTopBar(title = "خدماتي", onNavigateBack = onNavigateBack) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, "إضافة خدمة")
            }
        }
    ) { padding ->
        when (val state = servicesState) {
            is AuthResult.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            is AuthResult.Success -> {
                LazyColumn(
                    modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(state.data) { service ->
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = service.name, style = MaterialTheme.typography.titleMedium)
                                    if (service.description.isNotBlank()) Text(text = service.description, style = MaterialTheme.typography.bodySmall)
                                }
                                Row {
                                    IconButton(onClick = { serviceToEdit = service; showAddDialog = true }) {
                                        Icon(Icons.Default.Edit, "تعديل")
                                    }
                                    IconButton(onClick = { authViewModel.deleteCustomService(providerId, service.id) { _, _ -> } }) {
                                        Icon(Icons.Default.Delete, "حذف")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else -> {}
        }

        if (showAddDialog) {
            AddEditServiceDialog(
                providerId = providerId,
                service = serviceToEdit,
                onDismiss = { showAddDialog = false; serviceToEdit = null },
                onSave = { service ->
                    if (service.id.isBlank()) authViewModel.addCustomService(service) { _, _ -> }
                    else authViewModel.updateCustomService(service) { _, _ -> }
                    showAddDialog = false
                    serviceToEdit = null
                }
            )
        }
    }
}
