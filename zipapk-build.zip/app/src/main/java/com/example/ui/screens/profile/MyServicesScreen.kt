package com.example.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomService
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun MyServicesScreen(
    providerId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val servicesState by authViewModel.customServicesState.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var serviceToEdit by remember { mutableStateOf<CustomService?>(null) }

    LaunchedEffect(providerId) {
        authViewModel.loadCustomServices(providerId)
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "خدماتي المهنية",
                onNavigateBack = onNavigateBack
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = BluePrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Add, "إضافة خدمة")
            }
        },
        containerColor = BackgroundLight
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (val state = servicesState) {
                is AuthResult.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary)
                    }
                }
                is AuthResult.Success -> {
                    if (state.data.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Handyman, null, modifier = Modifier.size(64.dp), tint = OutlineLight)
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(text = "لم تقم بإضافة أي خدمات مخصصة بعد", color = TextTertiaryLight)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(20.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.data) { service ->
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = service.name,
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = BlueDark
                                            )
                                            if (service.description.isNotBlank()) {
                                                Text(
                                                    text = service.description,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextTertiaryLight
                                                )
                                            }
                                        }
                                        Row {
                                            IconButton(
                                                onClick = { serviceToEdit = service; showAddDialog = true },
                                                modifier = Modifier.size(40.dp)
                                            ) {
                                                Icon(Icons.Default.Edit, "تعديل", tint = BluePrimary, modifier = Modifier.size(20.dp))
                                            }
                                            IconButton(
                                                onClick = { authViewModel.deleteCustomService(providerId, service.id) { _, _ -> } },
                                                modifier = Modifier.size(40.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, "حذف", tint = ErrorRed, modifier = Modifier.size(20.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                is AuthResult.Error -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = "فشل تحميل الخدمات: ${state.messageAr}", color = ErrorRed)
                    }
                }
                else -> {}
            }
        }

        if (showAddDialog) {
            AddEditServiceDialog(
                providerId = providerId,
                service = serviceToEdit,
                onDismiss = { showAddDialog = false; serviceToEdit = null },
                onSave = { service ->
                    if (service.id.isBlank()) authViewModel.addCustomService(service) { _, _ -> }
                    else authViewModel.updateCustomService(service) { _, _ -> }
                    showAddDialog = false
                    serviceToEdit = null
                }
            )
        }
    }
}
