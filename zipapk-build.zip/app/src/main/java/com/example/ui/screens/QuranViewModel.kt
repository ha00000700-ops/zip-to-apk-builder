package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AyahSearchResult
import com.example.data.QuranRepository
import com.example.data.Surah
import com.example.data.db.LastRead
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class QuranViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = QuranRepository(application)
    
    private val _surahs = MutableStateFlow<List<Surah>>(emptyList())
    val surahs: StateFlow<List<Surah>> = _surahs
    
    private val _searchResults = MutableStateFlow<List<AyahSearchResult>>(emptyList())
    val searchResults: StateFlow<List<AyahSearchResult>> = _searchResults
    
    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching
    
    val lastRead: StateFlow<LastRead?> = repository.getLastRead().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )
    
    val bookmarks = repository.getAllBookmarks().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        loadSurahs()
    }
    
    private fun loadSurahs() {
        viewModelScope.launch {
            _surahs.value = repository.getSurahs()
        }
    }
    
    fun search(query: String) {
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        
        _isSearching.value = true
        viewModelScope.launch {
            _searchResults.value = repository.search(query)
            _isSearching.value = false
        }
    }
    
    fun clearSearch() {
        _searchResults.value = emptyList()
    }
    
    fun saveLastRead(surahNumber: Int, surahName: String, ayahNumber: Int) {
        viewModelScope.launch {
            repository.saveLastRead(surahNumber, surahName, ayahNumber)
        }
    }
}
