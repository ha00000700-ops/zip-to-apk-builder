package com.example.ui.screens.requests

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.EmptyState
import com.example.ui.components.StatusBadge
import com.example.ui.components.UrgencyBadge
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestsListScreen(
    currentUser: UserEntity?,
    currentPro: ProfessionalEntity?,
    requestsList: List<ServiceRequestEntity>,
    onSelectRequest: (ServiceRequestEntity) -> Unit,
    onCreateNewRequest: () -> Unit,
    onAcceptRequest: (ServiceRequestEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedFilterTab by remember { mutableStateOf(0) } // 0: All, 1: Active, 2: Completed

    val isPro = currentUser?.role == UserRole.PROFESSIONAL || currentPro != null

    val filteredRequests = remember(requestsList, selectedFilterTab) {
        when (selectedFilterTab) {
            1 -> requestsList.filter { it.status != RequestStatus.COMPLETED && it.status != RequestStatus.CANCELLED }
            2 -> requestsList.filter { it.status == RequestStatus.COMPLETED }
            else -> requestsList
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("requests_list_screen")
    ) {
        // Header
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isPro) "لوحة طلبات الحرفي" else "طلباتي ومتابعة الخدمات",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isPro) "إدارة الطلبات الموجهة إليك والمهام في ولايتك" else "متابعة وتتبع الحرفيين وتقييم الخدمة",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (!isPro) {
                        FilledTonalButton(
                            onClick = onCreateNewRequest,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("طلب جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Filter Tabs
                TabRow(
                    selectedTabIndex = selectedFilterTab,
                    containerColor = Color.Transparent,
                    divider = {}
                ) {
                    Tab(
                        selected = selectedFilterTab == 0,
                        onClick = { selectedFilterTab = 0 },
                        text = { Text("الكل (${requestsList.size})", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedFilterTab == 1,
                        onClick = { selectedFilterTab = 1 },
                        text = {
                            val activeCount = requestsList.count { it.status != RequestStatus.COMPLETED && it.status != RequestStatus.CANCELLED }
                            Text("قيد المتابعة ($activeCount)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    )
                    Tab(
                        selected = selectedFilterTab == 2,
                        onClick = { selectedFilterTab = 2 },
                        text = {
                            val doneCount = requestsList.count { it.status == RequestStatus.COMPLETED }
                            Text("المكتملة ($doneCount)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    )
                }
            }
        }

        // Requests List
        if (filteredRequests.isEmpty()) {
            EmptyState(
                title = if (isPro) "لا توجد طلبات واردة حالياً" else "لا توجد لديك طلبات في هذه القائمة",
                description = if (isPro) "ستظهر هنا أي طلبات خدمة جديدة موجهة إليك في ولايتك" else "يمكنك إنشاء طلب خدمة جديد وسيتواصل معك الحرفيون في أقرب وقت.",
                icon = Icons.Outlined.Assignment,
                actionLabel = if (!isPro) "إنشاء طلب خدمة" else null,
                onAction = if (!isPro) onCreateNewRequest else null
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredRequests, key = { it.id }) { req ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectRequest(req) }
                            .testTag("request_item_${req.id}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header Row: Service + Status Badge
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(DzGreenLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Build, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(18.dp))
                                    }
                                    Column {
                                        Text(
                                            text = if (req.title.isNotBlank()) req.title else req.serviceNameAr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "رقم الطلب #${req.id} • ${req.serviceNameAr}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                StatusBadge(status = req.status)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Description
                            Text(
                                text = req.description,
                                fontSize = 13.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Details Row (Urgency + Location + Price if agreed)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    UrgencyBadge(urgency = req.urgency)

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(13.dp))
                                        Text(
                                            text = "${req.wilayaNameAr} • ${req.communeNameAr}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                if (req.agreedPriceDzd != null) {
                                    Text(
                                        text = "${req.agreedPriceDzd.toInt()} دج",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = DzGreenPrimary
                                    )
                                }
                            }


                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(8.dp))

                            // Partner info & Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isPro) {
                                    Text(
                                        text = "الزبون: ${req.customerName} (${req.customerPhone})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Text(
                                        text = if (req.professionalName != null) "الحرفي: ${req.professionalName}" else "طلب عام لجميع الحرفيين",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // If Pro and request is NEW/Unassigned, allow Quick Accept
                                    if (isPro && (req.status == RequestStatus.NEW || req.professionalUid.isBlank())) {
                                        Button(
                                            onClick = { onAcceptRequest(req) },
                                            colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("قبول الطلب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Quick Call Button
                                    val targetPhone = if (isPro) req.customerPhone else req.professionalPhone
                                    if (!targetPhone.isNullOrBlank()) {
                                        IconButton(
                                            onClick = {
                                                val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$targetPhone"))
                                                try {
                                                    context.startActivity(dialIntent)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "الهاتف: $targetPhone", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            modifier = Modifier.size(32.dp).clip(CircleShape).background(DzGreenLight)
                                        ) {
                                            Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = DzGreenPrimary, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    TextButton(
                                        onClick = { onSelectRequest(req) },
                                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text("التفاصيل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Icon(Icons.Default.ChevronLeft, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
