package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EditLocation
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CityWeatherData
import com.example.data.model.WeatherConditionType
import com.example.ui.theme.CardTransparencyStyle
import kotlin.math.roundToInt

@Composable
fun SideBySideWeatherCards(
    userWeather: CityWeatherData?,
    partnerWeather: CityWeatherData?,
    userName: String,
    partnerName: String,
    cardStyle: CardTransparencyStyle = CardTransparencyStyle.TRANSLUCENT_GLASS,
    onSelectUserCity: () -> Unit,
    onSelectPartnerCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Dual Side-by-Side Weather Columns
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // User's City Card
            ModernSingleWeatherCard(
                title = "مدينة $userName",
                weatherData = userWeather,
                accentColor = Color(0xFF38BDF8),
                cardStyle = cardStyle,
                onChangeCity = onSelectUserCity,
                modifier = Modifier
                    .weight(1f)
                    .testTag("user_weather_card")
            )

            // Partner's City Card
            ModernSingleWeatherCard(
                title = "مدينة $partnerName",
                weatherData = partnerWeather,
                accentColor = MaterialTheme.colorScheme.primary,
                cardStyle = cardStyle,
                onChangeCity = onSelectPartnerCity,
                modifier = Modifier
                    .weight(1f)
                    .testTag("partner_weather_card")
            )
        }

        // Innovative Feature: Contextual Couple Outfit & Romantic Activity Advice
        CoupleWeatherAdviceCard(
            userWeather = userWeather,
            partnerWeather = partnerWeather,
            userName = userName,
            partnerName = partnerName,
            cardStyle = cardStyle
        )
    }
}

@Composable
fun ModernSingleWeatherCard(
    title: String,
    weatherData: CityWeatherData?,
    accentColor: Color,
    cardStyle: CardTransparencyStyle = CardTransparencyStyle.TRANSLUCENT_GLASS,
    onChangeCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val condition = weatherData?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: WeatherConditionType.CLEAR_DAY

    val cardBorder = if (cardStyle == CardTransparencyStyle.GLOW_ROMANTIC) {
        BorderStroke(1.5.dp, accentColor.copy(alpha = cardStyle.borderAlpha))
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = cardStyle.borderAlpha))
    }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        border = cardBorder,
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = cardStyle.surfaceAlpha)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    maxLines = 1
                )

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(accentColor.copy(alpha = 0.12f), CircleShape)
                        .clickable(onClick = onChangeCity),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.EditLocation,
                        contentDescription = "تغيير المدينة",
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // City name
            Text(
                text = weatherData?.city?.name ?: "تحميل...",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Weather Icon Badge
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(
                        Brush.radialGradient(listOf(accentColor.copy(alpha = 0.25f), Color.Transparent)),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getWeatherIcon(condition),
                    contentDescription = condition.titleArabic,
                    tint = accentColor,
                    modifier = Modifier.size(34.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Temperature
            val temp = weatherData?.current?.temperature
            Text(
                text = if (temp != null) "${temp.roundToInt()}°C" else "--°C",
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Weather Condition Label
            Text(
                text = condition.titleArabic,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Metrics Row (Feels-like, Humidity, Wind)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        RoundedCornerShape(14.dp)
                    )
                    .padding(vertical = 7.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Feels like
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = "محسوسة",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.apparentTemperature?.roundToInt() ?: "--"}°",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Humidity
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = "رطوبة",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.relativeHumidity ?: "--"}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Wind
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "رياح",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.windSpeed?.roundToInt() ?: "--"}k",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Intelligent Weather Advice Card for both lovers based on current meteorological conditions
 */
@Composable
private fun CoupleWeatherAdviceCard(
    userWeather: CityWeatherData?,
    partnerWeather: CityWeatherData?,
    userName: String,
    partnerName: String,
    cardStyle: CardTransparencyStyle
) {
    val partnerCondition = partnerWeather?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: WeatherConditionType.CLEAR_DAY

    val partnerTemp = partnerWeather?.current?.temperature ?: 22.0

    val outfitAdvice = when {
        partnerCondition == WeatherConditionType.RAINY ->
            "الجو ماطر عند $partnerName 🌧️ - انصحها بحمل مظلة أنيقة وارتداء معطف دافئ ومقاوم للماء!"
        partnerCondition == WeatherConditionType.SNOWY || partnerTemp < 10.0 ->
            "الطقس بارد عند $partnerName 🧣 - كنزة صوفية دافئة، وشاح أنيق ومشروب ساخن يحميها من البرد!"
        partnerTemp > 30.0 ->
            "حرارة مرتفعة عند $partnerName ☀️ - ملابس قطنية خفيفة، قبعة صيفية، وتذكير بشرب الماء بانتظام!"
        partnerCondition == WeatherConditionType.CLEAR_NIGHT ->
            "ليلة هادئة مقمرة عند $partnerName 🌙 - مناسبة جداً لمكالمة ليلية دافئة قبل النوم!"
        else ->
            "جو معتدل ورائع عند $partnerName 🌸 - إطلالة كاجوال مريحة، وجو يشجع على تبادل الرسائل اللطيفة!"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("couple_weather_advice_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = cardStyle.surfaceAlpha)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Checkroom,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "رادار النصائح لـ $partnerName 💡",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = outfitAdvice,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

fun getWeatherIcon(condition: WeatherConditionType): ImageVector {
    return when (condition) {
        WeatherConditionType.CLEAR_DAY -> Icons.Default.WbSunny
        WeatherConditionType.CLEAR_NIGHT -> Icons.Default.NightsStay
        WeatherConditionType.CLOUDY, WeatherConditionType.PARTLY_CLOUDY, WeatherConditionType.FOGGY -> Icons.Default.Cloud
        WeatherConditionType.RAINY, WeatherConditionType.THUNDERSTORM -> Icons.Default.WaterDrop
        WeatherConditionType.SNOWY -> Icons.Default.WaterDrop
    }
}
