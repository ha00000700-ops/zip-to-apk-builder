package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.EditLocation
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CityWeatherData
import com.example.data.model.WeatherConditionType
import com.example.ui.theme.RoseLight
import com.example.ui.theme.RosePrimary

@Composable
fun SideBySideWeatherCards(
    userWeather: CityWeatherData?,
    partnerWeather: CityWeatherData?,
    userName: String,
    partnerName: String,
    onSelectUserCity: () -> Unit,
    onSelectPartnerCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // User's City Card
            SingleCoupleCityCard(
                title = "مدينة $userName",
                weatherData = userWeather,
                accentColor = Color(0xFF38BDF8),
                onChangeCity = onSelectUserCity,
                modifier = Modifier
                    .weight(1f)
                    .testTag("user_weather_card")
            )

            // Partner's City Card
            SingleCoupleCityCard(
                title = "مدينة $partnerName",
                weatherData = partnerWeather,
                accentColor = Color(0xFFF43F5E),
                onChangeCity = onSelectPartnerCity,
                modifier = Modifier
                    .weight(1f)
                    .testTag("partner_weather_card")
            )
        }
    }
}

@Composable
fun SingleCoupleCityCard(
    title: String,
    weatherData: CityWeatherData?,
    accentColor: Color,
    onChangeCity: () -> Unit,
    modifier: Modifier = Modifier
) {
    val condition = weatherData?.let {
        WeatherConditionType.fromWmoCode(it.current.weatherCode, it.current.isDay)
    } ?: WeatherConditionType.CLEAR_DAY

    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = androidx.compose.material3.CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header: Card Role + Change location button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = accentColor,
                    maxLines = 1
                )

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(accentColor.copy(alpha = 0.12f), CircleShape)
                        .clickable(onClick = onChangeCity),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.EditLocation,
                        contentDescription = "تغيير المدينة",
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // City name
            Text(
                text = weatherData?.city?.name ?: "جاري التحميل...",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Weather Icon & Temp
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .background(
                        Brush.radialGradient(listOf(accentColor.copy(alpha = 0.25f), Color.Transparent)),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getWeatherIcon(condition),
                    contentDescription = condition.titleArabic,
                    tint = accentColor,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Temperature
            val temp = weatherData?.current?.temperature
            Text(
                text = if (temp != null) "${temp.toInt()}°C" else "--°C",
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Condition title
            Text(
                text = condition.titleArabic,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Weather Metrics mini row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(vertical = 6.dp, horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Feels like
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = "محسوسة",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.apparentTemperature?.toInt() ?: "--"}°",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Humidity
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = "رطوبة",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.relativeHumidity ?: "--"}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Wind
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = "رياح",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${weatherData?.current?.windSpeed?.toInt() ?: "--"}k",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Cute couple note for this city's weather
            Text(
                text = condition.romanticSubtitle,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}

fun getWeatherIcon(condition: WeatherConditionType): ImageVector {
    return when (condition) {
        WeatherConditionType.CLEAR_DAY -> Icons.Default.WbSunny
        WeatherConditionType.CLEAR_NIGHT -> Icons.Default.NightsStay
        WeatherConditionType.CLOUDY, WeatherConditionType.PARTLY_CLOUDY, WeatherConditionType.FOGGY -> Icons.Default.Cloud
        WeatherConditionType.RAINY, WeatherConditionType.THUNDERSTORM -> Icons.Default.WaterDrop
        WeatherConditionType.SNOWY -> Icons.Default.WaterDrop
    }
}
