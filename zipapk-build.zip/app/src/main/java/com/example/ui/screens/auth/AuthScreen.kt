package com.example.ui.screens.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceCategoryEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.components.ServiceIcon
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.DzGreenLight
import com.example.ui.theme.DzGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    services: List<ServiceCategoryEntity>,
    onLoginWithEmailPassword: (email: String, password: String, onDone: (Boolean, String?) -> Unit) -> Unit,
    onRegisterCustomer: (
        name: String,
        phone: String,
        email: String,
        password: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        onDone: (Boolean, String?) -> Unit
    ) -> Unit,
    onRegisterProfessional: (
        name: String,
        phone: String,
        email: String,
        password: String,
        whatsapp: String,
        serviceId: Long,
        serviceName: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        exp: Int,
        bio: String,
        workingHours: String,
        price: String,
        onDone: (Boolean, String?) -> Unit
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedAuthTab by remember { mutableStateOf(0) } // 0: Login, 1: Customer Reg, 2: Pro Reg

    // Login Form State
    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var isLoggingIn by remember { mutableStateOf(false) }

    // Customer Form State
    var custName by remember { mutableStateOf("") }
    var custPhone by remember { mutableStateOf("") }
    var custEmail by remember { mutableStateOf("") }
    var custPassword by remember { mutableStateOf("") }
    var custWilayaCode by remember { mutableStateOf(16) }
    var custWilayaName by remember { mutableStateOf("الجزائر") }
    var custCommuneName by remember { mutableStateOf("الجزائر الوسطى") }
    var isRegisteringCust by remember { mutableStateOf(false) }

    // Pro Form State
    var proName by remember { mutableStateOf("") }
    var proPhone by remember { mutableStateOf("") }
    var proEmail by remember { mutableStateOf("") }
    var proPassword by remember { mutableStateOf("") }
    var proWhatsapp by remember { mutableStateOf("") }
    var proServiceId by remember { mutableStateOf(services.firstOrNull()?.id ?: 1L) }
    var proServiceName by remember { mutableStateOf(services.firstOrNull()?.nameAr ?: "سباكة") }
    var proWilayaCode by remember { mutableStateOf(16) }
    var proWilayaName by remember { mutableStateOf("الجزائر") }
    var proCommuneName by remember { mutableStateOf("حيدرة") }
    var proExpYears by remember { mutableStateOf("5") }
    var proBio by remember { mutableStateOf("") }
    var proWorkingHours by remember { mutableStateOf("08:00 - 18:00 (السبت - الخميس)") }
    var proPriceEstimate by remember { mutableStateOf("حسب المعاينة") }
    var isRegisteringPro by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("auth_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Logo & Welcome
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(DzGreenPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("منصة خدملي DZ 🇩🇿", fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("سجل دخولك أو أنشئ حساباً حقيقياً في Firebase", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Tab Selector
        item {
            TabRow(
                selectedTabIndex = selectedAuthTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                divider = {}
            ) {
                Tab(
                    selected = selectedAuthTab == 0,
                    onClick = { selectedAuthTab = 0 },
                    text = { Text("تسجيل الدخول", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedAuthTab == 1,
                    onClick = { selectedAuthTab = 1 },
                    text = { Text("حساب زبون", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedAuthTab == 2,
                    onClick = { selectedAuthTab = 2 },
                    text = { Text("حساب حرفي", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        // TAB 0: LOGIN
        if (selectedAuthTab == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("تسجيل الدخول عبر البريد الإلكتروني:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = loginEmail,
                            onValueChange = { loginEmail = it },
                            placeholder = { Text("البريد الإلكتروني (مثال: user@khdemli.dz)") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("login_phone_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            placeholder = { Text("كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("login_password_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val email = loginEmail.trim()
                                val password = loginPassword.trim()
                                if (email.isBlank() || !email.contains("@") || !email.contains(".")) {
                                    Toast.makeText(context, "الرجاء إدخال بريد إلكتروني صالح", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (password.length < 6) {
                                    Toast.makeText(context, "كلمة المرور يجب أن تتكون من 6 أحرف على الأقل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                isLoggingIn = true
                                onLoginWithEmailPassword(email, password) { success, errMsg ->
                                    isLoggingIn = false
                                    if (!success) {
                                        val msg = errMsg ?: "فشل تسجيل الدخول. تحقق من صحة البريد وكلمة المرور في Firebase"
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "تم تسجيل الدخول بنجاح عبر Firebase", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            enabled = !isLoggingIn,
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("login_submit_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isLoggingIn) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                            } else {
                                Text("دخول إلى حسابي", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: REGISTER CUSTOMER
        if (selectedAuthTab == 1) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("إنشاء حساب زبون جديد في Firebase:", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                        OutlinedTextField(
                            value = custName,
                            onValueChange = { custName = it },
                            label = { Text("الاسم واللقب") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("cust_reg_name"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custPhone,
                            onValueChange = { custPhone = it },
                            label = { Text("رقم الهاتف") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("cust_reg_phone"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custEmail,
                            onValueChange = { custEmail = it },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custPassword,
                            onValueChange = { custPassword = it },
                            label = { Text("كلمة المرور (6 أحرف على الأقل)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        WilayaCommuneSelector(
                            selectedWilayaCode = custWilayaCode,
                            selectedCommuneName = custCommuneName,
                            onLocationSelected = { code, wName, cName ->
                                custWilayaCode = code
                                custWilayaName = wName
                                custCommuneName = cName
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val name = custName.trim()
                                val phone = custPhone.trim()
                                val email = custEmail.trim()
                                val pass = custPassword.trim()

                                if (name.isBlank() || phone.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال الاسم ورقم الهاتف", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (!email.contains("@") || !email.contains(".")) {
                                    Toast.makeText(context, "الرجاء إدخال بريد إلكتروني صالح", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (pass.length < 6) {
                                    Toast.makeText(context, "كلمة المرور يجب أن تكون 6 أحرف على الأقل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                isRegisteringCust = true
                                onRegisterCustomer(name, phone, email, pass, custWilayaCode, custWilayaName, custCommuneName) { success, errorMsg ->
                                    isRegisteringCust = false
                                    if (success) {
                                        Toast.makeText(context, "تم إنشاء الحساب بنجاح في Firebase!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, errorMsg ?: "فشل إنشاء الحساب في Firebase", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isRegisteringCust,
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("cust_reg_submit"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isRegisteringCust) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                            } else {
                                Text("تسجيل الحساب", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: REGISTER PROFESSIONAL
        if (selectedAuthTab == 2) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("تسجيل كحرفي في Firebase:", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                        OutlinedTextField(
                            value = proName,
                            onValueChange = { proName = it },
                            label = { Text("اسم الحرفي أو الورشة") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("pro_reg_name"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPhone,
                            onValueChange = { proPhone = it },
                            label = { Text("رقم الهاتف للاتصال") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("pro_reg_phone"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proEmail,
                            onValueChange = { proEmail = it },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPassword,
                            onValueChange = { proPassword = it },
                            label = { Text("كلمة المرور (6 أحرف على الأقل)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        OutlinedTextField(
                            value = proWhatsapp,
                            onValueChange = { proWhatsapp = it },
                            label = { Text("رقم الواتساب (WhatsApp)") },
                            leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text("اختر المهنة الرئيسية:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            items(services) { s ->
                                val isSel = s.id == proServiceId
                                FilterChip(
                                    selected = isSel,
                                    onClick = {
                                        proServiceId = s.id
                                        proServiceName = s.nameAr
                                    },
                                    label = { Text(s.nameAr, fontSize = 11.sp) },
                                    leadingIcon = { ServiceIcon(s.iconName, modifier = Modifier.size(14.dp)) }
                                )
                            }
                        }

                        WilayaCommuneSelector(
                            selectedWilayaCode = proWilayaCode,
                            selectedCommuneName = proCommuneName,
                            onLocationSelected = { code, wName, cName ->
                                proWilayaCode = code
                                proWilayaName = wName
                                proCommuneName = cName
                            }
                        )

                        OutlinedTextField(
                            value = proExpYears,
                            onValueChange = { proExpYears = it },
                            label = { Text("سنوات الخبرة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proBio,
                            onValueChange = { proBio = it },
                            label = { Text("نبذة عن خبرتك والخدمات التي تتقنها") },
                            placeholder = { Text("مثال: خبرة 7 سنوات في التمديدات الصحية وكشف التسريبات...") },
                            modifier = Modifier.fillMaxWidth().height(90.dp),
                            maxLines = 4
                        )

                        OutlinedTextField(
                            value = proWorkingHours,
                            onValueChange = { proWorkingHours = it },
                            label = { Text("أوقات العمل المتاحة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPriceEstimate,
                            onValueChange = { proPriceEstimate = it },
                            label = { Text("التسعيرة التقديرية (مثال: تبدأ من 1500 دج)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val name = proName.trim()
                                val phone = proPhone.trim()
                                val email = proEmail.trim()
                                val pass = proPassword.trim()

                                if (name.isBlank() || phone.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال الاسم ورقم الهاتف", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (!email.contains("@") || !email.contains(".")) {
                                    Toast.makeText(context, "الرجاء إدخال بريد إلكتروني صالح", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (pass.length < 6) {
                                    Toast.makeText(context, "كلمة المرور يجب أن تكون 6 أحرف على الأقل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                val exp = proExpYears.toIntOrNull() ?: 3
                                isRegisteringPro = true
                                onRegisterProfessional(
                                    name,
                                    phone,
                                    email,
                                    pass,
                                    if (proWhatsapp.isBlank()) phone else proWhatsapp.trim(),
                                    proServiceId,
                                    proServiceName,
                                    proWilayaCode,
                                    proWilayaName,
                                    proCommuneName,
                                    exp,
                                    proBio,
                                    proWorkingHours,
                                    proPriceEstimate
                                ) { success, errorMsg ->
                                    isRegisteringPro = false
                                    if (success) {
                                        Toast.makeText(context, "تم تسجيل حساب الحرفي بنجاح في Firebase!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, errorMsg ?: "فشل تسجيل حساب الحرفي في Firebase", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = !isRegisteringPro,
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pro_reg_submit"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isRegisteringPro) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                            } else {
                                Text("إنشاء الملف المهني للحرفي", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
