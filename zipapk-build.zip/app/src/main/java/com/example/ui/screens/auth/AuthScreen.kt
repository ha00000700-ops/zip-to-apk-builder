package com.example.ui.screens.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceCategoryEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.components.ServiceIcon
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.DzGreenLight
import com.example.ui.theme.DzGreenPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    services: List<ServiceCategoryEntity>,
    allDemoUsers: List<UserEntity>,
    onLoginSuccess: (UserEntity) -> Unit,
    onLoginWithEmailPassword: (email: String, password: String, onDone: (Boolean) -> Unit) -> Unit = { _, _, _ -> },
    onLoginWithPhone: (phone: String, onDone: (Boolean) -> Unit) -> Unit = { _, _ -> },
    onRegisterCustomer: (name: String, phone: String, email: String, password: String, wilayaCode: Int, wilayaName: String, communeName: String) -> Unit,
    onRegisterProfessional: (
        name: String,
        phone: String,
        email: String,
        password: String,
        whatsapp: String,
        serviceId: Long,
        serviceName: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        exp: Int,
        bio: String,
        workingHours: String,
        price: String
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedAuthTab by remember { mutableStateOf(0) } // 0: Login / Switch Demo, 1: Customer Reg, 2: Pro Reg

    // Login Form State
    var loginInput by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var isLoggingIn by remember { mutableStateOf(false) }

    // Customer Form State
    var custName by remember { mutableStateOf("") }
    var custPhone by remember { mutableStateOf("") }
    var custEmail by remember { mutableStateOf("") }
    var custPassword by remember { mutableStateOf("") }
    var custWilayaCode by remember { mutableStateOf(16) }
    var custWilayaName by remember { mutableStateOf("الجزائر") }
    var custCommuneName by remember { mutableStateOf("الجزائر الوسطى") }

    // Pro Form State
    var proName by remember { mutableStateOf("") }
    var proPhone by remember { mutableStateOf("") }
    var proEmail by remember { mutableStateOf("") }
    var proPassword by remember { mutableStateOf("") }
    var proWhatsapp by remember { mutableStateOf("") }
    var proServiceId by remember { mutableStateOf(services.firstOrNull()?.id ?: 1L) }
    var proServiceName by remember { mutableStateOf(services.firstOrNull()?.nameAr ?: "سباكة") }
    var proWilayaCode by remember { mutableStateOf(16) }
    var proWilayaName by remember { mutableStateOf("الجزائر") }
    var proCommuneName by remember { mutableStateOf("حيدرة") }
    var proExpYears by remember { mutableStateOf("5") }
    var proBio by remember { mutableStateOf("") }
    var proWorkingHours by remember { mutableStateOf("08:00 - 18:00 (السبت - الخميس)") }
    var proPriceEstimate by remember { mutableStateOf("حسب المعاينة") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("auth_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Logo & Welcome
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(DzGreenPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Handyman, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text("منصة خدملي DZ 🇩🇿", fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text("سجل دخولك أو أنشئ حساباً جديداً في 58 ولاية", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Tab Selector
        item {
            TabRow(
                selectedTabIndex = selectedAuthTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                divider = {}
            ) {
                Tab(
                    selected = selectedAuthTab == 0,
                    onClick = { selectedAuthTab = 0 },
                    text = { Text("تسجيل الدخول", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedAuthTab == 1,
                    onClick = { selectedAuthTab = 1 },
                    text = { Text("حساب زبون", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedAuthTab == 2,
                    onClick = { selectedAuthTab = 2 },
                    text = { Text("حساب حرفي", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                )
            }
        }

        // TAB 0: LOGIN & QUICK DEMO SWITCHER
        if (selectedAuthTab == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("تسجيل الدخول (البريد أو رقم الهاتف):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = loginInput,
                            onValueChange = { loginInput = it },
                            placeholder = { Text("أدخل البريد الإلكتروني أو رقم الهاتف") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("login_phone_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            placeholder = { Text("كلمة المرور") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("login_password_input"),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                val trimmed = loginInput.trim()
                                if (trimmed.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال البريد أو رقم الهاتف", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                isLoggingIn = true

                                // Check demo users first for instant offline preview if desired
                                val foundDemo = allDemoUsers.find { it.phone.trim() == trimmed || it.email.equals(trimmed, ignoreCase = true) }
                                if (foundDemo != null && loginPassword.isBlank()) {
                                    onLoginSuccess(foundDemo)
                                    Toast.makeText(context, "مرحباً ${foundDemo.fullName}", Toast.LENGTH_SHORT).show()
                                    isLoggingIn = false
                                    return@Button
                                }

                                if (trimmed.contains("@")) {
                                    onLoginWithEmailPassword(trimmed, loginPassword) { success ->
                                        isLoggingIn = false
                                        if (!success) {
                                            Toast.makeText(context, "فشل تسجيل الدخول. تحقق من البريد وكلمة المرور", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    onLoginWithPhone(trimmed) { success ->
                                        isLoggingIn = false
                                        if (!success) {
                                            val found = allDemoUsers.find { it.phone.trim() == trimmed }
                                            if (found != null) {
                                                onLoginSuccess(found)
                                            } else {
                                                Toast.makeText(context, "الرقم غير مسجل، يمكنك تجربة الحسابات الجاهزة أدناه أو إنشاء حساب جديد", Toast.LENGTH_LONG).show()
                                            }
                                        } else {
                                            Toast.makeText(context, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            enabled = !isLoggingIn,
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("login_submit_btn"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            if (isLoggingIn) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White)
                            } else {
                                Text("دخول إلى حسابي", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Quick Demo Accounts Switcher (Very helpful for testing Admin, Client & Artisans)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = DzGreenPrimary)
                            Text("الدخول السريع بحسابات تجريبية جاهزة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Text("اختر أي حساب لتجربة وظائف الزبون، الحرفي، أو لوحة تحكم المدير فوراً:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        Spacer(modifier = Modifier.height(12.dp))

                        allDemoUsers.forEach { demoUser ->
                            Surface(
                                onClick = {
                                    onLoginSuccess(demoUser)
                                    Toast.makeText(context, "تم تسجيل الدخول كـ: ${demoUser.fullName}", Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .testTag("demo_user_${demoUser.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (demoUser.role) {
                                                        UserRole.ADMIN -> Color(0xFFFEF2F2)
                                                        UserRole.PROFESSIONAL -> DzGreenLight
                                                        UserRole.CUSTOMER -> Color(0xFFEFF6FF)
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = when (demoUser.role) {
                                                    UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                                                    UserRole.PROFESSIONAL -> Icons.Default.Handyman
                                                    UserRole.CUSTOMER -> Icons.Default.Person
                                                },
                                                contentDescription = null,
                                                tint = when (demoUser.role) {
                                                    UserRole.ADMIN -> Color(0xFFDC2626)
                                                    UserRole.PROFESSIONAL -> DzGreenPrimary
                                                    UserRole.CUSTOMER -> Color(0xFF2563EB)
                                                },
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }

                                        Column {
                                            Text(demoUser.fullName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text(
                                                text = when (demoUser.role) {
                                                    UserRole.ADMIN -> "مدير المنصة الكامل (صلاحيات Admin)"
                                                    UserRole.PROFESSIONAL -> "حرفي مهني (${demoUser.wilayaNameAr})"
                                                    UserRole.CUSTOMER -> "زبون عادي (${demoUser.wilayaNameAr})"
                                                },
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: REGISTER CUSTOMER
        if (selectedAuthTab == 1) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("إنشاء حساب زبون جديد:", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                        OutlinedTextField(
                            value = custName,
                            onValueChange = { custName = it },
                            label = { Text("الاسم واللقب") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("cust_reg_name"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custPhone,
                            onValueChange = { custPhone = it },
                            label = { Text("رقم الهاتف") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("cust_reg_phone"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custEmail,
                            onValueChange = { custEmail = it },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = custPassword,
                            onValueChange = { custPassword = it },
                            label = { Text("كلمة المرور (6 أحرف على الأقل)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        WilayaCommuneSelector(
                            selectedWilayaCode = custWilayaCode,
                            selectedCommuneName = custCommuneName,
                            onLocationSelected = { code, wName, cName ->
                                custWilayaCode = code
                                custWilayaName = wName
                                custCommuneName = cName
                            }
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                if (custName.isBlank() || custPhone.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال الاسم ورقم الهاتف", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                onRegisterCustomer(custName, custPhone, custEmail, custPassword, custWilayaCode, custWilayaName, custCommuneName)
                                Toast.makeText(context, "تم إنشاء الحساب بنجاح في Firebase!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("cust_reg_submit"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("تسجيل الحساب", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // TAB 2: REGISTER PROFESSIONAL
        if (selectedAuthTab == 2) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("تسجيل كحرفي أو صاحب خدمة:", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                        OutlinedTextField(
                            value = proName,
                            onValueChange = { proName = it },
                            label = { Text("اسم الحرفي أو الورشة") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("pro_reg_name"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPhone,
                            onValueChange = { proPhone = it },
                            label = { Text("رقم الهاتف للاتصال") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth().testTag("pro_reg_phone"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proEmail,
                            onValueChange = { proEmail = it },
                            label = { Text("البريد الإلكتروني") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPassword,
                            onValueChange = { proPassword = it },
                            label = { Text("كلمة المرور (6 أحرف على الأقل)") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation()
                        )

                        OutlinedTextField(
                            value = proWhatsapp,
                            onValueChange = { proWhatsapp = it },
                            label = { Text("رقم الواتساب (WhatsApp)") },
                            leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Text("اختر المهنة الرئيسية:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            items(services) { s ->
                                val isSel = s.id == proServiceId
                                FilterChip(
                                    selected = isSel,
                                    onClick = {
                                        proServiceId = s.id
                                        proServiceName = s.nameAr
                                    },
                                    label = { Text(s.nameAr, fontSize = 11.sp) },
                                    leadingIcon = { ServiceIcon(s.iconName, modifier = Modifier.size(14.dp)) }
                                )
                            }
                        }

                        WilayaCommuneSelector(
                            selectedWilayaCode = proWilayaCode,
                            selectedCommuneName = proCommuneName,
                            onLocationSelected = { code, wName, cName ->
                                proWilayaCode = code
                                proWilayaName = wName
                                proCommuneName = cName
                            }
                        )

                        OutlinedTextField(
                            value = proExpYears,
                            onValueChange = { proExpYears = it },
                            label = { Text("سنوات الخبرة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proBio,
                            onValueChange = { proBio = it },
                            label = { Text("نبذة عن خبرتك والخدمات التي تتقنها") },
                            placeholder = { Text("مثال: خبرة 7 سنوات في التمديدات الصحية وكشف التسريبات...") },
                            modifier = Modifier.fillMaxWidth().height(90.dp),
                            maxLines = 4
                        )

                        OutlinedTextField(
                            value = proWorkingHours,
                            onValueChange = { proWorkingHours = it },
                            label = { Text("أوقات العمل المتاحة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = proPriceEstimate,
                            onValueChange = { proPriceEstimate = it },
                            label = { Text("التسعيرة التقديرية (مثال: تبدأ من 1500 دج)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = {
                                if (proName.isBlank() || proPhone.isBlank()) {
                                    Toast.makeText(context, "الرجاء إدخال الاسم ورقم الهاتف", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val exp = proExpYears.toIntOrNull() ?: 3
                                onRegisterProfessional(
                                    proName,
                                    proPhone,
                                    proEmail,
                                    proPassword,
                                    if (proWhatsapp.isBlank()) proPhone else proWhatsapp,
                                    proServiceId,
                                    proServiceName,
                                    proWilayaCode,
                                    proWilayaName,
                                    proCommuneName,
                                    exp,
                                    proBio,
                                    proWorkingHours,
                                    proPriceEstimate
                                )
                                Toast.makeText(context, "تم تسجيل حساب الحرفي بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pro_reg_submit"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("إنشاء الملف المهني للحرفي", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
