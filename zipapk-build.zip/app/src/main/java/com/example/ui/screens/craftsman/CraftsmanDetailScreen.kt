package com.example.ui.screens.craftsman

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProfessionalEntity
import com.example.data.model.ReportEntity
import com.example.data.model.ReviewEntity
import com.example.data.model.UserEntity
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.RatingStars
import com.example.ui.components.VerifiedBadge
import com.example.ui.screens.dialogs.ReportDialog
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CraftsmanDetailScreen(
    craftsman: ProfessionalEntity,
    reviews: List<ReviewEntity>,
    currentUser: UserEntity?,
    onBack: () -> Unit,
    onRequestService: () -> Unit,
    onStartDirectChat: () -> Unit,
    onSubmitReport: (ReportEntity) -> Unit,
    onFlagReview: (reviewId: Long, reason: String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showReportDialog by remember { mutableStateOf(false) }
    var flaggingReview by remember { mutableStateOf<ReviewEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(craftsman.fullName, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "تعرف على الحرفي ${craftsman.fullName} (${craftsman.professionNameAr}) في ولاية ${craftsman.wilayaNameAr} عبر تطبيق خدملي DZ 🇩🇿 - هاتف: ${craftsman.phone}")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة ملف الحرفي"))
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "مشاركة")
                    }
                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(Icons.Outlined.Flag, contentDescription = "إبلاغ", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onRequestService,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("request_craftsman_bottom_cta"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إرسال طلب خدمة الآن", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Profile Header Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = craftsman.fullName.split(" ").mapNotNull { it.firstOrNull()?.toString() }.take(2).joinToString(""),
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontSize = 24.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = craftsman.fullName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            if (craftsman.isVerified) {
                                VerifiedBadge()
                            }
                        }

                        Text(
                            text = craftsman.professionNameAr,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(16.dp))
                            Text(
                                text = "ولاية ${craftsman.wilayaNameAr} • بلدية ${craftsman.communeNameAr}",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        AvailabilityBadge(isAvailable = craftsman.isAvailable)

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(14.dp))

                        // Stats Trio
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${craftsman.experienceYears}+ سنوات", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("الخبرة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box(modifier = Modifier.width(1.dp).height(30.dp).background(Color.LightGray))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${craftsman.completedJobsCount}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DzGreenPrimary)
                                Text("خدمة منجزة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box(modifier = Modifier.width(1.dp).height(30.dp).background(Color.LightGray))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = DzGold, modifier = Modifier.size(16.dp))
                                    Text(String.format("%.1f", craftsman.ratingAverage), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Text("التقييم العام", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            // 2. Direct Contact Buttons Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Call Direct
                    Button(
                        onClick = {
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${craftsman.phone}"))
                            try {
                                context.startActivity(dialIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "الهاتف: ${craftsman.phone}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اتصال هاتفي", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // WhatsApp Direct
                    Button(
                        onClick = {
                            val waNum = if (craftsman.whatsapp.startsWith("0")) "213" + craftsman.whatsapp.substring(1) else craftsman.whatsapp
                            val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$waNum"))
                            try {
                                context.startActivity(waIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "واتساب: ${craftsman.whatsapp}", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("واتساب", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // In-App Chat
                    FilledTonalIconButton(
                        onClick = onStartDirectChat,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Default.Forum, contentDescription = "محادثة داخل التطبيق", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            // 3. Bio & Working Hours
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("نبذة عن الحرفي والخبرة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = craftsman.bio.ifBlank { "حرفي متخصص ذو كفاءة عالية في تقديم الخدمات بأعلى معايير الإتقان والسلامة." },
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 20.sp
                        )

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("أوقات العمل المعتادة:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(craftsman.workingHours, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Payments, contentDescription = null, tint = DzGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("تسعيرة الخدمة التقديرية:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(craftsman.priceEstimate, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }

            // 4. Portfolio / Showcase
            if (craftsman.portfolioImages.isNotBlank()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("نماذج من الأعمال السابقة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(8.dp))

                            craftsman.portfolioImages.split(",").map { it.trim() }.forEach { workItem ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(workItem, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 5. Customer Reviews List
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "تقييمات وآراء الزبائن (${reviews.size})",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    RatingStars(rating = craftsman.ratingAverage)
                }
            }

            if (reviews.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "لا توجد تقييمات بعد، كن أول من يطلب خدمة ويقيم هذا الحرفي!",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(reviews) { review ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(review.customerName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Row {
                                    (1..5).forEach { star ->
                                        Icon(
                                            imageVector = Icons.Filled.Star,
                                            contentDescription = null,
                                            tint = if (star <= review.rating) DzGold else Color.LightGray,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(review.comment, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(
                                    onClick = { flaggingReview = review },
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Icon(Icons.Outlined.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إبلاغ عن هذا التقييم", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    flaggingReview?.let { rev ->
        com.example.ui.screens.dialogs.FlagReviewDialog(
            reviewId = rev.id,
            reviewerName = rev.customerName,
            onDismiss = { flaggingReview = null },
            onSubmit = { reason ->
                onFlagReview(rev.id, reason)
                flaggingReview = null
                Toast.makeText(context, "تم إرسال بلاغ التقييم للإدارة للمراجعة", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showReportDialog && currentUser != null) {
        ReportDialog(
            targetType = "PROFESSIONAL",
            targetId = craftsman.id,
            targetName = craftsman.fullName,
            reporterId = currentUser.id,
            reporterName = currentUser.fullName,
            onDismiss = { showReportDialog = false },
            onSubmitReport = { report ->
                onSubmitReport(report)
                showReportDialog = false
                Toast.makeText(context, "تم إرسال البلاغ إلى الإدارة للمتابعة", Toast.LENGTH_SHORT).show()
            }
        )
    }
}
