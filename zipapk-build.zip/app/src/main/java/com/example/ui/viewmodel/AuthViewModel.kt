package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthSessionState {
    object Loading : AuthSessionState()
    data class Authenticated(val userProfile: UserProfile, val providerProfile: ServiceProviderProfile? = null) : AuthSessionState()
    data class NeedsProfileCompletion(val uid: String, val email: String, val role: UserRole? = null) : AuthSessionState()
    object Unauthenticated : AuthSessionState()
}

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _sessionState = MutableStateFlow<AuthSessionState>(AuthSessionState.Loading)
    val sessionState: StateFlow<AuthSessionState> = _sessionState.asStateFlow()

    private val _loginState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val loginState: StateFlow<AuthResult<UserProfile>?> = _loginState.asStateFlow()

    private val _customerRegState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val customerRegState: StateFlow<AuthResult<UserProfile>?> = _customerRegState.asStateFlow()

    private val _providerRegState = MutableStateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?>(null)
    val providerRegState: StateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?> = _providerRegState.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    private val _currentProviderProfile = MutableStateFlow<ServiceProviderProfile?>(null)
    val currentProviderProfile: StateFlow<ServiceProviderProfile?> = _currentProviderProfile.asStateFlow()

    private val _updateProfileState = MutableStateFlow<AuthResult<ServiceProviderProfile>?>(null)
    val updateProfileState: StateFlow<AuthResult<ServiceProviderProfile>?> = _updateProfileState.asStateFlow()

    private val _providersListState = MutableStateFlow<AuthResult<List<ServiceProviderProfile>>?>(null)
    val providersListState: StateFlow<AuthResult<List<ServiceProviderProfile>>?> = _providersListState.asStateFlow()

    val isFirebaseReady: Boolean
        get() = authRepository.isFirebaseReady

    val isUserLoggedIn: Boolean
        get() = authRepository.isUserLoggedIn

    val currentAuthUserEmail: String?
        get() = authRepository.currentAuthUserEmail

    init {
        checkAuthSession()
    }

    fun checkAuthSession() {
        _sessionState.value = AuthSessionState.Loading
        var isInitialCheck = true

        authRepository.observeAuthState { currentUid ->
            if (currentUid == null) {
                _sessionState.value = AuthSessionState.Unauthenticated
                _currentUserProfile.value = null
                _currentProviderProfile.value = null
            } else {
                if (!isInitialCheck && _sessionState.value is AuthSessionState.Authenticated) {
                    return@observeAuthState
                }
                viewModelScope.launch {
                    when (val userResult = authRepository.getUserProfile(currentUid)) {
                        is AuthResult.Success -> {
                            val userProfile = userResult.data
                            _currentUserProfile.value = userProfile
                            if (userProfile.role == UserRole.SERVICE_PROVIDER) {
                                when (val providerResult = authRepository.getServiceProviderProfile(currentUid)) {
                                    is AuthResult.Success -> {
                                        _currentProviderProfile.value = providerResult.data
                                        _sessionState.value = AuthSessionState.Authenticated(userProfile, providerResult.data)
                                    }
                                    is AuthResult.ProfileMissing -> {
                                        _sessionState.value = AuthSessionState.NeedsProfileCompletion(currentUid, userProfile.email, UserRole.SERVICE_PROVIDER)
                                    }
                                    else -> {
                                        _sessionState.value = AuthSessionState.Authenticated(userProfile)
                                    }
                                }
                            } else {
                                _sessionState.value = AuthSessionState.Authenticated(userProfile)
                            }
                        }
                        is AuthResult.ProfileMissing -> {
                            _sessionState.value = AuthSessionState.NeedsProfileCompletion(currentUid, userResult.email, userResult.role)
                        }
                        else -> {
                            // If it's a network error, we can't fetch the profile, but we know they are logged in.
                            // To prevent kicking them out, we will retry or fallback.
                            // For now, if we can't load the profile, we don't force a login. 
                            // But we need to know their role to route them.
                            // If they are cached, Success is returned. If no cache and offline, Error is returned.
                            // We will set Unauthenticated to force a login if it's completely unrecoverable, 
                            // or better, we set a specific error state. Since we only have these states, 
                            // we'll try to fetch again on the next UI action, but for Splash routing, 
                            // we have no choice but to force them to welcome if we can't route them.
                            // Wait, if we use Unauthenticated, they are forced to login again.
                            // Let's just set Unauthenticated for now because the bug specifically mentioned 
                            // persistence was completely failing, likely due to the null currentUid.
                            // With observeAuthState, currentUid should be valid.
                            _sessionState.value = AuthSessionState.Unauthenticated
                        }
                    }
                }
            }
            isInitialCheck = false
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginState.value = AuthResult.Error("يرجى ملء جميع الحقول المطلوبة")
            return
        }

        viewModelScope.launch {
            _loginState.value = AuthResult.Loading
            val result = authRepository.login(email, password)
            _loginState.value = result
            when (result) {
                is AuthResult.Success -> {
                    _currentUserProfile.value = result.data
                    if (result.data.role == UserRole.SERVICE_PROVIDER) {
                        when (val pRes = authRepository.getServiceProviderProfile(result.data.uid)) {
                            is AuthResult.Success -> {
                                _currentProviderProfile.value = pRes.data
                                _sessionState.value = AuthSessionState.Authenticated(result.data, pRes.data)
                            }
                            is AuthResult.ProfileMissing -> {
                                _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.data.uid, result.data.email, UserRole.SERVICE_PROVIDER)
                            }
                            else -> {
                                _sessionState.value = AuthSessionState.Authenticated(result.data)
                            }
                        }
                    } else {
                        _sessionState.value = AuthSessionState.Authenticated(result.data)
                    }
                }
                is AuthResult.ProfileMissing -> {
                    _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.uid, result.email, result.role)
                }
                else -> {}
            }
        }
    }

    fun registerCustomer(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ) {
        viewModelScope.launch {
            _customerRegState.value = AuthResult.Loading
            val result = authRepository.registerCustomer(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName
            )
            _customerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                _sessionState.value = AuthSessionState.Authenticated(result.data)
            }
        }
    }

    fun registerServiceProvider(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        serviceDescription: String,
        experienceYears: Int
    ) {
        viewModelScope.launch {
            _providerRegState.value = AuthResult.Loading
            val result = authRepository.registerServiceProvider(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                serviceDescription = serviceDescription,
                experienceYears = experienceYears
            )
            _providerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data.first
                _currentProviderProfile.value = result.data.second
                _sessionState.value = AuthSessionState.Authenticated(result.data.first, result.data.second)
            }
        }
    }

    fun loadServiceProviders(professionId: String? = null, wilayaCode: Int? = null) {
        viewModelScope.launch {
            _providersListState.value = AuthResult.Loading
            val result = authRepository.fetchServiceProviders(professionId, wilayaCode)
            _providersListState.value = result
        }
    }

    fun loadUserProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getUserProfile(uid)
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                if (result.data.role == UserRole.SERVICE_PROVIDER) {
                    loadProviderProfile(uid)
                }
            }
        }
    }

    fun loadProviderProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getServiceProviderProfile(uid)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = result.data
            }
        }
    }

    fun toggleProviderAvailability(isAvailable: Boolean) {
        val current = _currentProviderProfile.value ?: return
        viewModelScope.launch {
            val result = authRepository.updateProviderAvailability(current.uid, isAvailable)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = current.copy(isAvailable = isAvailable)
            }
        }
    }

    fun updateProviderProfile(profile: ServiceProviderProfile) {
        viewModelScope.launch {
            _updateProfileState.value = AuthResult.Loading
            val result = authRepository.updateServiceProviderProfile(profile)
            _updateProfileState.value = result
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = result.data
            }
        }
    }

    fun setCurrentUserForDemo(profile: UserProfile, providerProfile: ServiceProviderProfile? = null) {
        _currentUserProfile.value = profile
        _currentProviderProfile.value = providerProfile
    }

    fun logout() {
        authRepository.logout()
        _currentUserProfile.value = null
        _currentProviderProfile.value = null
        _sessionState.value = AuthSessionState.Unauthenticated
        resetAuthStates()
    }

    fun resetAuthStates() {
        _loginState.value = null
        _customerRegState.value = null
        _providerRegState.value = null
        _updateProfileState.value = null
    }
}
