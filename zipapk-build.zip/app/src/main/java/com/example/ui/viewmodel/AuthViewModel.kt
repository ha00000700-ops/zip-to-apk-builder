package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.RequestStatus
import com.example.data.model.Review
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.ServiceRequest
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed class AuthSessionState {
    object Loading : AuthSessionState()
    data class Authenticated(val userProfile: UserProfile, val providerProfile: ServiceProviderProfile? = null) : AuthSessionState()
    data class NeedsProfileCompletion(val uid: String, val email: String, val role: UserRole? = null) : AuthSessionState()
    object Unauthenticated : AuthSessionState()
}

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _sessionState = MutableStateFlow<AuthSessionState>(AuthSessionState.Loading)
    val sessionState: StateFlow<AuthSessionState> = _sessionState.asStateFlow()

    private val _loginState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val loginState: StateFlow<AuthResult<UserProfile>?> = _loginState.asStateFlow()

    private val _customerRegState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val customerRegState: StateFlow<AuthResult<UserProfile>?> = _customerRegState.asStateFlow()

    private val _providerRegState = MutableStateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?>(null)
    val providerRegState: StateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?> = _providerRegState.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    private val _currentProviderProfile = MutableStateFlow<ServiceProviderProfile?>(null)
    val currentProviderProfile: StateFlow<ServiceProviderProfile?> = _currentProviderProfile.asStateFlow()

    private val _updateProfileState = MutableStateFlow<AuthResult<ServiceProviderProfile>?>(null)
    val updateProfileState: StateFlow<AuthResult<ServiceProviderProfile>?> = _updateProfileState.asStateFlow()

    private val _providersListState = MutableStateFlow<AuthResult<List<ServiceProviderProfile>>?>(null)
    val providersListState: StateFlow<AuthResult<List<ServiceProviderProfile>>?> = _providersListState.asStateFlow()

    private val _userConversationsState = MutableStateFlow<AuthResult<List<Conversation>>?>(null)
    val userConversationsState: StateFlow<AuthResult<List<Conversation>>?> = _userConversationsState.asStateFlow()

    private val _currentChatMessagesState = MutableStateFlow<AuthResult<List<ChatMessage>>?>(null)
    val currentChatMessagesState: StateFlow<AuthResult<List<ChatMessage>>?> = _currentChatMessagesState.asStateFlow()

    private val _activeConversationState = MutableStateFlow<AuthResult<Conversation>?>(null)
    val activeConversationState: StateFlow<AuthResult<Conversation>?> = _activeConversationState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    val filteredProvidersListState: StateFlow<AuthResult<List<ServiceProviderProfile>>?> = kotlinx.coroutines.flow.combine(
        _providersListState,
        _searchQuery
    ) { state, query ->
        if (state is AuthResult.Success) {
            val trimmedQuery = query.trim().lowercase()
            if (trimmedQuery.isBlank()) {
                state
            } else {
                val filtered = state.data.filter { p ->
                    p.fullName.lowercase().contains(trimmedQuery) ||
                    p.professionNameAr.lowercase().contains(trimmedQuery) ||
                    p.serviceDescription.lowercase().contains(trimmedQuery) ||
                    p.wilayaName.lowercase().contains(trimmedQuery) ||
                    p.communeName.lowercase().contains(trimmedQuery)
                }
                AuthResult.Success(filtered)
            }
        } else {
            state
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
    .stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val isFirebaseReady: Boolean
        get() = authRepository.isFirebaseReady

    val isUserLoggedIn: Boolean
        get() = authRepository.isUserLoggedIn

    val currentAuthUserEmail: String?
        get() = authRepository.currentAuthUserEmail

    init {
        checkAuthSession()
    }

    fun checkAuthSession() {
        _sessionState.value = AuthSessionState.Loading
        var isInitialCheck = true

        authRepository.observeAuthState { currentUid ->
            if (currentUid == null) {
                _sessionState.value = AuthSessionState.Unauthenticated
                _currentUserProfile.value = null
                _currentProviderProfile.value = null
            } else {
                if (!isInitialCheck && _sessionState.value is AuthSessionState.Authenticated) {
                    return@observeAuthState
                }
                viewModelScope.launch {
                    when (val userResult = authRepository.getUserProfile(currentUid)) {
                        is AuthResult.Success -> {
                            val userProfile = userResult.data
                            _currentUserProfile.value = userProfile
                            if (userProfile.role == UserRole.SERVICE_PROVIDER) {
                                when (val providerResult = authRepository.getServiceProviderProfile(currentUid)) {
                                    is AuthResult.Success -> {
                                        _currentProviderProfile.value = providerResult.data
                                        _sessionState.value = AuthSessionState.Authenticated(userProfile, providerResult.data)
                                    }
                                    is AuthResult.ProfileMissing -> {
                                        _sessionState.value = AuthSessionState.NeedsProfileCompletion(currentUid, userProfile.email, UserRole.SERVICE_PROVIDER)
                                    }
                                    else -> {
                                        _sessionState.value = AuthSessionState.Authenticated(userProfile)
                                    }
                                }
                            } else {
                                _sessionState.value = AuthSessionState.Authenticated(userProfile)
                            }
                        }
                        is AuthResult.ProfileMissing -> {
                            _sessionState.value = AuthSessionState.NeedsProfileCompletion(currentUid, userResult.email, userResult.role)
                        }
                        else -> {
                            // If it's a network error, we can't fetch the profile, but we know they are logged in.
                            // To prevent kicking them out, we will retry or fallback.
                            // For now, if we can't load the profile, we don't force a login. 
                            // But we need to know their role to route them.
                            // If they are cached, Success is returned. If no cache and offline, Error is returned.
                            // We will set Unauthenticated to force a login if it's completely unrecoverable, 
                            // or better, we set a specific error state. Since we only have these states, 
                            // we'll try to fetch again on the next UI action, but for Splash routing, 
                            // we have no choice but to force them to welcome if we can't route them.
                            // Wait, if we use Unauthenticated, they are forced to login again.
                            // Let's just set Unauthenticated for now because the bug specifically mentioned 
                            // persistence was completely failing, likely due to the null currentUid.
                            // With observeAuthState, currentUid should be valid.
                            _sessionState.value = AuthSessionState.Unauthenticated
                        }
                    }
                }
            }
            isInitialCheck = false
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginState.value = AuthResult.Error("يرجى ملء جميع الحقول المطلوبة")
            return
        }

        viewModelScope.launch {
            _loginState.value = AuthResult.Loading
            val result = authRepository.login(email, password)
            _loginState.value = result
            when (result) {
                is AuthResult.Success -> {
                    _currentUserProfile.value = result.data
                    if (result.data.role == UserRole.SERVICE_PROVIDER) {
                        when (val pRes = authRepository.getServiceProviderProfile(result.data.uid)) {
                            is AuthResult.Success -> {
                                _currentProviderProfile.value = pRes.data
                                _sessionState.value = AuthSessionState.Authenticated(result.data, pRes.data)
                            }
                            is AuthResult.ProfileMissing -> {
                                _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.data.uid, result.data.email, UserRole.SERVICE_PROVIDER)
                            }
                            else -> {
                                _sessionState.value = AuthSessionState.Authenticated(result.data)
                            }
                        }
                    } else {
                        _sessionState.value = AuthSessionState.Authenticated(result.data)
                    }
                }
                is AuthResult.ProfileMissing -> {
                    _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.uid, result.email, result.role)
                }
                else -> {}
            }
        }
    }

    fun registerCustomer(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ) {
        viewModelScope.launch {
            _customerRegState.value = AuthResult.Loading
            val result = authRepository.registerCustomer(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName
            )
            _customerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                _sessionState.value = AuthSessionState.Authenticated(result.data)
            }
        }
    }

    fun registerServiceProvider(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        serviceDescription: String,
        experienceYears: Int
    ) {
        viewModelScope.launch {
            _providerRegState.value = AuthResult.Loading
            val result = authRepository.registerServiceProvider(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                serviceDescription = serviceDescription,
                experienceYears = experienceYears
            )
            _providerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data.first
                _currentProviderProfile.value = result.data.second
                _sessionState.value = AuthSessionState.Authenticated(result.data.first, result.data.second)
            }
        }
    }

    fun loadServiceProviders(professionId: String? = null, wilayaCode: Int? = null) {
        viewModelScope.launch {
            _providersListState.value = AuthResult.Loading
            val result = authRepository.fetchServiceProviders(professionId, wilayaCode)
            _providersListState.value = result
        }
    }

    fun loadUserProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getUserProfile(uid)
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                if (result.data.role == UserRole.SERVICE_PROVIDER) {
                    loadProviderProfile(uid)
                }
            }
        }
    }

    fun loadProviderProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getServiceProviderProfile(uid)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = result.data
            }
        }
    }

    fun toggleProviderAvailability(isAvailable: Boolean) {
        val current = _currentProviderProfile.value ?: return
        viewModelScope.launch {
            val result = authRepository.updateProviderAvailability(current.uid, isAvailable)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = current.copy(isAvailable = isAvailable)
            }
        }
    }

    private val _selectedProviderState = MutableStateFlow<AuthResult<ServiceProviderProfile>?>(null)
    val selectedProviderState: StateFlow<AuthResult<ServiceProviderProfile>?> = _selectedProviderState.asStateFlow()

    private val _createRequestState = MutableStateFlow<AuthResult<com.example.data.model.ServiceRequest>?>(null)
    val createRequestState: StateFlow<AuthResult<com.example.data.model.ServiceRequest>?> = _createRequestState.asStateFlow()

    fun loadSelectedProviderProfile(uid: String) {
        viewModelScope.launch {
            _selectedProviderState.value = AuthResult.Loading
            val result = authRepository.getServiceProviderProfile(uid)
            _selectedProviderState.value = result
        }
    }

    fun createServiceRequest(
        provider: ServiceProviderProfile,
        description: String,
        addressDetails: String,
        proposedPriceDzd: Long? = null
    ) {
        val user = _currentUserProfile.value ?: return
        viewModelScope.launch {
            _createRequestState.value = AuthResult.Loading
            val request = com.example.data.model.ServiceRequest(
                customerId = user.uid,
                customerName = user.fullName,
                customerPhone = user.phone,
                providerId = provider.uid,
                providerName = provider.fullName,
                professionId = provider.professionId,
                professionNameAr = provider.professionNameAr,
                wilayaName = provider.wilayaName,
                communeName = provider.communeName,
                addressDetails = addressDetails,
                description = description,
                proposedPriceDzd = proposedPriceDzd,
                status = com.example.data.model.RequestStatus.PENDING
            )
            val result = authRepository.createServiceRequest(request)
            _createRequestState.value = result
        }
    }

    fun resetServiceRequestState() {
        _createRequestState.value = null
    }

    fun updateProviderProfile(profile: ServiceProviderProfile) {
        viewModelScope.launch {
            _updateProfileState.value = AuthResult.Loading
            val result = authRepository.updateServiceProviderProfile(profile)
            _updateProfileState.value = result
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = result.data
            }
        }
    }

    fun setCurrentUserForDemo(profile: UserProfile, providerProfile: ServiceProviderProfile? = null) {
        _currentUserProfile.value = profile
        _currentProviderProfile.value = providerProfile
    }

    fun logout() {
        authRepository.logout()
        _currentUserProfile.value = null
        _currentProviderProfile.value = null
        _sessionState.value = AuthSessionState.Unauthenticated
        resetAuthStates()
    }

    fun resetAuthStates() {
        _loginState.value = null
        _customerRegState.value = null
        _providerRegState.value = null
        _updateProfileState.value = null
    }

    private val _customerRequestsState = MutableStateFlow<AuthResult<List<ServiceRequest>>?>(null)
    val customerRequestsState: StateFlow<AuthResult<List<ServiceRequest>>?> = _customerRequestsState.asStateFlow()

    private val _providerRequestsState = MutableStateFlow<AuthResult<List<ServiceRequest>>?>(null)
    val providerRequestsState: StateFlow<AuthResult<List<ServiceRequest>>?> = _providerRequestsState.asStateFlow()

    fun observeCustomerRequests() {
        val user = _currentUserProfile.value ?: return
        viewModelScope.launch {
            _customerRequestsState.value = AuthResult.Loading
            authRepository.getServiceRequestsFlowForCustomer(user.uid).collectLatest { result ->
                _customerRequestsState.value = result
            }
        }
    }

    fun observeProviderRequests() {
        val user = _currentUserProfile.value ?: return
        viewModelScope.launch {
            _providerRequestsState.value = AuthResult.Loading
            authRepository.getServiceRequestsFlowForProvider(user.uid).collectLatest { result ->
                _providerRequestsState.value = result
            }
        }
    }

    fun getServiceRequestFlow(requestId: String) = authRepository.getServiceRequestByIdFlow(requestId)

    fun updateServiceRequestStatus(
        requestId: String,
        newStatus: RequestStatus,
        onResult: (Boolean, String?) -> Unit
    ) {
        val user = _currentUserProfile.value
        if (user == null) {
            onResult(false, "يجب تسجيل الدخول أولاً")
            return
        }
        viewModelScope.launch {
            val result = authRepository.updateServiceRequestStatus(
                requestId = requestId,
                newStatus = newStatus,
                userUid = user.uid,
                userRole = user.role
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع")
            }
        }
    }

    fun submitReview(
        requestId: String,
        providerId: String,
        rating: Int,
        comment: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val user = _currentUserProfile.value
        if (user == null) {
            onResult(false, "يجب تسجيل الدخول أولاً")
            return
        }
        viewModelScope.launch {
            val review = Review(
                serviceRequestId = requestId,
                customerId = user.uid,
                customerName = user.fullName,
                providerId = providerId,
                rating = rating,
                comment = comment
            )
            val result = authRepository.submitReview(review)
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع")
            }
        }
    }

    // Chat ViewModel Methods
    fun observeUserConversations() {
        val uid = authRepository.currentUserId
        if (uid.isNullOrBlank()) {
            _userConversationsState.value = AuthResult.Error("يجب تسجيل الدخول لعرض المحادثات")
            return
        }
        viewModelScope.launch {
            authRepository.observeConversationsForUser(uid).collect { result ->
                _userConversationsState.value = result
            }
        }
    }

    fun openOrCreateConversation(
        customerId: String,
        customerName: String,
        customerPhotoUrl: String = "",
        providerId: String,
        providerName: String,
        providerPhotoUrl: String = "",
        providerProfession: String = "",
        serviceRequestId: String? = null,
        serviceRequestTitle: String? = null,
        onResult: (String?, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.getOrCreateConversation(
                customerId = customerId,
                customerName = customerName,
                customerPhotoUrl = customerPhotoUrl,
                providerId = providerId,
                providerName = providerName,
                providerPhotoUrl = providerPhotoUrl,
                providerProfession = providerProfession,
                serviceRequestId = serviceRequestId,
                serviceRequestTitle = serviceRequestTitle
            )
            when (result) {
                is AuthResult.Success -> {
                    _activeConversationState.value = result
                    onResult(result.data.id, null)
                }
                is AuthResult.Error -> {
                    _activeConversationState.value = result
                    onResult(null, result.messageAr)
                }
                else -> {
                    _activeConversationState.value = AuthResult.Error("خطأ غير معروف")
                    onResult(null, "خطأ غير معروف")
                }
            }
        }
    }

    fun loadConversationDetails(conversationId: String) {
        viewModelScope.launch {
            _activeConversationState.value = AuthResult.Loading
            val result = authRepository.getConversationById(conversationId)
            _activeConversationState.value = result
        }
    }

    fun observeChatMessages(conversationId: String) {
        if (conversationId.isBlank()) return
        viewModelScope.launch {
            _currentChatMessagesState.value = AuthResult.Loading
            authRepository.observeChatMessages(conversationId).collect { result ->
                _currentChatMessagesState.value = result
            }
        }
    }

    fun sendMessage(
        conversationId: String,
        text: String,
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        if (senderId.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لأداء هذا الإجراء")
            return
        }
        viewModelScope.launch {
            val result = authRepository.sendMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                text = text
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة")
            }
        }
    }

    fun sendVoiceMessage(
        conversationId: String,
        audioUrl: String,
        duration: Long,
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        if (senderId.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لأداء هذا الإجراء")
            return
        }
        viewModelScope.launch {
            val result = authRepository.sendVoiceMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                audioUrl = audioUrl,
                duration = duration
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة الصوتية")
            }
        }
    }

    fun sendMediaMessage(
        conversationId: String,
        mediaUrl: String,
        type: String,
        duration: Long = 0L,
        caption: String = "",
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        if (senderId.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لأداء هذا الإجراء")
            return
        }
        viewModelScope.launch {
            val result = authRepository.sendMediaMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                mediaUrl = mediaUrl,
                type = type,
                duration = duration,
                caption = caption
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الوسائط")
            }
        }
    }

    fun markMessagesAsRead(conversationId: String) {
        val uid = authRepository.currentUserId ?: return
        if (conversationId.isBlank()) return
        viewModelScope.launch {
            authRepository.markMessagesAsRead(conversationId, uid)
        }
    }
}
