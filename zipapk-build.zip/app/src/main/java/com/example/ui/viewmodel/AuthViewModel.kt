package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.OfferStatus
import com.example.data.model.PublicRequestOffer
import com.example.data.model.PublicRequestStatus
import com.example.data.model.PublicServiceRequest
import com.example.data.model.RequestStatus
import com.example.data.model.Review
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.ServiceRequest
import android.content.Context
import android.util.Log
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import com.example.service.LocalNotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

sealed class AuthSessionState {
    object Loading : AuthSessionState()
    data class Authenticated(val userProfile: UserProfile, val providerProfile: ServiceProviderProfile? = null) : AuthSessionState()
    data class NeedsProfileCompletion(val uid: String, val email: String, val role: UserRole? = null) : AuthSessionState()
    object Unauthenticated : AuthSessionState()
}

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _sessionState = MutableStateFlow<AuthSessionState>(AuthSessionState.Loading)
    val sessionState: StateFlow<AuthSessionState> = _sessionState.asStateFlow()

    private val _loginState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val loginState: StateFlow<AuthResult<UserProfile>?> = _loginState.asStateFlow()

    private val _customerRegState = MutableStateFlow<AuthResult<UserProfile>?>(null)
    val customerRegState: StateFlow<AuthResult<UserProfile>?> = _customerRegState.asStateFlow()

    private val _providerRegState = MutableStateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?>(null)
    val providerRegState: StateFlow<AuthResult<Pair<UserProfile, ServiceProviderProfile>>?> = _providerRegState.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    private val _currentProviderProfile = MutableStateFlow<ServiceProviderProfile?>(null)
    val currentProviderProfile: StateFlow<ServiceProviderProfile?> = _currentProviderProfile.asStateFlow()

    private val _updateProfileState = MutableStateFlow<AuthResult<ServiceProviderProfile>?>(null)
    val updateProfileState: StateFlow<AuthResult<ServiceProviderProfile>?> = _updateProfileState.asStateFlow()

    private val _providersListState = MutableStateFlow<AuthResult<List<ServiceProviderProfile>>?>(null)
    val providersListState: StateFlow<AuthResult<List<ServiceProviderProfile>>?> = _providersListState.asStateFlow()

    private val _userConversationsState = MutableStateFlow<AuthResult<List<Conversation>>?>(null)
    val userConversationsState: StateFlow<AuthResult<List<Conversation>>?> = _userConversationsState.asStateFlow()

    private val _currentChatMessagesState = MutableStateFlow<AuthResult<List<ChatMessage>>?>(null)
    val currentChatMessagesState: StateFlow<AuthResult<List<ChatMessage>>?> = _currentChatMessagesState.asStateFlow()

    private val _activeConversationState = MutableStateFlow<AuthResult<Conversation>?>(null)
    val activeConversationState: StateFlow<AuthResult<Conversation>?> = _activeConversationState.asStateFlow()

    private val _createPublicRequestState = MutableStateFlow<AuthResult<PublicServiceRequest>?>(null)
    val createPublicRequestState: StateFlow<AuthResult<PublicServiceRequest>?> = _createPublicRequestState.asStateFlow()

    private val _openPublicRequestsState = MutableStateFlow<AuthResult<List<PublicServiceRequest>>?>(null)
    val openPublicRequestsState: StateFlow<AuthResult<List<PublicServiceRequest>>?> = _openPublicRequestsState.asStateFlow()

    private val _customerPublicRequestsState = MutableStateFlow<AuthResult<List<PublicServiceRequest>>?>(null)
    val customerPublicRequestsState: StateFlow<AuthResult<List<PublicServiceRequest>>?> = _customerPublicRequestsState.asStateFlow()

    private val _publicRequestOffersState = MutableStateFlow<AuthResult<List<PublicRequestOffer>>?>(null)
    val publicRequestOffersState: StateFlow<AuthResult<List<PublicRequestOffer>>?> = _publicRequestOffersState.asStateFlow()

    private val _userNotificationsState = MutableStateFlow<AuthResult<List<AppNotification>>?>(null)
    val userNotificationsState: StateFlow<AuthResult<List<AppNotification>>?> = _userNotificationsState.asStateFlow()

    val unreadNotificationsCount: StateFlow<Int> = kotlinx.coroutines.flow.combine(
        _userNotificationsState
    ) { (state) ->
        if (state is AuthResult.Success) {
            state.data.count { !it.isRead }
        } else {
            0
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalUnreadChatCount: StateFlow<Int> = kotlinx.coroutines.flow.combine(
        _userConversationsState,
        _currentUserProfile
    ) { state, userProfile ->
        if (state is AuthResult.Success && userProfile != null) {
            val isCustomer = userProfile.role == UserRole.CUSTOMER
            state.data.sumOf { conv ->
                if (isCustomer) conv.customerUnreadCount else conv.providerUnreadCount
            }
        } else {
            0
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    val filteredProvidersListState: StateFlow<AuthResult<List<ServiceProviderProfile>>?> = kotlinx.coroutines.flow.combine(
        _providersListState,
        _searchQuery
    ) { state, query ->
        if (state is AuthResult.Success) {
            val trimmedQuery = query.trim().lowercase()
            if (trimmedQuery.isBlank()) {
                state
            } else {
                val filtered = state.data.filter { p ->
                    p.fullName.lowercase().contains(trimmedQuery) ||
                    p.professionNameAr.lowercase().contains(trimmedQuery) ||
                    p.serviceDescription.lowercase().contains(trimmedQuery) ||
                    p.wilayaName.lowercase().contains(trimmedQuery) ||
                    p.communeName.lowercase().contains(trimmedQuery)
                }
                AuthResult.Success(filtered)
            }
        } else {
            state
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
    .stateIn(
        scope = viewModelScope,
        started = kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val isFirebaseReady: Boolean
        get() = authRepository.isFirebaseReady

    val isUserLoggedIn: Boolean
        get() = authRepository.isUserLoggedIn

    val currentAuthUserEmail: String?
        get() = authRepository.currentAuthUserEmail

    init {
        checkAuthSession()
    }

    fun checkAuthSession() {
        _sessionState.value = AuthSessionState.Loading

        viewModelScope.launch {
            var isInitialLoad = true

            authRepository.observeAuthState { currentUid ->
                if (currentUid != null) {
                    isInitialLoad = false
                    viewModelScope.launch {
                        loadUserProfileAndSetSession(currentUid)
                    }
                } else {
                    // If it's not the initial load (i.e. the user explicitly signed out later),
                    // transition to Unauthenticated immediately.
                    if (!isInitialLoad) {
                        _sessionState.value = AuthSessionState.Unauthenticated
                        _currentUserProfile.value = null
                        _currentProviderProfile.value = null
                    }
                }
            }

            // Wait 800ms for Firebase to restore session from disk
            delay(800)

            // After 800ms, if we are still in initial load (meaning no authenticated user has been detected),
            // we check if the user is indeed null, and transition to Unauthenticated.
            if (isInitialLoad && authRepository.currentUserId == null) {
                isInitialLoad = false
                Log.d("AuthViewModel", "No authenticated session restored after 800ms. Setting Unauthenticated.")
                _sessionState.value = AuthSessionState.Unauthenticated
                _currentUserProfile.value = null
                _currentProviderProfile.value = null
            }
        }
    }

    private suspend fun loadUserProfileAndSetSession(currentUid: String) {
        if (_sessionState.value is AuthSessionState.Authenticated) {
            val currentProfile = _currentUserProfile.value
            if (currentProfile != null && currentProfile.uid == currentUid) {
                return
            }
        }

        when (val userResult = authRepository.getUserProfile(currentUid)) {
            is AuthResult.Success -> {
                val userProfile = userResult.data
                _currentUserProfile.value = userProfile
                if (userProfile.role == UserRole.SERVICE_PROVIDER) {
                    when (val providerResult = authRepository.getServiceProviderProfile(currentUid)) {
                        is AuthResult.Success -> {
                            val newData = providerResult.data
                            val current = _currentProviderProfile.value
                            if (current == null || newData.updatedAt >= current.updatedAt) {
                                _currentProviderProfile.value = newData
                            }
                            _sessionState.value = AuthSessionState.Authenticated(userProfile, _currentProviderProfile.value)
                        }
                        is AuthResult.ProfileMissing -> {
                            _sessionState.value = AuthSessionState.NeedsProfileCompletion(currentUid, userProfile.email, UserRole.SERVICE_PROVIDER)
                        }
                        else -> {
                            _sessionState.value = AuthSessionState.Authenticated(userProfile)
                        }
                    }
                } else {
                    _sessionState.value = AuthSessionState.Authenticated(userProfile)
                }
            }
            is AuthResult.ProfileMissing -> {
                _sessionState.value = AuthSessionState.NeedsProfileCompletion(
                    uid = currentUid,
                    email = authRepository.currentAuthUserEmail ?: "",
                    role = null
                )
            }
            else -> {
                val email = authRepository.currentAuthUserEmail ?: ""
                val fallbackProfile = UserProfile(
                    uid = currentUid,
                    fullName = "مستخدم خدمتي",
                    email = email,
                    role = UserRole.CUSTOMER
                )
                _currentUserProfile.value = fallbackProfile
                _sessionState.value = AuthSessionState.Authenticated(fallbackProfile)
            }
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _loginState.value = AuthResult.Error("يرجى ملء جميع الحقول المطلوبة")
            return
        }

        viewModelScope.launch {
            _loginState.value = AuthResult.Loading
            val result = authRepository.login(email, password)
            _loginState.value = result
            when (result) {
                is AuthResult.Success -> {
                    _currentUserProfile.value = result.data
                    if (result.data.role == UserRole.SERVICE_PROVIDER) {
                        when (val pRes = authRepository.getServiceProviderProfile(result.data.uid)) {
                            is AuthResult.Success -> {
                                _currentProviderProfile.value = pRes.data
                                _sessionState.value = AuthSessionState.Authenticated(result.data, pRes.data)
                            }
                            is AuthResult.ProfileMissing -> {
                                _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.data.uid, result.data.email, UserRole.SERVICE_PROVIDER)
                            }
                            else -> {
                                _sessionState.value = AuthSessionState.Authenticated(result.data)
                            }
                        }
                    } else {
                        _sessionState.value = AuthSessionState.Authenticated(result.data)
                    }
                }
                is AuthResult.ProfileMissing -> {
                    _sessionState.value = AuthSessionState.NeedsProfileCompletion(result.uid, result.email, result.role)
                }
                else -> {}
            }
        }
    }

    fun registerCustomer(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ) {
        viewModelScope.launch {
            _customerRegState.value = AuthResult.Loading
            val result = authRepository.registerCustomer(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName
            )
            _customerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                _sessionState.value = AuthSessionState.Authenticated(result.data)
            }
        }
    }

    fun registerServiceProvider(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        serviceDescription: String,
        experienceYears: Int
    ) {
        viewModelScope.launch {
            _providerRegState.value = AuthResult.Loading
            val result = authRepository.registerServiceProvider(
                fullName = fullName,
                email = email,
                password = password,
                phone = phone,
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                serviceDescription = serviceDescription,
                experienceYears = experienceYears
            )
            _providerRegState.value = result
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data.first
                _currentProviderProfile.value = result.data.second
                _sessionState.value = AuthSessionState.Authenticated(result.data.first, result.data.second)
            }
        }
    }

    fun loadServiceProviders(professionId: String? = null, wilayaCode: Int? = null) {
        viewModelScope.launch {
            _providersListState.value = AuthResult.Loading
            val result = authRepository.fetchServiceProviders(professionId, wilayaCode)
            _providersListState.value = result
        }
    }

    fun loadUserProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getUserProfile(uid)
            if (result is AuthResult.Success) {
                _currentUserProfile.value = result.data
                if (result.data.role == UserRole.SERVICE_PROVIDER) {
                    loadProviderProfile(uid)
                }
            }
        }
    }

    fun loadProviderProfile(uid: String) {
        viewModelScope.launch {
            val result = authRepository.getServiceProviderProfile(uid)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = result.data
            }
        }
    }

    fun toggleProviderAvailability(isAvailable: Boolean) {
        val current = _currentProviderProfile.value ?: return
        viewModelScope.launch {
            val result = authRepository.updateProviderAvailability(current.uid, isAvailable)
            if (result is AuthResult.Success) {
                _currentProviderProfile.value = current.copy(isAvailable = isAvailable)
            }
        }
    }

    private val _selectedProviderState = MutableStateFlow<AuthResult<ServiceProviderProfile>?>(null)
    val selectedProviderState: StateFlow<AuthResult<ServiceProviderProfile>?> = _selectedProviderState.asStateFlow()

    private val _createRequestState = MutableStateFlow<AuthResult<com.example.data.model.ServiceRequest>?>(null)
    val createRequestState: StateFlow<AuthResult<com.example.data.model.ServiceRequest>?> = _createRequestState.asStateFlow()

    fun loadSelectedProviderProfile(uid: String) {
        viewModelScope.launch {
            _selectedProviderState.value = AuthResult.Loading
            val result = authRepository.getServiceProviderProfile(uid)
            _selectedProviderState.value = result
        }
    }

    fun createServiceRequest(
        provider: ServiceProviderProfile,
        description: String,
        addressDetails: String,
        proposedPriceDzd: Long? = null,
        customServiceId: String? = null
    ) {
        val user = _currentUserProfile.value
        val customerUid = user?.uid ?: authRepository.currentUserId ?: ""
        if (customerUid.isBlank()) {
            _createRequestState.value = AuthResult.Error("يرجى تسجيل الدخول أولاً لإرسال طلب الخدمة")
            return
        }
        viewModelScope.launch {
            _createRequestState.value = AuthResult.Loading
            val request = com.example.data.model.ServiceRequest(
                customerId = customerUid,
                customerName = user?.fullName?.ifBlank { "زبون" } ?: "زبون",
                customerPhone = user?.phone ?: "",
                providerId = provider.uid,
                providerName = provider.fullName,
                professionId = provider.professionId,
                professionNameAr = provider.professionNameAr,
                wilayaName = provider.wilayaName,
                communeName = provider.communeName,
                addressDetails = addressDetails,
                description = description,
                proposedPriceDzd = proposedPriceDzd,
                customServiceId = customServiceId,
                status = com.example.data.model.RequestStatus.PENDING
            )
            val result = authRepository.createServiceRequest(request)
            _createRequestState.value = result
        }
    }

    fun resetServiceRequestState() {
        _createRequestState.value = null
    }

    private val _customServicesState = MutableStateFlow<AuthResult<List<com.example.data.model.CustomService>>?>(null)
    val customServicesState: StateFlow<AuthResult<List<com.example.data.model.CustomService>>?> = _customServicesState.asStateFlow()

    fun loadCustomServices(providerId: String) {
        viewModelScope.launch {
            _customServicesState.value = AuthResult.Loading
            val result = authRepository.getCustomServices(providerId)
            _customServicesState.value = result
        }
    }

    fun addCustomService(service: com.example.data.model.CustomService, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.addCustomService(service)
            if (result is AuthResult.Success) {
                onResult(true, null)
                loadCustomServices(service.providerId)
            } else if (result is AuthResult.Error) {
                onResult(false, result.messageAr)
            }
        }
    }

    fun updateCustomService(service: com.example.data.model.CustomService, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.updateCustomService(service)
            if (result is AuthResult.Success) {
                onResult(true, null)
                loadCustomServices(service.providerId)
            } else if (result is AuthResult.Error) {
                onResult(false, result.messageAr)
            }
        }
    }

    fun deleteCustomService(providerId: String, serviceId: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val result = authRepository.deleteCustomService(providerId, serviceId)
            if (result is AuthResult.Success) {
                onResult(true, null)
                loadCustomServices(providerId)
            } else if (result is AuthResult.Error) {
                onResult(false, result.messageAr)
            }
        }
    }

     fun updateProviderProfile(context: android.content.Context? = null, profile: ServiceProviderProfile) {
         viewModelScope.launch {
             android.util.Log.d("KhedmatiTrace", "AuthViewModel updating provider profile: uid=${profile.uid}, avatarUrl=${profile.avatarUrl}")
             _updateProfileState.value = AuthResult.Loading
             val result = authRepository.updateServiceProviderProfile(context, profile)
             _updateProfileState.value = result
             if (result is AuthResult.Success) {
                 android.util.Log.d("KhedmatiTrace", "AuthViewModel update success: avatarUrl=${result.data.avatarUrl}, updatedAt=${result.data.updatedAt}")
                 _currentProviderProfile.value = result.data
                 
                 // Synchronize current user profile to prevent any stale state reading
                 val currentUsr = _currentUserProfile.value
                 if (currentUsr != null && currentUsr.uid == result.data.uid) {
                     _currentUserProfile.value = currentUsr.copy(
                         fullName = result.data.fullName,
                         phone = result.data.phone,
                         avatarUrl = result.data.avatarUrl,
                         wilayaCode = result.data.wilayaCode,
                         wilayaName = result.data.wilayaName,
                         communeName = result.data.communeName,
                         updatedAt = result.data.updatedAt
                     )
                 }
             }
         }
     }

    fun setCurrentUserForDemo(profile: UserProfile, providerProfile: ServiceProviderProfile? = null) {
        _currentUserProfile.value = profile
        _currentProviderProfile.value = providerProfile
    }

    fun logout() {
        authRepository.logout()
        notificationsJob?.cancel()
        notificationsJob = null
        currentObservedUid = null
        LocalNotificationHelper.resetSession()
        _currentUserProfile.value = null
        _currentProviderProfile.value = null
        _userNotificationsState.value = null
        _sessionState.value = AuthSessionState.Unauthenticated
        resetAuthStates()
    }

    fun resetAuthStates() {
        _loginState.value = null
        _customerRegState.value = null
        _providerRegState.value = null
        _updateProfileState.value = null
    }

    private val _customerRequestsState = MutableStateFlow<AuthResult<List<ServiceRequest>>?>(null)
    val customerRequestsState: StateFlow<AuthResult<List<ServiceRequest>>?> = _customerRequestsState.asStateFlow()

    private val _providerRequestsState = MutableStateFlow<AuthResult<List<ServiceRequest>>?>(null)
    val providerRequestsState: StateFlow<AuthResult<List<ServiceRequest>>?> = _providerRequestsState.asStateFlow()

    fun observeCustomerRequests() {
        val user = _currentUserProfile.value ?: return
        viewModelScope.launch {
            _customerRequestsState.value = AuthResult.Loading
            authRepository.getServiceRequestsFlowForCustomer(user.uid).collectLatest { result ->
                _customerRequestsState.value = result
            }
        }
    }

    fun observeProviderRequests() {
        val user = _currentUserProfile.value ?: return
        viewModelScope.launch {
            _providerRequestsState.value = AuthResult.Loading
            authRepository.getServiceRequestsFlowForProvider(user.uid).collectLatest { result ->
                _providerRequestsState.value = result
            }
        }
    }

    fun getServiceRequestFlow(requestId: String) = authRepository.getServiceRequestByIdFlow(requestId)

    fun updateServiceRequestStatus(
        requestId: String,
        newStatus: RequestStatus,
        onResult: (Boolean, String?) -> Unit
    ) {
        val user = _currentUserProfile.value
        if (user == null) {
            onResult(false, "يجب تسجيل الدخول أولاً")
            return
        }
        viewModelScope.launch {
            val result = authRepository.updateServiceRequestStatus(
                requestId = requestId,
                newStatus = newStatus,
                userUid = user.uid,
                userRole = user.role
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع")
            }
        }
    }

    fun submitReview(
        requestId: String,
        providerId: String,
        rating: Int,
        comment: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val user = _currentUserProfile.value
        if (user == null) {
            onResult(false, "يجب تسجيل الدخول أولاً")
            return
        }
        viewModelScope.launch {
            val review = Review(
                serviceRequestId = requestId,
                customerId = user.uid,
                customerName = user.fullName,
                providerId = providerId,
                rating = rating,
                comment = comment
            )
            val result = authRepository.submitReview(review)
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع")
            }
        }
    }

    // Chat ViewModel Methods
    fun observeUserConversations() {
        val uid = authRepository.currentUserId
        if (uid.isNullOrBlank()) {
            _userConversationsState.value = AuthResult.Error("يجب تسجيل الدخول لعرض المحادثات")
            return
        }
        viewModelScope.launch {
            authRepository.observeConversationsForUser(uid).collect { result ->
                _userConversationsState.value = result
            }
        }
    }

    fun openOrCreateConversation(
        customerId: String,
        customerName: String,
        customerPhotoUrl: String = "",
        providerId: String,
        providerName: String,
        providerPhotoUrl: String = "",
        providerProfession: String = "",
        serviceRequestId: String? = null,
        serviceRequestTitle: String? = null,
        isPublicRequest: Boolean = false,
        onResult: (String?, String?) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.getOrCreateConversation(
                customerId = customerId,
                customerName = customerName,
                customerPhotoUrl = customerPhotoUrl,
                providerId = providerId,
                providerName = providerName,
                providerPhotoUrl = providerPhotoUrl,
                providerProfession = providerProfession,
                serviceRequestId = serviceRequestId,
                serviceRequestTitle = serviceRequestTitle,
                isPublicRequest = isPublicRequest
            )
            when (result) {
                is AuthResult.Success -> {
                    _activeConversationState.value = result
                    onResult(result.data.id, null)
                }
                is AuthResult.Error -> {
                    _activeConversationState.value = result
                    onResult(null, result.messageAr)
                }
                else -> {
                    _activeConversationState.value = AuthResult.Error("خطأ غير معروف")
                    onResult(null, "خطأ غير معروف")
                }
            }
        }
    }

    fun loadConversationDetails(conversationId: String) {
        viewModelScope.launch {
            _activeConversationState.value = AuthResult.Loading
            val result = authRepository.getConversationById(conversationId)
            _activeConversationState.value = result
        }
    }

    fun observeChatMessages(conversationId: String) {
        if (conversationId.isBlank()) return
        viewModelScope.launch {
            _currentChatMessagesState.value = AuthResult.Loading
            authRepository.observeChatMessages(conversationId).collect { result ->
                _currentChatMessagesState.value = result
            }
        }
    }

    fun sendMessage(
        conversationId: String,
        text: String,
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        if (senderId.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لأداء هذا الإجراء")
            return
        }
        viewModelScope.launch {
            val result = authRepository.sendMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                text = text
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة")
            }
        }
    }

    fun sendVoiceMessage(
        conversationId: String,
        audioUrl: String,
        duration: Long,
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        val activeCtx = appContextRef
        if (senderId.isNullOrBlank() || activeCtx == null) {
            onResult(false, "يجب تسجيل الدخول وتوفر السياق لأداء هذا الإجراء")
            return
        }

        viewModelScope.launch {
            val uploadResult = authRepository.uploadChatMedia(activeCtx, audioUrl, "audio", conversationId)
            val uploadedUrl = when (uploadResult) {
                is AuthResult.Success -> uploadResult.data
                is AuthResult.Error -> {
                    onResult(false, uploadResult.messageAr)
                    return@launch
                }
                else -> {
                    onResult(false, "حدث خطأ أثناء رفع الرسالة الصوتية")
                    return@launch
                }
            }

            val result = authRepository.sendVoiceMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                audioUrl = uploadedUrl,
                duration = duration
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة الصوتية")
            }
        }
    }

    fun sendMediaMessage(
        conversationId: String,
        mediaUrl: String,
        type: String,
        duration: Long = 0L,
        caption: String = "",
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        val activeCtx = appContextRef
        if (senderId.isNullOrBlank() || activeCtx == null) {
            onResult(false, "يجب تسجيل الدخول وتوفر السياق لأداء هذا الإجراء")
            return
        }

        viewModelScope.launch {
            val uploadResult = authRepository.uploadChatMedia(activeCtx, mediaUrl, type, conversationId)
            val uploadedUrl = when (uploadResult) {
                is AuthResult.Success -> uploadResult.data
                is AuthResult.Error -> {
                    onResult(false, uploadResult.messageAr)
                    return@launch
                }
                else -> {
                    onResult(false, "حدث خطأ أثناء رفع الوسائط")
                    return@launch
                }
            }

            val result = authRepository.sendMediaMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                mediaUrl = uploadedUrl,
                type = type,
                duration = duration,
                caption = caption
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة")
            }
        }
    }

    fun markMessagesAsRead(conversationId: String) {
        val uid = authRepository.currentUserId ?: return
        if (conversationId.isBlank()) return
        viewModelScope.launch {
            authRepository.markMessagesAsRead(conversationId, uid)
        }
    }

    // Public Service Requests
    fun createPublicServiceRequest(
        title: String,
        description: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        addressDetails: String = "",
        budgetDzd: Long? = null,
        scheduledDate: Long? = null,
        imageUrl: String? = null
    ) {
        val customerId = authRepository.currentUserId
        if (customerId.isNullOrBlank()) {
            _createPublicRequestState.value = AuthResult.Error("يجب تسجيل الدخول لنشر طلب خدمة")
            return
        }

        val currentUser = _currentUserProfile.value
        val providerProfile = _currentProviderProfile.value

        val creatorName = currentUser?.fullName?.takeIf { it.isNotBlank() }
            ?: providerProfile?.fullName?.takeIf { it.isNotBlank() }
            ?: "مستخدم خدمتي"
        val creatorPhone = currentUser?.phone?.takeIf { it.isNotBlank() }
            ?: providerProfile?.phone?.takeIf { it.isNotBlank() }
            ?: ""

        Log.d("AuthViewModel", "Creating public service request: authUid=$customerId, profileName=$creatorName, profilePhone=$creatorPhone, userProfileNull=${currentUser == null}, providerProfileNull=${providerProfile == null}")

        if (title.isBlank()) {
            _createPublicRequestState.value = AuthResult.Error("يرجى كتابة عنوان واضح لطلب الخدمة")
            return
        }

        if (description.isBlank()) {
            _createPublicRequestState.value = AuthResult.Error("يرجى كتابة تفاصيل ووصف المشكلة أو الخدمة المطلوبة")
            return
        }

        if (professionId.isBlank() || professionNameAr.isBlank()) {
            _createPublicRequestState.value = AuthResult.Error("يرجى اختيار التخصص المهني المطلوب")
            return
        }

        if (wilayaCode <= 0 || wilayaName.isBlank() || communeName.isBlank()) {
            _createPublicRequestState.value = AuthResult.Error("يرجى تحديد الولاية والبلدية بدقة")
            return
        }

        _createPublicRequestState.value = AuthResult.Loading

        viewModelScope.launch {
            val request = PublicServiceRequest(
                customerId = customerId,
                customerName = creatorName,
                customerPhone = creatorPhone,
                title = title.trim(),
                description = description.trim(),
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                addressDetails = addressDetails.trim(),
                budgetDzd = budgetDzd,
                scheduledDate = scheduledDate,
                imageUrl = imageUrl
            )

            Log.d("AuthViewModel", "Submitting public service request to repository with customerId=$customerId")
            val result = authRepository.createPublicServiceRequest(request)
            _createPublicRequestState.value = result
        }
    }

    fun resetCreatePublicRequestState() {
        _createPublicRequestState.value = null
    }

    fun observeOpenPublicRequests() {
        _openPublicRequestsState.value = AuthResult.Loading
        viewModelScope.launch {
            authRepository.getOpenPublicServiceRequestsFlow().collectLatest { result ->
                _openPublicRequestsState.value = result
            }
        }
    }

    fun observeCustomerPublicRequests() {
        val customerId = authRepository.currentUserId ?: return
        _customerPublicRequestsState.value = AuthResult.Loading
        viewModelScope.launch {
            authRepository.getCustomerPublicRequestsFlow(customerId).collectLatest { result ->
                _customerPublicRequestsState.value = result
            }
        }
    }

    fun getPublicServiceRequestFlow(requestId: String): kotlinx.coroutines.flow.Flow<AuthResult<PublicServiceRequest?>> {
        return authRepository.getPublicServiceRequestByIdFlow(requestId)
    }

    fun observePublicRequestOffers(requestId: String) {
        _publicRequestOffersState.value = AuthResult.Loading
        viewModelScope.launch {
            authRepository.getPublicRequestOffersFlow(requestId).collectLatest { result ->
                _publicRequestOffersState.value = result
            }
        }
    }

    fun observeMyPublicRequestOffer(requestId: String, providerId: String) {
        _publicRequestOffersState.value = AuthResult.Loading
        viewModelScope.launch {
            authRepository.getMyPublicRequestOfferFlow(requestId, providerId).collectLatest { result ->
                when (result) {
                    is AuthResult.Success -> {
                        val offer = result.data
                        val list = if (offer != null) listOf(offer) else emptyList()
                        _publicRequestOffersState.value = AuthResult.Success(list)
                    }
                    is AuthResult.Error -> {
                        _publicRequestOffersState.value = AuthResult.Error(result.messageAr, result.rawError)
                    }
                    is AuthResult.Loading -> {
                        _publicRequestOffersState.value = AuthResult.Loading
                    }
                    is AuthResult.ProfileMissing -> {
                        _publicRequestOffersState.value = AuthResult.Error("الملف الشخصي غير مكتمل")
                    }
                }
            }
        }
    }

    fun resolveRequestDestination(requestId: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val isPublic = authRepository.isPublicRequest(requestId)
            onResult(isPublic)
        }
    }

    fun getProviderOfferForRequest(
        requestId: String,
        providerId: String,
        onResult: (PublicRequestOffer?) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.getProviderOfferForRequest(requestId, providerId)
            if (result is AuthResult.Success) {
                onResult(result.data)
            } else {
                onResult(null)
            }
        }
    }

    fun submitPublicRequestOffer(
        requestId: String,
        priceDzd: Long,
        message: String,
        estimatedTime: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val providerProfile = _currentProviderProfile.value
        val userProfile = _currentUserProfile.value
        val providerId = authRepository.currentUserId

        if (providerId.isNullOrBlank() || providerProfile == null) {
            onResult(false, "يجب تسجيل الدخول كحرفي معتمد لتقديم عرض سعر")
            return
        }

        if (priceDzd <= 0) {
            onResult(false, "يرجى تحديد سعر مقترح صالح (أكبر من 0 د.ج)")
            return
        }

        viewModelScope.launch {
            val offer = PublicRequestOffer(
                id = providerId,
                requestId = requestId,
                providerId = providerId,
                providerName = providerProfile.fullName.ifBlank { userProfile?.fullName ?: "حرفي خدمتي" },
                providerProfession = providerProfile.professionNameAr,
                providerPhone = providerProfile.phone.ifBlank { userProfile?.phone ?: "" },
                providerAvatarUrl = providerProfile.effectiveAvatarUrl(),
                providerRating = providerProfile.rating,
                providerRatingCount = providerProfile.reviewCount,
                providerWilayaName = providerProfile.wilayaName,
                providerCommuneName = providerProfile.communeName,
                priceDzd = priceDzd,
                message = message.trim(),
                estimatedTime = estimatedTime.trim()
            )

            val result = authRepository.submitPublicRequestOffer(offer)
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع أثناء إرسال العرض")
            }
        }
    }

    fun acceptPublicRequestOffer(
        requestId: String,
        offer: PublicRequestOffer,
        onResult: (Boolean, Conversation?, String?) -> Unit
    ) {
        val customerProfile = _currentUserProfile.value
        val customerId = authRepository.currentUserId

        if (customerId.isNullOrBlank() || customerProfile == null) {
            onResult(false, null, "يجب تسجيل الدخول لإجراء هذه العملية")
            return
        }

        viewModelScope.launch {
            val result = authRepository.acceptPublicRequestOffer(
                requestId = requestId,
                selectedOffer = offer,
                customerId = customerId,
                customerName = customerProfile.fullName,
                customerPhotoUrl = customerProfile.avatarUrl
            )

            when (result) {
                is AuthResult.Success -> onResult(true, result.data, null)
                is AuthResult.Error -> onResult(false, null, result.messageAr)
                else -> onResult(false, null, "حدث خطأ غير متوقع عند قبول العرض")
            }
        }
    }

    fun cancelPublicServiceRequest(
        requestId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val customerId = authRepository.currentUserId
        if (customerId.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لإجراء هذه العملية")
            return
        }

        viewModelScope.launch {
            val result = authRepository.cancelPublicServiceRequest(requestId, customerId)
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ أثناء إلغاء الطلب")
            }
        }
    }

    fun completePublicServiceRequest(
        requestId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val currentUid = authRepository.currentUserId
        if (currentUid.isNullOrBlank()) {
            onResult(false, "يجب تسجيل الدخول لإجراء هذه العملية")
            return
        }

        viewModelScope.launch {
            val result = authRepository.completePublicServiceRequest(requestId, currentUid)
            when (result) {
                is AuthResult.Success -> {
                    // Refresh provider profile in viewmodel if current user is provider
                    authRepository.currentUserId?.let { uid ->
                        if (_currentUserProfile.value?.role == UserRole.SERVICE_PROVIDER) {
                            val providerResult = authRepository.getServiceProviderProfile(uid)
                            if (providerResult is AuthResult.Success) {
                                val newData = providerResult.data
                                val current = _currentProviderProfile.value
                                if (current == null || newData.updatedAt >= current.updatedAt) {
                                    _currentProviderProfile.value = newData
                                }
                            }
                        }
                    }
                    onResult(true, null)
                }
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ أثناء إتمام الخدمة")
            }
        }
    }

    fun submitPublicRequestReview(
        requestId: String,
        rating: Int,
        comment: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val userProfile = _currentUserProfile.value
        val customerName = userProfile?.fullName ?: "زبون خدمتي"

        viewModelScope.launch {
            val result = authRepository.submitPublicRequestReview(
                requestId = requestId,
                rating = rating,
                comment = comment,
                customerName = customerName
            )
            when (result) {
                is AuthResult.Success -> onResult(true, null)
                is AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ أثناء إرسال التقييم")
            }
        }
    }

    fun getReviewForPublicRequest(
        requestId: String,
        onResult: (Review?) -> Unit
    ) {
        viewModelScope.launch {
            val result = authRepository.getReviewForPublicRequest(requestId)
            if (result is AuthResult.Success) {
                onResult(result.data)
            } else {
                onResult(null)
            }
        }
    }

    private val _providerReviewsState = MutableStateFlow<AuthResult<List<Review>>>(AuthResult.Loading)
    val providerReviewsState: StateFlow<AuthResult<List<Review>>> = _providerReviewsState.asStateFlow()

    fun loadProviderReviews(providerId: String) {
        if (providerId.isBlank()) return
        viewModelScope.launch {
            _providerReviewsState.value = AuthResult.Loading
            _providerReviewsState.value = authRepository.getProviderReviews(providerId)
        }
    }

    // ==================================================
    // NOTIFICATIONS VIEWMODEL METHODS
    // ==================================================

    private var notificationsJob: Job? = null
    private var appContextRef: Context? = null
    private var currentObservedUid: String? = null

    fun observeUserNotifications(context: Context? = null) {
        val uid = authRepository.currentUserId
        if (uid.isNullOrBlank()) {
            _userNotificationsState.value = AuthResult.Error("يجب تسجيل الدخول لعرض الإشعارات")
            return
        }
        if (context != null) {
            appContextRef = context.applicationContext
        }
        if (notificationsJob?.isActive == true && currentObservedUid == uid) {
            return
        }
        notificationsJob?.cancel()
        currentObservedUid = uid
        LocalNotificationHelper.startSession(uid)
        notificationsJob = viewModelScope.launch {
            authRepository.getMyNotificationsFlow(uid).collect { result ->
                _userNotificationsState.value = result
                val activeCtx = appContextRef
                if (result is AuthResult.Success && activeCtx != null) {
                    LocalNotificationHelper.handleNewNotifications(activeCtx, result.data)
                }
            }
        }
    }

    fun markNotificationAsRead(notificationId: String) {
        viewModelScope.launch {
            authRepository.markNotificationAsRead(notificationId)
        }
    }

    fun markAllNotificationsAsRead() {
        val uid = authRepository.currentUserId ?: return
        viewModelScope.launch {
            authRepository.markAllNotificationsAsRead(uid)
        }
    }

    fun deleteNotification(notificationId: String) {
        viewModelScope.launch {
            authRepository.deleteNotification(notificationId)
        }
    }

    fun deleteAllNotifications() {
        val uid = authRepository.currentUserId ?: return
        viewModelScope.launch {
            authRepository.deleteAllNotifications(uid)
        }
    }
}
