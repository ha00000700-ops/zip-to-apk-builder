package com.example.ui.screens.request

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.components.KhedmatiTextField
import androidx.compose.material3.Surface
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.BorderStroke
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateServiceRequestScreen(
    providerUid: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onRequestSubmitted: () -> Unit
) {
    val selectedProviderState by authViewModel.selectedProviderState.collectAsState()
    val createRequestState by authViewModel.createRequestState.collectAsState()

    var description by remember { mutableStateOf("") }
    var addressDetails by remember { mutableStateOf("") }
    var proposedPrice by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    LaunchedEffect(providerUid) {
        authViewModel.loadSelectedProviderProfile(providerUid)
        authViewModel.loadCustomServices(providerUid)
        authViewModel.resetServiceRequestState()
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "إرسال طلب خدمة",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val pState = selectedProviderState) {
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(text = pState.messageAr, color = ErrorRed, textAlign = TextAlign.Center)
                    }
                }
                is AuthResult.Success -> {
                    val provider = pState.data

                    if (createRequestState is AuthResult.Success) {
                        val createdReq = (createRequestState as AuthResult.Success).data
                        Column(
                            modifier = Modifier.fillMaxSize().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                modifier = Modifier.size(80.dp),
                                shape = CircleShape,
                                color = SuccessGreen.copy(alpha = 0.1f)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.CheckCircle, null, tint = SuccessGreen, modifier = Modifier.size(40.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(24.dp))
                            Text(text = "تم إرسال الطلب بنجاح", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = BlueDark)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سيتواصل معك الحرفي ${provider.fullName} قريباً للمعاينة والتأكيد.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextTertiaryLight,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(32.dp))
                            KhedmatiPrimaryButton(text = "العودة للرئيسية", onClick = onRequestSubmitted)
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(24.dp)
                        ) {
                            // Provider Card
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(20.dp),
                                color = Color.White,
                                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Surface(modifier = Modifier.size(50.dp), shape = RoundedCornerShape(12.dp), color = BlueContainer.copy(alpha = 0.4f)) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(Icons.Default.Handyman, null, tint = BluePrimary, modifier = Modifier.size(24.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column {
                                        Text(text = provider.fullName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = BlueDark)
                                        Text(text = provider.professionNameAr, style = MaterialTheme.typography.bodySmall, color = TextTertiaryLight)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Custom Services
                            val customServicesState by authViewModel.customServicesState.collectAsState()
                            var selectedService by remember { mutableStateOf<com.example.data.model.CustomService?>(null) }
                            if (customServicesState is AuthResult.Success && (customServicesState as AuthResult.Success<List<com.example.data.model.CustomService>>).data.isNotEmpty()) {
                                Text(text = "اختر الخدمة المطلوبة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = BlueDark)
                                Spacer(modifier = Modifier.height(12.dp))
                                FlowRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    (customServicesState as AuthResult.Success<List<com.example.data.model.CustomService>>).data.forEach { service ->
                                        FilterChip(
                                            selected = selectedService == service,
                                            onClick = { selectedService = if (selectedService == service) null else service },
                                            label = { Text(service.name) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = BluePrimary,
                                                selectedLabelColor = Color.White
                                            ),
                                            border = FilterChipDefaults.filterChipBorder(
                                                enabled = true,
                                                selected = selectedService == service,
                                                borderColor = OutlineLight,
                                                selectedBorderColor = BluePrimary
                                            ),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(24.dp))
                            }

                            // Form
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(28.dp),
                                color = Color.White,
                                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                            ) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    KhedmatiTextField(
                                        value = description,
                                        onValueChange = { description = it; errorMessage = "" },
                                        label = "وصف المشكلة أو الطلب",
                                        leadingIcon = Icons.Default.Description,
                                        singleLine = false,
                                        maxLines = 4
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    KhedmatiTextField(
                                        value = addressDetails,
                                        onValueChange = { addressDetails = it; errorMessage = "" },
                                        label = "العنوان بالتفصيل",
                                        leadingIcon = Icons.Default.LocationOn
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    KhedmatiTextField(
                                        value = proposedPrice,
                                        onValueChange = { proposedPrice = it.filter { c -> c.isDigit() } },
                                        label = "الميزانية المقترحة (د.ج)",
                                        leadingIcon = Icons.Default.Payments,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                    )
                                    
                                    if (errorMessage.isNotBlank()) {
                                        Text(text = errorMessage, color = ErrorRed, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
                                    }
                                    if (createRequestState is AuthResult.Error) {
                                        Text(text = (createRequestState as AuthResult.Error).messageAr, color = ErrorRed, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 12.dp))
                                    }

                                    Spacer(modifier = Modifier.height(32.dp))
                                    KhedmatiPrimaryButton(
                                        text = "تأكيد إرسال الطلب",
                                        onClick = {
                                            if (description.isBlank()) { errorMessage = "يرجى وصف الخدمة المطلوبة"; return@KhedmatiPrimaryButton }
                                            if (addressDetails.isBlank()) { errorMessage = "يرجى إدخال العنوان"; return@KhedmatiPrimaryButton }
                                            authViewModel.createServiceRequest(provider, description, addressDetails, proposedPrice.toLongOrNull(), selectedService?.id)
                                        },
                                        isLoading = createRequestState is AuthResult.Loading
                                    )
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}
