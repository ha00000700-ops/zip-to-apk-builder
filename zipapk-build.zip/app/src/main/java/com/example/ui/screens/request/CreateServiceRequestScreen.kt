package com.example.ui.screens.request

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateServiceRequestScreen(
    providerUid: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onRequestSubmitted: () -> Unit
) {
    val selectedProviderState by authViewModel.selectedProviderState.collectAsState()
    val createRequestState by authViewModel.createRequestState.collectAsState()

    var description by remember { mutableStateOf("") }
    var addressDetails by remember { mutableStateOf("") }
    var proposedPrice by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    LaunchedEffect(providerUid) {
        authViewModel.loadSelectedProviderProfile(providerUid)
        authViewModel.loadCustomServices(providerUid) // Load custom services
        authViewModel.resetServiceRequestState()
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "إرسال طلب خدمة للحرفي",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val pState = selectedProviderState) {
                is AuthResult.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = EmeraldPrimary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "جاري تحضير نموذج الطلب...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is AuthResult.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "تعذر تحميل بيانات الحرفي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = pState.messageAr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is AuthResult.Success -> {
                    val provider = pState.data

                    if (createRequestState is AuthResult.Success) {
                        val createdReq = (createRequestState as AuthResult.Success).data
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "تم الإرسال بنجاح",
                                tint = SuccessGreen,
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "تم إرسال طلب الخدمة بنجاح! 🎉",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDark,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "تم تسجيل طلبك في Cloud Firestore برقم مرجعي:\n${createdReq.id.take(12)}...",
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سيتواصل معك الحرفي (${provider.fullName}) قريباً لحجم المعاينة والتأكيد.",
                                style = MaterialTheme.typography.bodySmall,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            KhedmatiPrimaryButton(
                                text = "العودة إلى الصفحة الرئيسية",
                                onClick = onRequestSubmitted,
                                testTag = "back_to_home_after_request"
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Target Provider Summary Card
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = EmeraldContainer)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Handyman,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(32.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "الطلب موجه إلى الحرفي: ${provider.fullName}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldDark
                                        )
                                        Text(
                                            text = "${provider.professionNameAr} • ${provider.communeName}، ${provider.wilayaName}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = EmeraldPrimary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            // Custom Service Selection
                            val customServicesState by authViewModel.customServicesState.collectAsState()
                            var selectedService by remember { mutableStateOf<com.example.data.model.CustomService?>(null) }
                            if (customServicesState is AuthResult.Success && (customServicesState as AuthResult.Success<List<com.example.data.model.CustomService>>).data.isNotEmpty()) {
                                Text(
                                    text = "اختيار خدمة محددة (اختياري)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    (customServicesState as AuthResult.Success<List<com.example.data.model.CustomService>>).data.forEach { service ->
                                        FilterChip(
                                            selected = selectedService == service,
                                            onClick = { selectedService = if (selectedService == service) null else service },
                                            label = { Text(service.name) }
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                            }

                            Text(
                                text = "تفاصيل العمل المطلوب",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = description,
                                onValueChange = {
                                    description = it
                                    errorMessage = ""
                                },
                                label = { Text("وصف الخدمة أو المشكلة بالتفصيل *") },
                                placeholder = { Text("مثال: تسرب مياه في المطبخ يحتاج إصلاح عاجل وشفرة أنبوب...") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Description,
                                        contentDescription = null,
                                        tint = EmeraldPrimary
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .testTag("request_description_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "العنوان والموقع",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = addressDetails,
                                onValueChange = {
                                    addressDetails = it
                                    errorMessage = ""
                                },
                                label = { Text("العنوان بالتفصيل (الحي، الشارع، رقم المنزل) *") },
                                placeholder = { Text("مثال: حي 500 مسكن، عمارة ب، شقة 12") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = EmeraldPrimary
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("request_address_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                ),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "الميزانية المقترحة (اختياري)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = proposedPrice,
                                onValueChange = {
                                    proposedPrice = it.filter { char -> char.isDigit() }
                                },
                                label = { Text("الميزانية التقديرية (بالدينار الجزائري DZD)") },
                                placeholder = { Text("مثال: 3000") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        tint = EmeraldPrimary
                                    )
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("request_price_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EmeraldPrimary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                                ),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            if (errorMessage.isNotBlank()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = errorMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (createRequestState is AuthResult.Error) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = (createRequestState as AuthResult.Error).messageAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            KhedmatiPrimaryButton(
                                text = "تأكيد وإرسال الطلب إلى الحرفي",
                                onClick = {
                                    if (description.isBlank()) {
                                        errorMessage = "يرجى إدخال وصف للخدمة المطلوب إنجازها"
                                        return@KhedmatiPrimaryButton
                                    }
                                    if (addressDetails.isBlank()) {
                                        errorMessage = "يرجى إدخال عنوان ومكان إنجاز الخدمة"
                                        return@KhedmatiPrimaryButton
                                    }
                                    val price = proposedPrice.toLongOrNull()
                                    authViewModel.createServiceRequest(
                                        provider = provider,
                                        description = description,
                                        addressDetails = addressDetails,
                                        proposedPriceDzd = price,
                                        customServiceId = selectedService?.id
                                    )
                                },
                                isLoading = createRequestState is AuthResult.Loading,
                                testTag = "submit_service_request_button"
                            )
                        }
                    }
                }
                else -> {}
            }
        }
    }
}
