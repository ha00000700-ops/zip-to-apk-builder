package com.example.ui.screens.notifications

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToPublicRequestDetails: (String) -> Unit,
    onNavigateToChat: (String) -> Unit,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val notifsState by authViewModel.userNotificationsState.collectAsState()
    var showOnlyUnread by remember { mutableStateOf(false) }

    val context = LocalContext.current
    LaunchedEffect(Unit) {
        authViewModel.observeUserNotifications(context.applicationContext)
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الإشعارات",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = notifsState) {
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(text = state.messageAr, color = Color.Red, textAlign = TextAlign.Center)
                    }
                }
                is AuthResult.Success -> {
                    val allNotifs = state.data
                    val unreadCount = allNotifs.count { !it.isRead }
                    val displayedNotifs = if (showOnlyUnread) allNotifs.filter { !it.isRead } else allNotifs

                    if (allNotifs.isEmpty()) {
                        EmptyNotificationsView()
                    } else {
                        // Filter Section
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FilterChip(
                                selected = !showOnlyUnread,
                                onClick = { showOnlyUnread = false },
                                label = { Text("الكل (${allNotifs.size})") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BluePrimary,
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White,
                                    labelColor = TextSecondaryLight
                                ),
                                border = BorderStroke(1.dp, if (!showOnlyUnread) BluePrimary else OutlineLight.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp)
                            )
                            FilterChip(
                                selected = showOnlyUnread,
                                onClick = { showOnlyUnread = true },
                                label = { Text("غير المقروءة ($unreadCount)") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = BluePrimary,
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White,
                                    labelColor = TextSecondaryLight
                                ),
                                border = BorderStroke(1.dp, if (showOnlyUnread) BluePrimary else OutlineLight.copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }

                        if (displayedNotifs.isEmpty()) {
                            FilterEmptyNotificationsView(onShowAllClick = { showOnlyUnread = false })
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(displayedNotifs, key = { it.id }) { notif ->
                                    NotificationItemCard(
                                        notification = notif,
                                        onClick = {
                                            if (!notif.isRead) {
                                                authViewModel.markNotificationAsRead(notif.id)
                                            }
                                            when {
                                                notif.targetType == AppNotificationTargetType.PUBLIC_REQUEST ||
                                                notif.type == AppNotificationType.NEW_PUBLIC_REQUEST ||
                                                notif.type == AppNotificationType.NEW_OFFER ||
                                                notif.type == AppNotificationType.OFFER_ACCEPTED ||
                                                notif.type == AppNotificationType.SERVICE_COMPLETED -> {
                                                    if (notif.targetId.isNotBlank()) onNavigateToPublicRequestDetails(notif.targetId)
                                                }
                                                notif.targetType == AppNotificationTargetType.CONVERSATION ||
                                                notif.type == AppNotificationType.NEW_MESSAGE -> {
                                                    if (notif.targetId.isNotBlank()) onNavigateToChat(notif.targetId)
                                                }
                                                notif.targetType == AppNotificationTargetType.SERVICE_REQUEST -> {
                                                    if (notif.targetId.isNotBlank()) onNavigateToRequestDetails(notif.targetId)
                                                }
                                                else -> {}
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun NotificationItemCard(
    notification: AppNotification,
    onClick: () -> Unit
) {
    val isUnread = !notification.isRead
    val attributes = getNotificationAttributes(notification.type)

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = if (isUnread) BluePrimary.copy(alpha = 0.03f) else Color.White,
        border = BorderStroke(1.dp, if (isUnread) BluePrimary.copy(alpha = 0.3f) else OutlineLight.copy(alpha = 0.5f)),
        shadowElevation = if (isUnread) 2.dp else 0.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(attributes.iconBgColor.copy(alpha = 0.1f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = attributes.icon, contentDescription = null, tint = attributes.iconTint)
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = attributes.typeLabelAr,
                        style = MaterialTheme.typography.labelSmall,
                        color = attributes.iconTint,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = formatRelativeTime(notification.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiaryLight
                    )
                }
                
                Text(
                    text = notification.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Black,
                    color = BlueDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = notification.body,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isUnread) BlueDark else TextSecondaryLight,
                    fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }
            
            if (isUnread) {
                Box(
                    modifier = Modifier
                        .padding(start = 8.dp, top = 24.dp)
                        .size(8.dp)
                        .background(BluePrimary, CircleShape)
                )
            }
        }
    }
}

@Composable
private fun EmptyNotificationsView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Ambient soft icon container
            Surface(
                modifier = Modifier.size(92.dp),
                shape = CircleShape,
                color = BlueContainer.copy(alpha = 0.5f),
                border = BorderStroke(1.5.dp, BluePrimary.copy(alpha = 0.2f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "لا توجد إشعارات حالياً",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "ستصلك هنا تنبيهات فورية عند تقديم عروض أسعار جديدة، قبول العروض، والرسائل والطلبات العامة في مجالك.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun FilterEmptyNotificationsView(
    onShowAllClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                modifier = Modifier.size(84.dp),
                shape = CircleShape,
                color = SuccessGreenContainer.copy(alpha = 0.6f),
                border = BorderStroke(1.5.dp, SuccessGreen.copy(alpha = 0.25f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircleOutline,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "لا توجد إشعارات غير مقروءة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "رائع! لقد اطلعت على جميع التنبيهات والإشعارات الواردة.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            TextButton(
                onClick = onShowAllClick,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "عرض جميع الإشعارات",
                    style = MaterialTheme.typography.labelLarge,
                    color = BluePrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private data class NotificationVisualAttributes(
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconTint: Color,
    val typeLabelAr: String
)

private fun getNotificationAttributes(type: String): NotificationVisualAttributes {
    return when (type) {
        AppNotificationType.NEW_PUBLIC_REQUEST -> NotificationVisualAttributes(
            icon = Icons.Default.Campaign,
            iconBgColor = Color(0xFFFFF3E0), // Light Orange/Amber
            iconTint = Color(0xFFE65100),   // Deep Orange
            typeLabelAr = "طلب عام جديد"
        )
        AppNotificationType.NEW_OFFER -> NotificationVisualAttributes(
            icon = Icons.Default.MonetizationOn,
            iconBgColor = Color(0xFFFFF8E1), // Light Amber
            iconTint = Color(0xFFF57F17),   // Deep Amber
            typeLabelAr = "عرض سعر جديد"
        )
        AppNotificationType.OFFER_ACCEPTED -> NotificationVisualAttributes(
            icon = Icons.Default.CheckCircle,
            iconBgColor = Color(0xFFE8F5E9), // Light Green
            iconTint = Color(0xFF2E7D32),   // Deep Green
            typeLabelAr = "تم قبول العرض"
        )
        AppNotificationType.NEW_MESSAGE -> NotificationVisualAttributes(
            icon = Icons.Default.Forum,
            iconBgColor = Color(0xFFE0F2F1), // Light Teal
            iconTint = Color(0xFF00796B),   // Deep Teal
            typeLabelAr = "رسالة خاصة"
        )
        AppNotificationType.SERVICE_COMPLETED -> NotificationVisualAttributes(
            icon = Icons.Default.AssignmentTurnedIn,
            iconBgColor = Color(0xFFEDE7F6), // Light Purple
            iconTint = Color(0xFF512DA8),   // Deep Purple
            typeLabelAr = "اكتمال الخدمة"
        )
        AppNotificationType.REQUEST_ASSIGNED -> NotificationVisualAttributes(
            icon = Icons.Default.Work,
            iconBgColor = Color(0xFFE3F2FD), // Light Blue
            iconTint = Color(0xFF1976D2),   // Deep Blue
            typeLabelAr = "تعيين طلب"
        )
        AppNotificationType.REQUEST_CANCELLED -> NotificationVisualAttributes(
            icon = Icons.Default.Cancel,
            iconBgColor = Color(0xFFFFEBEE), // Light Red
            iconTint = Color(0xFFD32F2F),   // Deep Red
            typeLabelAr = "إلغاء الطلب"
        )
        else -> NotificationVisualAttributes(
            icon = Icons.Default.Notifications,
            iconBgColor = Color(0xFFF0F4F2),
            iconTint = Color(0xFF4A5568),
            typeLabelAr = "تنبيه"
        )
    }
}

private fun formatRelativeTime(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    val diff = System.currentTimeMillis() - timestamp
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        minutes < 1 -> "الآن"
        minutes < 60 -> "منذ $minutes دقيقة"
        hours < 24 -> "منذ $hours ساعة"
        days == 1L -> "أمس"
        days < 7 -> "منذ $days أيام"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

