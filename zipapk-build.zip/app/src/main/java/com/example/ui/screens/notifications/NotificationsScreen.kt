package com.example.ui.screens.notifications

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.IconButton
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.SurfaceLight
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotificationsScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToPublicRequestDetails: (String) -> Unit,
    onNavigateToChat: (String) -> Unit,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val notifsState by authViewModel.userNotificationsState.collectAsState()
    var showOnlyUnread by remember { mutableStateOf(false) }

    val context = LocalContext.current
    LaunchedEffect(Unit) {
        authViewModel.observeUserNotifications(context.applicationContext)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
        topBar = {
            val unreadCount = (notifsState as? AuthResult.Success)?.data?.count { !it.isRead } ?: 0
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(listOf(BlueDark, BluePrimary)),
                            shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
                        )
                        .padding(top = 48.dp, bottom = 40.dp, start = 24.dp, end = 24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(18.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "الإشعارات 🔔",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "تابع آخر التحديثات والطلبات الجديدة",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (unreadCount > 0) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.clickable { authViewModel.markAllNotificationsAsRead() }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DoneAll,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "قراءة الكل",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
            containerColor = BackgroundLight
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (val state = notifsState) {
                    is AuthResult.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = BluePrimary,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                    is AuthResult.Error -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = ErrorRedContainer,
                                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = state.messageAr,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = ErrorRed,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                    is AuthResult.Success -> {
                        val allNotifs = state.data
                        val unreadCount = allNotifs.count { !it.isRead }
                        val displayedNotifs = if (showOnlyUnread) {
                            allNotifs.filter { !it.isRead }
                        } else {
                            allNotifs
                        }

                        if (allNotifs.isEmpty()) {
                            EmptyNotificationsView()
                        } else {
                            // Filter Bar with clean marketplace aesthetic
                            Surface(
                                color = SurfaceLight,
                                shadowElevation = 0.5.dp,
                                border = BorderStroke(0.5.dp, OutlineLight.copy(alpha = 0.35f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // "All" Filter Chip
                                    FilterChip(
                                        selected = !showOnlyUnread,
                                        onClick = { showOnlyUnread = false },
                                        label = {
                                            Text(
                                                text = "الكل (${allNotifs.size})",
                                                fontWeight = if (!showOnlyUnread) FontWeight.Bold else FontWeight.Medium
                                            )
                                        },
                                        shape = RoundedCornerShape(20.dp),
                                         colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BluePrimary,
                                            selectedLabelColor = Color.White,
                                            containerColor = BackgroundLight,
                                            labelColor = TextSecondaryLight
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = !showOnlyUnread,
                                            borderColor = if (!showOnlyUnread) BluePrimary else OutlineLight.copy(alpha = 0.6f)
                                        )
                                    )

                                    // "Unread" Filter Chip
                                    FilterChip(
                                        selected = showOnlyUnread,
                                        onClick = { showOnlyUnread = true },
                                        label = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (unreadCount > 0) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(8.dp)
                                                            .clip(CircleShape)
                                                            .background(if (showOnlyUnread) Color.White else AmberPrimary)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                }
                                                Text(
                                                    text = "غير المقروءة ($unreadCount)",
                                                    fontWeight = if (showOnlyUnread) FontWeight.Bold else FontWeight.Medium
                                                )
                                            }
                                        },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = BluePrimary,
                                            selectedLabelColor = Color.White,
                                            containerColor = BackgroundLight,
                                            labelColor = TextSecondaryLight
                                        ),
                                        border = FilterChipDefaults.filterChipBorder(
                                            enabled = true,
                                            selected = showOnlyUnread,
                                            borderColor = if (showOnlyUnread) BluePrimary else OutlineLight.copy(alpha = 0.6f)
                                        )
                                    )
                                }
                            }

                            if (displayedNotifs.isEmpty()) {
                                FilterEmptyNotificationsView(
                                    onShowAllClick = { showOnlyUnread = false }
                                )
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    items(displayedNotifs, key = { it.id }) { notif ->
                                        NotificationItemCard(
                                            notification = notif,
                                            onClick = {
                                                if (!notif.isRead) {
                                                    authViewModel.markNotificationAsRead(notif.id)
                                                }
                                                when {
                                                    notif.targetType == AppNotificationTargetType.PUBLIC_REQUEST ||
                                                    notif.type == AppNotificationType.NEW_PUBLIC_REQUEST ||
                                                    notif.type == AppNotificationType.NEW_OFFER ||
                                                    notif.type == AppNotificationType.OFFER_ACCEPTED ||
                                                    notif.type == AppNotificationType.SERVICE_COMPLETED -> {
                                                        if (notif.targetId.isNotBlank()) {
                                                            onNavigateToPublicRequestDetails(notif.targetId)
                                                        }
                                                    }
                                                    notif.targetType == AppNotificationTargetType.CONVERSATION ||
                                                    notif.type == AppNotificationType.NEW_MESSAGE -> {
                                                        if (notif.targetId.isNotBlank()) {
                                                            onNavigateToChat(notif.targetId)
                                                        }
                                                    }
                                                    notif.targetType == AppNotificationTargetType.SERVICE_REQUEST -> {
                                                        if (notif.targetId.isNotBlank()) {
                                                            onNavigateToRequestDetails(notif.targetId)
                                                        }
                                                    }
                                                    else -> {}
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        EmptyNotificationsView()
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationItemCard(
    notification: AppNotification,
    onClick: () -> Unit
) {
    val isUnread = !notification.isRead
    val isPublicRequest = notification.type == AppNotificationType.NEW_PUBLIC_REQUEST
    val attributes = getNotificationAttributes(notification.type)

    // Distinct styling for unread vs read, and special styling for NEW_PUBLIC_REQUEST
    val containerBgColor = when {
        isUnread && isPublicRequest -> Color(0xFFFFFBF0) // Warm subtle amber glow
        isUnread -> Color(0xFFF0F7FF) // Crisp light blue wash
        else -> Color.White // Pure white surface for read notifications
    }

    val cardBorderColor = when {
        isUnread && isPublicRequest -> AmberPrimary.copy(alpha = 0.35f)
        isUnread -> BluePrimary.copy(alpha = 0.25f)
        else -> BluePrimary.copy(alpha = 0.05f)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = containerBgColor,
        border = BorderStroke(if (isUnread) 1.5.dp else 1.dp, cardBorderColor),
        shadowElevation = if (isUnread) 6.dp else 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Leading Icon
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(attributes.iconBgColor.copy(alpha = 0.7f))
                        .border(1.5.dp, attributes.iconTint.copy(alpha = 0.15f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = attributes.icon,
                        contentDescription = null,
                        tint = attributes.iconTint,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Spacer(modifier = Modifier.width(18.dp))

                // Notification Content Column
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    // Category Tag & Relative Time Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Category Tag Pill
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = attributes.iconBgColor.copy(alpha = 0.5f),
                                border = BorderStroke(1.dp, attributes.iconTint.copy(alpha = 0.1f))
                            ) {
                                Text(
                                    text = attributes.typeLabelAr,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = attributes.iconTint,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }

                            // Unread Badge Pill
                            if (isUnread) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isPublicRequest) AmberPrimary else BluePrimary,
                                ) {
                                    Text(
                                        text = "جديد",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isPublicRequest) Color.Black else Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        // Time Stamp
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = TextSecondaryLight.copy(alpha = 0.6f),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = formatRelativeTime(notification.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryLight.copy(alpha = 0.8f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Title
                    Text(
                        text = notification.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlueDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Body
                    Text(
                        text = notification.body,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isUnread) BlueDark.copy(alpha = 0.85f) else TextSecondaryLight,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 22.sp,
                        fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }

            // Special highlighted callout footer for NEW_PUBLIC_REQUEST notifications
            if (isPublicRequest) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AmberPrimary.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, AmberPrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "فرصة عمل جديدة في منطقتك وتخصصك 💼",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberPrimary,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "اضغط للتفاصيل ←",
                            style = MaterialTheme.typography.labelSmall,
                            color = AmberPrimary,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyNotificationsView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Ambient soft icon container
            Surface(
                modifier = Modifier.size(92.dp),
                shape = CircleShape,
                color = BlueContainer.copy(alpha = 0.5f),
                border = BorderStroke(1.5.dp, BluePrimary.copy(alpha = 0.2f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = "لا توجد إشعارات حالياً",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "ستصلك هنا تنبيهات فورية عند تقديم عروض أسعار جديدة، قبول العروض، والرسائل والطلبات العامة في مجالك.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun FilterEmptyNotificationsView(
    onShowAllClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                modifier = Modifier.size(84.dp),
                shape = CircleShape,
                color = SuccessGreenContainer.copy(alpha = 0.6f),
                border = BorderStroke(1.5.dp, SuccessGreen.copy(alpha = 0.25f))
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircleOutline,
                        contentDescription = null,
                        tint = SuccessGreen,
                        modifier = Modifier.size(42.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "لا توجد إشعارات غير مقروءة",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "رائع! لقد اطلعت على جميع التنبيهات والإشعارات الواردة.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(18.dp))

            TextButton(
                onClick = onShowAllClick,
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "عرض جميع الإشعارات",
                    style = MaterialTheme.typography.labelLarge,
                    color = BluePrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private data class NotificationVisualAttributes(
    val icon: ImageVector,
    val iconBgColor: Color,
    val iconTint: Color,
    val typeLabelAr: String
)

private fun getNotificationAttributes(type: String): NotificationVisualAttributes {
    return when (type) {
        AppNotificationType.NEW_PUBLIC_REQUEST -> NotificationVisualAttributes(
            icon = Icons.Default.Campaign,
            iconBgColor = Color(0xFFFFF3E0), // Light Orange/Amber
            iconTint = Color(0xFFE65100),   // Deep Orange
            typeLabelAr = "طلب عام جديد"
        )
        AppNotificationType.NEW_OFFER -> NotificationVisualAttributes(
            icon = Icons.Default.MonetizationOn,
            iconBgColor = Color(0xFFFFF8E1), // Light Amber
            iconTint = Color(0xFFF57F17),   // Deep Amber
            typeLabelAr = "عرض سعر جديد"
        )
        AppNotificationType.OFFER_ACCEPTED -> NotificationVisualAttributes(
            icon = Icons.Default.CheckCircle,
            iconBgColor = Color(0xFFE8F5E9), // Light Green
            iconTint = Color(0xFF2E7D32),   // Deep Green
            typeLabelAr = "تم قبول العرض"
        )
        AppNotificationType.NEW_MESSAGE -> NotificationVisualAttributes(
            icon = Icons.Default.Forum,
            iconBgColor = Color(0xFFE0F2F1), // Light Teal
            iconTint = Color(0xFF00796B),   // Deep Teal
            typeLabelAr = "رسالة خاصة"
        )
        AppNotificationType.SERVICE_COMPLETED -> NotificationVisualAttributes(
            icon = Icons.Default.AssignmentTurnedIn,
            iconBgColor = Color(0xFFEDE7F6), // Light Purple
            iconTint = Color(0xFF512DA8),   // Deep Purple
            typeLabelAr = "اكتمال الخدمة"
        )
        AppNotificationType.REQUEST_ASSIGNED -> NotificationVisualAttributes(
            icon = Icons.Default.Work,
            iconBgColor = Color(0xFFE3F2FD), // Light Blue
            iconTint = Color(0xFF1976D2),   // Deep Blue
            typeLabelAr = "تعيين طلب"
        )
        AppNotificationType.REQUEST_CANCELLED -> NotificationVisualAttributes(
            icon = Icons.Default.Cancel,
            iconBgColor = Color(0xFFFFEBEE), // Light Red
            iconTint = Color(0xFFD32F2F),   // Deep Red
            typeLabelAr = "إلغاء الطلب"
        )
        else -> NotificationVisualAttributes(
            icon = Icons.Default.Notifications,
            iconBgColor = Color(0xFFF0F4F2),
            iconTint = Color(0xFF4A5568),
            typeLabelAr = "تنبيه"
        )
    }
}

private fun formatRelativeTime(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    val diff = System.currentTimeMillis() - timestamp
    val seconds = diff / 1000
    val minutes = seconds / 60
    val hours = minutes / 60
    val days = hours / 24

    return when {
        minutes < 1 -> "الآن"
        minutes < 60 -> "منذ $minutes دقيقة"
        hours < 24 -> "منذ $hours ساعة"
        days == 1L -> "أمس"
        days < 7 -> "منذ $days أيام"
        else -> SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

