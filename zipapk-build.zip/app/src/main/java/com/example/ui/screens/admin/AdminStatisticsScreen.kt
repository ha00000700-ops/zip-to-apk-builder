package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.*
import com.example.data.repository.AuthResult
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminStatisticsScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val usersState by authViewModel.allUsersState.collectAsState()
    val providersState by authViewModel.allServiceProvidersAdminState.collectAsState()
    val pendingVerificationsState by authViewModel.pendingVerificationRequestsState.collectAsState()
    val directRequestsState by authViewModel.adminDirectRequestsState.collectAsState()
    val publicRequestsState by authViewModel.adminPublicRequestsState.collectAsState()
    val reportsState by authViewModel.adminReportsState.collectAsState()
    val reviewsState by authViewModel.adminReviewsState.collectAsState()

    LaunchedEffect(Unit) {
        authViewModel.loadAllUsers()
        authViewModel.loadAllServiceProvidersForAdmin()
        authViewModel.loadPendingVerificationRequests()
        authViewModel.loadAllServiceRequestsForAdmin()
        authViewModel.loadAllReportsForAdmin()
        authViewModel.loadAllReviewsForAdmin()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "الإحصائيات والتقارير",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "مؤشرات أداء ونمو منصة خدمتي الجزائرية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            authViewModel.loadAllUsers()
                            authViewModel.loadAllServiceProvidersForAdmin()
                            authViewModel.loadPendingVerificationRequests()
                            authViewModel.loadAllServiceRequestsForAdmin()
                            authViewModel.loadAllReportsForAdmin()
                            authViewModel.loadAllReviewsForAdmin()
                        }) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "تحديث")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            // Extract raw lists
            val usersList = (usersState as? AuthResult.Success)?.data ?: emptyList()
            val providersList = (providersState as? AuthResult.Success)?.data ?: emptyList()
            val pendingVerifications = (pendingVerificationsState as? AuthResult.Success)?.data ?: emptyList()
            val directRequests = (directRequestsState as? AuthResult.Success)?.data ?: emptyList()
            val publicRequests = (publicRequestsState as? AuthResult.Success)?.data ?: emptyList()
            val reportsList = (reportsState as? AuthResult.Success)?.data ?: emptyList()
            val reviewsList = (reviewsState as? AuthResult.Success)?.data ?: emptyList()

            // Calculations
            val totalUsers = usersList.size
            val customersCount = usersList.count { it.role == UserRole.CUSTOMER }
            val totalProviders = providersList.size
            val verifiedProviders = providersList.count { it.isVerified }
            val pendingVerifCount = pendingVerifications.size

            val totalRequests = directRequests.size + publicRequests.size
            val openDirect = directRequests.count { it.status == RequestStatus.PENDING || it.status == RequestStatus.ACCEPTED || it.status == RequestStatus.IN_PROGRESS }
            val completedDirect = directRequests.count { it.status == RequestStatus.COMPLETED }
            val cancelledDirect = directRequests.count { it.status == RequestStatus.CANCELLED || it.status == RequestStatus.REJECTED }

            val openPublic = publicRequests.count { it.status == PublicRequestStatus.OPEN }
            val assignedPublic = publicRequests.count { it.status == PublicRequestStatus.ASSIGNED }
            val completedPublic = publicRequests.count { it.status == PublicRequestStatus.COMPLETED }
            val cancelledPublic = publicRequests.count { it.status == PublicRequestStatus.CANCELLED }
            val totalPublicOffers = publicRequests.sumOf { it.offersCount }

            val totalReports = reportsList.size
            val pendingReports = reportsList.count { it.status == ReportStatus.PENDING || it.status == ReportStatus.IN_REVIEW }

            val totalReviews = reviewsList.size
            val avgRating = if (reviewsList.isNotEmpty()) {
                String.format(java.util.Locale.US, "%.1f", reviewsList.map { it.rating }.average())
            } else "0.0"

            // Grouping: Most requested professions in public requests
            val topProfessions = (directRequests.map { it.professionNameAr } + publicRequests.map { it.professionNameAr })
                .filter { it.isNotBlank() }
                .groupingBy { it }
                .eachCount()
                .toList()
                .sortedByDescending { it.second }
                .take(5)

            // Grouping: Requests by Wilaya
            val topWilayas = (directRequests.map { it.wilayaName } + publicRequests.map { it.wilayaName })
                .filter { it.isNotBlank() }
                .groupingBy { it }
                .eachCount()
                .toList()
                .sortedByDescending { it.second }
                .take(5)

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Section 1: Users & Providers Growth
                item {
                    Text(
                        text = "👥 المستخدمين ومجتمع الحرفيين",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "إجمالي المستخدمين",
                            value = totalUsers.toString(),
                            icon = Icons.Default.People,
                            color = BluePrimary
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "الزبائن المسجلين",
                            value = customersCount.toString(),
                            icon = Icons.Default.Person,
                            color = Color(0xFF00897B)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "الحرفيين والمهنيين",
                            value = totalProviders.toString(),
                            icon = Icons.Default.Engineering,
                            color = Color(0xFF6A1B9A)
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "حرفيون موثقون",
                            value = "$verifiedProviders (${if (totalProviders > 0) (verifiedProviders * 100 / totalProviders) else 0}%)",
                            icon = Icons.Default.Verified,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }

                if (pendingVerifCount > 0) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.HourglassTop, contentDescription = null, tint = Color(0xFFE65100))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "يوجد $pendingVerifCount طلب توثيق حرفي معلق بانتظار المراجعة",
                                    color = Color(0xFFE65100),
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }

                // Section 2: Service Requests Overview
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "📋 نشاط طلبات الخدمات وسوق العروض",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "إجمالي الطلبات",
                            value = totalRequests.toString(),
                            icon = Icons.Default.Assignment,
                            color = Color(0xFF1565C0)
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "عروض الأسعار المقدمة",
                            value = totalPublicOffers.toString(),
                            icon = Icons.Default.LocalOffer,
                            color = Color(0xFFE65100)
                        )
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "تفصيل حالات الطلبات المباشرة:", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("قيد المعالجة والإنجاز: $openDirect", color = Color(0xFF1565C0), style = MaterialTheme.typography.bodySmall)
                                Text("مكتملة بنجاح: $completedDirect", color = Color(0xFF2E7D32), style = MaterialTheme.typography.bodySmall)
                                Text("ملغاة / مرفوضة: $cancelledDirect", color = Color(0xFFC62828), style = MaterialTheme.typography.bodySmall)
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(12.dp))

                            Text(text = "تفصيل حالات طلبات السوق العامة:", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("مفتوحة للعروض: $openPublic", color = Color(0xFF00897B), style = MaterialTheme.typography.bodySmall)
                                Text("تم اختيار حرفي: $assignedPublic", color = Color(0xFF1565C0), style = MaterialTheme.typography.bodySmall)
                                Text("مكتملة: $completedPublic", color = Color(0xFF2E7D32), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                // Section 3: Reviews & Reports
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "⭐ التقييمات والنزاهة والرقابة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BluePrimary
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "مراجعات وتقييمات",
                            value = "$totalReviews ($avgRating ★)",
                            icon = Icons.Default.Star,
                            color = Color(0xFFFF8F00)
                        )
                        StatCard(
                            modifier = Modifier.weight(1f),
                            title = "إجمالي البلاغات",
                            value = "$totalReports (معلق: $pendingReports)",
                            icon = Icons.Default.ReportProblem,
                            color = if (pendingReports > 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                        )
                    }
                }

                // Section 4: Top Requested Professions
                if (topProfessions.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "🔥 أكثر المهن والخدمات طلباً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                topProfessions.forEachIndexed { index, pair ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${index + 1}. ${pair.first}",
                                            fontWeight = FontWeight.Medium,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Surface(
                                            color = BluePrimary.copy(alpha = 0.1f),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = "${pair.second} طلب",
                                                color = BluePrimary,
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Section 5: Top Wilayas
                if (topWilayas.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "📍 أنشط الولايات في تقديم الطلبات",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                topWilayas.forEachIndexed { index, pair ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${index + 1}. ولاية ${pair.first}",
                                            fontWeight = FontWeight.Medium,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "${pair.second} طلب خدمة",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: ImageVector,
    color: Color
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(color.copy(alpha = 0.12f), shape = RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
