package com.example.ui.screens.request

import android.content.Intent
import android.widget.Toast
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.material3.Surface
import androidx.compose.foundation.BorderStroke
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.theme.BackgroundLight
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RequestStatus
import com.example.data.model.ServiceRequest
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import java.util.Date

@Composable
fun RequestDetailsScreen(
    requestId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChat: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()

    var requestState by remember { mutableStateOf<AuthResult<ServiceRequest?>>(AuthResult.Loading) }
    var isSubmittingAction by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }

    LaunchedEffect(requestId) {
        authViewModel.getServiceRequestFlow(requestId).collect { result ->
            requestState = result
        }
    }

    Scaffold(
        topBar = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(listOf(BlueDark, BluePrimary)),
                            shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
                        )
                        .padding(top = 48.dp, bottom = 40.dp, start = 24.dp, end = 24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(18.dp))
                        
                        Column {
                            Text(
                                text = "تفاصيل الطلب",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "متابعة حالة طلب الخدمة الخاصة بك",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = com.example.ui.theme.BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = requestState) {
                is AuthResult.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = BluePrimary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "جاري تحميل تفاصيل الطلب...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is AuthResult.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = ErrorRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = state.messageAr,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is AuthResult.Success -> {
                    val request = state.data
                    if (request == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "لم يتم العثور على طلب الخدمة المطلوب.",
                                style = MaterialTheme.typography.titleMedium,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        val isCustomer = currentUserProfile?.role == UserRole.CUSTOMER || request.customerId == currentUserProfile?.uid
                        val isProvider = currentUserProfile?.role == UserRole.SERVICE_PROVIDER || request.providerId == currentUserProfile?.uid

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Status Header Card
                            RequestStatusHeaderCard(request = request)

                            Spacer(modifier = Modifier.height(16.dp))

                            // Timeline Progress
                            RequestTimelineCard(status = request.status)

                            Spacer(modifier = Modifier.height(16.dp))

                            // Counterparty Info Card (Customer sees Provider, Provider sees Customer)
                            if (isCustomer) {
                                PersonInfoCard(
                                    title = "بيانات الحرفي مقدم الخدمة",
                                    name = request.providerName,
                                    subtitle = request.professionNameAr,
                                    phone = "",
                                    wilaya = request.wilayaName,
                                    commune = request.communeName,
                                    icon = Icons.Default.Handyman,
                                    badgeColor = BlueContainer,
                                    iconColor = BluePrimary,
                                    onPhoneClick = null,
                                    onChatClick = {
                                        authViewModel.openOrCreateConversation(
                                            customerId = request.customerId,
                                            customerName = request.customerName,
                                            providerId = request.providerId,
                                            providerName = request.providerName,
                                            providerProfession = request.professionNameAr,
                                            serviceRequestId = request.id,
                                            serviceRequestTitle = request.professionNameAr
                                        ) { conversationId, errorMsg ->
                                            if (conversationId != null) {
                                                onNavigateToChat(conversationId)
                                            } else {
                                                Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            } else if (isProvider) {
                                PersonInfoCard(
                                    title = "بيانات الزبون صاحب الطلب",
                                    name = request.customerName,
                                    subtitle = "زبون مسجل في خدمتي",
                                    phone = request.customerPhone,
                                    wilaya = request.wilayaName,
                                    commune = request.communeName,
                                    icon = Icons.Default.Person,
                                    badgeColor = AmberLight,
                                    iconColor = AmberPrimary,
                                    onPhoneClick = {
                                        if (request.customerPhone.isNotBlank()) {
                                            try {
                                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                                    data = Uri.parse("tel:${request.customerPhone}")
                                                }
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    },
                                    onChatClick = {
                                        authViewModel.openOrCreateConversation(
                                            customerId = request.customerId,
                                            customerName = request.customerName,
                                            providerId = request.providerId,
                                            providerName = request.providerName,
                                            providerProfession = request.professionNameAr,
                                            serviceRequestId = request.id,
                                            serviceRequestTitle = request.professionNameAr
                                        ) { conversationId, errorMsg ->
                                            if (conversationId != null) {
                                                onNavigateToChat(conversationId)
                                            } else {
                                                Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Service Details Card
                            ServiceDetailsCard(request = request)

                            Spacer(modifier = Modifier.height(24.dp))

                            // Action Buttons based on Role & Status
                            if (isSubmittingAction) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(color = BluePrimary)
                                }
                            } else {
                                RequestActionButtons(
                                    request = request,
                                    isCustomer = isCustomer,
                                    isProvider = isProvider,
                                    onAccept = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.ACCEPTED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onReject = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.REJECTED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onStartProgress = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.IN_PROGRESS) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onComplete = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.COMPLETED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            } else {
                                                scope.launch { snackbarHostState.showSnackbar("تمت إحالة الخدمة إلى مكتملة بنجاح ✅") }
                                            }
                                        }
                                    },
                                    onCancelClick = { showCancelDialog = true },
                                    onReviewClick = { showReviewDialog = true }
                                )
                            }

                            Spacer(modifier = Modifier.height(32.dp))
                        }
                    }
                }
                else -> {}
            }
        }
    }

    // Cancellation Dialog
    if (showCancelDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = {
                Text(
                    text = "إلغاء طلب الخدمة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من إلغاء طلب الخدمة؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelDialog = false
                        if (request != null) {
                            isSubmittingAction = true
                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.CANCELLED) { success, error ->
                                isSubmittingAction = false
                                if (!success && error != null) {
                                    scope.launch { snackbarHostState.showSnackbar(error) }
                                } else {
                                    scope.launch { snackbarHostState.showSnackbar("تم إلغاء الطلب بنجاح") }
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("نعم، إلغاء الطلب")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("رجوع")
                }
            }
        )
    }

    // Review Dialog
    if (showReviewDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        if (request != null) {
            ReviewSubmissionDialog(
                providerName = request.providerName,
                onDismiss = { showReviewDialog = false },
                onSubmit = { rating, comment ->
                    showReviewDialog = false
                    isSubmittingAction = true
                    authViewModel.submitReview(
                        requestId = request.id,
                        providerId = request.providerId,
                        rating = rating,
                        comment = comment
                    ) { success, error ->
                        isSubmittingAction = false
                        if (success) {
                            scope.launch { snackbarHostState.showSnackbar("شكراً لك! تم تقديم التقييم بنجاح ⭐️") }
                        } else if (error != null) {
                            scope.launch { snackbarHostState.showSnackbar(error) }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun RequestStatusHeaderCard(request: ServiceRequest) {
    val (statusBg, statusText, statusTitle) = when (request.status) {
        RequestStatus.PENDING -> Triple(AmberLight, AmberPrimary, "قيد الانتظار")
        RequestStatus.ACCEPTED -> Triple(BlueContainer.copy(alpha = 0.5f), BluePrimary, "تم القبول")
        RequestStatus.IN_PROGRESS -> Triple(Color(0xFFEDE7F6), Color(0xFF673AB7), "قيد التنفيذ")
        RequestStatus.COMPLETED -> Triple(SuccessGreenContainer, SuccessGreen, "مكتمل")
        RequestStatus.REJECTED -> Triple(Color(0xFFFFEBEE), ErrorRed, "مرفوض")
        RequestStatus.CANCELLED -> Triple(OutlineLight.copy(alpha = 0.1f), TextSecondaryLight, "ملغى")
    }

    val formattedDate = remember(request.createdAt) {
        try {
            DateFormat.format("yyyy/MM/dd - HH:mm", Date(request.createdAt)).toString()
        } catch (_: Exception) {
            ""
        }
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = request.professionNameAr,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryLight
                    )
                    if (formattedDate.isNotBlank()) {
                        Text(
                            text = "طلب رقم #${request.id.takeLast(6).uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                        Text(
                            text = "تاريخ الطلب: $formattedDate",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = statusBg,
                    border = BorderStroke(1.dp, statusText.copy(alpha = 0.15f))
                ) {
                    Text(
                        text = statusTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = statusText,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RequestTimelineCard(status: RequestStatus) {
    val steps = listOf(
        RequestStatus.PENDING to "قيد الانتظار",
        RequestStatus.ACCEPTED to "تم القبول",
        RequestStatus.IN_PROGRESS to "قيد التنفيذ",
        RequestStatus.COMPLETED to "مكتمل"
    )

    val currentStepIndex = when (status) {
        RequestStatus.PENDING -> 0
        RequestStatus.ACCEPTED -> 1
        RequestStatus.IN_PROGRESS -> 2
        RequestStatus.COMPLETED -> 3
        RequestStatus.REJECTED, RequestStatus.CANCELLED -> -1
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "تتبع مسار الخدمة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (currentStepIndex == -1) {
                val text = if (status == RequestStatus.REJECTED) "تم رفض هذا الطلب من قبل الحرفي" else "تم إلغاء هذا الطلب من قبل صاحب الطلب"
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = if (status == RequestStatus.REJECTED) Color(0xFFFFEBEE) else Color(0xFFF5F5F5),
                    border = BorderStroke(1.dp, (if (status == RequestStatus.REJECTED) ErrorRed else TextSecondaryLight).copy(alpha = 0.1f))
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (status == RequestStatus.REJECTED) ErrorRed else TextSecondaryLight,
                        modifier = Modifier.padding(16.dp),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    steps.forEachIndexed { index, pair ->
                        val isDone = index <= currentStepIndex
                        val isCurrent = index == currentStepIndex

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isDone) BluePrimary else OutlineLight.copy(alpha = 0.1f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                } else {
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = TextSecondaryLight
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = pair.second,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = if (isCurrent) FontWeight.ExtraBold else FontWeight.Medium,
                                color = if (isDone) BluePrimary else TextSecondaryLight,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonInfoCard(
    title: String,
    name: String,
    subtitle: String,
    phone: String,
    wilaya: String,
    commune: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeColor: Color,
    iconColor: Color,
    onPhoneClick: (() -> Unit)?,
    onChatClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = badgeColor.copy(alpha = 0.4f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconColor,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = name.ifBlank { "مستخدم خدمتي" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = iconColor,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = TextTertiaryLight,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$commune، $wilaya",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryLight
                        )
                    }
                }

                if (onChatClick != null) {
                    IconButton(
                        onClick = onChatClick,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BlueContainer.copy(alpha = 0.4f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = "مراسلة",
                            tint = BluePrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    if (onPhoneClick != null && phone.isNotBlank()) {
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                }

                if (onPhoneClick != null && phone.isNotBlank()) {
                    IconButton(
                        onClick = onPhoneClick,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AmberLight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال",
                            tint = AmberPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceDetailsCard(request: ServiceRequest) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "تفاصيل مهمة الخدمة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (request.description.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BackgroundLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "وصف المشكلة / الخدمة المطلوبة",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = request.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight,
                            lineHeight = 20.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (request.addressDetails.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BackgroundLight,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = null,
                                tint = AmberPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "العنوان الدقيق للخدمة",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryLight
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = request.addressDetails,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight,
                            lineHeight = 20.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (request.proposedPriceDzd != null && request.proposedPriceDzd > 0) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BlueContainer.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "الميزانية المقترحة:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryLight
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${request.proposedPriceDzd} د.ج",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = BluePrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RequestActionButtons(
    request: ServiceRequest,
    isCustomer: Boolean,
    isProvider: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onStartProgress: () -> Unit,
    onComplete: () -> Unit,
    onCancelClick: () -> Unit,
    onReviewClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Provider Actions
        if (isProvider) {
            when (request.status) {
                RequestStatus.PENDING -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onAccept,
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(56.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("قبول المهمة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold)
                        }

                        OutlinedButton(
                            onClick = onReject,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.5.dp, ErrorRed.copy(alpha = 0.4f))
                        ) {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("رفض", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                RequestStatus.ACCEPTED -> {
                    Button(
                        onClick = onStartProgress,
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("بدء تنفيذ المهمة 🛠️", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    }
                }
                RequestStatus.IN_PROGRESS -> {
                    Button(
                        onClick = onComplete,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("إتمام المهمة بنجاح ✅", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    }
                }
                else -> {}
            }
        }

        // Customer Actions
        if (isCustomer) {
            when (request.status) {
                RequestStatus.PENDING, RequestStatus.ACCEPTED -> {
                    OutlinedButton(
                        onClick = onCancelClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.5.dp, ErrorRed.copy(alpha = 0.4f))
                    ) {
                        Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("إلغاء الطلب", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    }
                }
                RequestStatus.COMPLETED -> {
                    Button(
                        onClick = onReviewClick,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("تقييم تجربة الخدمة ⭐️", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun ReviewSubmissionDialog(
    providerName: String,
    onDismiss: () -> Unit,
    onSubmit: (Int, String) -> Unit
) {
    var selectedRating by remember { mutableIntStateOf(5) }
    var commentText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تقييم أداء الحرفي",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "كيف كانت تجربتك مع $providerName؟",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    for (i in 1..5) {
                        IconButton(
                            onClick = { selectedRating = i },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (i <= selectedRating) Icons.Default.Star else Icons.Outlined.Star,
                                contentDescription = "$i stars",
                                tint = if (i <= selectedRating) AmberPrimary else OutlineLight,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                androidx.compose.material3.OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("أضف تعليقك هنا (اختياري)...", style = MaterialTheme.typography.bodySmall) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BluePrimary,
                        unfocusedBorderColor = OutlineLight.copy(alpha = 0.3f),
                        unfocusedContainerColor = BackgroundLight
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedRating, commentText) },
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(44.dp)
            ) {
                Text("إرسال التقييم", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondaryLight)
            }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = Color.White
    )
}
