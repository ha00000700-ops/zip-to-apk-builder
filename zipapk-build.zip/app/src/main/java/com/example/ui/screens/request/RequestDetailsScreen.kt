package com.example.ui.screens.request

import android.content.Intent
import android.widget.Toast
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.data.repository.AuthResult
import com.example.ui.components.FirebaseStatusBanner
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.screens.home.KhedmatiEmptyState
import com.example.ui.screens.home.KhedmatiErrorState
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import java.util.Date

@Composable
fun RequestDetailsScreen(
    requestId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChat: (String) -> Unit = {},
    onNavigateToPaymentWeb: (String, String, String) -> Unit = { _, _, _ -> },
    onNavigateToReports: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()

    var requestState by remember { mutableStateOf<AuthResult<ServiceRequest?>>(AuthResult.Loading) }
    var isSubmittingAction by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var isInitiatingPayment by remember { mutableStateOf(false) }

    LaunchedEffect(requestId) {
        authViewModel.getServiceRequestFlow(requestId).collect { result ->
            requestState = result
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تفاصيل الطلب",
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = { onNavigateToReports(requestId) }) {
                        Icon(
                            imageVector = Icons.Default.ReportProblem,
                            contentDescription = "إبلاغ عن مشكلة",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = requestState) {
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        KhedmatiErrorState(message = state.messageAr) {
                            // Retry is handled automatically by flow
                        }
                    }
                }
                is AuthResult.ProfileMissing -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = "يرجى استكمال ملفك الشخصي أولاً", color = Color.Red)
                    }
                }
                is AuthResult.Success -> {
                    val request = state.data
                    if (request == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "طلب غير موجود")
                        }
                    } else {
                        val isCustomer = currentUserProfile?.role == UserRole.CUSTOMER || request.customerId == currentUserProfile?.uid
                        val isProvider = currentUserProfile?.role == UserRole.SERVICE_PROVIDER || request.providerId == currentUserProfile?.uid

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Status Banner
                            RequestStatusBanner(request = request)

                            // Timeline
                            RequestTimelineSection(status = request.status)

                            // Main Content
                            Column(
                                modifier = Modifier.padding(horizontal = 24.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // Counterparty Info
                                if (isCustomer) {
                                    PersonCard(
                                        title = "الحرفي",
                                        name = request.providerName,
                                        subtitle = request.professionNameAr,
                                        icon = Icons.Default.Handyman,
                                        iconColor = BluePrimary,
                                        onChatClick = {
                                            authViewModel.openOrCreateConversation(
                                                customerId = request.customerId,
                                                customerName = request.customerName,
                                                providerId = request.providerId,
                                                providerName = request.providerName,
                                                providerProfession = request.professionNameAr,
                                                serviceRequestId = request.id,
                                                serviceRequestTitle = request.professionNameAr
                                            ) { conversationId, errorMsg ->
                                                if (conversationId != null) {
                                                    onNavigateToChat(conversationId)
                                                } else {
                                                    Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    )
                                } else if (isProvider) {
                                    PersonCard(
                                        title = "الزبون",
                                        name = request.customerName,
                                        subtitle = "زبون في خدمتي",
                                        icon = Icons.Default.Person,
                                        iconColor = AmberPrimary,
                                        onPhoneClick = {
                                            if (request.customerPhone.isNotBlank()) {
                                                try {
                                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                                        data = Uri.parse("tel:${request.customerPhone}")
                                                    }
                                                    context.startActivity(intent)
                                                } catch (_: Exception) {}
                                            }
                                        },
                                        onChatClick = {
                                            authViewModel.openOrCreateConversation(
                                                customerId = request.customerId,
                                                customerName = request.customerName,
                                                providerId = request.providerId,
                                                providerName = request.providerName,
                                                providerProfession = request.professionNameAr,
                                                serviceRequestId = request.id,
                                                serviceRequestTitle = request.professionNameAr
                                            ) { conversationId, errorMsg ->
                                                if (conversationId != null) {
                                                    onNavigateToChat(conversationId)
                                                } else {
                                                    Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    )
                                }

                                // Details Card
                                DetailsSection(request = request)

                                // Price Card
                                if (request.proposedPriceDzd != null && request.proposedPriceDzd > 0) {
                                    PriceCard(price = request.proposedPriceDzd)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    // Temporarily hidden for Free Trial Mode
                                    /*
                                    PaymentInfoSection(
                                        request = request,
                                        isCustomer = isCustomer,
                                        isInitiatingPayment = isInitiatingPayment,
                                        onPayClick = { showPaymentDialog = true }
                                    )
                                    */
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Actions
                            if (isSubmittingAction) {
                                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = BluePrimary, strokeWidth = 2.dp)
                                }
                            } else {
                                Box(modifier = Modifier.padding(horizontal = 24.dp)) {
                                    ActionsSection(
                                        request = request,
                                        isCustomer = isCustomer,
                                        isProvider = isProvider,
                                        onAccept = {
                                            isSubmittingAction = true
                                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.ACCEPTED) { _, _ -> isSubmittingAction = false }
                                        },
                                        onReject = {
                                            isSubmittingAction = true
                                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.REJECTED) { _, _ -> isSubmittingAction = false }
                                        },
                                        onStartProgress = {
                                            isSubmittingAction = true
                                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.IN_PROGRESS) { _, _ -> isSubmittingAction = false }
                                        },
                                        onComplete = {
                                            isSubmittingAction = true
                                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.COMPLETED) { _, _ -> isSubmittingAction = false }
                                        },
                                        onCancelClick = { showCancelDialog = true },
                                        onReviewClick = { showReviewDialog = true }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(48.dp))
                        }
                    }
                }
            }
        }
    }

    if (showCancelDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("إلغاء الطلب", fontWeight = FontWeight.Black) },
            text = { Text("هل أنت متأكد من إلغاء هذا الطلب؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCancelDialog = false
                        if (request != null) {
                            isSubmittingAction = true
                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.CANCELLED) { _, _ -> isSubmittingAction = false }
                        }
                    }
                ) { Text("نعم، إلغاء", color = Color.Red, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) { Text("تراجع") }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = Color.White
        )
    }

    if (showReviewDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        if (request != null) {
            ReviewSubmissionDialog(
                providerName = request.providerName,
                onDismiss = { showReviewDialog = false },
                onSubmit = { rating, comment ->
                    showReviewDialog = false
                    isSubmittingAction = true
                    authViewModel.submitReview(request.id, request.providerId, rating, comment) { _, _ -> isSubmittingAction = false }
                }
            )
        }
    }

    if (showPaymentDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        if (request != null && request.proposedPriceDzd != null) {
            ChargilyPaymentSelectionDialog(
                amountDzd = request.proposedPriceDzd,
                onDismiss = { showPaymentDialog = false },
                onSelectMethod = { selectedMethod ->
                    showPaymentDialog = false
                    isInitiatingPayment = true
                    authViewModel.initiateServiceRequestPayment(
                        requestId = request.id,
                        amountDzd = request.proposedPriceDzd,
                        paymentMethod = selectedMethod,
                        customerName = request.customerName
                    ) { result ->
                        isInitiatingPayment = false
                        when (result) {
                            is AuthResult.Success -> {
                                val checkout = result.data
                                onNavigateToPaymentWeb(request.id, checkout.checkoutUrl, selectedMethod.code)
                            }
                            is AuthResult.Error -> {
                                Toast.makeText(context, result.messageAr, Toast.LENGTH_LONG).show()
                            }
                            else -> {}
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun RequestStatusBanner(request: ServiceRequest) {
    val (statusColor, statusText) = when (request.status) {
        RequestStatus.PENDING -> AmberPrimary to "قيد الانتظار"
        RequestStatus.ACCEPTED -> BluePrimary to "تم القبول"
        RequestStatus.IN_PROGRESS -> EmeraldPrimary to "قيد التنفيذ"
        RequestStatus.COMPLETED -> EmeraldPrimary to "مكتمل"
        RequestStatus.REJECTED -> Color.Red to "مرفوض"
        RequestStatus.CANCELLED -> Color.Gray to "ملغى"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .padding(24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = request.professionNameAr,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = BlueDark
                )
                Text(
                    text = "رقم الطلب: #${request.id.takeLast(6).uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryLight
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = statusColor.copy(alpha = 0.1f)
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Black,
                    color = statusColor,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun RequestTimelineSection(status: RequestStatus) {
    val steps = listOf("انتظار", "قبول", "تنفيذ", "اكتمال")
    val currentStep = when (status) {
        RequestStatus.PENDING -> 0
        RequestStatus.ACCEPTED -> 1
        RequestStatus.IN_PROGRESS -> 2
        RequestStatus.COMPLETED -> 3
        else -> -1
    }

    if (currentStep != -1) {
        Column(modifier = Modifier.padding(24.dp)) {
            Text(text = "تتبع الطلب", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = BlueDark)
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                steps.forEachIndexed { index, label ->
                    val isCompleted = index <= currentStep
                    val isCurrent = index == currentStep
                    
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(if (isCompleted) BluePrimary else OutlineLight.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompleted) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Medium,
                            color = if (isCompleted) BluePrimary else TextTertiaryLight
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonCard(
    title: String,
    name: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    onPhoneClick: (() -> Unit)? = null,
    onChatClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(48.dp).background(iconColor.copy(alpha = 0.1f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = TextSecondaryLight)
                Text(text = name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, color = BlueDark)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = iconColor, fontWeight = FontWeight.Bold)
            }
            
            if (onChatClick != null) {
                IconButton(onClick = onChatClick) {
                    Icon(imageVector = Icons.Default.Forum, contentDescription = null, tint = BluePrimary)
                }
            }
            if (onPhoneClick != null) {
                IconButton(onClick = onPhoneClick) {
                    Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = AmberPrimary)
                }
            }
        }
    }
}

@Composable
private fun DetailsSection(request: ServiceRequest) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(text = "التفاصيل", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Black, color = BlueDark)
            Spacer(modifier = Modifier.height(12.dp))
            
            InfoRow(label = "الوصف", value = request.description)
            Spacer(modifier = Modifier.height(12.dp))
            InfoRow(label = "العنوان", value = "${request.communeName}، ${request.wilayaName}\n${request.addressDetails}")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextTertiaryLight, fontWeight = FontWeight.Bold)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = BlueDark, lineHeight = 20.sp)
    }
}

@Composable
private fun PriceCard(price: Long) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = BluePrimary,
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "الميزانية المقترحة", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color.White)
            Text(text = "$price د.ج", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Color.White)
        }
    }
}

@Composable
private fun ActionsSection(
    request: ServiceRequest,
    isCustomer: Boolean,
    isProvider: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onStartProgress: () -> Unit,
    onComplete: () -> Unit,
    onCancelClick: () -> Unit,
    onReviewClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (isProvider) {
            when (request.status) {
                RequestStatus.PENDING -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Button(
                            onClick = onAccept,
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) { Text("قبول", fontWeight = FontWeight.Black) }
                        OutlinedButton(
                            onClick = onReject,
                            modifier = Modifier.weight(1f).height(56.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color.Red.copy(alpha = 0.5f))
                        ) { Text("رفض", color = Color.Red, fontWeight = FontWeight.Bold) }
                    }
                }
                RequestStatus.ACCEPTED -> {
                    Button(onClick = onStartProgress, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                        Text("بدء التنفيذ", fontWeight = FontWeight.Black)
                    }
                }
                RequestStatus.IN_PROGRESS -> {
                    Button(onClick = onComplete, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)) {
                        Text("إتمام المهمة", fontWeight = FontWeight.Black)
                    }
                }
                else -> {}
            }
        }

        if (isCustomer) {
            when (request.status) {
                RequestStatus.PENDING, RequestStatus.ACCEPTED -> {
                    OutlinedButton(onClick = onCancelClick, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                        Text("إلغاء الطلب", color = Color.Red)
                    }
                }
                RequestStatus.COMPLETED -> {
                    Button(onClick = onReviewClick, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary)) {
                        Text("تقييم الحرفي", color = BlueDark, fontWeight = FontWeight.Black)
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun ReviewSubmissionDialog(
    providerName: String,
    onDismiss: () -> Unit,
    onSubmit: (Int, String) -> Unit
) {
    var selectedRating by remember { mutableIntStateOf(5) }
    var commentText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تقييم أداء الحرفي",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "كيف كانت تجربتك مع $providerName؟",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondaryLight,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(20.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    for (i in 1..5) {
                        IconButton(
                            onClick = { selectedRating = i },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (i <= selectedRating) Icons.Default.Star else Icons.Outlined.Star,
                                contentDescription = "$i stars",
                                tint = if (i <= selectedRating) AmberPrimary else OutlineLight,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(20.dp))
                
                androidx.compose.material3.OutlinedTextField(
                    value = commentText,
                    onValueChange = { commentText = it },
                    placeholder = { Text("أضف تعليقك هنا (اختياري)...", style = MaterialTheme.typography.bodySmall) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BluePrimary,
                        unfocusedBorderColor = OutlineLight.copy(alpha = 0.3f),
                        unfocusedContainerColor = BackgroundLight
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedRating, commentText) },
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(44.dp)
            ) {
                Text("إرسال التقييم", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondaryLight)
            }
        },
        shape = RoundedCornerShape(28.dp),
        containerColor = Color.White
    )
}

@Composable
private fun PaymentInfoSection(
    request: ServiceRequest,
    isCustomer: Boolean,
    isInitiatingPayment: Boolean,
    onPayClick: () -> Unit
) {
    val paymentInfo = request.paymentInfo
    val (statusColor, statusBg, statusText) = when (paymentInfo.status) {
        PaymentStatus.UNPAID -> Triple(TextSecondaryLight, OutlineLight.copy(alpha = 0.2f), "غير مدفوع")
        PaymentStatus.PENDING -> Triple(AmberPrimary, Color(0xFFFFF8E1), "قيد انتظار المعالجة")
        PaymentStatus.SUCCESSFUL -> Triple(EmeraldPrimary, Color(0xFFE8F5E9), "مدفوع بنجاح (Chargily Pay)")
        PaymentStatus.FAILED -> Triple(Color.Red, Color(0xFFFFEBEE), "فشلت عملية الدفع")
        PaymentStatus.CANCELLED -> Triple(TextSecondaryLight, Color(0xFFF5F5F5), "ملغاة")
    }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        tonalElevation = 2.dp,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "حالة الدفع الإلكتروني",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = BlueDark
                    )
                }

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            if (paymentInfo.status == PaymentStatus.SUCCESSFUL && paymentInfo.chargilyPaymentId != null) {
                Text(
                    text = "رقم المعاملة: ${paymentInfo.chargilyPaymentId}",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondaryLight
                )
            }

            Text(
                text = "وسيلة الدفع: ${paymentInfo.method.titleAr}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryLight
            )

            if (isCustomer && (paymentInfo.status == PaymentStatus.UNPAID || paymentInfo.status == PaymentStatus.FAILED || paymentInfo.status == PaymentStatus.CANCELLED)) {
                Button(
                    onClick = onPayClick,
                    enabled = !isInitiatingPayment,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    if (isInitiatingPayment) {
                        CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("الدفع إلكترونياً (Chargily Pay — CIB / الذهبية)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            } else if (paymentInfo.status == PaymentStatus.PENDING) {
                Surface(
                    color = Color(0xFFFFF8E1),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "جاري التحقق من عملية الدفع من خلال السيرفر. ستتحدث الحالة تلقائياً فور التأكيد.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFB78103),
                        modifier = Modifier.padding(10.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun ChargilyPaymentSelectionDialog(
    amountDzd: Long,
    onDismiss: () -> Unit,
    onSelectMethod: (PaymentMethod) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Payment, contentDescription = null, tint = BluePrimary)
                Text(text = "اختر طريقة الدفع", fontWeight = FontWeight.Bold, color = BlueDark)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "المبلغ الإجمالي المطلوب: $amountDzd د.ج",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldPrimary
                )
                Text(
                    text = "سيتم التوجيه بأمان إلى بوابة Chargily Pay لإتمام العملية ببطاقة EDAHABIA أو CIB.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = { onSelectMethod(PaymentMethod.EDAHABIA) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.5.dp, AmberPrimary)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("البطاقة الذهبية (EDAHABIA)", color = BlueDark, fontWeight = FontWeight.Bold)
                        Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = AmberPrimary)
                    }
                }

                OutlinedButton(
                    onClick = { onSelectMethod(PaymentMethod.CIB) },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.5.dp, BluePrimary)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("بطاقة CIB البنكية", color = BlueDark, fontWeight = FontWeight.Bold)
                        Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = BluePrimary)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextSecondaryLight)
            }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White
    )
}
