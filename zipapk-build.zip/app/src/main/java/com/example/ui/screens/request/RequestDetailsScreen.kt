package com.example.ui.screens.request

import android.content.Intent
import android.widget.Toast
import android.net.Uri
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RequestStatus
import com.example.data.model.ServiceRequest
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import java.util.Date

@Composable
fun RequestDetailsScreen(
    requestId: String,
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToChat: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val currentUserProfile by authViewModel.currentUserProfile.collectAsState()

    var requestState by remember { mutableStateOf<AuthResult<ServiceRequest?>>(AuthResult.Loading) }
    var isSubmittingAction by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }

    LaunchedEffect(requestId) {
        authViewModel.getServiceRequestFlow(requestId).collect { result ->
            requestState = result
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تفاصيل طلب الخدمة",
                onNavigateBack = onNavigateBack
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = requestState) {
                is AuthResult.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = EmeraldPrimary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "جاري تحميل تفاصيل الطلب...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                is AuthResult.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = ErrorRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = state.messageAr,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                    }
                }
                is AuthResult.Success -> {
                    val request = state.data
                    if (request == null) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "لم يتم العثور على طلب الخدمة المطلوب.",
                                style = MaterialTheme.typography.titleMedium,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        val isCustomer = currentUserProfile?.role == UserRole.CUSTOMER || request.customerId == currentUserProfile?.uid
                        val isProvider = currentUserProfile?.role == UserRole.SERVICE_PROVIDER || request.providerId == currentUserProfile?.uid

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(16.dp)
                        ) {
                            // Status Header Card
                            RequestStatusHeaderCard(request = request)

                            Spacer(modifier = Modifier.height(16.dp))

                            // Timeline Progress
                            RequestTimelineCard(status = request.status)

                            Spacer(modifier = Modifier.height(16.dp))

                            // Counterparty Info Card (Customer sees Provider, Provider sees Customer)
                            if (isCustomer) {
                                PersonInfoCard(
                                    title = "بيانات الحرفي مقدم الخدمة",
                                    name = request.providerName,
                                    subtitle = request.professionNameAr,
                                    phone = "",
                                    wilaya = request.wilayaName,
                                    commune = request.communeName,
                                    icon = Icons.Default.Handyman,
                                    badgeColor = EmeraldContainer,
                                    iconColor = EmeraldPrimary,
                                    onPhoneClick = null,
                                    onChatClick = {
                                        authViewModel.openOrCreateConversation(
                                            customerId = request.customerId,
                                            customerName = request.customerName,
                                            providerId = request.providerId,
                                            providerName = request.providerName,
                                            providerProfession = request.professionNameAr,
                                            serviceRequestId = request.id,
                                            serviceRequestTitle = request.professionNameAr
                                        ) { conversationId, errorMsg ->
                                            if (conversationId != null) {
                                                onNavigateToChat(conversationId)
                                            } else {
                                                Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            } else if (isProvider) {
                                PersonInfoCard(
                                    title = "بيانات الزبون صاحب الطلب",
                                    name = request.customerName,
                                    subtitle = "زبون مسجل في خدمتي",
                                    phone = request.customerPhone,
                                    wilaya = request.wilayaName,
                                    commune = request.communeName,
                                    icon = Icons.Default.Person,
                                    badgeColor = AmberLight,
                                    iconColor = AmberPrimary,
                                    onPhoneClick = {
                                        if (request.customerPhone.isNotBlank()) {
                                            try {
                                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                                    data = Uri.parse("tel:${request.customerPhone}")
                                                }
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        }
                                    },
                                    onChatClick = {
                                        authViewModel.openOrCreateConversation(
                                            customerId = request.customerId,
                                            customerName = request.customerName,
                                            providerId = request.providerId,
                                            providerName = request.providerName,
                                            providerProfession = request.professionNameAr,
                                            serviceRequestId = request.id,
                                            serviceRequestTitle = request.professionNameAr
                                        ) { conversationId, errorMsg ->
                                            if (conversationId != null) {
                                                onNavigateToChat(conversationId)
                                            } else {
                                                Toast.makeText(context, errorMsg ?: "تعذر فتح المحادثة", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Service Details Card
                            ServiceDetailsCard(request = request)

                            Spacer(modifier = Modifier.height(24.dp))

                            // Action Buttons based on Role & Status
                            if (isSubmittingAction) {
                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(color = EmeraldPrimary)
                                }
                            } else {
                                RequestActionButtons(
                                    request = request,
                                    isCustomer = isCustomer,
                                    isProvider = isProvider,
                                    onAccept = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.ACCEPTED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onReject = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.REJECTED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onStartProgress = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.IN_PROGRESS) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            }
                                        }
                                    },
                                    onComplete = {
                                        isSubmittingAction = true
                                        authViewModel.updateServiceRequestStatus(request.id, RequestStatus.COMPLETED) { success, error ->
                                            isSubmittingAction = false
                                            if (!success && error != null) {
                                                scope.launch { snackbarHostState.showSnackbar(error) }
                                            } else {
                                                scope.launch { snackbarHostState.showSnackbar("تمت إحالة الخدمة إلى مكتملة بنجاح ✅") }
                                            }
                                        }
                                    },
                                    onCancelClick = { showCancelDialog = true },
                                    onReviewClick = { showReviewDialog = true }
                                )
                            }

                            Spacer(modifier = Modifier.height(32.dp))
                        }
                    }
                }
                else -> {}
            }
        }
    }

    // Cancellation Dialog
    if (showCancelDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = {
                Text(
                    text = "إلغاء طلب الخدمة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من إلغاء طلب الخدمة؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelDialog = false
                        if (request != null) {
                            isSubmittingAction = true
                            authViewModel.updateServiceRequestStatus(request.id, RequestStatus.CANCELLED) { success, error ->
                                isSubmittingAction = false
                                if (!success && error != null) {
                                    scope.launch { snackbarHostState.showSnackbar(error) }
                                } else {
                                    scope.launch { snackbarHostState.showSnackbar("تم إلغاء الطلب بنجاح") }
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text("نعم، إلغاء الطلب")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("رجوع")
                }
            }
        )
    }

    // Review Dialog
    if (showReviewDialog && requestState is AuthResult.Success) {
        val request = (requestState as AuthResult.Success<ServiceRequest?>).data
        if (request != null) {
            ReviewSubmissionDialog(
                providerName = request.providerName,
                onDismiss = { showReviewDialog = false },
                onSubmit = { rating, comment ->
                    showReviewDialog = false
                    isSubmittingAction = true
                    authViewModel.submitReview(
                        requestId = request.id,
                        providerId = request.providerId,
                        rating = rating,
                        comment = comment
                    ) { success, error ->
                        isSubmittingAction = false
                        if (success) {
                            scope.launch { snackbarHostState.showSnackbar("شكراً لك! تم تقديم التقييم بنجاح ⭐️") }
                        } else if (error != null) {
                            scope.launch { snackbarHostState.showSnackbar(error) }
                        }
                    }
                }
            )
        }
    }
}

@Composable
private fun RequestStatusHeaderCard(request: ServiceRequest) {
    val (statusBg, statusText, statusTitle) = when (request.status) {
        RequestStatus.PENDING -> Triple(AmberLight, AmberPrimary, "قيد الانتظار")
        RequestStatus.ACCEPTED -> Triple(Color(0xFFE3F2FD), Color(0xFF1976D2), "تم القبول")
        RequestStatus.IN_PROGRESS -> Triple(Color(0xFFEDE7F6), Color(0xFF673AB7), "قيد التنفيذ")
        RequestStatus.COMPLETED -> Triple(SuccessGreenContainer, SuccessGreen, "مكتمل")
        RequestStatus.REJECTED -> Triple(Color(0xFFFFEBEE), ErrorRed, "مرفوض")
        RequestStatus.CANCELLED -> Triple(Color(0xFFF5F5F5), Color(0xFF757575), "ملغى")
    }

    val formattedDate = remember(request.createdAt) {
        try {
            DateFormat.format("yyyy/MM/dd - HH:mm", Date(request.createdAt)).toString()
        } catch (_: Exception) {
            ""
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = request.professionNameAr,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (formattedDate.isNotBlank()) {
                        Text(
                            text = "تاريخ الطلب: $formattedDate",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(statusBg)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = statusTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = statusText
                    )
                }
            }
        }
    }
}

@Composable
private fun RequestTimelineCard(status: RequestStatus) {
    val steps = listOf(
        RequestStatus.PENDING to "قيد الانتظار",
        RequestStatus.ACCEPTED to "تم القبول",
        RequestStatus.IN_PROGRESS to "قيد التنفيذ",
        RequestStatus.COMPLETED to "مكتمل"
    )

    val currentStepIndex = when (status) {
        RequestStatus.PENDING -> 0
        RequestStatus.ACCEPTED -> 1
        RequestStatus.IN_PROGRESS -> 2
        RequestStatus.COMPLETED -> 3
        RequestStatus.REJECTED, RequestStatus.CANCELLED -> -1
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "مسار تنفيذ الخدمة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (currentStepIndex == -1) {
                val text = if (status == RequestStatus.REJECTED) "تم رفض هذا الطلب من قبل الحرفي" else "تم إلغاء هذا الطلب"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (status == RequestStatus.REJECTED) Color(0xFFFFEBEE) else Color(0xFFF5F5F5))
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = text,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (status == RequestStatus.REJECTED) ErrorRed else Color(0xFF616161)
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    steps.forEachIndexed { index, pair ->
                        val isDone = index <= currentStepIndex
                        val isCurrent = index == currentStepIndex

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isDone) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text(
                                        text = "${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = pair.second,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isDone) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PersonInfoCard(
    title: String,
    name: String,
    subtitle: String,
    phone: String,
    wilaya: String,
    commune: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    badgeColor: Color,
    iconColor: Color,
    onPhoneClick: (() -> Unit)?,
    onChatClick: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(badgeColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = name.ifBlank { "غير مدخل" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$commune، ولاية $wilaya",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (onChatClick != null) {
                    IconButton(
                        onClick = onChatClick,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(EmeraldContainer)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = "مراسلة",
                            tint = EmeraldPrimary
                        )
                    }
                    if (onPhoneClick != null && phone.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                }

                if (onPhoneClick != null && phone.isNotBlank()) {
                    IconButton(
                        onClick = onPhoneClick,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(AmberLight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال",
                            tint = AmberPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceDetailsCard(request: ServiceRequest) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "تفاصيل طلب الخدمة",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (request.description.isNotBlank()) {
                Text(
                    text = "وصف المشكلة / الخدمة المطلوبة:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = request.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (request.addressDetails.isNotBlank()) {
                Text(
                    text = "العنوان الدقيق للخدمة:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = request.addressDetails,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            if (request.proposedPriceDzd != null && request.proposedPriceDzd > 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Payments,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الميزانية المقترحة: ${request.proposedPriceDzd} د.ج",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun RequestActionButtons(
    request: ServiceRequest,
    isCustomer: Boolean,
    isProvider: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onStartProgress: () -> Unit,
    onComplete: () -> Unit,
    onCancelClick: () -> Unit,
    onReviewClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Provider Actions
        if (isProvider) {
            when (request.status) {
                RequestStatus.PENDING -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onAccept,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("قبول الطلب", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onReject,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("رفض الطلب", fontWeight = FontWeight.Bold)
                        }
                    }
                }
                RequestStatus.ACCEPTED -> {
                    Button(
                        onClick = onStartProgress,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("بدء تنفيذ الخدمة 🛠️", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                RequestStatus.IN_PROGRESS -> {
                    Button(
                        onClick = onComplete,
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إتمام الخدمة  ✅", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                else -> {}
            }
        }

        // Customer Actions
        if (isCustomer) {
            when (request.status) {
                RequestStatus.PENDING, RequestStatus.ACCEPTED -> {
                    OutlinedButton(
                        onClick = onCancelClick,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Cancel, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إلغاء الطلب", fontWeight = FontWeight.Bold)
                    }
                }
                RequestStatus.COMPLETED -> {
                    Button(
                        onClick = onReviewClick,
                        colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Star, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تقييم الحرفي ⭐️", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun ReviewSubmissionDialog(
    providerName: String,
    onDismiss: () -> Unit,
    onSubmit: (rating: Int, comment: String) -> Unit
) {
    var rating by remember { mutableIntStateOf(5) }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تقييم أداء الحرفي $providerName",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "يرجى تقييم تجربة الخدمة من 1 إلى 5 نجوم:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    (1..5).forEach { starIndex ->
                        IconButton(onClick = { rating = starIndex }) {
                            Icon(
                                imageVector = if (starIndex <= rating) Icons.Default.Star else Icons.Outlined.Star,
                                contentDescription = "$starIndex نجوم",
                                tint = AmberPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("تعليق أو ملاحظة حول الخدمة (اختياري)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(rating, comment) },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("إرسال التقييم")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
