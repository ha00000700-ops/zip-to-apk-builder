package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.GardenPlant
import com.example.data.model.PlantDiagnosis
import com.example.data.remote.ApiKeyMissingException
import com.example.data.remote.NotAPlantException
import com.example.data.repository.PlantRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class Screen {
    object Scan : Screen()
    object DiagnosisResult : Screen()
    object Chat : Screen()
    object MyGarden : Screen()
    object Encyclopedia : Screen()
}

class PlantDoctorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PlantRepository(application.applicationContext)

    val scanHistory: StateFlow<List<PlantDiagnosis>> = repository.scanHistory
    val gardenPlants: StateFlow<List<GardenPlant>> = repository.gardenPlants
    val chatMessages: StateFlow<List<ChatMessage>> = repository.chatMessages
    val activeDiagnosis: StateFlow<PlantDiagnosis?> = repository.activeDiagnosis
    val isAnalyzing: StateFlow<Boolean> = repository.isAnalyzing

    private val _currentScreen = MutableStateFlow<Screen>(Screen.Scan)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _isSendingChat = MutableStateFlow(false)
    val isSendingChat: StateFlow<Boolean> = _isSendingChat.asStateFlow()

    private val _diagnosisError = MutableStateFlow<String?>(null)
    val diagnosisError: StateFlow<String?> = _diagnosisError.asStateFlow()

    val hasApiKey: Boolean
        get() = repository.apiKeyManager.hasValidKey()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun clearError() {
        _diagnosisError.value = null
    }

    fun diagnoseBitmap(bitmap: Bitmap) {
        viewModelScope.launch {
            _diagnosisError.value = null
            try {
                repository.diagnoseImage(bitmap)
                _currentScreen.value = Screen.DiagnosisResult
            } catch (e: ApiKeyMissingException) {
                _diagnosisError.value = "مفتاح الذكاء الاصطناعي مطلوب لإجراء الفحص.\nيرجى تعيين GEMINI_API_KEY في لوحة الأسرار (Secrets Panel) في AI Studio ليظل مخفياً ومحمياً."
            } catch (e: NotAPlantException) {
                _diagnosisError.value = e.message
            } catch (e: Exception) {
                _diagnosisError.value = e.message ?: "حدث خطأ أثناء إجراء الفحص بالذكاء الاصطناعي."
            }
        }
    }

    fun diagnoseUri(uri: Uri) {
        viewModelScope.launch {
            _diagnosisError.value = null
            try {
                repository.diagnoseFromUri(uri)
                _currentScreen.value = Screen.DiagnosisResult
            } catch (e: ApiKeyMissingException) {
                _diagnosisError.value = "مفتاح الذكاء الاصطناعي مطلوب لإجراء الفحص.\nيرجى تعيين GEMINI_API_KEY في لوحة الأسرار (Secrets Panel) في AI Studio ليظل مخفياً ومحمياً."
            } catch (e: NotAPlantException) {
                _diagnosisError.value = e.message
            } catch (e: Exception) {
                _diagnosisError.value = e.message ?: "حدث خطأ أثناء فحص الصورة المحددة."
            }
        }
    }

    fun viewDiagnosis(diagnosis: PlantDiagnosis) {
        repository.setDiagnosis(diagnosis)
        _currentScreen.value = Screen.DiagnosisResult
    }

    fun updateDiagnosisStatus(diagnosisId: String, newStatus: String) {
        repository.updateDiagnosisStatus(diagnosisId, newStatus)
    }

    fun waterPlant(plantId: String) {
        repository.waterPlant(plantId)
    }

    fun addGardenPlant(name: String, type: String, wateringDays: Int, note: String, isUnderTreatment: Boolean) {
        repository.addPlantToGarden(name, type, wateringDays, note, isUnderTreatment)
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _isSendingChat.value = true
            try {
                repository.sendChatMessage(text)
            } finally {
                _isSendingChat.value = false
            }
        }
    }

    fun consultDoctorAboutDiagnosis(diagnosis: PlantDiagnosis) {
        repository.setDiagnosis(diagnosis)
        _currentScreen.value = Screen.Chat
        val prompt = if (diagnosis.isHealthy) {
            "فحصت نبتتي بالذكاء الاصطناعي وظهر أنها (${diagnosis.plantName}) وهي سليمة. ما هي نصائحك للمحافظة عليها وتجنب أي إصابات فطرية أو حشرية؟"
        } else {
            "أهلاً دكتور، قمت بفحص صورة نبتتي بالذكاء الاصطناعي وشخصت إصابتها بـ '${diagnosis.diseaseNameArabic}'. ما هي أول خطوة سريعة يجب عليّ تطبيقها لعلاجها وحمايتها؟"
        }
        sendChatMessage(prompt)
    }
}
