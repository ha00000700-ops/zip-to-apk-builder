package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarViewWeek
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CareTaskEntity
import com.example.ui.PlantDoctorViewModel
import com.example.ui.components.AppTopBar
import com.example.ui.components.EmptyStateCard
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CareScheduleScreen(viewModel: PlantDoctorViewModel) {
    val pendingTasks by viewModel.pendingTasks.collectAsState()
    val completedTasks by viewModel.completedTasks.collectAsState()
    val plants by viewModel.plants.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedCalendarScope by remember { mutableStateOf("أسبوعي") } // أسبوعي vs شهري vs الكل
    var selectedTaskType by remember { mutableStateOf("الكل") }
    var showAddTaskDialog by remember { mutableStateOf(false) }

    // Dialog state for adding new task
    var newTaskPlantName by remember { mutableStateOf(plants.firstOrNull()?.name ?: "نبات الحديقة") }
    var newTaskType by remember { mutableStateOf("ري") }
    var newTaskIntervalDays by remember { mutableStateOf("3") }
    var newTaskNotes by remember { mutableStateOf("") }
    var plantDropdownExpanded by remember { mutableStateOf(false) }

    val taskTypes = listOf("الكل", "ري", "تسميد", "تقليم", "فحص وقائي")

    val now = System.currentTimeMillis()
    val oneWeekMillis = 7 * 24 * 60 * 60 * 1000L
    val oneMonthMillis = 30 * 24 * 60 * 60 * 1000L

    val baseTasks = if (selectedTabIndex == 0) pendingTasks else completedTasks
    val filteredTasks = baseTasks.filter { task ->
        val matchesType = selectedTaskType == "الكل" || task.taskType.contains(selectedTaskType)
        val matchesScope = when (selectedCalendarScope) {
            "أسبوعي" -> task.dueDate <= (now + oneWeekMillis)
            "شهري" -> task.dueDate <= (now + oneMonthMillis)
            else -> true
        }
        matchesType && matchesScope
    }

    if (showAddTaskDialog) {
        val typesList = listOf("ري", "تسميد", "تقليم", "فحص وقائي")
        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("جدولة تذكير عناية جديد 🗓️", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Plant selector
                    if (plants.isNotEmpty()) {
                        ExposedDropdownMenuBox(
                            expanded = plantDropdownExpanded,
                            onExpandedChange = { plantDropdownExpanded = !plantDropdownExpanded }
                        ) {
                            OutlinedTextField(
                                value = newTaskPlantName,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("النبات المستهدف") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = plantDropdownExpanded) },
                                modifier = Modifier.fillMaxWidth().menuAnchor(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(
                                expanded = plantDropdownExpanded,
                                onDismissRequest = { plantDropdownExpanded = false }
                            ) {
                                plants.forEach { p ->
                                    DropdownMenuItem(
                                        text = { Text(p.name) },
                                        onClick = {
                                            newTaskPlantName = p.name
                                            plantDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        OutlinedTextField(
                            value = newTaskPlantName,
                            onValueChange = { newTaskPlantName = it },
                            label = { Text("اسم النبات") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    // Task Type Chips
                    Text("نوع المهمة:", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        typesList.forEach { t ->
                            FilterChip(
                                selected = newTaskType == t,
                                onClick = { newTaskType = t },
                                label = { Text(t, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = newTaskIntervalDays,
                        onValueChange = { newTaskIntervalDays = it },
                        label = { Text("الموعد بعد (عدد الأيام)") },
                        placeholder = { Text("مثال: 3") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = newTaskNotes,
                        onValueChange = { newTaskNotes = it },
                        label = { Text("ملاحظات إرشادية (اختياري)") },
                        placeholder = { Text("مثال: التأكد من جفاف التربة أولاً...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val days = newTaskIntervalDays.toIntOrNull() ?: 3
                        val targetPlant = plants.find { it.name == newTaskPlantName }
                        viewModel.saveCareTask(
                            CareTaskEntity(
                                plantId = targetPlant?.id ?: 0L,
                                plantName = newTaskPlantName,
                                taskType = newTaskType,
                                dueDate = System.currentTimeMillis() + (days * 24 * 60 * 60 * 1000L),
                                notes = newTaskNotes
                            )
                        )
                        showAddTaskDialog = false
                        newTaskNotes = ""
                    }
                ) {
                    Text("إضافة التذكير")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "تقويم العناية والري 🗓️",
                subtitle = "جدول أسبوعي وشهري مخصص لاحتياجات نباتاتك",
                showBackButton = true,
                onBackClick = { viewModel.navigateBack() }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddTaskDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_care_task_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مهمة عناية")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tabs: Pending vs Completed
            TabRow(selectedTabIndex = selectedTabIndex) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("المهام القادمة (${pendingTasks.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("المهام المنجزة (${completedTasks.size})", fontWeight = FontWeight.Bold) }
                )
            }

            // Calendar Scope Selector (أسبوعي / شهري / الكل)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("أسبوعي", "شهري", "عرض الكل").forEach { scope ->
                    FilterChip(
                        selected = selectedCalendarScope == scope,
                        onClick = { selectedCalendarScope = scope },
                        label = { Text(scope, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
                        leadingIcon = {
                            if (scope == "أسبوعي") Icon(Icons.Default.CalendarViewWeek, contentDescription = null, modifier = Modifier.size(16.dp))
                            else if (scope == "شهري") Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    )
                }
            }

            // Task Type Filter Chips
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(taskTypes) { type ->
                    FilterChip(
                        selected = selectedTaskType == type,
                        onClick = { selectedTaskType = type },
                        label = { Text(type, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }

            if (filteredTasks.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.CalendarMonth,
                    title = if (selectedTabIndex == 0) "لا توجد مهام رعاية مستحقة" else "لا توجد مهام منجزة",
                    description = if (selectedTabIndex == 0) "نباتاتك في حالة ممتازة، أو يمكنك إضافة تذكير ري جديد بالضغط على زر (+)" else "ستظهر هنا المهام التي أكملتها لاحقاً"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredTasks, key = { it.id }) { task ->
                        CareTaskCard(
                            task = task,
                            onCompleteClick = { viewModel.completeTask(task.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CareTaskCard(
    task: CareTaskEntity,
    onCompleteClick: () -> Unit
) {
    val isOverdue = !task.isCompleted && task.dueDate < System.currentTimeMillis()
    val dateFormat = SimpleDateFormat("EEEE, d MMMM", Locale("ar"))
    val dueDateStr = dateFormat.format(Date(task.dueDate))

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("care_task_card_${task.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (task.isCompleted) 0.dp else 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Task Type Icon
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            task.taskType.contains("ري") -> AgriGreenMint
                            task.taskType.contains("تسميد") -> MaterialTheme.colorScheme.secondaryContainer
                            task.taskType.contains("تقليم") -> Color(0xFFFFF3E0)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        task.taskType.contains("ري") -> Icons.Default.WaterDrop
                        task.taskType.contains("تسميد") -> Icons.Default.LocalFlorist
                        task.taskType.contains("تقليم") -> Icons.Default.ContentCut
                        else -> Icons.Default.CalendarMonth
                    },
                    contentDescription = null,
                    tint = when {
                        task.taskType.contains("ري") -> AgriGreenDark
                        task.taskType.contains("تسميد") -> MaterialTheme.colorScheme.secondary
                        task.taskType.contains("تقليم") -> Color(0xFFE65100)
                        else -> MaterialTheme.colorScheme.primary
                    },
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${task.taskType} • ${task.plantName}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (task.isCompleted) "تم الإنجاز بنجاح ✓" else dueDateStr,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline,
                    fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                )
                if (task.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = task.notes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }
            }

            if (!task.isCompleted) {
                IconButton(
                    onClick = onCompleteClick,
                    modifier = Modifier.testTag("complete_task_button_${task.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "تم الإنجاز",
                        tint = AgriGreenDark,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
