package com.example.ui.screens.requests

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.StatusBadge
import com.example.ui.components.UrgencyBadge
import com.example.ui.screens.dialogs.ReviewDialog
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequestDetailScreen(
    request: ServiceRequestEntity,
    offers: List<RequestOfferEntity> = emptyList(),
    currentUser: UserEntity?,
    currentPro: ProfessionalEntity?,
    onBack: () -> Unit,
    onStatusChange: (RequestStatus) -> Unit,
    onAcceptByPro: () -> Unit,
    onSubmitOffer: (priceDzd: Double, note: String) -> Unit = { _, _ -> },
    onAcceptOffer: (RequestOfferEntity) -> Unit = {},
    onRejectOffer: (Long) -> Unit = {},
    onRequestClarification: (RequestOfferEntity) -> Unit = {},
    onCancelRequestWithReason: (reason: String) -> Unit = {},
    onOpenChat: () -> Unit,
    onSubmitReview: (rating: Int, comment: String) -> Unit,
    onSubmitReport: (ReportEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showReviewDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }
    var showCancelDialog by remember { mutableStateOf(false) }
    var showOfferDialog by remember { mutableStateOf(false) }
    var offerPriceInput by remember { mutableStateOf("") }
    var offerNoteInput by remember { mutableStateOf("") }
    var cancelReasonInput by remember { mutableStateOf("") }

    val isPro = currentUser?.role == UserRole.PROFESSIONAL || currentPro != null
    val isCustomer = currentUser?.id == request.customerId || !isPro

    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("تفاصيل الطلب #${request.id}", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Status & Service Header
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (request.title.isNotBlank()) request.title else request.serviceNameAr,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                if (request.title.isNotBlank()) {
                                    Text(
                                        text = "نوع الخدمة: ${request.serviceNameAr}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            StatusBadge(status = request.status)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تاريخ الطلب: ${dateFormatter.format(Date(request.createdAt))}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        UrgencyBadge(urgency = request.urgency)

                        if (request.agreedPriceDzd != null) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = DzGreenLight,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AttachMoney, contentDescription = null, tint = DzGreenPrimary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("السعر المتفق عليه:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DzGreenDark)
                                    }
                                    Text("${request.agreedPriceDzd.toInt()} دج", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = DzGreenDark)
                                }
                            }
                        }
                    }
                }
            }

            // 2. Interactive Status Timeline Stepper
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("مراحل تنفيذ الخدمة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        val steps = listOf(
                            Pair(RequestStatus.NEW, "1. تم إرسال الطلب"),
                            Pair(RequestStatus.ACCEPTED, "2. تم قبول الطلب من الحرفي"),
                            Pair(RequestStatus.ON_THE_WAY, "3. الحرفي في الطريق إليك"),
                            Pair(RequestStatus.IN_PROGRESS, "4. جاري تنفيذ العمل"),
                            Pair(RequestStatus.COMPLETED, "5. تم إنجاز الخدمة بنجاح")
                        )

                        val currentStepIndex = when (request.status) {
                            RequestStatus.NEW, RequestStatus.REVIEWING -> 0
                            RequestStatus.ACCEPTED -> 1
                            RequestStatus.ON_THE_WAY -> 2
                            RequestStatus.IN_PROGRESS -> 3
                            RequestStatus.COMPLETED -> 4
                            RequestStatus.CANCELLED -> -1
                        }

                        if (request.status == RequestStatus.CANCELLED) {
                            Surface(
                                color = StatusCancelled.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Cancel, contentDescription = null, tint = StatusCancelled)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تم إلغاء هذا الطلب", color = StatusCancelled, fontWeight = FontWeight.Bold)
                                    }
                                    if (request.cancellationReason.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "سبب الإلغاء: ${request.cancellationReason}",
                                            fontSize = 12.sp,
                                            color = StatusCancelled
                                        )
                                    }
                                }
                            }
                        } else {
                            steps.forEachIndexed { index, pair ->
                                val isDone = index <= currentStepIndex
                                val isCurrent = index == currentStepIndex

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (isDone) DzGreenPrimary else Color.LightGray),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isDone) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                        } else {
                                            Text("${index + 1}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Text(
                                        text = pair.second,
                                        fontSize = 13.sp,
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isCurrent) MaterialTheme.colorScheme.primary else if (isDone) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Price Offers Section (عروض الأسعار)
            if (request.agreedPriceDzd == null && request.status != RequestStatus.CANCELLED) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("💰 عروض الأسعار المقترحة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                if (isPro && (request.status == RequestStatus.NEW || request.status == RequestStatus.ACCEPTED)) {
                                    FilledTonalButton(
                                        onClick = { showOfferDialog = true },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تقديم عرض سعر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (offers.isEmpty()) {
                                Text(
                                    text = if (isPro) "لم تقدم عرض سعر بعد. انقر 'تقديم عرض سعر' لإرسال تقدير التكلفة للزبون." else "لم يتم تقديم عرض سعر محدد بعد من الحرفي.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    offers.forEach { offer ->
                                        Surface(
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(offer.professionalName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                    Text("${offer.priceDzd.toInt()} دج", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = DzGreenPrimary)
                                                }
                                                if (offer.note.isNotBlank()) {
                                                    Text("ملاحظة: ${offer.note}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
                                                }
                                                Text("الحالة: ${offer.status.labelAr}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))

                                                // Customer Offer Actions
                                                if (isCustomer && offer.status == OfferStatus.PENDING) {
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        Button(
                                                            onClick = { onAcceptOffer(offer) },
                                                            colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary),
                                                            modifier = Modifier.weight(1f).height(36.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp)
                                                        ) {
                                                            Text("قبول العرض ✅", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        }

                                                        OutlinedButton(
                                                            onClick = { onRequestClarification(offer); onOpenChat() },
                                                            modifier = Modifier.weight(1f).height(36.dp),
                                                            contentPadding = PaddingValues(horizontal = 8.dp)
                                                        ) {
                                                            Text("طلب توضيح 💬", fontSize = 11.sp)
                                                        }

                                                        TextButton(
                                                            onClick = { onRejectOffer(offer.id) },
                                                            modifier = Modifier.height(36.dp)
                                                        ) {
                                                            Text("رفض ❌", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Problem Description & Address Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("وصف المشكلة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = request.description,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 20.sp
                        )

                        if (request.images.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("الصور المرفقة مع الطلب:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                request.images.split(",").forEach { imgTag ->
                                    AssistChip(
                                        onClick = {},
                                        label = { Text("📷 ${imgTag.trim()}", fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text("موقع التدخل والعنوان:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = DzGreenPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ولاية ${request.wilayaNameAr} • بلدية ${request.communeNameAr}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (request.addressDetails.isNotBlank()) {
                            Text(
                                text = "تفاصيل العنوان: ${request.addressDetails}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp, start = 24.dp)
                            )
                        }
                    }
                }
            }

            // 5. Partner Contact & In-App Communication Hub
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (isPro) "معلومات الزبون للتواصل:" else "معلومات الحرفي المسؤول:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val partnerName = if (isPro) request.customerName else (request.professionalName ?: "بانتظار قبول حرفي")
                        val partnerPhone = if (isPro) request.customerPhone else (request.professionalPhone ?: "")

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = partnerName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                if (partnerPhone.isNotBlank()) {
                                    Text(text = partnerPhone, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (partnerPhone.isNotBlank()) {
                                    IconButton(
                                        onClick = {
                                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$partnerPhone"))
                                            try {
                                                context.startActivity(dialIntent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "الهاتف: $partnerPhone", Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(DzGreenLight)
                                    ) {
                                        Icon(Icons.Default.Phone, contentDescription = "اتصال", tint = DzGreenPrimary)
                                    }
                                }

                                Button(
                                    onClick = onOpenChat,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Outlined.Chat, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("المحادثة", color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 6. Action Controls Based on Role & Status
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // For Professional:
                    if (isPro && request.status != RequestStatus.COMPLETED && request.status != RequestStatus.CANCELLED) {
                        when (request.status) {
                            RequestStatus.NEW, RequestStatus.REVIEWING -> {
                                Button(
                                    onClick = onAcceptByPro,
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("قبول هذا الطلب والبدء", fontWeight = FontWeight.Bold)
                                }
                            }
                            RequestStatus.ACCEPTED -> {
                                Button(
                                    onClick = { onStatusChange(RequestStatus.ON_THE_WAY) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusOnTheWay)
                                ) {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("أنا في الطريق إلى الزبون 🛵", fontWeight = FontWeight.Bold)
                                }
                            }
                            RequestStatus.ON_THE_WAY -> {
                                Button(
                                    onClick = { onStatusChange(RequestStatus.IN_PROGRESS) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusInProgress)
                                ) {
                                    Icon(Icons.Default.Build, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("وصلت - بدء تنفيذ الخدمة 🔧", fontWeight = FontWeight.Bold)
                                }
                            }
                            RequestStatus.IN_PROGRESS -> {
                                Button(
                                    onClick = { onStatusChange(RequestStatus.COMPLETED) },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusCompleted)
                                ) {
                                    Icon(Icons.Default.DoneAll, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("تم إنهاء الخدمة بنجاح ✓", fontWeight = FontWeight.Bold)
                                }
                            }
                            else -> {}
                        }
                    }

                    // For Customer:
                    if (isCustomer) {
                        // Rate Button if Completed & not rated
                        if (request.status == RequestStatus.COMPLETED) {
                            if (!request.isRated && request.professionalId != null) {
                                Button(
                                    onClick = { showReviewDialog = true },
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("rate_craftsman_btn"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = DzGold)
                                ) {
                                    Icon(Icons.Outlined.Star, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("تقييم الحرفي وكتابة رأيك ★★★★★", fontWeight = FontWeight.Bold, color = Color.White)
                                }
                            } else if (request.isRated) {
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Star, contentDescription = null, tint = DzGold)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("شكراً لك! لقد قمت بتقييم هذه الخدمة بالفعل.", color = Color(0xFF78350F), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                }
                            }
                        }

                        // Cancel Button if still New / Accepted
                        if (request.status == RequestStatus.NEW || request.status == RequestStatus.REVIEWING || request.status == RequestStatus.ACCEPTED) {
                            OutlinedButton(
                                onClick = { showCancelDialog = true },
                                modifier = Modifier.fillMaxWidth().height(46.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusCancelled)
                            ) {
                                Icon(Icons.Outlined.Cancel, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إلغاء الطلب")
                            }
                        }
                    }

                    // Report/Dispute Trigger
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(
                        onClick = { showReportDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Icon(Icons.Default.ReportProblem, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("الإبلاغ عن مشكلة أو نزاع للإدارة", fontSize = 12.sp)
                    }
                }
            }
        }
    }

    // Offer Dialog
    if (showOfferDialog) {
        AlertDialog(
            onDismissRequest = { showOfferDialog = false },
            title = { Text("تقديم عرض سعر 💰", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("أدخل السعر المقترح بالدينار الجزائري (دج):", fontSize = 13.sp)
                    OutlinedTextField(
                        value = offerPriceInput,
                        onValueChange = { offerPriceInput = it },
                        label = { Text("السعر المقترح (دج)") },
                        placeholder = { Text("مثال: 1500") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = offerNoteInput,
                        onValueChange = { offerNoteInput = it },
                        label = { Text("ملاحظة أو تفاصيل العرض (اختياري)") },
                        placeholder = { Text("مثال: شامل قطع الغيار والتنقل...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = offerPriceInput.toDoubleOrNull()
                        if (price != null && price > 0) {
                            onSubmitOffer(price, offerNoteInput)
                            showOfferDialog = false
                            offerPriceInput = ""
                            offerNoteInput = ""
                            Toast.makeText(context, "تم إرسال عرض السعر للزبون بنجاح ✅", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "الرجاء أدخل مبلغاً صحيحاً", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary)
                ) {
                    Text("إرسال العرض")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOfferDialog = false }) { Text("إلغاء") }
            }
        )
    }

    // Cancel Reason Dialog
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = { Text("تأكيد إلغاء الطلب ❌", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("يرجى كتابة سبب الإلغاء لمساعدة الطرف الآخر والإدارة:", fontSize = 13.sp)
                    OutlinedTextField(
                        value = cancelReasonInput,
                        onValueChange = { cancelReasonInput = it },
                        placeholder = { Text("مثال: تم التوصل إلى حل آخر / عدم التوافق في الموعد...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onCancelRequestWithReason(cancelReasonInput.ifBlank { "إلغاء من قبل المستخدم" })
                        showCancelDialog = false
                        Toast.makeText(context, "تم إلغاء الطلب بنجاح", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("تأكيد الإلغاء")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) { Text("تراجع") }
            }
        )
    }

    if (showReportDialog) {
        com.example.ui.screens.dialogs.ReportDialog(
            targetType = "طلب خدمة #${request.id}",
            targetId = request.id,
            targetName = if (isPro) request.customerName else (request.professionalName ?: "الطلب"),
            reporterId = currentUser?.id ?: 0L,
            reporterName = currentUser?.fullName ?: "مستخدم",
            onDismiss = { showReportDialog = false },
            onSubmitReport = { report ->
                onSubmitReport(report)
                showReportDialog = false
                Toast.makeText(context, "تم إرسال بلاغك للإدارة للمراجعة", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showReviewDialog && request.professionalName != null) {
        ReviewDialog(
            professionalName = request.professionalName,
            onDismiss = { showReviewDialog = false },
            onSubmit = { rating, comment ->
                onSubmitReview(rating, comment)
                showReviewDialog = false
            }
        )
    }
}

