package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.Screen
import com.example.ui.theme.BottomNavBackground
import com.example.ui.theme.NavActiveColor

@Composable
fun MainScreen() {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val navController = rememberNavController()
        val screens = listOf(Screen.Home, Screen.Quran, Screen.Wird, Screen.More)

        Scaffold(
            bottomBar = { CustomBottomBar(navController, screens) }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.padding(innerPadding).background(MaterialTheme.colorScheme.background)
            ) {
                composable(Screen.Home.route) { HomeScreen() }
                composable(Screen.Quran.route) { QuranScreen(navController = navController) }
                composable(Screen.Wird.route) { WirdScreen() }
                composable(Screen.More.route) { SettingsScreen() } // Reusing SettingsScreen for More for now
                composable("surah/{surahId}") { backStackEntry ->
                    val surahId = backStackEntry.arguments?.getString("surahId")?.toIntOrNull()
                    if (surahId != null) {
                        SurahDetailScreen(surahId = surahId, navController = navController)
                    }
                }
                composable("bookmarks") {
                    BookmarksScreen(navController = navController)
                }
            }
        }
    }
}

@Composable
fun CustomBottomBar(navController: NavHostController, screens: List<Screen>) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BottomNavBackground)
            .padding(vertical = 12.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        screens.forEach { screen ->
            val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
            val color = if (selected) NavActiveColor else Color.White.copy(alpha = 0.5f)
            
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        navController.navigate(screen.route) {
                            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                    .padding(8.dp)
            ) {
                Icon(screen.icon, contentDescription = stringResource(screen.titleResId), tint = color, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text(stringResource(screen.titleResId), color = color, fontSize = 12.sp)
                if (selected) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(modifier = Modifier.size(4.dp).background(color, CircleShape))
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}
