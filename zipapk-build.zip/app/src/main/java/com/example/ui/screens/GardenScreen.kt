package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.GardenPlant
import com.example.ui.theme.*
import com.example.ui.viewmodel.PlantDoctorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GardenScreen(viewModel: PlantDoctorViewModel) {
    val plants by viewModel.gardenPlants.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }

    val plantsDueWatering = remember(plants) { plants.filter { it.isWateringDue() } }
    val plantsUnderTreatment = remember(plants) { plants.filter { it.isUnderTreatment } }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 80.dp)
                    .testTag("add_garden_plant_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة نبتة")
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Stats Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "حديقتي وسجل الرعاية",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = EmeraldPrimary
                                )
                                Text(
                                    text = "متابعة جداول الري وحالات العلاج",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Surface(
                                shape = CircleShape,
                                color = MintSoft,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Yard,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = SurfaceTint)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            StatColumn(title = "إجمالي النباتات", value = plants.size.toString(), color = EmeraldPrimary)
                            StatColumn(title = "تحتاج ري اليوم", value = plantsDueWatering.size.toString(), color = if (plantsDueWatering.isNotEmpty()) WarningOrange else SuccessGreen)
                            StatColumn(title = "تحت العلاج", value = plantsUnderTreatment.size.toString(), color = if (plantsUnderTreatment.isNotEmpty()) DangerRed else SuccessGreen)
                        }
                    }
                }
            }

            // Watering Alert Banner
            if (plantsDueWatering.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarningOrangeBg),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.WaterDrop,
                                contentDescription = null,
                                tint = WarningOrange,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حان موعد سقاية ${plantsDueWatering.size} من نباتاتك!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = WarningOrange
                                )
                                Text(
                                    text = plantsDueWatering.joinToString("، ") { it.name },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Plants List Title
            item {
                Text(
                    text = "نباتاتي المزروعة (${plants.size})",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            // Plants List
            if (plants.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Eco,
                                contentDescription = null,
                                tint = MintSecondary,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(text = "لا توجد نباتات مسجلة بعد", fontWeight = FontWeight.Bold)
                            Text(
                                text = "أضف نباتاتك المنزلية لتنظيم مواعيد السقاية والعلاج",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(plants) { plant ->
                    GardenPlantCard(
                        plant = plant,
                        onWater = { viewModel.waterPlant(plant.id) }
                    )
                }
            }
        }

        // Add Plant Dialog
        if (showAddDialog) {
            AddPlantDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { name, type, days, note, isUnderTreatment ->
                    viewModel.addGardenPlant(name, type, days, note, isUnderTreatment)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun StatColumn(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
        Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun GardenPlantCard(plant: GardenPlant, onWater: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("garden_plant_${plant.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (plant.isUnderTreatment) DangerRedBg else MintSoft,
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (plant.isUnderTreatment) Icons.Default.MedicalServices else Icons.Default.Park,
                        contentDescription = null,
                        tint = if (plant.isUnderTreatment) DangerRed else EmeraldPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = plant.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (plant.isUnderTreatment) DangerRedBg else SuccessGreenBg
                    ) {
                        Text(
                            text = if (plant.isUnderTreatment) "تحت العلاج" else "سليم",
                            color = if (plant.isUnderTreatment) DangerRed else SuccessGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = plant.plantType,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (plant.diagnosisNote.isNotBlank()) {
                    Text(
                        text = "ملاحظة: ${plant.diagnosisNote}",
                        fontSize = 11.sp,
                        color = if (plant.isUnderTreatment) WarningOrange else EmeraldPrimary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = null,
                        tint = if (plant.isWateringDue()) WarningOrange else MintSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (plant.isWateringDue()) "الري مستحق اليوم!" else "الري القادم بعد ${plant.daysUntilNextWatering()} يوم",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (plant.isWateringDue()) WarningOrange else MintSecondary
                    )
                }
            }

            // Quick Water Button
            IconButton(
                onClick = onWater,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (plant.isWateringDue()) WarningOrangeBg else SurfaceTint)
                    .size(42.dp)
                    .testTag("water_plant_button_${plant.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.WaterDrop,
                    contentDescription = "سقاية الآن",
                    tint = if (plant.isWateringDue()) WarningOrange else EmeraldPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun AddPlantDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, type: String, wateringDays: Int, note: String, isUnderTreatment: Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("نبات منزلي") }
    var wateringDaysText by remember { mutableStateOf("3") }
    var note by remember { mutableStateOf("") }
    var isUnderTreatment by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "إضافة نبتة جديدة لحديقتي",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = EmeraldPrimary
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم النبتة (مثال: نبتة البوتوس، شجرة ليمون)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = type,
                    onValueChange = { type = it },
                    label = { Text("نوع النبتة (نبات ظل، خضار، حمضيات)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = wateringDaysText,
                    onValueChange = { wateringDaysText = it },
                    label = { Text("تكرار الري (كل كم يوم؟)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("ملاحظات علاجية أو وقائية") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Checkbox(
                        checked = isUnderTreatment,
                        onCheckedChange = { isUnderTreatment = it },
                        colors = CheckboxDefaults.colors(checkedColor = EmeraldPrimary)
                    )
                    Text(text = "النبتة مصابة وتحت العلاج حالياً", fontSize = 13.sp)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء")
                    }
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                val days = wateringDaysText.toIntOrNull() ?: 3
                                onAdd(name, type, days, note, isUnderTreatment)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("إضافة")
                    }
                }
            }
        }
    }
}
