package com.example.ui.screens.chat

import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.Conversation
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import androidx.compose.material.icons.filled.Forum
import com.example.ui.theme.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.foundation.BorderStroke
import com.example.ui.viewmodel.AuthViewModel
import androidx.compose.material3.Surface
import androidx.compose.ui.unit.sp
import java.util.Date

@Composable
fun ConversationsScreen(
    authViewModel: AuthViewModel,
    onNavigateToChat: (String) -> Unit,
    onNavigateBack: (() -> Unit)? = null
) {
    val currentUserId = authViewModel.currentUserProfile.collectAsState().value?.uid ?: ""
    val conversationsState by authViewModel.userConversationsState.collectAsState()

    LaunchedEffect(Unit) {
        authViewModel.observeUserConversations()
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الرسائل",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (val state = conversationsState) {
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(text = state.messageAr, color = Color.Red)
                    }
                }
                is AuthResult.Success -> {
                    val conversations = state.data
                    if (conversations.isEmpty()) {
                        EmptyConversationsView()
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("conversations_list"),
                            contentPadding = PaddingValues(24.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(conversations, key = { it.id }) { conv ->
                                ConversationItem(
                                    conversation = conv,
                                    currentUserId = currentUserId,
                                    onClick = { onNavigateToChat(conv.id) }
                                )
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun EmptyConversationsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .background(BluePrimary.copy(alpha = 0.05f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Forum,
                contentDescription = null,
                tint = BluePrimary.copy(alpha = 0.4f),
                modifier = Modifier.size(64.dp)
            )
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "لا توجد رسائل بعد",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            color = BlueDark
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "تواصل مع الحرفيين لمناقشة طلباتك والحصول على أفضل خدمة.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondaryLight,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ConversationItem(
    conversation: Conversation,
    currentUserId: String,
    onClick: () -> Unit
) {
    val isCustomer = conversation.customerId == currentUserId
    val otherName = if (isCustomer) conversation.providerName else conversation.customerName
    val otherPhoto = if (isCustomer) conversation.providerPhotoUrl else conversation.customerPhotoUrl
    val otherSub = if (isCustomer) conversation.providerProfession else "زبون"

    val unreadCount = if (isCustomer) conversation.customerUnreadCount else conversation.providerUnreadCount
    val hasUnread = unreadCount > 0

    val formattedTime = remember(conversation.lastMessageAt) {
        try {
            val now = System.currentTimeMillis()
            val diff = now - conversation.lastMessageAt
            if (diff < 24 * 60 * 60 * 1000) {
                DateFormat.format("HH:mm", Date(conversation.lastMessageAt)).toString()
            } else {
                DateFormat.format("MM/dd", Date(conversation.lastMessageAt)).toString()
            }
        } catch (_: Exception) {
            ""
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, if (hasUnread) BluePrimary.copy(alpha = 0.5f) else OutlineLight.copy(alpha = 0.5f)),
        shadowElevation = if (hasUnread) 4.dp else 0.dp
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(BluePrimary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (!otherPhoto.isNullOrBlank()) {
                    AsyncImage(
                        model = com.example.data.remote.SupabaseConfig.resolveUrl(otherPhoto),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().clip(CircleShape)
                    )
                } else {
                    Text(
                        text = otherName.take(1).uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = BluePrimary
                    )
                }
                
                if (hasUnread) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(Color.White, CircleShape)
                            .align(Alignment.TopEnd)
                            .padding(2.dp)
                    ) {
                        Box(modifier = Modifier.fillMaxSize().background(Color.Red, CircleShape))
                    }
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = otherName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = BlueDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = formattedTime,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (hasUnread) BluePrimary else TextTertiaryLight,
                        fontWeight = if (hasUnread) FontWeight.Bold else FontWeight.Medium
                    )
                }
                
                Text(
                    text = conversation.lastMessage.ifBlank { "محادثة جديدة" },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (hasUnread) BlueDark else TextSecondaryLight,
                    fontWeight = if (hasUnread) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
