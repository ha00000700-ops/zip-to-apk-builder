package com.example.ui.screens

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CastConnected
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ReceiverStatus
import com.example.receiver.TvReceiverEngine
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.RedAlert
import com.example.util.NetworkUtils

@Composable
fun ReceiverScreen(
    defaultSenderUrl: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val receiverEngine = remember { TvReceiverEngine() }

    val status by receiverEngine.status.collectAsState()
    val frameBitmap by receiverEngine.latestFrame.collectAsState()
    val receiverFps by receiverEngine.receiverFps.collectAsState()
    val errorMessage by receiverEngine.errorMessage.collectAsState()

    var targetUrl by remember {
        val initial = if (defaultSenderUrl.isNotEmpty()) defaultSenderUrl else {
            val ip = NetworkUtils.getLocalIpAddress(context)
            "http://$ip:8080"
        }
        mutableStateOf(initial)
    }

    var isFullscreen by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            receiverEngine.disconnect()
        }
    }

    if (isFullscreen && status == ReceiverStatus.STREAMING) {
        // Fullscreen TV Display Mode
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .testTag("tv_fullscreen_view")
        ) {
            frameBitmap?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "بث شاشة الهاتف",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }

            // TV HUD
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .background(Color(0xCC090E17), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(GreenSuccess))
                Text("بث مباشر | $receiverFps FPS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)

                IconButton(
                    onClick = { isFullscreen = false },
                    modifier = Modifier.size(32.dp).testTag("exit_fullscreen_button")
                ) {
                    Icon(Icons.Default.FullscreenExit, contentDescription = "خروج من ملء الشاشة", tint = Color.White)
                }
            }
        }
        return
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // TV Mode Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("receiver_header_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Tv, contentDescription = null, tint = CyanPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "وضع استقبال التلفزيون (Android TV Receiver)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "استقبال شاشة الهاتف وعرضها على التلفزيون بدقة عالية وتأخير منخفض",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Connection Controller
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "عنوان هاتف البث (Sender URL):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                var pinCode by remember { mutableStateOf("") }

                OutlinedTextField(
                    value = targetUrl,
                    onValueChange = { targetUrl = it },
                    placeholder = { Text("http://192.168.1.x:8080") },
                    label = { Text("عنوان البث (URL)") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("target_url_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = pinCode,
                    onValueChange = { if (it.length <= 4) pinCode = it },
                    placeholder = { Text("4 أرقام (إذا كان مفعل)") },
                    label = { Text("رمز الأمان (PIN) - اختياري") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("target_pin_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (status != ReceiverStatus.STREAMING) {
                        Button(
                            onClick = { receiverEngine.connect(targetUrl, pinCode) },
                            enabled = targetUrl.isNotBlank() && status != ReceiverStatus.CONNECTING,
                            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color(0xFF001E2B)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("connect_receiver_button")
                        ) {
                            if (status == ReceiverStatus.CONNECTING) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF001E2B), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("جاري الاتصال...")
                            } else {
                                Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("بدء استقبال البث", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = { receiverEngine.disconnect() },
                            colors = ButtonDefaults.buttonColors(containerColor = RedAlert, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("disconnect_receiver_button")
                        ) {
                            Icon(Icons.Default.LinkOff, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("قطع الاتصال", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { isFullscreen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("fullscreen_button")
                        ) {
                            Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("شاشة كاملة للـ TV", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                errorMessage?.let { error ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = error, color = RedAlert, fontSize = 12.sp)
                }
            }
        }

        // Live Receiver Video Surface Preview
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("receiver_display_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            border = CardDefaults.outlinedCardBorder().copy(
                brush = androidx.compose.ui.graphics.SolidColor(
                    if (status == ReceiverStatus.STREAMING) CyanPrimary.copy(alpha = 0.5f) else Color.DarkGray
                )
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (status == ReceiverStatus.STREAMING) "معاينة شاشة البث المستلمة" else "شاشة الاستقبال في وضع الانتظار",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    if (status == ReceiverStatus.STREAMING) {
                        Text(
                            text = "$receiverFps FPS",
                            color = GreenSuccess,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color(0xFF070B12), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (frameBitmap != null && status == ReceiverStatus.STREAMING) {
                        Image(
                            bitmap = frameBitmap!!.asImageBitmap(),
                            contentDescription = "Received Frame",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tv,
                                contentDescription = null,
                                tint = Color.Gray,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "لا يوجد بث نشط حالياً",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "اضغط 'بدء استقبال البث' بعد تشغيل الإرسال من الهاتف",
                                color = Color.DarkGray,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
