package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.data.model.WeatherConditionType
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun DynamicWeatherBackground(
    condition: WeatherConditionType,
    particlesEnabled: Boolean = true,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val topColor by animateColorAsState(
        targetValue = condition.gradientColors.firstOrNull() ?: Color(0xFFF43F5E),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "bgTop"
    )
    val bottomColor by animateColorAsState(
        targetValue = condition.gradientColors.lastOrNull() ?: Color(0xFF1E1118),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "bgBottom"
    )

    // Master continuous animation timer (0.0 to 1.0)
    val infiniteTransition = rememberInfiniteTransition(label = "weatherAnimMaster")
    val timeLoop by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "timeLoop"
    )

    // Sun rays rotation
    val sunRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 24000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sunRotation"
    )

    // Sun pulse
    val sunPulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sunPulse"
    )

    // Lightning flash timer
    val lightningFlash by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "lightningFlash"
    )

    // Pre-calculated particle seed arrays
    val rainDrops = remember {
        List(45) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 12f + 14f)
        }
    }
    val snowFlakes = remember {
        List(35) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 6f + 3f)
        }
    }
    val stars = remember {
        List(45) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 2.8f + 1f)
        }
    }
    val romanticParticles = remember {
        List(22) {
            Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat() * 7f + 3f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(topColor.copy(alpha = 0.52f), bottomColor.copy(alpha = 0.88f))
                )
            )
    ) {
        if (particlesEnabled) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                when (condition) {
                    WeatherConditionType.CLOUDY, WeatherConditionType.PARTLY_CLOUDY -> {
                        drawFloatingClouds(canvasWidth, canvasHeight, timeLoop, condition == WeatherConditionType.CLOUDY)
                        drawRomanticFloatingMotes(canvasWidth, canvasHeight, timeLoop, romanticParticles)
                    }

                    WeatherConditionType.RAINY -> {
                        drawFloatingClouds(canvasWidth, canvasHeight, timeLoop, isDense = true)
                        drawRainfall(canvasWidth, canvasHeight, timeLoop, rainDrops, isStorm = false)
                    }

                    WeatherConditionType.THUNDERSTORM -> {
                        // Lightning flicker flash
                        if (lightningFlash in 0.94f..0.98f) {
                            drawRect(
                                color = Color.White.copy(alpha = 0.28f),
                                size = size
                            )
                        }
                        drawFloatingClouds(canvasWidth, canvasHeight, timeLoop, isDense = true)
                        drawRainfall(canvasWidth, canvasHeight, timeLoop, rainDrops, isStorm = true)
                    }

                    WeatherConditionType.SNOWY -> {
                        drawSnowfall(canvasWidth, canvasHeight, timeLoop, snowFlakes)
                        drawRomanticFloatingMotes(canvasWidth, canvasHeight, timeLoop, romanticParticles)
                    }

                    WeatherConditionType.CLEAR_DAY -> {
                        drawRadiantSun(canvasWidth, canvasHeight, sunRotation, sunPulse)
                        drawRomanticFloatingMotes(canvasWidth, canvasHeight, timeLoop, romanticParticles)
                    }

                    WeatherConditionType.CLEAR_NIGHT -> {
                        drawStarryNight(canvasWidth, canvasHeight, timeLoop, stars)
                        drawCrescentMoon(canvasWidth, canvasHeight)
                    }

                    WeatherConditionType.FOGGY -> {
                        drawMistyFog(canvasWidth, canvasHeight, timeLoop)
                        drawRomanticFloatingMotes(canvasWidth, canvasHeight, timeLoop, romanticParticles)
                    }
                }
            }
        }

        content()
    }
}

// -------------------------------------------------------------
// Canvas Weather Drawers
// -------------------------------------------------------------

/**
 * Draws soft, drifting multi-circle clouds with parallax movement
 */
private fun DrawScope.drawFloatingClouds(
    width: Float,
    height: Float,
    time: Float,
    isDense: Boolean
) {
    val cloudCount = if (isDense) 4 else 3
    val cloudYPositions = listOf(0.10f, 0.25f, 0.45f, 0.65f)
    val speeds = listOf(0.08f, 0.05f, 0.12f, 0.07f)
    val baseRadii = listOf(45f, 60f, 50f, 70f)

    for (i in 0 until cloudCount) {
        val y = cloudYPositions[i] * height + sin((time * 6.28f + i).toDouble()).toFloat() * 12f
        val progress = (time * speeds[i] * 4f + i * 0.35f) % 1.3f - 0.2f
        val x = progress * width

        val cloudAlpha = if (isDense) 0.32f else 0.22f
        val cloudColor = Color.White.copy(alpha = cloudAlpha)
        val r = baseRadii[i]

        // Puffy cloud composed of 4 overlapping circles
        drawCircle(color = cloudColor, radius = r, center = Offset(x, y))
        drawCircle(color = cloudColor, radius = r * 0.85f, center = Offset(x - r * 0.7f, y + r * 0.15f))
        drawCircle(color = cloudColor, radius = r * 0.90f, center = Offset(x + r * 0.75f, y + r * 0.10f))
        drawCircle(color = cloudColor, radius = r * 0.75f, center = Offset(x + r * 1.3f, y + r * 0.25f))
        drawCircle(color = cloudColor, radius = r * 0.70f, center = Offset(x - r * 1.2f, y + r * 0.20f))
    }
}

/**
 * Draws diagonal falling rain with splash ripples
 */
private fun DrawScope.drawRainfall(
    width: Float,
    height: Float,
    time: Float,
    drops: List<Triple<Float, Float, Float>>,
    isStorm: Boolean
) {
    val speedMultiplier = if (isStorm) 2.2f else 1.4f
    val rainColor = if (isStorm) Color(0xFFC7D2FE).copy(alpha = 0.50f) else Color.White.copy(alpha = 0.40f)

    drops.forEachIndexed { index, (xRatio, yRatio, length) ->
        val y = ((yRatio + time * speedMultiplier * (1f + (index % 5) * 0.2f)) % 1f) * height
        val x = (xRatio * width + sin((time * 3f + index).toDouble()).toFloat() * 10f)

        // Rain streak
        drawLine(
            color = rainColor,
            start = Offset(x, y),
            end = Offset(x - 5f, y + length),
            strokeWidth = if (isStorm) 2.8f else 1.8f
        )

        // Splash ripple near bottom
        if (y > height * 0.88f) {
            val rippleProgress = (y - height * 0.88f) / (height * 0.12f)
            drawOval(
                color = rainColor.copy(alpha = (1f - rippleProgress) * 0.35f),
                topLeft = Offset(x - 8f * rippleProgress, y - 2f),
                size = Size(16f * rippleProgress, 4f * rippleProgress),
                style = Stroke(width = 1.2f)
            )
        }
    }
}

/**
 * Draws fluttering snowflakes swaying side-to-side
 */
private fun DrawScope.drawSnowfall(
    width: Float,
    height: Float,
    time: Float,
    flakes: List<Triple<Float, Float, Float>>
) {
    flakes.forEachIndexed { index, (xRatio, yRatio, radius) ->
        val y = ((yRatio + time * 0.35f * (0.8f + (index % 4) * 0.15f)) % 1f) * height
        val sway = sin((time * 5f + index * 1.5f).toDouble()).toFloat() * 22f
        val x = xRatio * width + sway

        // Snowflake dot with soft glow
        drawCircle(
            color = Color.White.copy(alpha = 0.75f),
            radius = radius,
            center = Offset(x, y)
        )
        drawCircle(
            color = Color(0xFFE0E7FF).copy(alpha = 0.30f),
            radius = radius * 1.6f,
            center = Offset(x, y)
        )
    }
}

/**
 * Draws radiant golden sun with pulsing glow and rotating sunrays
 */
private fun DrawScope.drawRadiantSun(
    width: Float,
    height: Float,
    rotationDeg: Float,
    pulseScale: Float
) {
    val sunCenter = Offset(width * 0.84f, height * 0.13f)
    val baseRadius = 42f * pulseScale

    // Corona Outer Halo
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFDE68A).copy(alpha = 0.55f), Color.Transparent),
            center = sunCenter,
            radius = baseRadius * 3.2f
        ),
        radius = baseRadius * 3.2f,
        center = sunCenter
    )

    // Corona Middle
    drawCircle(
        color = Color(0xFFFBBF24).copy(alpha = 0.45f),
        radius = baseRadius * 1.4f,
        center = sunCenter
    )

    // Sun Core
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFEF3C7), Color(0xFFF59E0B)),
            center = sunCenter,
            radius = baseRadius
        ),
        radius = baseRadius,
        center = sunCenter
    )

    // Rotating Sunrays
    val rayCount = 12
    val rayInner = baseRadius * 1.25f
    val rayOuter = baseRadius * 1.75f

    for (i in 0 until rayCount) {
        val angleRad = (rotationDeg + i * (360f / rayCount)) * (PI / 180.0)
        val startX = (sunCenter.x + cos(angleRad) * rayInner).toFloat()
        val startY = (sunCenter.y + sin(angleRad) * rayInner).toFloat()
        val endX = (sunCenter.x + cos(angleRad) * rayOuter).toFloat()
        val endY = (sunCenter.y + sin(angleRad) * rayOuter).toFloat()

        drawLine(
            color = Color(0xFFFDE68A).copy(alpha = 0.60f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 3f
        )
    }
}

/**
 * Draws twinkling stars and shooting star
 */
private fun DrawScope.drawStarryNight(
    width: Float,
    height: Float,
    time: Float,
    stars: List<Triple<Float, Float, Float>>
) {
    stars.forEachIndexed { index, (xRatio, yRatio, size) ->
        val x = xRatio * width
        val y = yRatio * (height * 0.75f) // Upper night sky

        // Twinkle factor
        val twinkle = (sin((time * 12f + index * 2.3f).toDouble()).toFloat() + 1f) / 2f
        val starAlpha = 0.25f + twinkle * 0.70f

        drawCircle(
            color = Color(0xFFFEF08A).copy(alpha = starAlpha),
            radius = size * (0.8f + twinkle * 0.4f),
            center = Offset(x, y)
        )
    }

    // Romantic Shooting Star (شهاب الحب)
    val shootCycle = (time * 2.5f) % 1f
    if (shootCycle in 0.10f..0.25f) {
        val progress = (shootCycle - 0.10f) / 0.15f
        val startX = width * 0.85f - progress * width * 0.6f
        val startY = height * 0.08f + progress * height * 0.25f
        drawLine(
            color = Color.White.copy(alpha = (1f - progress) * 0.8f),
            start = Offset(startX, startY),
            end = Offset(startX + 45f, startY - 22f),
            strokeWidth = 2.5f
        )
    }
}

/**
 * Draws gentle crescent moon
 */
private fun DrawScope.drawCrescentMoon(width: Float, height: Float) {
    val moonCenter = Offset(width * 0.82f, height * 0.12f)
    val radius = 30f

    // Moon Glow
    drawCircle(
        color = Color(0xFFFEF9C3).copy(alpha = 0.25f),
        radius = radius * 2f,
        center = moonCenter
    )

    // Base Moon circle
    drawCircle(
        color = Color(0xFFFEF08A),
        radius = radius,
        center = moonCenter
    )

    // Shadow cutout to form crescent
    drawCircle(
        color = Color(0xFF1E1035),
        radius = radius * 0.88f,
        center = Offset(moonCenter.x - radius * 0.45f, moonCenter.y - radius * 0.25f)
    )
}

/**
 * Draws misty horizontal drifting fog
 */
private fun DrawScope.drawMistyFog(width: Float, height: Float, time: Float) {
    val fogBands = listOf(0.18f, 0.38f, 0.58f, 0.78f)
    fogBands.forEachIndexed { index, yRatio ->
        val drift = sin((time * 3f + index).toDouble()).toFloat() * 35f
        val y = yRatio * height

        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.24f), Color.Transparent),
                center = Offset(width * 0.5f + drift, y),
                radius = width * 0.65f
            ),
            topLeft = Offset(0f, y - 45f),
            size = Size(width, 90f)
        )
    }
}

/**
 * Romantic warm floating dust / hearts motes
 */
private fun DrawScope.drawRomanticFloatingMotes(
    width: Float,
    height: Float,
    time: Float,
    motes: List<Triple<Float, Float, Float>>
) {
    motes.forEachIndexed { index, (xRatio, yRatio, size) ->
        val y = ((yRatio - time * 0.25f * (0.6f + (index % 3) * 0.2f)) % 1f + 1f) % 1f * height
        val sway = sin((time * 4f + index).toDouble()).toFloat() * 14f
        val x = xRatio * width + sway

        val alpha = (sin((time * 5f + index * 2f).toDouble()).toFloat() + 1f) / 2f
        drawCircle(
            color = Color(0xFFFFB4C8).copy(alpha = 0.20f + alpha * 0.30f),
            radius = size,
            center = Offset(x, y)
        )
    }
}
