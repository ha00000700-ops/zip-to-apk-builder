package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.data.model.WeatherConditionType
import kotlin.random.Random

@Composable
fun DynamicWeatherBackground(
    condition: WeatherConditionType,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val topColor by animateColorAsState(
        targetValue = condition.gradientColors.firstOrNull() ?: Color(0xFFF43F5E),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "bgTop"
    )
    val bottomColor by animateColorAsState(
        targetValue = condition.gradientColors.lastOrNull() ?: Color(0xFF1E1118),
        animationSpec = tween(1200, easing = FastOutSlowInEasing),
        label = "bgBottom"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "weatherAnim")
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "floatAnim"
    )

    // Pre-calculated particles for romance & weather
    val particleCount = 20
    val particles = remember {
        List(particleCount) {
            Triple(
                Random.nextFloat(), // x ratio
                Random.nextFloat(), // y initial ratio
                Random.nextFloat() * 8f + 4f // size
            )
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(topColor.copy(alpha = 0.45f), bottomColor.copy(alpha = 0.85f))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            particles.forEachIndexed { index, (xRatio, yRatio, pSize) ->
                val currentY = ((yRatio + floatOffset * (0.6f + (index % 3) * 0.2f)) % 1f) * height
                val currentX = (xRatio * width + kotlin.math.sin((floatOffset * 6.28f + index).toDouble()).toFloat() * 18f)

                when (condition) {
                    WeatherConditionType.RAINY, WeatherConditionType.THUNDERSTORM -> {
                        // Rain droplet streaks
                        drawLine(
                            color = Color.White.copy(alpha = 0.35f),
                            start = Offset(currentX, currentY),
                            end = Offset(currentX - 4f, currentY + 16f),
                            strokeWidth = 2.5f
                        )
                    }
                    WeatherConditionType.SNOWY -> {
                        // Soft snow flakes
                        drawCircle(
                            color = Color.White.copy(alpha = 0.6f),
                            radius = pSize * 0.7f,
                            center = Offset(currentX, currentY)
                        )
                    }
                    WeatherConditionType.CLEAR_NIGHT -> {
                        // Starry sparkles
                        val alpha = (kotlin.math.sin((floatOffset * 6.28f + index * 2).toDouble()).toFloat() + 1f) / 2f
                        drawCircle(
                            color = Color(0xFFFDE68A).copy(alpha = 0.3f + alpha * 0.5f),
                            radius = pSize * 0.5f,
                            center = Offset(currentX, currentY)
                        )
                    }
                    else -> {
                        // Floating romantic heart sparkles / warm dust
                        val alpha = (kotlin.math.sin((floatOffset * 3.14f + index).toDouble()).toFloat() + 1f) / 2f
                        drawCircle(
                            color = Color(0xFFFFB6C1).copy(alpha = 0.25f + alpha * 0.35f),
                            radius = pSize * 0.8f,
                            center = Offset(currentX, currentY)
                        )
                    }
                }
            }
        }

        content()
    }
}
