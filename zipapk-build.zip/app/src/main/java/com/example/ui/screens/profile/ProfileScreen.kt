package com.example.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UserRole
import com.example.data.model.VerificationRequest
import com.example.data.model.VerificationStatus
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiOutlinedButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEditProviderProfile: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onLogoutFinished: () -> Unit,
    onNavigateToAdmin: () -> Unit = {},
    onNavigateToProSubscription: () -> Unit = {}
) {
    val currentUser by authViewModel.currentUserProfile.collectAsState()
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    val verificationRequestState by authViewModel.myVerificationRequestState.collectAsState()
    val submitState by authViewModel.submitVerificationRequestState.collectAsState()

    val isProvider = currentUser?.role == UserRole.SERVICE_PROVIDER
    val isAdmin = currentUser?.role == UserRole.ADMIN
    var showRequestDialog by remember { mutableStateOf(false) }
    var verificationNotes by remember { mutableStateOf("") }

    LaunchedEffect(currentUser?.uid) {
        currentUser?.uid?.let { uid ->
            if (isProvider) {
                authViewModel.loadProviderProfile(uid)
                authViewModel.loadMyVerificationRequest(uid)
            }
        }
    }

    val myRequest = (verificationRequestState as? AuthResult.Success)?.data
    val isVerified = providerProfile?.isVerified == true

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الملف الشخصي",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(Color.White, CircleShape)
                        .padding(4.dp)
                        .border(1.5.dp, BluePrimary.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(BlueContainer.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val imgUrl = if (isProvider) providerProfile?.effectiveAvatarUrl() else currentUser?.resolvedAvatarUrl()
                        if (!imgUrl.isNullOrBlank()) {
                            coil.compose.AsyncImage(
                                model = imgUrl,
                                contentDescription = null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = if (isProvider) Icons.Default.Handyman else Icons.Default.Person,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(54.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = currentUser?.fullName ?: "مستخدم خدمتي",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    if (isProvider && isVerified) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "موثق",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isProvider) {
                        if (isVerified) EmeraldPrimary.copy(alpha = 0.12f) else AmberPrimary.copy(alpha = 0.1f)
                    } else BluePrimary.copy(alpha = 0.1f),
                ) {
                    Text(
                        text = if (isProvider) {
                            if (isVerified) "حرفي موثق ومعتمد ✓" else "حرفي مهني 🛠️"
                        } else "حساب زبون 👤",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isProvider) {
                            if (isVerified) EmeraldPrimary else AmberPrimary
                        } else BluePrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // VERIFICATION STATUS CARD FOR SERVICE PROVIDERS
            if (isProvider) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    border = BorderStroke(
                        1.dp,
                        when {
                            isVerified -> EmeraldPrimary.copy(alpha = 0.3f)
                            myRequest?.status == VerificationStatus.PENDING -> AmberPrimary.copy(alpha = 0.4f)
                            myRequest?.status == VerificationStatus.REJECTED -> Color(0xFFEF5350).copy(alpha = 0.4f)
                            else -> BluePrimary.copy(alpha = 0.2f)
                        }
                    )
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                modifier = Modifier.size(40.dp),
                                shape = RoundedCornerShape(12.dp),
                                color = when {
                                    isVerified -> EmeraldPrimary.copy(alpha = 0.12f)
                                    myRequest?.status == VerificationStatus.PENDING -> AmberPrimary.copy(alpha = 0.12f)
                                    myRequest?.status == VerificationStatus.REJECTED -> Color(0xFFFFEBEE)
                                    else -> BluePrimary.copy(alpha = 0.1f)
                                }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = when {
                                            isVerified -> Icons.Default.Verified
                                            myRequest?.status == VerificationStatus.PENDING -> Icons.Default.HourglassTop
                                            myRequest?.status == VerificationStatus.REJECTED -> Icons.Default.Cancel
                                            else -> Icons.Default.Shield
                                        },
                                        contentDescription = null,
                                        tint = when {
                                            isVerified -> EmeraldPrimary
                                            myRequest?.status == VerificationStatus.PENDING -> AmberPrimary
                                            myRequest?.status == VerificationStatus.REJECTED -> Color(0xFFD32F2F)
                                            else -> BluePrimary
                                        },
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "حالة توثيق الحساب",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueDark
                                )
                                Text(
                                    text = when {
                                        isVerified -> "حسابك موثق ومعتمد من إدارة خدمتي ✓"
                                        myRequest?.status == VerificationStatus.PENDING -> "طلب التوثيق قيد المراجعة حالياً من قبل الإدارة"
                                        myRequest?.status == VerificationStatus.REJECTED -> "تم رفض طلب التوثيق السابق"
                                        else -> "احصل على شارة التوثيق لزيادة ثقة الزبائن والطلبات"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight
                                )
                            }
                        }

                        // Detailed info based on state
                        if (isVerified) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = EmeraldPrimary.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "حسابك يتمتع بكامل ميزات الحرفي المعتمد وتظهر شارة التوثيق الخضراء للزبائن في نتائج البحث.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = EmeraldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        } else if (myRequest?.status == VerificationStatus.PENDING) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = AmberPrimary.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "⏳ تم استلام طلبك وهو قيد التدقيق الإداري. سيصلك إشعار فوري عند اكتمال المراجعة.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFB78103),
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (myRequest.notes.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "ملاحظاتك المرسلة: ${myRequest.notes}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondaryLight
                                        )
                                    }
                                }
                            }
                        } else if (myRequest?.status == VerificationStatus.REJECTED) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFFFEBEE),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "سبب الرفض: ${if (myRequest.rejectionReason.isNotBlank()) myRequest.rejectionReason else "يرجى استكمال البيانات وإرفاق معلومات دقيقة."}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFC62828),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "يمكنك تصحيح بياناتك وإعادة تقديم طلب التوثيق الآن.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondaryLight
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    verificationNotes = ""
                                    showRequestDialog = true
                                },
                                modifier = Modifier.fillMaxWidth().testTag("reapply_verification_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("إعادة تقديم طلب التوثيق ↺", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Unverified, no active request
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    verificationNotes = ""
                                    showRequestDialog = true
                                },
                                modifier = Modifier.fillMaxWidth().testTag("request_verification_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Icon(Icons.Default.Shield, null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("طلب توثيق الحساب المهني 🛡️", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Information Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "البيانات الأساسية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ProfileItem(icon = Icons.Default.Email, label = "البريد الإلكتروني", value = currentUser?.email ?: "غير محدد")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                    ProfileItem(icon = Icons.Default.Phone, label = "رقم الهاتف", value = currentUser?.phone ?: "غير محدد")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                    ProfileItem(icon = Icons.Default.LocationOn, label = "الموقع", value = "${currentUser?.communeName}، ${currentUser?.wilayaName}")

                    if (isProvider && providerProfile != null) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                        ProfileItem(icon = Icons.Default.Handyman, label = "المهنة", value = providerProfile?.professionNameAr ?: "")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Options Section
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    if (isAdmin) {
                        ProfileOptionItem(
                            icon = Icons.Default.AdminPanelSettings,
                            title = "لوحة تحكم المدير 👑",
                            color = AmberPrimary,
                            onClick = onNavigateToAdmin
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    }

                    if (isProvider) {
                        ProfileOptionItem(
                            icon = Icons.Default.Verified,
                            title = "تعديل الملف المهني",
                            color = AmberPrimary,
                            onClick = onNavigateToEditProviderProfile
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    }
                    
                    ProfileOptionItem(
                        icon = Icons.Default.Stars,
                        title = "عضوية خدمتي Pro ⭐",
                        color = AmberPrimary,
                        onClick = onNavigateToProSubscription
                    )
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))

                    ProfileOptionItem(
                        icon = Icons.Default.Settings,
                        title = "الإعدادات",
                        color = BluePrimary,
                        onClick = onNavigateToSettings
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Logout
            Surface(
                modifier = Modifier.fillMaxWidth().clickable {
                    authViewModel.logout()
                    onLogoutFinished()
                },
                shape = RoundedCornerShape(20.dp),
                color = ErrorRedContainer.copy(alpha = 0.2f),
                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.ExitToApp, null, tint = ErrorRed, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = "تسجيل الخروج", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ErrorRed)
                }
            }
        }
    }

    // Submit Verification Request Dialog
    if (showRequestDialog) {
        val isSubmitting = submitState is AuthResult.Loading
        AlertDialog(
            onDismissRequest = { if (!isSubmitting) showRequestDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint = BluePrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "طلب توثيق الحساب المهني",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "سيتم إرسال بيانات ملفك المهني الحالي إلى إدارة خدمتي للمراجعة:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = BackgroundLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("👤 الاسم: ${providerProfile?.fullName ?: currentUser?.fullName ?: ""}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Text("🛠️ المهنة: ${providerProfile?.professionNameAr ?: ""}", style = MaterialTheme.typography.labelSmall)
                            Text("📍 الولاية: ${providerProfile?.wilayaName ?: ""}", style = MaterialTheme.typography.labelSmall)
                            Text("📞 الهاتف: ${providerProfile?.phone ?: currentUser?.phone ?: ""}", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "ملاحظات إضافية أو روابط لإثبات الخبرة (اختياري):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = verificationNotes,
                        onValueChange = { verificationNotes = it },
                        modifier = Modifier.fillMaxWidth().testTag("verification_notes_input"),
                        placeholder = { Text("مثال: خبرة 5 سنوات، شهادة تأهيل مهني، محل معتمد...") },
                        maxLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )

                    if (submitState is AuthResult.Error) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = (submitState as AuthResult.Error).messageAr,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uid = currentUser?.uid ?: return@Button
                        authViewModel.submitVerificationRequest(uid, verificationNotes) { success ->
                            if (success) {
                                showRequestDialog = false
                            }
                        }
                    },
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("submit_verification_request_btn")
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("إرسال الطلب للمراجعة")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showRequestDialog = false },
                    enabled = !isSubmitting
                ) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun ProfileOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(40.dp),
            shape = RoundedCornerShape(10.dp),
            color = color.copy(alpha = 0.1f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BlueDark)
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = OutlineLight, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun ProfileItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            modifier = Modifier.size(44.dp),
            shape = RoundedCornerShape(12.dp),
            color = BluePrimary.copy(alpha = 0.08f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = BluePrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondaryLight,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )
        }
    }
}
