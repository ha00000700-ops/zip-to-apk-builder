package com.example.ui.screens.profile

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.AvailabilityBadge
import com.example.ui.components.RatingStars
import com.example.ui.components.VerifiedBadge
import com.example.ui.screens.dialogs.CraftsmanVerificationDialog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    currentUser: UserEntity?,
    currentPro: ProfessionalEntity?,
    notifications: List<NotificationEntity> = emptyList(),
    isDarkMode: Boolean,
    onToggleDarkMode: (Boolean) -> Unit,
    onToggleProAvailability: (Boolean) -> Unit,
    onSubmitVerification: (idCard: String, qualification: String, notes: String) -> Unit = { _, _, _ -> },
    onMarkNotificationRead: (Long) -> Unit = {},
    onNavigateToAdmin: () -> Unit,
    onSwitchAccount: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showScalabilityInfo by remember { mutableStateOf<String?>(null) }
    var showVerificationDialog by remember { mutableStateOf(false) }

    val isPro = currentUser?.role == UserRole.PROFESSIONAL || currentPro != null
    val isAdmin = currentUser?.role == UserRole.ADMIN

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("profile_screen"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. User Profile Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.fullName?.split(" ")?.mapNotNull { it.firstOrNull()?.toString() }?.take(2)?.joinToString("") ?: "خ",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontSize = 22.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = currentUser?.fullName ?: "",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (currentPro?.isVerified == true) {
                            VerifiedBadge()
                        }
                    }

                    Text(
                        text = when (currentUser?.role) {
                            UserRole.ADMIN -> "مدير المنصة الكامل (Admin) 🛡️"
                            UserRole.PROFESSIONAL -> "حرفي مهني (${currentPro?.professionNameAr ?: "خدمات"}) 🛠️"
                            else -> "حساب زبون (Customer) 👤"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (currentUser != null) "الهاتف: ${currentUser.phone} • ${currentUser.wilayaNameAr}" else "",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (isPro && currentPro != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                        Spacer(modifier = Modifier.height(14.dp))

                        // Professional Availability Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("حالة توفرك للعمل:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    text = if (currentPro.isAvailable) "أنت ظاهر كـ متاح الآن في البحث" else "أنت في فترة استراحة ولا تستقبل طلبات جديدة",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = currentPro.isAvailable,
                                onCheckedChange = { onToggleProAvailability(it) }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Professional Stats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${currentPro.completedJobsCount}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = DzGreenPrimary)
                                Text("خدمة منجزة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                RatingStars(rating = currentPro.ratingAverage)
                                Text("التقييم العام (${currentPro.ratingCount})", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // 2. Trust & Verification Badge Module (For Craftsmen)
        if (isPro && currentPro != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (currentPro.isVerified) DzGreenLight else Color(0xFFF8FAFC)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = if (currentPro.isVerified) Icons.Default.Verified else Icons.Default.GppMaybe,
                                contentDescription = null,
                                tint = if (currentPro.isVerified) DzGreenPrimary else Color(0xFFD97706),
                                modifier = Modifier.size(24.dp)
                            )
                            Text(
                                text = if (currentPro.isVerified) "حسابك موثوق ومعتمد رسمياً ✓" else "شارة الحرفي الموثوق 🛡️",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = if (currentPro.isVerified) {
                                "تم التحقق من هويتك ومؤهلاتك المهنية من قبل إدارة خدملي. تظهر شارة التوثيق بجانب اسمك في نتائج البحث وتعزز ثقة الزبائن."
                            } else {
                                "توثيق حسابك بالبطاقة البيومترية والسجل الحرفي يمنحك أولوية الظهور في نتائج البحث ويزيد طلبات العمل بنسبة 300%."
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (!currentPro.isVerified) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { showVerificationDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تقديم طلب التوثيق الآن", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 3. Notifications & Security Alerts Module
        if (notifications.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = DzGreenPrimary)
                                Text("الإشعارات وتنبيهات الأمان (${notifications.size})", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        notifications.take(4).forEach { notif ->
                            Surface(
                                onClick = { onMarkNotificationRead(notif.id) },
                                shape = RoundedCornerShape(8.dp),
                                color = if (notif.isRead) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f) else DzGreenLight.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = when (notif.type) {
                                            NotificationType.ADMIN_ALERT -> Icons.Default.Security
                                            NotificationType.VERIFICATION_UPDATE -> Icons.Default.Verified
                                            NotificationType.REVIEW_RECEIVED -> Icons.Default.Star
                                            else -> Icons.Default.Notifications
                                        },
                                        contentDescription = null,
                                        tint = if (notif.type == NotificationType.ADMIN_ALERT) MaterialTheme.colorScheme.error else DzGreenPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(notif.body, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Admin Panel Quick Access (if Admin)
        if (isAdmin) {
            item {
                Card(
                    onClick = onNavigateToAdmin,
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth().testTag("admin_panel_quick_btn")
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(28.dp))
                            Column {
                                Text("لوحة تحكم إدارة المنصة والأمان", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                                Text("مراجعة التوثيق، البلاغات، التقييمات، وإدارة الحرفيين", fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f))
                            }
                        }
                        Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        // 5. App Settings (Theme, Language, Switch Account)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("إعدادات التطبيق والتفضيلات:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Dark mode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(if (isDarkMode) Icons.Filled.DarkMode else Icons.Outlined.LightMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("الوضع الداكن (Dark Mode)", fontSize = 13.sp)
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = onToggleDarkMode
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(8.dp))


                }
            }
        }

        // 6. Algerian Digital Scalability Features Roadmap
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.IntegrationInstructions, contentDescription = null, tint = DzGreenPrimary)
                        Text("الخدمات والميزات المستقبلية المجهزة:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text("تم تصميم معمارية التطبيق وقواعد البيانات لدعم التوسعات التالية بسلاسة:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(modifier = Modifier.height(10.dp))

                    val futureFeatures = listOf(
                        Pair("💳 الدفع الإلكتروني (الذهبية / CIB)", "جاهز للربط مع Satim و BaridiMob بمجرد توفر بوابة الدفع المعتمدة."),
                        Pair("⭐ اشتراكات Pro الحرفي المميز", "إمكانية تثبيت الحرفي في أعلى نتائج البحث وظهوره بشارة ذهبية مميزة."),
                        Pair("🤖 تشخيص المشاكل بالذكاء الاصطناعي", "تم تفعيل محرك التشخيص الأولي مع معمارية قابلة للتوسع لنموذج Gemini Multimodal."),
                        Pair("🗺️ تحديد المسافة والموقع الجغرافي الحي", "حساب المسافة بين الزبون والحرفي بالكيلومتر عبر GPS.")
                    )

                    futureFeatures.forEach { feat ->
                        Surface(
                            onClick = { showScalabilityInfo = "${feat.first}\n\n${feat.second}" },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(feat.first, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(feat.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // 7. App Info & Logout
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "تطبيق خدملي DZ 🇩🇿 - الإصدار 1.0.0",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "شعارنا: لقى لي يخدمها في 58 ولاية",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = onLogout,
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تسجيل الخروج من الحساب", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showVerificationDialog) {
        CraftsmanVerificationDialog(
            onDismiss = { showVerificationDialog = false },
            onSubmit = { idCard, qual, notes ->
                onSubmitVerification(idCard, qual, notes)
                showVerificationDialog = false
                Toast.makeText(context, "تم إرسال طلب التوثيق للمدير للمراجعة ⏳", Toast.LENGTH_LONG).show()
            }
        )
    }

    showScalabilityInfo?.let { info ->
        AlertDialog(
            onDismissRequest = { showScalabilityInfo = null },
            title = { Text("معلومات الميزة المستقبلية", fontWeight = FontWeight.Bold) },
            text = { Text(info, fontSize = 13.sp) },
            confirmButton = {
                TextButton(onClick = { showScalabilityInfo = null }) {
                    Text("حسناً")
                }
            }
        )
    }
}
