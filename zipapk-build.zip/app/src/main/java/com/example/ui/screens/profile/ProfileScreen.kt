package com.example.ui.screens.profile

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UserRole
import com.example.ui.components.KhedmatiOutlinedButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEditProviderProfile: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onLogoutFinished: () -> Unit
) {
    val currentUser by authViewModel.currentUserProfile.collectAsState()
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()

    val isProvider = currentUser?.role == UserRole.SERVICE_PROVIDER

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "الملف الشخصي",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(Color.White, CircleShape)
                        .padding(4.dp)
                        .border(1.5.dp, BluePrimary.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(BlueContainer.copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val imgUrl = if (isProvider) providerProfile?.effectiveAvatarUrl() else currentUser?.resolvedAvatarUrl()
                        if (!imgUrl.isNullOrBlank()) {
                            var imageState by remember { mutableStateOf<coil.compose.AsyncImagePainter.State>(coil.compose.AsyncImagePainter.State.Empty) }
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .border(3.dp, when(imageState) {
                                        is coil.compose.AsyncImagePainter.State.Success -> Color.Green
                                        is coil.compose.AsyncImagePainter.State.Error -> Color.Red
                                        else -> Color.Yellow
                                    }, CircleShape)
                            ) {
                                coil.compose.AsyncImage(
                                    model = imgUrl,
                                    contentDescription = null,
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape),
                                    onState = { state ->
                                        imageState = state
                                        android.util.Log.d("KhedmatiTrace", "Coil state: $state for URL: $imgUrl")
                                        val safeHostPath = try {
                                            val parsed = android.net.Uri.parse(imgUrl)
                                            "${parsed.scheme}://${parsed.host}${parsed.path}"
                                        } catch (e: Exception) {
                                            "invalid"
                                        }
                                        when (state) {
                                            is coil.compose.AsyncImagePainter.State.Loading -> {
                                                android.util.Log.d("ProfileImageDiagnostic", "AsyncImage State: LOADING for host/path: $safeHostPath")
                                            }
                                            is coil.compose.AsyncImagePainter.State.Success -> {
                                                android.util.Log.d("ProfileImageDiagnostic", "AsyncImage State: SUCCESS for host/path: $safeHostPath")
                                                val drawable = state.result.drawable
                                                val bmp = (drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
                                                val w = bmp?.width ?: drawable.intrinsicWidth
                                                val h = bmp?.height ?: drawable.intrinsicHeight
                                                android.util.Log.d("ProfileImageDiagnostic", "AsyncImage State: SUCCESS for host/path: $safeHostPath, Bitmap dims: ${w}x$h")
                                            }
                                            is coil.compose.AsyncImagePainter.State.Error -> {
                                                val err = state.result.throwable
                                                android.util.Log.e("ProfileImageDiagnostic", "AsyncImage State: ERROR for host/path: $safeHostPath, ex: ${err.javaClass.simpleName} - ${err.message}", err)
                                            }
                                            is coil.compose.AsyncImagePainter.State.Empty -> {
                                                android.util.Log.d("ProfileImageDiagnostic", "AsyncImage State: EMPTY")
                                            }
                                        }
                                    }
                                )
                                when (val st = imageState) {
                                    is coil.compose.AsyncImagePainter.State.Success -> {
                                        val drawable = st.result.drawable
                                        val bmp = (drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
                                        val w = bmp?.width ?: drawable.intrinsicWidth
                                        val h = bmp?.height ?: drawable.intrinsicHeight
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomCenter)
                                                .background(Color.Black.copy(alpha = 0.7f))
                                                .padding(horizontal = 4.dp, vertical = 2.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${w}x$h", color = Color.Green, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    is coil.compose.AsyncImagePainter.State.Error -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Red.copy(alpha = 0.5f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("ERR", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    is coil.compose.AsyncImagePainter.State.Loading -> {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Yellow.copy(alpha = 0.3f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        } else {
                            Icon(
                                imageVector = if (isProvider) Icons.Default.Handyman else Icons.Default.Person,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(54.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = currentUser?.fullName ?: "مستخدم خدمتي",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = BlueDark
                )

                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isProvider) AmberPrimary.copy(alpha = 0.1f) else BluePrimary.copy(alpha = 0.1f),
                ) {
                    Text(
                        text = if (isProvider) "حرفي معتمد 🛠️" else "حساب زبون 👤",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isProvider) AmberPrimary else BluePrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Information Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "البيانات الأساسية",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    ProfileItem(icon = Icons.Default.Email, label = "البريد الإلكتروني", value = currentUser?.email ?: "غير محدد")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                    ProfileItem(icon = Icons.Default.Phone, label = "رقم الهاتف", value = currentUser?.phone ?: "غير محدد")
                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                    ProfileItem(icon = Icons.Default.LocationOn, label = "الموقع", value = "${currentUser?.communeName}، ${currentUser?.wilayaName}")

                    if (isProvider && providerProfile != null) {
                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = OutlineLight.copy(alpha = 0.3f))
                        ProfileItem(icon = Icons.Default.Handyman, label = "المهنة", value = providerProfile?.professionNameAr ?: "")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Options Section
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    if (isProvider) {
                        ProfileOptionItem(
                            icon = Icons.Default.Verified,
                            title = "تعديل الملف المهني",
                            color = AmberPrimary,
                            onClick = onNavigateToEditProviderProfile
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = OutlineLight.copy(alpha = 0.3f))
                    }
                    
                    ProfileOptionItem(
                        icon = Icons.Default.Settings,
                        title = "الإعدادات",
                        color = BluePrimary,
                        onClick = onNavigateToSettings
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Logout
            Surface(
                modifier = Modifier.fillMaxWidth().clickable {
                    authViewModel.logout()
                    onLogoutFinished()
                },
                shape = RoundedCornerShape(20.dp),
                color = ErrorRedContainer.copy(alpha = 0.2f),
                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.ExitToApp, null, tint = ErrorRed, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = "تسجيل الخروج", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ErrorRed)
                }
            }
        }
    }
}

@Composable
private fun ProfileOptionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            modifier = Modifier.size(40.dp),
            shape = RoundedCornerShape(10.dp),
            color = color.copy(alpha = 0.1f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = BlueDark)
        Spacer(modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = OutlineLight, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun ProfileItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            modifier = Modifier.size(44.dp),
            shape = RoundedCornerShape(12.dp),
            color = BluePrimary.copy(alpha = 0.08f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = BluePrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondaryLight,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )
        }
    }
}
