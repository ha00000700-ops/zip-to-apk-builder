package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ArrowForward
import com.example.ui.theme.BackgroundLight
import androidx.compose.foundation.border
import com.example.ui.theme.TextPrimaryLight
import androidx.compose.material3.Surface
import androidx.compose.foundation.BorderStroke
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.ui.components.KhedmatiOutlinedButton
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEditProviderProfile: () -> Unit,
    onLogoutFinished: () -> Unit
) {
    val currentUser by authViewModel.currentUserProfile.collectAsState()
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()

    val isProvider = currentUser?.role == UserRole.SERVICE_PROVIDER

    Scaffold(
        topBar = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(listOf(BlueDark, BluePrimary)),
                            shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
                        )
                        .padding(top = 48.dp, bottom = 40.dp, start = 24.dp, end = 24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(18.dp))
                        
                        Column {
                            Text(
                                text = "الملف الشخصي 👤",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "إدارة بيانات حسابك وإعدادات التطبيق",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Avatar
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(if (isProvider) AmberLight.copy(alpha = 0.5f) else BlueContainer.copy(alpha = 0.5f))
                    .border(3.dp, if (isProvider) AmberPrimary else BluePrimary, CircleShape)
                    .padding(4.dp)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isProvider) Icons.Default.Handyman else Icons.Default.Person,
                    contentDescription = null,
                    tint = if (isProvider) AmberPrimary else BluePrimary,
                    modifier = Modifier.size(64.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = currentUser?.fullName ?: "مستخدم خدمتي",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Role Badge
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isProvider) AmberPrimary.copy(alpha = 0.15f) else BluePrimary.copy(alpha = 0.15f),
                border = BorderStroke(1.2.dp, if (isProvider) AmberPrimary.copy(alpha = 0.4f) else BluePrimary.copy(alpha = 0.4f))
            ) {
                Text(
                    text = if (isProvider) "حرفي معتمد 🛠️" else "حساب زبون 👤",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isProvider) AmberPrimary else BluePrimary,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Information Section
            Surface(
                modifier = Modifier
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                color = Color.White,
                border = BorderStroke(1.2.dp, BluePrimary.copy(alpha = 0.08f)),
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "البيانات الأساسية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = BlueDark
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    ProfileItem(
                        icon = Icons.Default.Email,
                        label = "البريد الإلكتروني",
                        value = currentUser?.email ?: "غير محدد"
                    )

                    HorizontalDivider(
                        color = BluePrimary.copy(alpha = 0.05f),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )

                    ProfileItem(
                        icon = Icons.Default.Phone,
                        label = "رقم الهاتف",
                        value = currentUser?.phone ?: "غير محدد"
                    )

                    HorizontalDivider(
                        color = BluePrimary.copy(alpha = 0.05f),
                        modifier = Modifier.padding(vertical = 16.dp)
                    )

                    ProfileItem(
                        icon = Icons.Default.LocationOn,
                        label = "الولاية والبلدية",
                        value = "${currentUser?.communeName ?: "البلدية"}، ولاية ${currentUser?.wilayaName ?: "الجزائر"}"
                    )

                    if (isProvider && providerProfile != null) {
                        HorizontalDivider(
                            color = BluePrimary.copy(alpha = 0.05f),
                            modifier = Modifier.padding(vertical = 16.dp)
                        )

                        ProfileItem(
                            icon = Icons.Default.Handyman,
                            label = "المهنة والتخصص",
                            value = "${providerProfile?.professionNameAr} (${providerProfile?.professionCategoryAr})"
                        )

                        HorizontalDivider(
                            color = BluePrimary.copy(alpha = 0.05f),
                            modifier = Modifier.padding(vertical = 16.dp)
                        )

                        ProfileItem(
                            icon = Icons.Default.Verified,
                            label = "سنوات الخبرة",
                            value = "${providerProfile?.experienceYears} سنوات"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Professional Edit Shortcut
            if (isProvider) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToEditProviderProfile() },
                    shape = RoundedCornerShape(20.dp),
                    color = BlueContainer.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier.padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(BluePrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Handyman, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "تحديث بيانات الملف المهني والمهنة",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = BluePrimary
                        )
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            // Logout Section
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        authViewModel.logout()
                        onLogoutFinished()
                    },
                shape = RoundedCornerShape(20.dp),
                color = ErrorRedContainer.copy(alpha = 0.4f),
                border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.15f))
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "تسجيل الخروج من الحساب",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = ErrorRed
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfileItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            modifier = Modifier.size(44.dp),
            shape = RoundedCornerShape(12.dp),
            color = BluePrimary.copy(alpha = 0.08f)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = BluePrimary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondaryLight,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark
            )
        }
    }
}
