package com.example.ui.screens.profile

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentMethod
import com.example.data.model.SubscriptionPlan
import com.example.data.model.SubscriptionStatus
import com.example.data.model.UserRole
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProSubscriptionScreen(
    authViewModel: AuthViewModel,
    onNavigateToPaymentWeb: (checkoutUrl: String, methodCode: String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val userProfile by authViewModel.currentUserProfile.collectAsState()

    var isProcessingCheckout by remember { mutableStateOf(false) }
    var selectedPlan by remember { mutableStateOf(SubscriptionPlan.PREMIUM) }

    val subscription = userProfile?.subscription
    val isSubscribed = subscription?.isSubscribed == true
    val currentPlan = subscription?.plan ?: SubscriptionPlan.FREE
    val subStatus = subscription?.status ?: SubscriptionStatus.FREE

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "اشتراكات المهنيين 🌟",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // If user is a customer, show customer explanatory banner
                if (userProfile?.role == UserRole.CUSTOMER) {
                    CustomerNoticeCard()
                } else {
                    // Header Banner Card
                    HeroPlansBannerCard(isSubscribed = isSubscribed, currentPlan = currentPlan)

                    Spacer(modifier = Modifier.height(16.dp))

                    // Subscription Status Panel
                    CurrentSubscriptionStatusCard(
                        subscription = subscription,
                        subStatus = subStatus,
                        currentPlan = currentPlan,
                        isSubscribed = isSubscribed
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Plan Selection Title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Loyalty,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختر خطة الاشتراك المناسبة لعملك:",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = BlueDark
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "جميع الخطط صالحة لمدة شهر كامل (30 يوماً). الدفع بالدينار الجزائري.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Tier 1: Basic (500 DZD)
                    SubscriptionTierCard(
                        plan = SubscriptionPlan.BASIC,
                        title = "الخطة الأساسية (Basic)",
                        priceDzd = 500L,
                        periodText = "شهرياً / شهر واحد",
                        isRecommended = false,
                        isSelected = selectedPlan == SubscriptionPlan.BASIC,
                        badgeLabel = "أساسي",
                        badgeColor = Color(0xFF64748B),
                        accentColor = BluePrimary,
                        features = listOf(
                            "ظهور الملف المهني للزبائن في نتائج البحث",
                            "استقبال طلبات الخدمة المباشرة والرد عليها بالعروض",
                            "وصول أساسي لسوق خدمات التطبيق",
                            "ظهور قياسي ومباشر في مدينتك وولايتك"
                        ),
                        onSelect = { selectedPlan = SubscriptionPlan.BASIC }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tier 2: Standard (1000 DZD)
                    SubscriptionTierCard(
                        plan = SubscriptionPlan.STANDARD,
                        title = "الخطة القياسية (Standard)",
                        priceDzd = 1000L,
                        periodText = "شهرياً / شهر واحد",
                        isRecommended = false,
                        isSelected = selectedPlan == SubscriptionPlan.STANDARD,
                        badgeLabel = "🥈 شارة معتمد",
                        badgeColor = BluePrimary,
                        accentColor = BluePrimary,
                        features = listOf(
                            "جميع ميزات الخطة الأساسية",
                            "ظهور أفضل ومتقدم في نتائج بحث الزبائن",
                            "ترتيب أعلى من مقدمي الخدمة بالخطة الأساسية",
                            "شارة الحرفي القياسي المعتمد (🥈 معتمد)",
                            "فرصة مضاعفة للتواصل وجذب الزبائن"
                        ),
                        onSelect = { selectedPlan = SubscriptionPlan.STANDARD }
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tier 3: Premium (1500 DZD) - RECOMMENDED
                    SubscriptionTierCard(
                        plan = SubscriptionPlan.PREMIUM,
                        title = "الخطة المميزة (Premium)",
                        priceDzd = 1500L,
                        periodText = "شهرياً / شهر واحد",
                        isRecommended = true,
                        isSelected = selectedPlan == SubscriptionPlan.PREMIUM,
                        badgeLabel = "⭐⭐⭐ شارة التميز الذهبية",
                        badgeColor = AmberDark,
                        accentColor = AmberPrimary,
                        features = listOf(
                            "جميع ميزات الخطة القياسية والأساسية",
                            "أولوية قصوى في صدارة نتائج البحث لولايتك ومدينتك",
                            "أعلى نسبة ظهور وتفاعل مع طلبات الزبائن",
                            "شارة التميز الذهبية (⭐ مميز)",
                            "إحصائيات وتحليلات متقدمة للمشاهدات ونمو الأعمال",
                            "أولوية وصول الإشعارات للطلبات العامة القريبة"
                        ),
                        onSelect = { selectedPlan = SubscriptionPlan.PREMIUM }
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Checkout Action Panel
                    PaymentCheckoutActionCard(
                        selectedPlan = selectedPlan,
                        onInitiatePayment = { paymentMethod ->
                            scope.launch {
                                isProcessingCheckout = true
                                authViewModel.initiateProSubscriptionPayment(
                                    plan = selectedPlan,
                                    paymentMethod = paymentMethod
                                ) { result ->
                                    isProcessingCheckout = false
                                    when (result) {
                                        is AuthResult.Success -> {
                                            onNavigateToPaymentWeb(
                                                result.data.checkoutUrl,
                                                result.data.paymentMethod.code
                                            )
                                        }
                                        is AuthResult.Error -> {
                                            Toast.makeText(context, result.messageAr, Toast.LENGTH_LONG).show()
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    )
                }
            }

            // Processing Loading Overlay
            if (isProcessingCheckout) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.Black.copy(alpha = 0.5f)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                CircularProgressIndicator(color = BluePrimary)
                                Text(
                                    text = "جاري تهيئة بوابة الدفع الآمنة Chargily Pay...",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = BlueDark
                                )
                                Text(
                                    text = "جاري تحضير رابط الخطة المختارة (${selectedPlan.displayNameAr})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryLight
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerNoticeCard() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pro_customer_notice"),
        shape = RoundedCornerShape(20.dp),
        color = BluePrimary.copy(alpha = 0.05f),
        border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = BluePrimary.copy(alpha = 0.1f),
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Celebration,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Text(
                text = "جميع ميزات الزبائن مجانية بالكامل 🎁",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BlueDark,
                textAlign = TextAlign.Center
            )

            Text(
                text = "بصفتك زبوناً في تطبيق خدمتي، فإن البحث عن الحرفيين، وتصفح الملفات، وتقديم طلبات الخدمة، والمحادثة المباشرة مجانية تماماً ودون أي اشتراكات.\n\nتتوفر خطط الاشتراك المهني خصيصاً لمقدمي الخدمات والحرفيين لترقية ملفاتهم وأولوية الظهور في نتائج البحث.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondaryLight,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )
        }
    }
}

@Composable
private fun HeroPlansBannerCard(isSubscribed: Boolean, currentPlan: SubscriptionPlan) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("subscription_hero_banner"),
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = if (isSubscribed) {
                            listOf(AmberPrimary, Color(0xFFD97706))
                        } else {
                            listOf(BlueDark, BluePrimary)
                        }
                    ),
                    shape = RoundedCornerShape(24.dp)
                )
                .padding(22.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isSubscribed) Icons.Default.WorkspacePremium else Icons.Default.Stars,
                            contentDescription = null,
                            tint = if (isSubscribed) Color.White else AmberPrimary,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = if (isSubscribed) "حسابك المهني مفعل (${currentPlan.displayNameAr}) ⭐" else "خطط اشتراك خدمتي للمهنيين",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "ارفع ظهورك المهني واجذب المزيد من الزبائن في ولايتك ومدينتك بخطط شهرية شفافة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.9f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun CurrentSubscriptionStatusCard(
    subscription: com.example.data.model.UserSubscription?,
    subStatus: SubscriptionStatus,
    currentPlan: SubscriptionPlan,
    isSubscribed: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "معلومات الاشتراك الحالي",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = BlueDark
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSubscribed) EmeraldPrimary.copy(alpha = 0.12f) else OutlineLight.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = if (isSubscribed) "نشط ومفعل" else subStatus.displayNameAr,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSubscribed) EmeraldPrimary else TextSecondaryLight,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = OutlineLight.copy(alpha = 0.3f))

            if (isSubscribed && subscription != null) {
                StatusDetailRow(label = "الخطة الحالية", value = currentPlan.displayNameAr, valueColor = AmberDark)
                StatusDetailRow(label = "مبلغ الاشتراك", value = "${subscription.amount} دج / شهر", valueColor = BluePrimary)
                StatusDetailRow(label = "تاريخ البدء", value = formatTimestampToDate(subscription.startDate))
                StatusDetailRow(label = "تاريخ الانتهاء", value = formatTimestampToDate(subscription.endDate))
            } else {
                if (subStatus == SubscriptionStatus.PENDING) {
                    Surface(
                        color = AmberPrimary.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Pending,
                                contentDescription = null,
                                tint = AmberPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "معاملتك قيد المراجعة والتأكيد من الخادم ⏳",
                                style = MaterialTheme.typography.bodySmall,
                                color = AmberDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    StatusDetailRow(label = "الخطة الحالية", value = "الحساب المجاني (Free)", valueColor = TextSecondaryLight)
                }
            }
        }
    }
}

@Composable
private fun SubscriptionTierCard(
    plan: SubscriptionPlan,
    title: String,
    priceDzd: Long,
    periodText: String,
    isRecommended: Boolean,
    isSelected: Boolean,
    badgeLabel: String,
    badgeColor: Color,
    accentColor: Color,
    features: List<String>,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onSelect() }
            .testTag("tier_card_${plan.code.lowercase()}"),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(
            width = if (isSelected) 2.5.dp else 1.dp,
            color = if (isSelected) accentColor else if (isRecommended) AmberPrimary.copy(alpha = 0.6f) else OutlineLight.copy(alpha = 0.5f)
        ),
        shadowElevation = if (isSelected) 4.dp else 1.dp
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row: Title + Badge + Radio
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = onSelect,
                        colors = RadioButtonDefaults.colors(
                            selectedColor = accentColor
                        ),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BlueDark
                    )
                }

                if (isRecommended) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AmberPrimary
                    ) {
                        Text(
                            text = "⭐ موصى به",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black,
                            color = BlueDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = badgeColor.copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = badgeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = badgeColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pricing Row
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "$priceDzd",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Black,
                    color = BlueDark
                )
                Text(
                    text = "دج",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = BluePrimary
                )
                Text(
                    text = " / $periodText",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondaryLight,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = OutlineLight.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(12.dp))

            // Features Checklist
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                features.forEach { featureText ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isSelected) accentColor else EmeraldPrimary,
                            modifier = Modifier
                                .size(18.dp)
                                .padding(top = 2.dp)
                        )
                        Text(
                            text = featureText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = BlueDark,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentCheckoutActionCard(
    selectedPlan: SubscriptionPlan,
    onInitiatePayment: (PaymentMethod) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.25f)),
        shadowElevation = 3.dp
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الخطة المحددة للاشتراك:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryLight
                    )
                    Text(
                        text = selectedPlan.displayNameAr,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                }

                Text(
                    text = "${selectedPlan.priceDzd} دج / شهر",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = BluePrimary
                )
            }

            HorizontalDivider(color = OutlineLight.copy(alpha = 0.3f))

            Text(
                text = "اختر طريقة الدفع الإلكتروني الآمن عبر Chargily Pay:",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = BlueDark
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onInitiatePayment(PaymentMethod.EDAHABIA) },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("subscribe_edahabia_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Payment,
                        contentDescription = null,
                        tint = BlueDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "البطاقة الذهبية",
                        color = BlueDark,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = { onInitiatePayment(PaymentMethod.CIB) },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("subscribe_cib_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CreditCard,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "بطاقة CIB",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "🔒 الدفع آمن ومحمي بالكامل 100% عبر بريد الجزائر والبنوك الوطنية",
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiaryLight,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun StatusDetailRow(label: String, value: String, valueColor: Color = BlueDark) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextSecondaryLight)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

private fun formatTimestampToDate(epoch: Long): String {
    if (epoch == 0L) return "غير محدد"
    val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
    return sdf.format(Date(epoch))
}
