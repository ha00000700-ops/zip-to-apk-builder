package com.example.ui.screens.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Profession
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.launch

@Composable
fun EditProviderProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    val updateState by authViewModel.updateProfileState.collectAsState()

    var fullName by remember(providerProfile) { mutableStateOf(providerProfile?.fullName ?: "") }
    var phone by remember(providerProfile) { mutableStateOf(providerProfile?.phone ?: "") }
    var profileImageUrl by remember(providerProfile) { mutableStateOf(providerProfile?.effectiveAvatarUrl() ?: "") }
    var specialization by remember(providerProfile) { mutableStateOf(providerProfile?.specialization ?: "") }

    var selectedProfessionId by remember(providerProfile) { mutableStateOf(providerProfile?.professionId ?: "") }
    var selectedProfessionNameAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionNameAr ?: "") }
    var selectedProfessionCategoryAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionCategoryAr ?: "") }

    var selectedWilayaCode by remember(providerProfile) { mutableIntStateOf(providerProfile?.wilayaCode ?: 16) }
    var selectedWilayaName by remember(providerProfile) { mutableStateOf(providerProfile?.wilayaName ?: "الجزائر") }
    var selectedCommuneName by remember(providerProfile) { mutableStateOf(providerProfile?.communeName ?: "الجزائر الوسطى") }

    var bio by remember(providerProfile) { mutableStateOf(providerProfile?.effectiveBio() ?: "") }
    var experienceYearsText by remember(providerProfile) { mutableStateOf(providerProfile?.experienceYears?.toString() ?: "3") }

    val portfolioUrls = remember(providerProfile) {
        mutableStateListOf<String>().apply {
            addAll(providerProfile?.portfolioImageUrls ?: emptyList())
        }
    }

    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var professionError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }

    var diagnosticResult by remember { mutableStateOf<com.example.data.remote.StorageIsolationTester.TestResult?>(null) }
    var isDiagnosticRunning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val focusManager = LocalFocusManager.current

    val singlePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> 
            if (uri != null) {
                android.util.Log.d("KhedmatiTrace", "Selected image URI: $uri")
                profileImageUrl = uri.toString() 
                diagnosticResult = null // Reset previous test when new image chosen
            }
        }
    )

    val multiplePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10),
        onResult = { uris ->
            uris.forEach { uri ->
                val str = uri.toString()
                if (!portfolioUrls.contains(str)) portfolioUrls.add(str)
            }
        }
    )

    LaunchedEffect(updateState) {
        if (updateState is AuthResult.Success) {
            onNavigateBack()
        }
    }

    fun saveChanges() {
        var isValid = true
        if (fullName.trim().isEmpty()) { fullNameError = "يرجى إدخال الاسم المهني"; isValid = false }
        if (selectedProfessionId.isBlank()) { professionError = "المهنة إجبارية"; isValid = false }
        if (phone.trim().length != 10) { phoneError = "رقم الهاتف غير صحيح"; isValid = false }
        if (bio.trim().length < 10) { descriptionError = "يرجى إدخال نبذة لا تقل عن 10 أحرف"; isValid = false }

        if (isValid) {
            focusManager.clearFocus()
            val existing = providerProfile ?: return
            val updated = existing.copy(
                fullName = fullName.trim(),
                phone = phone.trim(),
                profileImageUrl = profileImageUrl,
                avatarUrl = profileImageUrl,
                specialization = specialization.trim(),
                professionId = selectedProfessionId,
                professionNameAr = selectedProfessionNameAr,
                professionCategoryAr = selectedProfessionCategoryAr,
                wilayaCode = selectedWilayaCode,
                wilayaName = selectedWilayaName,
                communeName = selectedCommuneName,
                bio = bio.trim(),
                serviceDescription = bio.trim(),
                experienceYears = experienceYearsText.toIntOrNull() ?: 1,
                portfolioImageUrls = portfolioUrls.toList()
            )
            authViewModel.updateProviderProfile(context, updated)
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تعديل الملف المهني",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = BackgroundLight
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
        ) {
            // Profile Image Section
            Box(
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .background(Color.White, CircleShape)
                        .padding(4.dp)
                        .border(1.dp, BluePrimary.copy(alpha = 0.2f), CircleShape)
                        .clickable { singlePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                ) {
                    if (profileImageUrl.isNotBlank()) {
                        AsyncImage(
                            model = com.example.data.remote.SupabaseConfig.resolveUrl(profileImageUrl),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    } else {
                        Box(modifier = Modifier.fillMaxSize().background(BlueContainer.copy(alpha = 0.3f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AddAPhoto, null, tint = BluePrimary, modifier = Modifier.size(32.dp))
                        }
                    }
                    
                    Surface(
                        modifier = Modifier.align(Alignment.BottomEnd).size(32.dp),
                        shape = CircleShape,
                        color = BluePrimary,
                        shadowElevation = 2.dp
                    ) {
                        Icon(Icons.Default.AddAPhoto, null, tint = Color.White, modifier = Modifier.padding(6.dp))
                    }
                }
            }

            // ISOLATION DIAGNOSTIC SECTION
            if (profileImageUrl.startsWith("content://") || profileImageUrl.startsWith("file://")) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F7FF)),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "🔬 اختبار العزل والتشخيص الفوري للملف الشخصي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "تم اختيار صورة محلية جديدة. قم بتشغيل اختبار العزل والتأكيد للتأكد من عمل الرفع، تحميل الرابط الموقع والمطابقة بنسبة 100٪ مباشرة من Supabase.",
                            style = MaterialTheme.typography.bodySmall,
                            color = BlueDark.copy(alpha = 0.8f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        if (isDiagnosticRunning) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("يجري الرفع والتحميل والتطابق المباشر...", style = MaterialTheme.typography.bodySmall, color = BluePrimary)
                            }
                        } else {
                            Button(
                                onClick = {
                                    scope.launch {
                                        isDiagnosticRunning = true
                                        diagnosticResult = null
                                        try {
                                            val uri = android.net.Uri.parse(profileImageUrl)
                                            val testUid = providerProfile?.uid ?: "test_uid"
                                            diagnosticResult = com.example.data.remote.StorageIsolationTester.runDiagnostic(context, uri, testUid)
                                        } catch (e: Exception) {
                                            android.util.Log.e("KhedmatiTrace", "Error running diagnostic", e)
                                        } finally {
                                            isDiagnosticRunning = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("بدء اختبار العزل والتحقق المباشر", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        
                        diagnosticResult?.let { res ->
                            Spacer(modifier = Modifier.height(16.dp))
                            HorizontalDivider(color = BluePrimary.copy(alpha = 0.15f))
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Visual direct render
                            Text("1. التحقق البصري المباشر (Direct Render - No Coil / No Interceptor):", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = BlueDark)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            if (res.decodedBitmap != null) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        androidx.compose.foundation.Image(
                                            bitmap = res.decodedBitmap.asImageBitmap(),
                                            contentDescription = "Diagnostic Direct Download Image",
                                            modifier = Modifier
                                                .size(110.dp)
                                                .clip(CircleShape)
                                                .border(3.dp, Color.Green, CircleShape),
                                            contentScale = ContentScale.Crop
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("الصورة المسترجعة مباشرة من رابط التنزيل الموقع ✅", style = MaterialTheme.typography.labelSmall, color = Color(0xFF007E13), fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                Text("❌ فشل تحميل وعرض الصورة مباشرة من الخادم.", style = MaterialTheme.typography.bodySmall, color = Color.Red)
                            }
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("2. المعطيات والتحقق الرقمي:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = BlueDark)
                            Spacer(modifier = Modifier.height(6.dp))
                            
                            DiagnosticSpecLine(label = "بصمة الصورة المحددة محلياً (SHA-256 Hash):", value = res.localSha256)
                            DiagnosticSpecLine(label = "بصمة الصورة المحملة من الخادم (SHA-256 Hash):", value = res.downloadSha256)
                            DiagnosticSpecLine(
                                label = "حالة تطابق بصمتي الصورة (Image Match):",
                                value = if (res.hashMatches) "متطابقة بنسبة 100٪! ✅ (Perfect Match)" else "غير متطابقة ❌ (Mismatch)",
                                isHighlighted = true,
                                highlightColor = if (res.hashMatches) Color(0xFF007E13) else Color.Red
                            )
                            DiagnosticSpecLine(label = "مسار التخزين بالخادم (Object Path):", value = res.uploadPath)
                            DiagnosticSpecLine(label = "حالة الرفع (Upload HTTP Status):", value = "HTTP ${res.uploadHttpStatus} (${if (res.uploadHttpStatus in 200..299) "ناجح ✅" else "فشل ❌"})")
                            DiagnosticSpecLine(label = "حالة التحميل عبر الرابط الموقع (Download HTTP Status):", value = "HTTP ${res.downloadHttpStatus} (${if (res.downloadHttpStatus in 200..299) "ناجح ✅" else "فشل ❌"})")
                            DiagnosticSpecLine(label = "نوع المحتوى المستلم (Content-Type):", value = res.downloadContentType ?: "غير متوفر")
                            DiagnosticSpecLine(label = "حجم البيانات المستلمة (Content-Length):", value = "${res.downloadContentLength} بايت")
                            DiagnosticSpecLine(label = "أبعاد الصورة المسترجعة (Dimensions):", value = res.downloadDimensions)
                            
                            if (!res.isSuccess) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "خطأ التشخيص: ${res.errorMessage ?: "حدث خطأ أثناء إجراء التحقق الفوري"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.Red,
                                    fontWeight = FontWeight.Bold
                                )
                                res.uploadErrorBody?.let {
                                    Text("تفاصيل خطأ الرفع: $it", style = MaterialTheme.typography.labelSmall, color = Color.Red)
                                }
                            }
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF9E6)),
                    border = BorderStroke(1.dp, Color(0xFFFFD54F).copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Color(0xFFD84315))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "انقر على الصورة الشخصية بالأعلى لاختيار صورة جديدة من جهازك لتفعيل وتشغيل اختبار العزل والتأكيد المباشر.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFD84315)
                        )
                    }
                }
            }

            // Form Sections
            SectionHeader(title = "المهنة والموقع")
            MandatoryProfessionSelector(
                selectedProfessionId = selectedProfessionId,
                onProfessionSelected = { prof ->
                    selectedProfessionId = prof.id
                    selectedProfessionNameAr = prof.nameAr
                    selectedProfessionCategoryAr = prof.categoryAr
                    professionError = null
                },
                isError = professionError != null,
                errorMessage = professionError
            )
            Spacer(modifier = Modifier.height(12.dp))
            WilayaCommuneSelector(
                selectedWilayaCode = selectedWilayaCode,
                selectedCommuneName = selectedCommuneName,
                onLocationSelected = { code, wName, cName ->
                    selectedWilayaCode = code
                    selectedWilayaName = wName
                    selectedCommuneName = cName
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "المعلومات المهنية")
            KhedmatiTextField(value = fullName, onValueChange = { fullName = it; fullNameError = null }, label = "الاسم واللقب المهني", leadingIcon = Icons.Default.Person, errorMessage = fullNameError)
            Spacer(modifier = Modifier.height(12.dp))
            KhedmatiTextField(value = specialization, onValueChange = { specialization = it }, label = "التخصص الدقيق", leadingIcon = Icons.Default.Star)
            Spacer(modifier = Modifier.height(12.dp))
            KhedmatiPhoneField(value = phone, onValueChange = { phone = it; phoneError = null }, label = "رقم الهاتف", leadingIcon = Icons.Default.Phone, errorMessage = phoneError)
            Spacer(modifier = Modifier.height(12.dp))
            KhedmatiTextField(
                value = experienceYearsText,
                onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 2) experienceYearsText = it },
                label = "سنوات الخبرة",
                leadingIcon = Icons.Default.WorkHistory,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "نبذة عن الخدمات")
            KhedmatiTextField(value = bio, onValueChange = { bio = it; descriptionError = null }, label = "وصف الخدمات والخبرة", leadingIcon = Icons.Default.Description, errorMessage = descriptionError, singleLine = false, maxLines = 4)

            Spacer(modifier = Modifier.height(24.dp))
            SectionHeader(title = "معرض الأعمال")
            PortfolioSection(portfolioUrls = portfolioUrls, onAddPhotos = { multiplePhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, onRemovePhoto = { portfolioUrls.remove(it) })

            Spacer(modifier = Modifier.height(32.dp))
            KhedmatiPrimaryButton(text = "حفظ التعديلات", onClick = { saveChanges() }, isLoading = updateState is AuthResult.Loading)
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium,
        color = BluePrimary,
        fontWeight = FontWeight.Black,
        modifier = Modifier.padding(bottom = 12.dp, start = 4.dp)
    )
}

@Composable
private fun PortfolioSection(portfolioUrls: MutableList<String>, onAddPhotos: () -> Unit, onRemovePhoto: (String) -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(text = "صور الأعمال (${portfolioUrls.size})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = BlueDark)
                TextButton(onClick = onAddPhotos) {
                    Text(text = "+ إضافة صور", style = MaterialTheme.typography.labelMedium, color = BluePrimary, fontWeight = FontWeight.Bold)
                }
            }
            
            if (portfolioUrls.isEmpty()) {
                Text(text = "أضف صوراً لأعمالك السابقة لإقناع الزبائن بجودة عملك.", style = MaterialTheme.typography.bodySmall, color = TextTertiaryLight)
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    portfolioUrls.chunked(3).forEach { chunk ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            chunk.forEach { url ->
                                Box(modifier = Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(12.dp))) {
                                    AsyncImage(
                                        model = com.example.data.remote.SupabaseConfig.resolveUrl(url),
                                        contentDescription = "عمل سابق",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(24.dp)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                            .clickable { onRemovePhoto(url) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                            if (chunk.size < 3) {
                                repeat(3 - chunk.size) { Spacer(modifier = Modifier.weight(1f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticSpecLine(
    label: String,
    value: String,
    isHighlighted: Boolean = false,
    highlightColor: Color = Color.Unspecified
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextTertiaryLight, fontWeight = FontWeight.Bold)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = if (isHighlighted) highlightColor else BlueDark,
            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
        )
    }
}

