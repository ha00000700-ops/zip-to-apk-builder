package com.example.ui.screens.profile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.Profession
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPhoneField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.components.MandatoryProfessionSelector
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun EditProviderProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    val updateState by authViewModel.updateProfileState.collectAsState()

    var fullName by remember(providerProfile) { mutableStateOf(providerProfile?.fullName ?: "") }
    var phone by remember(providerProfile) { mutableStateOf(providerProfile?.phone ?: "") }

    var selectedProfessionId by remember(providerProfile) { mutableStateOf(providerProfile?.professionId ?: "") }
    var selectedProfessionNameAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionNameAr ?: "") }
    var selectedProfessionCategoryAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionCategoryAr ?: "") }

    var selectedWilayaCode by remember(providerProfile) { mutableIntStateOf(providerProfile?.wilayaCode ?: 16) }
    var selectedWilayaName by remember(providerProfile) { mutableStateOf(providerProfile?.wilayaName ?: "الجزائر") }
    var selectedCommuneName by remember(providerProfile) { mutableStateOf(providerProfile?.communeName ?: "الجزائر الوسطى") }

    var serviceDescription by remember(providerProfile) { mutableStateOf(providerProfile?.serviceDescription ?: "") }
    var experienceYearsText by remember(providerProfile) { mutableStateOf(providerProfile?.experienceYears?.toString() ?: "3") }

    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var professionError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current

    LaunchedEffect(updateState) {
        if (updateState is AuthResult.Success) {
            onNavigateBack()
        }
    }

    fun saveChanges() {
        var isValid = true

        if (fullName.trim().isEmpty()) {
            fullNameError = "يرجى إدخال الاسم المهني"
            isValid = false
        } else {
            fullNameError = null
        }

        if (selectedProfessionId.isBlank()) {
            professionError = "المهنة إجبارية ولا يمكن تركها فارغة"
            isValid = false
        } else {
            professionError = null
        }

        if (phone.trim().length != 10) {
            phoneError = "رقم الهاتف غير صحيح (10 أرقام)"
            isValid = false
        } else {
            phoneError = null
        }

        if (serviceDescription.trim().length < 10) {
            descriptionError = "يرجى إدخال وصف لا يقل عن 10 أحرف"
            isValid = false
        } else {
            descriptionError = null
        }

        if (isValid) {
            focusManager.clearFocus()
            val existing = providerProfile ?: return
            val updated = existing.copy(
                fullName = fullName.trim(),
                phone = phone.trim(),
                professionId = selectedProfessionId,
                professionNameAr = selectedProfessionNameAr,
                professionCategoryAr = selectedProfessionCategoryAr,
                wilayaCode = selectedWilayaCode,
                wilayaName = selectedWilayaName,
                communeName = selectedCommuneName,
                serviceDescription = serviceDescription.trim(),
                experienceYears = experienceYearsText.toIntOrNull() ?: 1
            )
            authViewModel.updateProviderProfile(updated)
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تعديل الملف المهني",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                text = "تحديث بيانات الحرفي والتخصص",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = EmeraldDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (updateState is AuthResult.Error) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = ErrorRedContainer)
                ) {
                    Text(
                        text = (updateState as AuthResult.Error).messageAr,
                        color = ErrorRed,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Mandatory Profession Selection
            MandatoryProfessionSelector(
                selectedProfessionId = selectedProfessionId,
                onProfessionSelected = { prof: Profession ->
                    selectedProfessionId = prof.id
                    selectedProfessionNameAr = prof.nameAr
                    selectedProfessionCategoryAr = prof.categoryAr
                    if (professionError != null) professionError = null
                },
                isError = professionError != null,
                errorMessage = professionError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Full Name
            KhedmatiTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    if (fullNameError != null) fullNameError = null
                },
                label = "الاسم واللقب المهني",
                leadingIcon = Icons.Default.Person,
                errorMessage = fullNameError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Phone
            KhedmatiPhoneField(
                value = phone,
                onValueChange = {
                    phone = it
                    if (phoneError != null) phoneError = null
                },
                label = "رقم الهاتف المهني",
                leadingIcon = Icons.Default.Phone,
                errorMessage = phoneError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Location
            WilayaCommuneSelector(
                selectedWilayaCode = selectedWilayaCode,
                selectedCommuneName = selectedCommuneName,
                onLocationSelected = { code, wName, cName ->
                    selectedWilayaCode = code
                    selectedWilayaName = wName
                    selectedCommuneName = cName
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Experience Years
            KhedmatiTextField(
                value = experienceYearsText,
                onValueChange = { input ->
                    if (input.all { it.isDigit() } && input.length <= 2) {
                        experienceYearsText = input
                    }
                },
                label = "سنوات الخبرة",
                leadingIcon = Icons.Default.WorkHistory,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Service Description
            KhedmatiTextField(
                value = serviceDescription,
                onValueChange = {
                    serviceDescription = it
                    if (descriptionError != null) descriptionError = null
                },
                label = "نبذة عن الخدمات المقدمة",
                leadingIcon = Icons.Default.Description,
                errorMessage = descriptionError,
                singleLine = false,
                maxLines = 4
            )

            Spacer(modifier = Modifier.height(24.dp))

            KhedmatiPrimaryButton(
                text = "حفظ التعديلات في Firestore",
                onClick = { saveChanges() },
                isLoading = updateState is AuthResult.Loading,
                testTag = "save_provider_profile_button"
            )
        }
    }
}
