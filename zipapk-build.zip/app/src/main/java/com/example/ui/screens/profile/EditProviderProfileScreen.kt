package com.example.ui.screens.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkHistory
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Profession
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiPhoneField
import com.example.ui.components.KhedmatiPrimaryButton
import com.example.ui.components.KhedmatiTextField
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.components.MandatoryProfessionSelector
import com.example.ui.components.WilayaCommuneSelector
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.ErrorRedContainer
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun EditProviderProfileScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit
) {
    val providerProfile by authViewModel.currentProviderProfile.collectAsState()
    val updateState by authViewModel.updateProfileState.collectAsState()

    var fullName by remember(providerProfile) { mutableStateOf(providerProfile?.fullName ?: "") }
    var phone by remember(providerProfile) { mutableStateOf(providerProfile?.phone ?: "") }
    var profileImageUrl by remember(providerProfile) { mutableStateOf(providerProfile?.effectiveAvatarUrl() ?: "") }
    var specialization by remember(providerProfile) { mutableStateOf(providerProfile?.specialization ?: "") }

    var selectedProfessionId by remember(providerProfile) { mutableStateOf(providerProfile?.professionId ?: "") }
    var selectedProfessionNameAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionNameAr ?: "") }
    var selectedProfessionCategoryAr by remember(providerProfile) { mutableStateOf(providerProfile?.professionCategoryAr ?: "") }

    var selectedWilayaCode by remember(providerProfile) { mutableIntStateOf(providerProfile?.wilayaCode ?: 16) }
    var selectedWilayaName by remember(providerProfile) { mutableStateOf(providerProfile?.wilayaName ?: "الجزائر") }
    var selectedCommuneName by remember(providerProfile) { mutableStateOf(providerProfile?.communeName ?: "الجزائر الوسطى") }

    var bio by remember(providerProfile) { mutableStateOf(providerProfile?.effectiveBio() ?: "") }
    var experienceYearsText by remember(providerProfile) { mutableStateOf(providerProfile?.experienceYears?.toString() ?: "3") }

    val portfolioUrls = remember(providerProfile) {
        mutableStateListOf<String>().apply {
            addAll(providerProfile?.portfolioImageUrls ?: emptyList())
        }
    }

    var fullNameError by remember { mutableStateOf<String?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var professionError by remember { mutableStateOf<String?>(null) }
    var descriptionError by remember { mutableStateOf<String?>(null) }

    val focusManager = LocalFocusManager.current

    // Single Photo Picker for Profile Image
    val singlePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                profileImageUrl = uri.toString()
            }
        }
    )

    // Multiple Photo Picker for Portfolio
    val multiplePhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10),
        onResult = { uris ->
            uris.forEach { uri ->
                val str = uri.toString()
                if (!portfolioUrls.contains(str)) {
                    portfolioUrls.add(str)
                }
            }
        }
    )

    LaunchedEffect(updateState) {
        if (updateState is AuthResult.Success) {
            onNavigateBack()
        }
    }

    fun saveChanges() {
        var isValid = true

        if (fullName.trim().isEmpty()) {
            fullNameError = "يرجى إدخال الاسم المهني"
            isValid = false
        } else {
            fullNameError = null
        }

        if (selectedProfessionId.isBlank()) {
            professionError = "المهنة إجبارية ولا يمكن تركها فارغة"
            isValid = false
        } else {
            professionError = null
        }

        if (phone.trim().length != 10) {
            phoneError = "رقم الهاتف غير صحيح (10 أرقام)"
            isValid = false
        } else {
            phoneError = null
        }

        if (bio.trim().length < 10) {
            descriptionError = "يرجى إدخال نبذة عن الخدمات لا تقل عن 10 أحرف"
            isValid = false
        } else {
            descriptionError = null
        }

        if (isValid) {
            focusManager.clearFocus()
            val existing = providerProfile ?: return
            val updated = existing.copy(
                fullName = fullName.trim(),
                phone = phone.trim(),
                profileImageUrl = profileImageUrl,
                avatarUrl = profileImageUrl,
                specialization = specialization.trim(),
                professionId = selectedProfessionId,
                professionNameAr = selectedProfessionNameAr,
                professionCategoryAr = selectedProfessionCategoryAr,
                wilayaCode = selectedWilayaCode,
                wilayaName = selectedWilayaName,
                communeName = selectedCommuneName,
                bio = bio.trim(),
                serviceDescription = bio.trim(),
                experienceYears = experienceYearsText.toIntOrNull() ?: 1,
                portfolioImageUrls = portfolioUrls.toList()
            )
            authViewModel.updateProviderProfile(updated)
        }
    }

    Scaffold(
        topBar = {
            KhedmatiTopBar(
                title = "تعديل الملف المهني",
                onNavigateBack = onNavigateBack
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Text(
                text = "تحديث بيانات الحرفي والصورة والتخصص",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = EmeraldDark
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (updateState is AuthResult.Error) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = ErrorRedContainer)
                ) {
                    Text(
                        text = (updateState as AuthResult.Error).messageAr,
                        color = ErrorRed,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Profile Image Selector Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(88.dp)
                            .clip(CircleShape)
                            .background(EmeraldContainer)
                            .border(2.dp, EmeraldPrimary, CircleShape)
                            .clickable {
                                singlePhotoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (profileImageUrl.isNotBlank()) {
                            AsyncImage(
                                model = profileImageUrl,
                                contentDescription = "الصورة الشخصية",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = "إضافة صورة",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            singlePhotoPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("pick_profile_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddAPhoto,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (profileImageUrl.isBlank()) "اختيار صورة شخصية" else "تغيير الصورة الشخصية",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Mandatory Profession Selection
            MandatoryProfessionSelector(
                selectedProfessionId = selectedProfessionId,
                onProfessionSelected = { prof: Profession ->
                    selectedProfessionId = prof.id
                    selectedProfessionNameAr = prof.nameAr
                    selectedProfessionCategoryAr = prof.categoryAr
                    if (professionError != null) professionError = null
                },
                isError = professionError != null,
                errorMessage = professionError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Specialization
            KhedmatiTextField(
                value = specialization,
                onValueChange = { specialization = it },
                label = "التخصص الدقيق (مثال: ترصيص غاز طبيعي، تركيب دوش)",
                leadingIcon = Icons.Default.Star
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Full Name
            KhedmatiTextField(
                value = fullName,
                onValueChange = {
                    fullName = it
                    if (fullNameError != null) fullNameError = null
                },
                label = "الاسم واللقب المهني",
                leadingIcon = Icons.Default.Person,
                errorMessage = fullNameError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Phone
            KhedmatiPhoneField(
                value = phone,
                onValueChange = {
                    phone = it
                    if (phoneError != null) phoneError = null
                },
                label = "رقم الهاتف المهني",
                leadingIcon = Icons.Default.Phone,
                errorMessage = phoneError
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Location
            WilayaCommuneSelector(
                selectedWilayaCode = selectedWilayaCode,
                selectedCommuneName = selectedCommuneName,
                onLocationSelected = { code, wName, cName ->
                    selectedWilayaCode = code
                    selectedWilayaName = wName
                    selectedCommuneName = cName
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Experience Years
            KhedmatiTextField(
                value = experienceYearsText,
                onValueChange = { input ->
                    if (input.all { it.isDigit() } && input.length <= 2) {
                        experienceYearsText = input
                    }
                },
                label = "سنوات الخبرة الميدانية",
                leadingIcon = Icons.Default.WorkHistory,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Biography
            KhedmatiTextField(
                value = bio,
                onValueChange = {
                    bio = it
                    if (descriptionError != null) descriptionError = null
                },
                label = "نبذة مفصلة عن الخدمات والخبرة الميدانية",
                leadingIcon = Icons.Default.Description,
                errorMessage = descriptionError,
                singleLine = false,
                maxLines = 4
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Portfolio Photos Management Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "معرض الأعمال والأنشطة السابقة",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )

                        Button(
                            onClick = {
                                multiplePhotoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_portfolio_photos_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة صور", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (portfolioUrls.isEmpty()) {
                        Text(
                            text = "لم تقم بإضافة أية صور لأعمالك السابقة بعد. يمكنك إضافة صور إنجازاتك لجذب الزبائن.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            portfolioUrls.chunked(3).forEach { chunk ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    chunk.forEach { url ->
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                        ) {
                                            AsyncImage(
                                                model = url,
                                                contentDescription = "عمل سابق",
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )

                                            IconButton(
                                                onClick = { portfolioUrls.remove(url) },
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .size(24.dp)
                                                    .background(
                                                        Color.Black.copy(alpha = 0.6f),
                                                        CircleShape
                                                    )
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = "حذف الصورة",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                    }
                                    repeat(3 - chunk.size) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            KhedmatiPrimaryButton(
                text = "حفظ التعديلات في Cloud Firestore",
                onClick = { saveChanges() },
                isLoading = updateState is AuthResult.Loading,
                testTag = "save_provider_profile_button"
            )
        }
    }
}

