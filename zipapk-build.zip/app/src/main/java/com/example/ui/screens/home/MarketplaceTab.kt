package com.example.ui.screens.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*

import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.rememberModalBottomSheetState

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.ProfessionData
import com.example.data.model.ServiceProviderProfile
import com.example.data.repository.AuthResult
import com.example.ui.components.FirebaseStatusBanner
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MarketplaceTab(
    paddingValues: PaddingValues,
    authViewModel: AuthViewModel,
    onNavigateToProviderProfile: (String) -> Unit,
    onNavigateToCreatePublicRequest: (() -> Unit)? = null,
    header: (@Composable () -> Unit)? = null
) {
    val providersListState by authViewModel.filteredProvidersListState.collectAsState()
    val activePromotedAds by authViewModel.activePromotedAds.collectAsState()
    var selectedCategoryIndex by remember { mutableStateOf<String?>(null) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var showAllCategories by remember { mutableStateOf(false) }
    var isSearchFocused by remember { mutableStateOf(false) }
    val searchQuery by authViewModel.searchQuery.collectAsState()

    LaunchedEffect(Unit) {
        authViewModel.loadServiceProviders()
    }

    val filteredProfessions = remember(searchQuery, selectedCategoryIndex) {
        var list = if (searchQuery.trim().isEmpty()) {
            ProfessionData.professions
        } else {
            ProfessionData.searchProfessions(searchQuery)
        }
        if (selectedCategoryIndex != null) {
            list = list.filter { it.categoryId == selectedCategoryIndex }
        }
        list
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues),
        contentPadding = PaddingValues(bottom = 120.dp)
    ) {
        // Optional Header
        if (header != null) {
            item { header() }
        }

        // Search Bar with Filter
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { query -> authViewModel.updateSearchQuery(query) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("customer_search_input")
                            .onFocusChanged { isSearchFocused = it.isFocused },
                        placeholder = { 
                            Text(
                                text = "ابحث عن خدمة (سباك، دهان...)", 
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextTertiaryLight
                            ) 
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = BluePrimary,
                            unfocusedBorderColor = OutlineLight.copy(alpha = 0.5f)
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    IconButton(
                        onClick = { showFilterDialog = true },
                        modifier = Modifier
                            .size(56.dp)
                            .background(BluePrimary, RoundedCornerShape(20.dp))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "تصفية",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                
                // Search Suggestions
                if (isSearchFocused && searchQuery.isNotBlank() && filteredProfessions.isNotEmpty()) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        shadowElevation = 4.dp
                    ) {
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            filteredProfessions.take(5).forEach { profession ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            authViewModel.updateSearchQuery(profession.nameAr)
                                        }
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = TextTertiaryLight,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = profession.nameAr,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = BlueDark
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Public Service Request Banner (Amber/Gold as in reference)
        if (onNavigateToCreatePublicRequest != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = AmberPrimary,
                ) {
                    Row(
                        modifier = Modifier.padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "هل تحتاج إلى خدمة؟",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = BlueDark
                            )
                            Text(
                                text = "انشر طلبك الآن مجاناً",
                                style = MaterialTheme.typography.bodyMedium,
                                color = BlueDark.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onNavigateToCreatePublicRequest() },
                                color = BlueDark,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "اطلب خدمة 📢",
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                        }
                        
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = BlueDark.copy(alpha = 0.2f),
                            modifier = Modifier.size(80.dp)
                        )
                    }
                }
            }
        }

        // Categories (Circular Icons)
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الأقسام",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    Text(
                        text = if (showAllCategories) "عرض أقل" else "عرض الكل",
                        style = MaterialTheme.typography.labelLarge,
                        color = BluePrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { showAllCategories = !showAllCategories }
                    )
                }

                if (showAllCategories) {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        ProfessionData.categories.forEach { cat ->
                            val isSelected = selectedCategoryIndex == cat.id
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { selectedCategoryIndex = if (isSelected) null else cat.id }
                                    .width(80.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(64.dp),
                                    shape = CircleShape,
                                    color = if (isSelected) BluePrimary else BackgroundLight,
                                    border = if (isSelected) null else BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Category,
                                            contentDescription = null,
                                            tint = if (isSelected) Color.White else BlueDark,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = cat.nameAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    color = if (isSelected) BluePrimary else TextSecondaryLight,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        items(ProfessionData.categories, key = { it.id }) { cat ->
                            val isSelected = selectedCategoryIndex == cat.id
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { selectedCategoryIndex = if (isSelected) null else cat.id }
                                    .width(80.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(64.dp),
                                    shape = CircleShape,
                                    color = if (isSelected) BluePrimary else BackgroundLight,
                                    border = if (isSelected) null else BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Category,
                                            contentDescription = null,
                                            tint = if (isSelected) Color.White else BlueDark,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = cat.nameAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    color = if (isSelected) BluePrimary else TextSecondaryLight,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section Title: Best Service Providers
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "أفضل الحرفيين",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = BlueDark
                )
                IconButton(
                    onClick = { authViewModel.loadServiceProviders() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "تحديث",
                        tint = BluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Providers Content
        when (val state = providersListState) {
            is AuthResult.Loading -> {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary, strokeWidth = 3.dp)
                    }
                }
            }
            is AuthResult.Success -> {
                val providers = state.data
                if (providers.isEmpty()) {
                    item {
                        KhedmatiEmptyState(
                            title = "لا يوجد حرفيون متاحون حالياً",
                            subtitle = "يرجى التحقق مرة أخرى لاحقاً",
                            icon = Icons.Default.SearchOff
                        )
                    }
                } else {
                    items(providers, key = { it.uid }) { provider ->
                        val matchingAd = remember(activePromotedAds, provider.uid) {
                            activePromotedAds.firstOrNull { it.providerId == provider.uid && it.isActive }
                        }
                        ServiceProviderCard(
                            provider = provider,
                            promotedAd = matchingAd,
                            onCardClick = { onNavigateToProviderProfile(provider.uid) },
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                        )
                    }
                }
            }
            is AuthResult.Error -> {
                item {
                    KhedmatiErrorState(message = state.messageAr) { authViewModel.loadServiceProviders() }
                }
            }
            else -> {}
        }

        // Firebase Status
        item {
            Box(modifier = Modifier.padding(24.dp)) {
                FirebaseStatusBanner(isFirebaseReady = authViewModel.isFirebaseReady)
            }
        }
    }

    // Filter Bottom Sheet
    if (showFilterDialog) {
        ModalBottomSheet(
            onDismissRequest = { showFilterDialog = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "تصفية الحرفيين",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = BlueDark
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "الأقسام",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlueDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfessionData.categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategoryIndex == cat.id,
                            onClick = { selectedCategoryIndex = if (selectedCategoryIndex == cat.id) null else cat.id },
                            label = { Text(cat.nameAr) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Button(
                    onClick = { showFilterDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("تطبيق التصفية")
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}