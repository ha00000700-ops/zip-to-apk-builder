package com.example.ui.screens.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.ProfessionData
import com.example.data.repository.AuthResult
import com.example.ui.components.FirebaseStatusBanner
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun MarketplaceTab(
    paddingValues: PaddingValues,
    authViewModel: AuthViewModel,
    onNavigateToProviderProfile: (String) -> Unit,
    onNavigateToCreatePublicRequest: (() -> Unit)? = null,
    header: (@Composable () -> Unit)? = null
) {
    val providersListState by authViewModel.filteredProvidersListState.collectAsState()
    var selectedCategoryIndex by remember { mutableStateOf<String?>(null) }
    val searchQuery by authViewModel.searchQuery.collectAsState()

    LaunchedEffect(Unit) {
        authViewModel.loadServiceProviders()
    }

    val filteredProfessions = remember(searchQuery, selectedCategoryIndex) {
        var list = if (searchQuery.trim().isEmpty()) {
            ProfessionData.professions
        } else {
            ProfessionData.searchProfessions(searchQuery)
        }
        if (selectedCategoryIndex != null) {
            list = list.filter { it.categoryId == selectedCategoryIndex }
        }
        list
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // Optional Header
        if (header != null) {
            item {
                header()
            }
        }

        // Public Service Request Quick Action Card (Customer side)
        if (onNavigateToCreatePublicRequest != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 24.dp),
                    shape = RoundedCornerShape(28.dp),
                    color = BlueContainer.copy(alpha = 0.5f),
                    border = BorderStroke(1.5.dp, BluePrimary.copy(alpha = 0.1f))
                ) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(BluePrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = BluePrimary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(
                                    text = "تحتاج خدمة عاجلة؟ 📢",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BlueDark
                                )
                                Text(
                                    text = "انشر طلبك وسيصل إلى جميع الحرفيين",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BluePrimary.copy(alpha = 0.85f),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onNavigateToCreatePublicRequest,
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("home_create_public_request_button")
                        ) {
                            Text(
                                text = "نشر طلب خدمة عام الآن",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            Box(modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { query -> authViewModel.updateSearchQuery(query) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_search_input"),
                    placeholder = { 
                        Text(
                            text = "ابحث عن حرفي (سباك، دهان...)", 
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryLight.copy(alpha = 0.7f)
                        ) 
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        focusedBorderColor = BluePrimary,
                        unfocusedBorderColor = OutlineLight.copy(alpha = 0.4f)
                    )
                )
            }
        }

        // Service Categories Horizontal Bar
        item {
            Column(modifier = Modifier.padding(top = 20.dp, bottom = 12.dp)) {
                Text(
                    text = "تصفح حسب المجال",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimaryLight,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Surface(
                            selected = selectedCategoryIndex == null,
                            onClick = { selectedCategoryIndex = null },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selectedCategoryIndex == null) BluePrimary else Color.White,
                            border = BorderStroke(1.2.dp, if (selectedCategoryIndex == null) BluePrimary else BluePrimary.copy(alpha = 0.15f)),
                            shadowElevation = if (selectedCategoryIndex == null) 4.dp else 0.dp
                        ) {
                            Text(
                                text = "الكل",
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (selectedCategoryIndex == null) Color.White else BluePrimary
                            )
                        }
                    }
                    items(ProfessionData.categories, key = { it.id }) { cat ->
                        Surface(
                            selected = selectedCategoryIndex == cat.id,
                            onClick = { selectedCategoryIndex = if (selectedCategoryIndex == cat.id) null else cat.id },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selectedCategoryIndex == cat.id) BluePrimary else Color.White,
                            border = BorderStroke(1.2.dp, if (selectedCategoryIndex == cat.id) BluePrimary else BluePrimary.copy(alpha = 0.15f)),
                            shadowElevation = if (selectedCategoryIndex == cat.id) 4.dp else 0.dp
                        ) {
                            Text(
                                text = cat.nameAr,
                                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (selectedCategoryIndex == cat.id) Color.White else BluePrimary
                            )
                        }
                    }
                }
            }
        }

        // Section Title
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "الحرفيون الموثقون ✅",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimaryLight
                    )
                    Text(
                        text = "اختر الحرفي الأنسب لمهمتك",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryLight
                    )
                }
                IconButton(
                    onClick = { authViewModel.loadServiceProviders() },
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(BlueContainer.copy(alpha = 0.4f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "تحديث",
                        tint = BluePrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        when (val state = providersListState) {
            is AuthResult.Loading -> {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = BluePrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "جاري تحميل قائمة الحرفيين من Firestore...",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            is AuthResult.Error -> {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "خطأ في جلب بيانات الحرفيين:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = state.messageAr,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = { authViewModel.loadServiceProviders() },
                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                            ) {
                                Text("إعادة المحاولة")
                            }
                        }
                    }
                }
            }
            is AuthResult.Success -> {
                val filteredProviders = state.data
                if (filteredProviders.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier.padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "لا يوجد حرفيون مسجلون حالياً بهذه المواصفات",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "عند قيام أي حرفي أو مهني جديد بالتسجيل في التطبيق عبر Firestore، سيظهر حسابه هنا فوراً.",
                                    style = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(filteredProviders, key = { it.uid }) { provider ->
                        ServiceProviderCard(
                            provider = provider,
                            onCardClick = { onNavigateToProviderProfile(provider.uid) },
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }
            }
            else -> {}
        }

        // Professions Marketplace Section
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "اختر الخدمة المطلوبة (${filteredProfessions.size} مهنة متوفرة)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        items(filteredProfessions, key = { it.id }) { profession ->
            ProfessionMarketplaceCard(
                profession = profession,
                wilayaName = authViewModel.currentUserProfile.collectAsState().value?.wilayaName ?: "منطقتك",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        // Firebase Status Banner
        item {
            Box(modifier = Modifier.padding(16.dp)) {
                FirebaseStatusBanner(isFirebaseReady = authViewModel.isFirebaseReady)
            }
        }
    }
}

