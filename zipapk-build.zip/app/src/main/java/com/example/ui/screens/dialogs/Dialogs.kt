package com.example.ui.screens.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GppBad
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.future.AiDiagnosisResult
import com.example.data.future.RuleBasedAiDiagnosticService
import com.example.data.model.ReportEntity
import com.example.data.model.ReportStatus
import com.example.data.model.VerificationRequestEntity
import com.example.ui.theme.DzGold
import com.example.ui.theme.DzGreenPrimary
import kotlinx.coroutines.launch

@Composable
fun ReviewDialog(
    professionalName: String,
    onDismiss: () -> Unit,
    onSubmit: (rating: Int, comment: String) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var comment by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "تقييم خدمة $professionalName",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "كيف كانت تجربتك وجودة العمل المنجز؟",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Star Picker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    (1..5).forEach { star ->
                        IconButton(onClick = { rating = star }) {
                            Icon(
                                imageVector = if (star <= rating) Icons.Filled.Star else Icons.Outlined.Star,
                                contentDescription = "$star نجوم",
                                tint = if (star <= rating) DzGold else Color.Gray,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("اكتب تعليقك ورأيك (اختياري)") },
                    placeholder = { Text("مثال: عمل ممتاز، دقيق في الموعد ونظيف...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .testTag("review_comment_input"),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isSubmitting = true
                    onSubmit(rating, comment.ifBlank { "خدمة جيدة ومتقنة" })
                },
                enabled = !isSubmitting,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("submit_review_btn")
            ) {
                Text("إرسال التقييم", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun ReportDialog(
    targetType: String,
    targetId: Long,
    targetName: String,
    reporterId: Long,
    reporterName: String,
    onDismiss: () -> Unit,
    onSubmitReport: (ReportEntity) -> Unit
) {
    var reason by remember { mutableStateOf("عدم الالتزام بالموعد أو الحضور") }
    var details by remember { mutableStateOf("") }
    val reasons = listOf(
        "عدم الالتزام بالموعد أو الحضور",
        "سوء المعاملة أو عدم الاحترافية",
        "طلب مبلغ مالي إضافي غير مبرر",
        "سوء في جودة العمل أو إتلاف أغراض",
        "حساب وهمي أو احتيالي",
        "الدفع أو التعامل خارج المنصة بطرق مشبوهة",
        "سبب آخر"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ReportProblem, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text(text = "الإبلاغ عن $targetName", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("اختر سبب الإبلاغ بدقة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                reasons.forEach { r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = reason == r,
                            onClick = { reason = r }
                        )
                        Text(text = r, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = details,
                    onValueChange = { details = it },
                    label = { Text("تفاصيل إضافية للإدارة") },
                    placeholder = { Text("اشرح ما حدث بدقة لمساعدة فريق الإدارة...") },
                    modifier = Modifier.fillMaxWidth().height(80.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val report = ReportEntity(
                        reporterId = reporterId,
                        reporterName = reporterName,
                        targetType = targetType,
                        targetId = targetId,
                        targetName = targetName,
                        reason = reason,
                        details = details,
                        status = ReportStatus.NEW
                    )
                    onSubmitReport(report)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إرسال البلاغ", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun FlagReviewDialog(
    reviewId: Long,
    reviewerName: String,
    onDismiss: () -> Unit,
    onSubmit: (reason: String) -> Unit
) {
    var reason by remember { mutableStateOf("تقييم غير حقيقي أو كيدي") }
    val reasons = listOf(
        "تقييم غير حقيقي أو كيدي",
        "ألفاظ غير لائقة أو تشهير",
        "ابتزاز أو محاولة إضرار بالسمعة",
        "تقييم لشخص آخر أو خدمة غير متعلقة"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.ReportProblem, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("الإبلاغ عن تقييم $reviewerName", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("سيقوم فريق الإدارة بمراجعة التقييم وحذفه إذا كان مخالفاً:", fontSize = 12.sp)
                Spacer(modifier = Modifier.height(8.dp))
                reasons.forEach { r ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = reason == r, onClick = { reason = r })
                        Text(text = r, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(reason) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إرسال للإدارة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun CraftsmanVerificationDialog(
    onDismiss: () -> Unit,
    onSubmit: (idCard: String, qualification: String, notes: String) -> Unit
) {
    var idCard by remember { mutableStateOf("") }
    var qualification by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = DzGreenPrimary)
                Text("طلب شارة الحرفي الموثوق 🛡️✓", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "شارة التوثيق تمنحك أولوية الظهور في نتائج البحث وثقة أكبر لدى الزبائن بعد مراجعة الإدارة لهويتك ومؤهلك.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = idCard,
                    onValueChange = { idCard = it },
                    label = { Text("رقم بطاقة التعريف البيومترية *") },
                    placeholder = { Text("18 رقماً") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = qualification,
                    onValueChange = { qualification = it },
                    label = { Text("رقم السجل الحرفي أو شهادة الكفاءة المهنية *") },
                    placeholder = { Text("مثال: سجل 16/00124 أو دبلوم تكوين مهني") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات أو مراجع إضافية") },
                    placeholder = { Text("مكان الحصول على الشهادة وسنوات الممارسة الفعلية...") },
                    modifier = Modifier.fillMaxWidth().height(80.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(idCard, qualification, notes) },
                enabled = idCard.isNotBlank() && qualification.isNotBlank(),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إرسال للمراجعة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AdminVerificationReviewDialog(
    request: VerificationRequestEntity,
    onDismiss: () -> Unit,
    onApprove: () -> Unit,
    onReject: (reason: String) -> Unit
) {
    var rejectReason by remember { mutableStateOf("") }
    var isRejectingMode by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = DzGreenPrimary)
                Text("مراجعة ملف توثيق الحرفي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("• الحرفي: ${request.professionalName}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("• المهنة: ${request.professionNameAr}", fontSize = 12.sp)
                        Text("• الولاية/البلدية: ${request.wilayaNameAr} - ${request.communeNameAr}", fontSize = 12.sp)
                        Text("• رقم الهاتف: ${request.phone}", fontSize = 12.sp)
                        Divider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("• رقم بطاقة التعريف: ${request.idCardNumber}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Text("• السجل/المؤهل: ${request.qualificationOrTradeRegister}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        if (request.documentNotes.isNotBlank()) {
                            Text("• ملاحظات الحرفي: ${request.documentNotes}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                if (isRejectingMode) {
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = rejectReason,
                        onValueChange = { rejectReason = it },
                        label = { Text("سبب الرفض للحرفي *") },
                        placeholder = { Text("مثال: رقم السجل غير واضح أو منتهي الصلاحية...") },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            if (!isRejectingMode) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = DzGreenPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("قبول ومنح الشارة")
                    }
                    OutlinedButton(
                        onClick = { isRejectingMode = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("رفض الملف")
                    }
                }
            } else {
                Button(
                    onClick = { onReject(rejectReason.ifBlank { "عدم مطابقة الوثائق للشروط" }) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("تأكيد الرفض")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )
}

@Composable
fun AdminRevokeVerificationDialog(
    professionalName: String,
    onDismiss: () -> Unit,
    onConfirmRevoke: (reason: String) -> Unit
) {
    var reason by remember { mutableStateOf("تكرار الشكاوى وسوء جودة الخدمة") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.GppBad, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("سحب شارة التوثيق", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "هل أنت متأكد من سحب شارة التوثيق من الحرفي $professionalName؟ سيتم تنبيه الحرفي وإزالة الشارة فوراً.",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("سبب سحب الشارة *") },
                    modifier = Modifier.fillMaxWidth().height(80.dp),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmRevoke(reason) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("تأكيد السحب", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun AiDiagnosisDialog(
    initialDescription: String = "",
    onDismiss: () -> Unit,
    onApplyCategory: (categoryKey: String) -> Unit
) {
    var problemInput by remember { mutableStateOf(initialDescription) }
    var diagnosisResult by remember { mutableStateOf<AiDiagnosisResult?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val aiService = remember { RuleBasedAiDiagnosticService() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = DzGreenPrimary)
                Text(text = "المساعد الذكي لتشخيص الأعطال 🇩🇿", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "صف المشكلة أو العطل وسيقوم النظام بتحديد المهنة المناسبة، درجة الاستعجال، وإرشادات السلامة الأولية:",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = problemInput,
                    onValueChange = { problemInput = it },
                    placeholder = { Text("مثال: عندي تسريب ماء تحت السخان في الحمام، أو قاطع الكهرباء يسقط كل ما أشغل المكيف...") },
                    modifier = Modifier.fillMaxWidth().height(90.dp),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        isAnalyzing = true
                        coroutineScope.launch {
                            diagnosisResult = aiService.analyzeProblem(problemInput)
                            isAnalyzing = false
                        }
                    },
                    enabled = problemInput.isNotBlank() && !isAnalyzing,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("تشخيص العطل الآن", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                diagnosisResult?.let { res ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("نتيجة التشخيص:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                            Text("• العطل: ${res.detectedProblem}", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text("• التكلفة التقديرية: ${res.estimatedRepairCostDzd}", fontSize = 12.sp)
                            Text("• درجة الاستعجال: ${res.estimatedUrgency}", fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("إرشادات السلامة الفورية:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                            res.safetyTips.forEach { tip ->
                                Text("⚠️ $tip", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (diagnosisResult != null) {
                Button(onClick = {
                    onApplyCategory(diagnosisResult!!.suggestedCategoryKey)
                    onDismiss()
                }) {
                    Text("اختيار المهنة المقترحة")
                }
            } else {
                TextButton(onClick = onDismiss) { Text("إغلاق") }
            }
        },
        dismissButton = {
            if (diagnosisResult != null) {
                TextButton(onClick = onDismiss) { Text("إلغاء") }
            }
        }
    )
}

