package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.CareTaskEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.DiagnosisEntity
import com.example.data.local.IssueReportEntity
import com.example.data.local.PlantEntity
import com.example.data.local.PlantGrowthEntryEntity
import com.example.data.model.DiseaseLibraryItem
import com.example.data.model.EncyclopediaPlant
import com.example.data.model.PlantEncyclopediaData
import com.example.data.model.UserProfile
import com.example.data.model.UserProfileManager
import com.example.data.remote.AgriculturalWeatherData
import com.example.data.remote.CityLocation
import com.example.data.remote.DiagnosticLogEntry
import com.example.data.remote.GeminiService
import com.example.data.remote.PlantDiagnosisResult
import com.example.data.remote.WeatherService
import com.example.data.repository.PlantRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Diagnose : Screen("diagnose")
    data object DiagnosisDetail : Screen("diagnosis_detail")
    data object Chat : Screen("chat")
    data object MyPlants : Screen("my_plants")
    data object PlantDetail : Screen("plant_detail")
    data object AddEditPlant : Screen("add_edit_plant")
    data object CareSchedule : Screen("care_schedule")
    data object Encyclopedia : Screen("encyclopedia")
    data object EncyclopediaDetail : Screen("encyclopedia_detail")
    data object Weather : Screen("weather")
    data object Profile : Screen("profile")
    data object CompareHistory : Screen("compare_history")
    data object AdminGuidance : Screen("admin_guidance")
}

class PlantDoctorViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = PlantRepository(database)
    private val profileManager = UserProfileManager(application)

    // Current Screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Navigation back stack for BackHandler
    private val screenStack = mutableListOf<Screen>(Screen.Home)

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            return true
        }
        return false
    }

    // Data streams
    val plants: StateFlow<List<PlantEntity>> = repository.getAllPlants()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTasks: StateFlow<List<CareTaskEntity>> = repository.getPendingTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedTasks: StateFlow<List<CareTaskEntity>> = repository.getCompletedTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val diagnoses: StateFlow<List<DiagnosisEntity>> = repository.getAllDiagnoses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentDiagnoses: StateFlow<List<DiagnosisEntity>> = repository.getRecentDiagnoses(5)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.getAllChatMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfile> = profileManager.userProfile

    // Selected plant & diagnosis for detail screens
    private val _selectedPlant = MutableStateFlow<PlantEntity?>(null)
    val selectedPlant: StateFlow<PlantEntity?> = _selectedPlant.asStateFlow()

    private val _selectedDiagnosis = MutableStateFlow<DiagnosisEntity?>(null)
    val selectedDiagnosis: StateFlow<DiagnosisEntity?> = _selectedDiagnosis.asStateFlow()

    private val _selectedEncyclopediaPlant = MutableStateFlow<EncyclopediaPlant?>(null)
    val selectedEncyclopediaPlant: StateFlow<EncyclopediaPlant?> = _selectedEncyclopediaPlant.asStateFlow()

    private val _selectedDiseaseItem = MutableStateFlow<DiseaseLibraryItem?>(null)
    val selectedDiseaseItem: StateFlow<DiseaseLibraryItem?> = _selectedDiseaseItem.asStateFlow()

    // Active Diagnosis In-Progress State
    private val _selectedImageFile = MutableStateFlow<File?>(null)
    val selectedImageFile: StateFlow<File?> = _selectedImageFile.asStateFlow()

    // Additional images for multi-photo diagnosis (leaf, stem, fruit)
    private val _additionalImages = MutableStateFlow<List<File>>(emptyList())
    val additionalImages: StateFlow<List<File>> = _additionalImages.asStateFlow()

    private val _isDiagnosing = MutableStateFlow(false)
    val isDiagnosing: StateFlow<Boolean> = _isDiagnosing.asStateFlow()

    private val _diagnosisError = MutableStateFlow<String?>(null)
    val diagnosisError: StateFlow<String?> = _diagnosisError.asStateFlow()

    private val _currentDiagnosisResult = MutableStateFlow<PlantDiagnosisResult?>(null)
    val currentDiagnosisResult: StateFlow<PlantDiagnosisResult?> = _currentDiagnosisResult.asStateFlow()

    // Form inputs state preservation across failures and navigation
    private val _diagnosisPlantTypeInput = MutableStateFlow("")
    val diagnosisPlantTypeInput: StateFlow<String> = _diagnosisPlantTypeInput.asStateFlow()

    private val _diagnosisLocation = MutableStateFlow("حديقة")
    val diagnosisLocation: StateFlow<String> = _diagnosisLocation.asStateFlow()

    private val _diagnosisAffectedPart = MutableStateFlow("الأوراق")
    val diagnosisAffectedPart: StateFlow<String> = _diagnosisAffectedPart.asStateFlow()

    private val _diagnosisUserSymptoms = MutableStateFlow("")
    val diagnosisUserSymptoms: StateFlow<String> = _diagnosisUserSymptoms.asStateFlow()

    val lastDiagnosticLog: StateFlow<DiagnosticLogEntry?> = GeminiService.lastDiagnosticLog

    fun setDiagnosisPlantType(value: String) { _diagnosisPlantTypeInput.value = value }
    fun setDiagnosisLocation(value: String) { _diagnosisLocation.value = value }
    fun setDiagnosisAffectedPart(value: String) { _diagnosisAffectedPart.value = value }
    fun setDiagnosisUserSymptoms(value: String) { _diagnosisUserSymptoms.value = value }

    // Weather State: initialized from user's saved wilaya if available, otherwise null until selected
    private fun getInitialCity(): CityLocation? {
        val savedWilaya = profileManager.userProfile.value.wilayaOrCity
        if (savedWilaya.isNotBlank()) {
            return WeatherService.allWilayas.find {
                it.name.contains(savedWilaya, ignoreCase = true) ||
                it.nameFrench.contains(savedWilaya, ignoreCase = true)
            }
        }
        return null
    }

    private val _selectedCity = MutableStateFlow<CityLocation?>(getInitialCity())
    val selectedCity: StateFlow<CityLocation?> = _selectedCity.asStateFlow()

    private val _weatherData = MutableStateFlow<AgriculturalWeatherData?>(null)
    val weatherData: StateFlow<AgriculturalWeatherData?> = _weatherData.asStateFlow()

    private val _isWeatherLoading = MutableStateFlow(false)
    val isWeatherLoading: StateFlow<Boolean> = _isWeatherLoading.asStateFlow()

    private val _weatherError = MutableStateFlow<String?>(null)
    val weatherError: StateFlow<String?> = _weatherError.asStateFlow()

    // Chat in-progress state
    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private val _chatInputText = MutableStateFlow("")
    val chatInputText: StateFlow<String> = _chatInputText.asStateFlow()

    private val _chatAttachedImage = MutableStateFlow<File?>(null)
    val chatAttachedImage: StateFlow<File?> = _chatAttachedImage.asStateFlow()

    private val _activeChatPlantContext = MutableStateFlow<String?>(null)
    val activeChatPlantContext: StateFlow<String?> = _activeChatPlantContext.asStateFlow()

    // Daily Agricultural Advice
    val dailyAdvice = listOf(
        "💧 نصيحة اليوم: أفضل وقت لري الخضروات والأشجار المثمرة في الصيف هو ساعات الصباح الباكر قبل اشتداد حرارة الشمس لتجنب صدمة الجذور وتبخر الماء السريع.",
        "🫒 نصيحة الزيتون: بعد موجات الأمطار الربيعية، افحص أوراق الزيتون لتفادي مرض عين الطاووس ورش مركبات النحاس الوقائية عند ظهور أول بقعة رمادية.",
        "🍅 نصيحة الطماطم: للوقاية من عفن الطرف الزهري الأسود أسفل ثمار الطماطم، حافظ على انتظام الري وتجنب جفاف التربة المفاجئ مع رش سماد الكالسيوم الورقي.",
        "🌱 نصيحة التسميد: تجنب الإفراط في التسميد النيتروجيني (الآزوتي) وقت التزهير لأنه يؤدي لنمو خضري مفرط على حساب عقد الثمار وضعف مقاومة النبات للآفات.",
        "🪴 نصيحة النباتات المنزلية: أكثر من 70% من موت النباتات المنزلية سببه كثرة الري وليس العطش! لا تسقِ نباتك إلا بعد التأكد من جفاف أعلى 3 سم من التربة."
    ).random()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
            _selectedCity.value?.let { loadWeatherForCity(it) }
        }
    }

    fun setSelectedPlant(plant: PlantEntity?) {
        _selectedPlant.value = plant
    }

    fun setSelectedDiagnosis(diagnosis: DiagnosisEntity?) {
        _selectedDiagnosis.value = diagnosis
    }

    fun setSelectedEncyclopediaPlant(plant: EncyclopediaPlant?) {
        _selectedEncyclopediaPlant.value = plant
    }

    fun setSelectedDiseaseItem(disease: DiseaseLibraryItem?) {
        _selectedDiseaseItem.value = disease
    }

    fun setImageForDiagnosis(file: File?) {
        _selectedImageFile.value = file
        _diagnosisError.value = null
    }

    fun addAdditionalImage(file: File) {
        val current = _additionalImages.value.toMutableList()
        if (current.size < 3) {
            current.add(file)
            _additionalImages.value = current
        }
    }

    fun removeAdditionalImage(index: Int) {
        val current = _additionalImages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _additionalImages.value = current
        }
    }

    fun clearAdditionalImages() {
        _additionalImages.value = emptyList()
    }

    fun copyUriToLocalCache(context: Context, uri: Uri): File? {
        return try {
            val contentResolver = context.contentResolver
            val inputStream = contentResolver.openInputStream(uri) ?: return null
            val file = File(context.cacheDir, "plant_capture_${System.currentTimeMillis()}.jpg")
            val outputStream = FileOutputStream(file)
            inputStream.copyTo(outputStream)
            inputStream.close()
            outputStream.close()
            file
        } catch (e: Exception) {
            null
        }
    }

    fun startPlantDiagnosis(
        plantTypeInput: String = _diagnosisPlantTypeInput.value,
        location: String = _diagnosisLocation.value,
        affectedPart: String = _diagnosisAffectedPart.value,
        userSymptoms: String = _diagnosisUserSymptoms.value
    ) {
        if (_isDiagnosing.value) return // Prevent duplicate concurrent submissions

        // Persist form inputs in ViewModel so retry or orientation change never clears them
        _diagnosisPlantTypeInput.value = plantTypeInput
        _diagnosisLocation.value = location
        _diagnosisAffectedPart.value = affectedPart
        _diagnosisUserSymptoms.value = userSymptoms

        val file = _selectedImageFile.value
        if (file == null || !file.exists()) {
            _diagnosisError.value = "يرجى التقاط صورة أو اختيار صورة من المعرض أولاً."
            return
        }

        if (!profileManager.canMakeAiRequest()) {
            _diagnosisError.value = "لقد استنفدت الحد اليومي لفحوصات الذكاء الاصطناعي (${profileManager.userProfile.value.dailyAiQuotaLimit}/15). يتجدد الرصيد غداً بإذن الله لحماية الحصة المجانية."
            return
        }

        viewModelScope.launch {
            _isDiagnosing.value = true
            _diagnosisError.value = null

            val result = GeminiService.diagnosePlant(
                imageFile = file,
                additionalImages = _additionalImages.value,
                plantTypeInput = plantTypeInput,
                plantLocation = location,
                affectedPart = affectedPart,
                userSymptoms = userSymptoms,
                customProxyUrl = profileManager.userProfile.value.customProxyUrl.ifBlank { null }
            )

            result.onSuccess { diagnosisResult ->
                profileManager.recordAiRequest()
                _currentDiagnosisResult.value = diagnosisResult
                _isDiagnosing.value = false

                val additionalPaths = _additionalImages.value.joinToString(";") { it.absolutePath }
                val clarifyingStr = diagnosisResult.clarifyingQuestions.joinToString(";;")

                // Automatically save into database
                val entity = DiagnosisEntity(
                    plantCommonName = diagnosisResult.plantCommonName,
                    plantScientificName = diagnosisResult.plantScientificName,
                    generalHealth = diagnosisResult.generalHealth,
                    diseaseName = diagnosisResult.diseaseName,
                    scientificDiseaseName = diagnosisResult.scientificDiseaseName,
                    confidenceLevel = diagnosisResult.confidenceLevel,
                    severity = diagnosisResult.severity,
                    urgency = diagnosisResult.urgency,
                    affectedPart = diagnosisResult.affectedPart,
                    symptomsSummary = diagnosisResult.symptomsSummary,
                    possibleCauses = diagnosisResult.possibleCauses,
                    alternativeDiagnoses = diagnosisResult.alternativeDiagnoses,
                    environmentalFactors = diagnosisResult.environmentalFactors,
                    immediateActions = diagnosisResult.immediateActions,
                    preventiveCare = diagnosisResult.preventiveCare,
                    chemicalTreatments = diagnosisResult.chemicalTreatments,
                    imagePath = file.absolutePath,
                    additionalImages = additionalPaths,
                    pathogenType = diagnosisResult.pathogenType,
                    clarifyingQuestions = clarifyingStr,
                    scientificSources = diagnosisResult.scientificSources,
                    advisoryNote = diagnosisResult.advisoryNote
                )
                val newId = repository.insertDiagnosis(entity)
                _selectedDiagnosis.value = entity.copy(id = newId)
                navigateTo(Screen.DiagnosisDetail)
            }.onFailure { error ->
                _isDiagnosing.value = false
                _diagnosisError.value = error.message ?: "حدث خطأ أثناء فحص الصورة"
                // Crucial: we do NOT clear _selectedImageFile, _additionalImages, or the input fields
            }
        }
    }

    fun retryPlantDiagnosis() {
        startPlantDiagnosis()
    }

    fun setChatInputText(text: String) {
        _chatInputText.value = text
    }

    fun setChatAttachedImage(file: File?) {
        _chatAttachedImage.value = file
    }

    fun askDoctorAboutPlant(plant: PlantEntity) {
        val contextInfo = "النبات: ${plant.name} (${plant.scientificName}), النوع: ${plant.plantType}, المكان: ${plant.location}, جدول الري: كل ${plant.wateringIntervalDays} أيام, الملاحظات: ${plant.notes}"
        _activeChatPlantContext.value = contextInfo
        _chatInputText.value = "أريد استشارة حول نبتتي '${plant.name}'، ما هي أفضل خطة للعناية بها حالياً؟"
        navigateTo(Screen.Chat)
    }

    fun clearActiveChatPlantContext() {
        _activeChatPlantContext.value = null
    }

    fun sendChatMessage(promptText: String? = null) {
        val text = (promptText ?: _chatInputText.value).trim()
        val image = _chatAttachedImage.value
        if (text.isBlank() && image == null) return

        if (!profileManager.canMakeAiRequest()) {
            viewModelScope.launch {
                val quotaMsg = ChatMessageEntity(
                    sender = "assistant",
                    text = "وصلت للحد اليومي لرسائل المساعد الذكي (${profileManager.userProfile.value.dailyAiQuotaLimit}/15). يتجدد الرصيد عند منتصف الليل لحماية الحصة المجانية. 🌱"
                )
                repository.insertChatMessage(quotaMsg)
            }
            return
        }

        viewModelScope.launch {
            val userMsg = ChatMessageEntity(
                sender = "user",
                text = text.ifBlank { "حلل لي هذه الصورة المرفقة لنباتي" },
                imagePath = image?.absolutePath
            )
            repository.insertChatMessage(userMsg)
            _chatInputText.value = ""
            _chatAttachedImage.value = null
            _isChatLoading.value = true

            // Prepare conversation context
            val history = chatMessages.value.map { Pair(it.sender, it.text) }

            val responseResult = GeminiService.chatWithDoctor(
                messages = history,
                newPrompt = userMsg.text,
                imageFile = image,
                plantContext = _activeChatPlantContext.value,
                customProxyUrl = profileManager.userProfile.value.customProxyUrl.ifBlank { null }
            )

            responseResult.onSuccess { (answer, followUps) ->
                profileManager.recordAiRequest()
                val assistantMsg = ChatMessageEntity(
                    sender = "assistant",
                    text = answer,
                    followUpQuestions = followUps.joinToString(",")
                )
                repository.insertChatMessage(assistantMsg)
                _isChatLoading.value = false
            }.onFailure { err ->
                val fallbackMsg = ChatMessageEntity(
                    sender = "assistant",
                    text = "عذراً يا طيب، تعذر الاتصال بالذكاء الاصطناعي حالياً (${err.message}). يمكنك التحقق من اتصال الإنترنت وضبط مفتاح GEMINI_API_KEY في لوحة Secrets."
                )
                repository.insertChatMessage(fallbackMsg)
                _isChatLoading.value = false
            }
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
        }
    }

    // Plant Growth Journal
    fun getGrowthEntriesForPlant(plantId: Long): Flow<List<PlantGrowthEntryEntity>> {
        return repository.getGrowthEntriesForPlant(plantId)
    }

    fun addGrowthEntry(plantId: Long, imagePath: String, stage: String, heightCm: Double?, notes: String) {
        viewModelScope.launch {
            repository.insertGrowthEntry(
                PlantGrowthEntryEntity(
                    plantId = plantId,
                    imagePath = imagePath,
                    stageTitle = stage,
                    heightCm = heightCm,
                    notes = notes
                )
            )
        }
    }

    fun deleteGrowthEntry(entry: PlantGrowthEntryEntity) {
        viewModelScope.launch {
            repository.deleteGrowthEntry(entry)
        }
    }

    // Previous Diagnoses for Plant Comparison
    fun getPreviousDiagnosesForPlant(plantName: String): Flow<List<DiagnosisEntity>> {
        return repository.getDiagnosesByPlantName(plantName)
    }

    // Issue Reporting
    fun reportDiagnosisIssue(diagnosisId: Long?, userFeedback: String, contactEmail: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            repository.insertIssueReport(
                IssueReportEntity(
                    diagnosisId = diagnosisId,
                    issueType = "تشخيص غير دقيق",
                    userComment = userFeedback,
                    contactEmail = contactEmail
                )
            )
            onSuccess()
        }
    }

    fun completeTask(taskId: Long) {
        viewModelScope.launch {
            repository.markTaskCompleted(taskId)
        }
    }

    fun saveCareTask(task: CareTaskEntity) {
        viewModelScope.launch {
            repository.insertTask(task)
        }
    }

    fun saveOrUpdatePlant(
        id: Long = 0,
        name: String,
        scientificName: String,
        type: String,
        location: String,
        imagePath: String,
        wateringDays: Int,
        fertilizingDays: Int,
        notes: String
    ) {
        viewModelScope.launch {
            val plant = PlantEntity(
                id = id,
                name = name,
                scientificName = scientificName,
                plantType = type,
                location = location,
                imagePath = imagePath,
                wateringIntervalDays = wateringDays,
                fertilizingIntervalDays = fertilizingDays,
                notes = notes
            )
            if (id == 0L) {
                repository.insertPlant(plant)
            } else {
                repository.updatePlant(plant)
            }
            navigateTo(Screen.MyPlants)
        }
    }

    fun deletePlant(plant: PlantEntity) {
        viewModelScope.launch {
            repository.deletePlant(plant)
            navigateTo(Screen.MyPlants)
        }
    }

    fun updateDiagnosisFollowUp(diagnosisId: Long, secondImagePath: String, notes: String, rating: Int) {
        viewModelScope.launch {
            val existing = repository.getDiagnosisById(diagnosisId)
            if (existing != null) {
                val updated = existing.copy(
                    secondImagePath = secondImagePath.ifBlank { existing.secondImagePath },
                    followUpNotes = notes,
                    improvementRating = rating
                )
                repository.updateDiagnosis(updated)
                _selectedDiagnosis.value = updated
            }
        }
    }

    fun selectWilaya(city: CityLocation) {
        _selectedCity.value = city
        val p = profileManager.userProfile.value
        profileManager.updateProfile(
            name = p.name,
            email = p.email,
            wilaya = city.name,
            farmingType = p.farmingType,
            language = p.preferredLanguage,
            notifications = p.notificationsEnabled
        )
        loadWeatherForCity(city)
    }

    fun loadWeatherForCity(city: CityLocation) {
        viewModelScope.launch {
            _isWeatherLoading.value = true
            _weatherError.value = null
            val result = WeatherService.fetchWeather(city)
            result.onSuccess {
                _weatherData.value = it
                _isWeatherLoading.value = false
            }.onFailure { err ->
                _weatherError.value = err.message ?: "تعذر جلب بيانات الطقس"
                _isWeatherLoading.value = false
            }
        }
    }

    fun toggleFavorite(itemId: String) {
        profileManager.toggleFavorite(itemId)
    }

    fun isFavorite(itemId: String): Boolean {
        return profileManager.isFavorite(itemId)
    }

    fun addRecentView(title: String) {
        profileManager.addRecentView(title)
    }

    fun setPreferredLanguage(lang: String) {
        profileManager.setPreferredLanguage(lang)
    }

    fun setCustomProxy(url: String) {
        profileManager.setCustomProxy(url)
    }

    fun updateUserProfile(name: String, email: String, wilaya: String, farmingType: String, lang: String, notifs: Boolean) {
        profileManager.updateProfile(name, email, wilaya, farmingType, lang, notifs)
    }

    fun shareDiagnosisReport(context: Context, diagnosis: DiagnosisEntity) {
        val report = """
📋 تقرير فحص نباتي - طبيب النباتات (Plant Doctor AI)
🌱 اسم النبات: ${diagnosis.plantCommonName} (${diagnosis.plantScientificName})
⚠️ التشخيص: ${diagnosis.diseaseName}
🔬 المسبب العلمي: ${diagnosis.scientificDiseaseName}
🏷️ نوع المسبب: ${diagnosis.pathogenType}
📊 درجة اليقين: ${diagnosis.confidenceLevel} | درجة الخطورة: ${diagnosis.severity}
⏱️ سرعة التدخل: ${diagnosis.urgency}

🔍 ملخص الأعراض:
${diagnosis.symptomsSummary}

💡 الأسباب المحتملة:
${diagnosis.possibleCauses}

⚡ التدخل الفوري المقترح:
${diagnosis.immediateActions}

🛡️ الوقاية وطرق العناية الزراعية (IPM):
${diagnosis.preventiveCare}

💊 المواد الفعالة والعلاج الموصى به:
${diagnosis.chemicalTreatments}

📚 المرجع العلمي المعتمد:
${diagnosis.scientificSources.ifBlank { "المعهد الوطني الجزائري للأبحاث الزراعية (INRAA) / دليل FAO" }}

⚠️ تنبيه إرشادي:
${diagnosis.advisoryNote.ifBlank { "نتائج التشخيص إرشادية بالذكاء الاصطناعي، يرجى استشارة مهندس زراعي قبل استخدام مبيدات كيميائية مكثفة." }}
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "تقرير تشخيص: ${diagnosis.plantCommonName} - ${diagnosis.diseaseName}")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة تقرير الفحص"))
    }
}
