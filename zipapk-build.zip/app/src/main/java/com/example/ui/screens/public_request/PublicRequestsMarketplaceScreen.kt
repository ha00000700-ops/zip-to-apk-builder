package com.example.ui.screens.public_request

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Surface
import androidx.compose.material3.Divider
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.ArrowForward
import com.example.ui.theme.TextPrimaryLight
import com.example.ui.theme.TextSecondaryLight
import com.example.ui.theme.TextTertiaryLight
import com.example.ui.theme.OutlineLight
import com.example.ui.theme.SuccessGreen
import com.example.data.model.AlgerianLocationData
import com.example.data.model.ProfessionData
import com.example.data.model.PublicRequestStatus
import com.example.data.model.PublicServiceRequest
import com.example.data.repository.AuthResult
import com.example.ui.components.KhedmatiTopBar
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.BlueContainer
import com.example.ui.theme.BlueDark
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.viewmodel.AuthViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PublicRequestsMarketplaceScreen(
    authViewModel: AuthViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToRequestDetails: (String) -> Unit
) {
    val openRequestsState by authViewModel.openPublicRequestsState.collectAsState()
    val currentProviderProfile by authViewModel.currentProviderProfile.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedProfessionFilter by remember {
        // default to provider's profession if available
        mutableStateOf<String?>(currentProviderProfile?.professionId?.ifBlank { null })
    }
    var selectedWilayaCodeFilter by remember {
        mutableStateOf<Int?>(currentProviderProfile?.wilayaCode)
    }

    LaunchedEffect(Unit) {
        authViewModel.observeOpenPublicRequests()
    }

    Scaffold(
        topBar = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(listOf(BlueDark, BluePrimary)),
                            shape = RoundedCornerShape(bottomStart = 40.dp, bottomEnd = 40.dp)
                        )
                        .padding(top = 48.dp, bottom = 40.dp, start = 24.dp, end = 24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(18.dp))
                        
                        Column {
                            Text(
                                text = "سوق الطلبات العامة",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Text(
                                text = "تصفح طلبات الزبائن وقدم عروضك الآن",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث في الطلبات (العنوان، المدينة، التخصص...)") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BluePrimary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("search_public_requests_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BluePrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                )
            )

            // Profession Filters Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedProfessionFilter == null,
                    onClick = { selectedProfessionFilter = null },
                    label = { Text("جميع المهن") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BluePrimary,
                        selectedLabelColor = Color.White
                    )
                )

                ProfessionData.professions.take(12).forEach { prof ->
                    FilterChip(
                        selected = selectedProfessionFilter == prof.id,
                        onClick = {
                            selectedProfessionFilter = if (selectedProfessionFilter == prof.id) null else prof.id
                        },
                        label = { Text(prof.nameAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BluePrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Wilaya Filter Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedWilayaCodeFilter == null,
                    onClick = { selectedWilayaCodeFilter = null },
                    label = { Text("كل الولايات") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AmberPrimary,
                        selectedLabelColor = Color.White
                    )
                )

                if (currentProviderProfile != null && currentProviderProfile!!.wilayaCode > 0) {
                    FilterChip(
                        selected = selectedWilayaCodeFilter == currentProviderProfile!!.wilayaCode,
                        onClick = {
                            selectedWilayaCodeFilter = if (selectedWilayaCodeFilter == currentProviderProfile!!.wilayaCode) null else currentProviderProfile!!.wilayaCode
                        },
                        label = { Text("ولايتي (${currentProviderProfile!!.wilayaName})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }

                AlgerianLocationData.wilayas.take(15).forEach { wilaya ->
                    FilterChip(
                        selected = selectedWilayaCodeFilter == wilaya.code,
                        onClick = {
                            selectedWilayaCodeFilter = if (selectedWilayaCodeFilter == wilaya.code) null else wilaya.code
                        },
                        label = { Text(wilaya.nameAr) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Request List
            when (val state = openRequestsState) {
                is AuthResult.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = BluePrimary)
                    }
                }
                is AuthResult.Error -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = state.messageAr,
                            color = ErrorRed,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
                is AuthResult.Success -> {
                    val allRequests = state.data
                    val filteredRequests = remember(allRequests, searchQuery, selectedProfessionFilter, selectedWilayaCodeFilter) {
                        allRequests.filter { req ->
                            val matchesSearch = searchQuery.isBlank() ||
                                    req.title.contains(searchQuery, ignoreCase = true) ||
                                    req.description.contains(searchQuery, ignoreCase = true) ||
                                    req.communeName.contains(searchQuery, ignoreCase = true) ||
                                    req.wilayaName.contains(searchQuery, ignoreCase = true) ||
                                    req.professionNameAr.contains(searchQuery, ignoreCase = true)

                            val matchesProfession = selectedProfessionFilter == null || req.professionId == selectedProfessionFilter
                            val matchesWilaya = selectedWilayaCodeFilter == null || req.wilayaCode == selectedWilayaCodeFilter

                            matchesSearch && matchesProfession && matchesWilaya
                        }
                    }

                    if (filteredRequests.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.HourglassEmpty,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا توجد طلبات خدمة عامة مطابقة حالياً",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "سيتم تحديث القائمة تلقائياً فور نشر زبائن منطقتك لطلبات جديدة.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filteredRequests, key = { it.id }) { req ->
                                PublicRequestCard(
                                    request = req,
                                    onClick = { onNavigateToRequestDetails(req.id) }
                                )
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
fun PublicRequestCard(
    request: PublicServiceRequest,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("ar")) }
    val formattedDate = remember(request.createdAt) { dateFormat.format(Date(request.createdAt)) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.05f)),
        shadowElevation = 2.dp
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Profession Badge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = BlueContainer.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, BluePrimary.copy(alpha = 0.1f))
                ) {
                    Text(
                        text = request.professionNameAr,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = BluePrimary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                // Offers count badge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AmberLight.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, AmberPrimary.copy(alpha = 0.1f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, tint = AmberPrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${request.offersCount} عروض",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = request.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = BlueDark,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = request.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondaryLight,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Divider(color = OutlineLight.copy(alpha = 0.1f))

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = TextTertiaryLight,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${request.communeName}، ${request.wilayaName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondaryLight,
                        fontWeight = FontWeight.Medium
                    )
                }

                if (request.budgetDzd != null && request.budgetDzd > 0) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SuccessGreen.copy(alpha = 0.05f)
                    ) {
                        Text(
                            text = "${request.budgetDzd} د.ج",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = SuccessGreen,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                } else {
                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiaryLight
                    )
                }
            }
        }
    }
}
