package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    romanticTheme: RomanticTheme = RomanticTheme.ROSE_RUBY,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = romanticTheme.primary,
            onPrimary = Color.White,
            primaryContainer = romanticTheme.primary.copy(alpha = 0.35f),
            onPrimaryContainer = Color.White,
            secondary = romanticTheme.secondary,
            onSecondary = Color.White,
            tertiary = romanticTheme.tertiary,
            background = WineBackground,
            surface = WineSurface,
            surfaceVariant = WineSurfaceVariant,
            onBackground = Color(0xFFFFF0F5),
            onSurface = Color(0xFFFFF0F5),
            onSurfaceVariant = SoftPinkText
        )
    } else {
        lightColorScheme(
            primary = romanticTheme.primary,
            onPrimary = Color.White,
            primaryContainer = romanticTheme.primaryContainer,
            onPrimaryContainer = romanticTheme.primary,
            secondary = romanticTheme.secondary,
            onSecondary = Color.White,
            tertiary = romanticTheme.tertiary,
            background = romanticTheme.background,
            surface = romanticTheme.surface,
            surfaceVariant = romanticTheme.surfaceVariant,
            onBackground = TextDark,
            onSurface = TextDark,
            onSurfaceVariant = TextMuted
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
