package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = AgriGreenDark,
    onPrimary = Color.White,
    primaryContainer = AgriGreenMint,
    onPrimaryContainer = Color(0xFF052E16),
    secondary = AgriGreenEmerald,
    onSecondary = Color.White,
    secondaryContainer = AgriGreenContainer,
    onSecondaryContainer = Color(0xFF0F3B1E),
    tertiary = SoilAmber,
    onTertiary = Color.White,
    tertiaryContainer = SoilAmberLight,
    onTertiaryContainer = Color(0xFF451A03),
    background = AgriGreenBackground,
    onBackground = Color(0xFF0F1713),
    surface = AgriSurface,
    onSurface = Color(0xFF0F1713),
    surfaceVariant = Color(0xFFE8F0E9),
    onSurfaceVariant = Color(0xFF3B4A40),
    outline = Color(0xFF718276),
    error = AlertRed,
    errorContainer = AlertRedLight,
    onError = Color.White,
    onErrorContainer = Color(0xFF7F1D1D)
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = AgriGreenMint,
    secondary = Color(0xFF86EFAC),
    onSecondary = Color(0xFF052E16),
    secondaryContainer = Color(0xFF14532D),
    onSecondaryContainer = Color(0xFFDCFCE7),
    tertiary = Color(0xFFFBBF24),
    onTertiary = Color(0xFF451A03),
    tertiaryContainer = Color(0xFF78350F),
    onTertiaryContainer = Color(0xFFFEF3C7),
    background = DarkBackground,
    onBackground = Color(0xFFF1F5F2),
    surface = DarkSurface,
    onSurface = Color(0xFFF1F5F2),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFCBD5CE),
    outline = Color(0xFF839488),
    error = Color(0xFFF87171),
    errorContainer = Color(0xFF7F1D1D),
    onError = Color(0xFF450A0A),
    onErrorContainer = Color(0xFFFEE2E2)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep brand botanical green as default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
