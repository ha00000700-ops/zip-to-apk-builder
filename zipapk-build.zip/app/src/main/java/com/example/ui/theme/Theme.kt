package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF5B86F5),
    onPrimary = Color(0xFF0A193F),
    primaryContainer = SleekBlueDark,
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFF34D399),
    onSecondary = Color(0xFF064E3B),
    secondaryContainer = Color(0xFF065F46),
    onSecondaryContainer = Color(0xFFA7F3D0),
    tertiary = Color(0xFFFBBF24),
    onTertiary = Color(0xFF451A03),
    background = SleekDarkBg,
    onBackground = Color(0xFFF8FAFC),
    surface = SleekDarkSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = SleekDarkSurfaceVariant,
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = SleekBorderDark
)

private val LightColorScheme = lightColorScheme(
    primary = SleekBluePrimary,
    onPrimary = Color.White,
    primaryContainer = SleekBlueContainer,
    onPrimaryContainer = SleekBlueOnContainer,
    secondary = SleekEmerald,
    onSecondary = Color.White,
    secondaryContainer = SleekEmeraldContainer,
    onSecondaryContainer = SleekEmeraldOnContainer,
    tertiary = SleekGold,
    onTertiary = Color.White,
    tertiaryContainer = SleekGoldContainer,
    onTertiaryContainer = SleekGoldOnContainer,
    background = SleekLightBg,
    onBackground = SleekTextPrimary,
    surface = SleekLightSurface,
    onSurface = SleekTextPrimary,
    surfaceVariant = SleekLightSurfaceVariant,
    onSurfaceVariant = SleekTextSecondary,
    outline = SleekBorderLight
)

@Composable
fun KhdemliTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

