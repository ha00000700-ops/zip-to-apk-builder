package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = RoseLight,
    onPrimary = Color.White,
    primaryContainer = RoseDark,
    onPrimaryContainer = Color.White,
    secondary = BlushSecondary,
    onSecondary = Color.White,
    tertiary = PeachTertiary,
    background = WineBackground,
    surface = WineSurface,
    surfaceVariant = WineSurfaceVariant,
    onBackground = Color(0xFFFFF0F5),
    onSurface = Color(0xFFFFF0F5),
    onSurfaceVariant = SoftPinkText
)

private val LightColorScheme = lightColorScheme(
    primary = RosePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE4E6),
    onPrimaryContainer = RoseDark,
    secondary = BlushSecondary,
    onSecondary = Color.White,
    tertiary = PeachTertiary,
    background = Color(0xFFFFF7F8),
    surface = Color.White,
    surfaceVariant = RoseSurface,
    onBackground = TextDark,
    onSurface = TextDark,
    onSurfaceVariant = TextMuted
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve our signature romantic palette
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
