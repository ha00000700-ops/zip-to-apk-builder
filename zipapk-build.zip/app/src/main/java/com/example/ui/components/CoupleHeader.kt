package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.RoseLight
import com.example.ui.theme.RosePrimary

@Composable
fun CoupleHeader(
    userName: String,
    partnerName: String,
    userCityName: String,
    partnerCityName: String,
    userTemp: Double?,
    partnerTemp: Double?,
    userAvatarUri: String?,
    partnerAvatarUri: String?,
    onEditUser: () -> Unit,
    onEditPartner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "heartBeat")
    val heartScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartPulse"
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("couple_header"),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, RoseLight.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // User Profile (Left / Start in RTL)
                CoupleAvatarItem(
                    name = userName,
                    city = userCityName,
                    temp = userTemp,
                    avatarUri = userAvatarUri,
                    defaultDrawable = R.drawable.img_avatar_him,
                    roleLabel = "أنا",
                    ringColor = Color(0xFF38BDF8),
                    onClick = onEditUser,
                    modifier = Modifier.weight(1f).testTag("avatar_user")
                )

                // Beating Heart in center
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    listOf(RoseLight.copy(alpha = 0.4f), Color.Transparent)
                                ),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "نبض القلوب",
                            tint = RosePrimary,
                            modifier = Modifier
                                .size(28.dp)
                                .scale(heartScale)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "معاً دائماً",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = RosePrimary
                    )
                }

                // Partner Profile (Right / End in RTL)
                CoupleAvatarItem(
                    name = partnerName,
                    city = partnerCityName,
                    temp = partnerTemp,
                    avatarUri = partnerAvatarUri,
                    defaultDrawable = R.drawable.img_avatar_her,
                    roleLabel = "حبيبتي",
                    ringColor = Color(0xFFF43F5E),
                    onClick = onEditPartner,
                    modifier = Modifier.weight(1f).testTag("avatar_partner")
                )
            }

            // Connection Weather Hint
            if (userTemp != null && partnerTemp != null) {
                Spacer(modifier = Modifier.height(12.dp))
                val tempDiff = kotlin.math.round((partnerTemp - userTemp) * 10) / 10.0
                val remark = when {
                    tempDiff > 2.0 -> "الطقس عند $partnerName أدفى بـ $tempDiff°C، دفيها بكلمة حنينة! ☀️"
                    tempDiff < -2.0 -> "الطقس عند $partnerName أبرد بـ ${-tempDiff}°C، ابعثلها حضن دافئ! 🧣"
                    else -> "درجة الحرارة متقاربة بينكما ($userTemp°C)، سماء واحدة تجمع قلبيكما! 🕊️"
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = remark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun CoupleAvatarItem(
    name: String,
    city: String,
    temp: Double?,
    avatarUri: String?,
    defaultDrawable: Int,
    roleLabel: String,
    ringColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(76.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            // Main Circular Avatar
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .border(
                        border = BorderStroke(2.5.dp, Brush.sweepGradient(listOf(ringColor, RosePrimary, ringColor))),
                        shape = CircleShape
                    )
                    .padding(3.dp)
                    .clip(CircleShape)
            ) {
                if (avatarUri != null) {
                    AsyncImage(
                        model = Uri.parse(avatarUri),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Image(
                        painter = painterResource(id = defaultDrawable),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                    )
                }
            }

            // Edit badge
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .background(RosePrimary, CircleShape)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = name,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )

        Text(
            text = city,
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )

        if (temp != null) {
            Text(
                text = "${temp.toInt()}°C",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = RosePrimary
            )
        }
    }
}
