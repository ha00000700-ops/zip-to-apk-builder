package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CityInfo
import kotlinx.coroutines.launch
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun CoupleHeader(
    userName: String,
    partnerName: String,
    userCity: CityInfo?,
    partnerCity: CityInfo?,
    userTemp: Double?,
    partnerTemp: Double?,
    userAvatarUri: String?,
    partnerAvatarUri: String?,
    onEditUser: () -> Unit,
    onEditPartner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "heartBeatPulse")
    val heartScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.22f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "heartPulse"
    )

    // Interactive Heart Touch ("لمسة القلوب")
    val scope = rememberCoroutineScope()
    var heartTapCount by remember { mutableIntStateOf(0) }
    val rippleScale = remember { Animatable(1f) }
    val rippleAlpha = remember { Animatable(0f) }
    var showLoveBurst by remember { mutableStateOf(false) }

    // Distance calculation (Haversine formula)
    val distanceKm = remember(userCity, partnerCity) {
        if (userCity != null && partnerCity != null) {
            calculateDistanceKm(
                userCity.latitude, userCity.longitude,
                partnerCity.latitude, partnerCity.longitude
            )
        } else 360
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("couple_header"),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f)
        ),
        border = BorderStroke(
            1.dp,
            Brush.horizontalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
                )
            )
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // User Avatar (Right side in RTL)
                ModernCoupleAvatarItem(
                    name = userName,
                    cityName = userCity?.name ?: "الجزائر",
                    temp = userTemp,
                    avatarUri = userAvatarUri,
                    defaultDrawable = R.drawable.img_avatar_him,
                    roleLabel = "أنا",
                    glowColor = Color(0xFF38BDF8),
                    onClick = onEditUser,
                    modifier = Modifier.weight(1f).testTag("avatar_user")
                )

                // Interactive Center: Virtual Heartbeat Touch (لمسة القلوب)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                heartTapCount++
                                showLoveBurst = true
                                scope.launch {
                                    rippleScale.snapTo(1f)
                                    rippleAlpha.snapTo(0.8f)
                                    rippleScale.animateTo(2.2f, animationSpec = tween(500, easing = FastOutSlowInEasing))
                                    rippleAlpha.animateTo(0f, animationSpec = tween(300))
                                    showLoveBurst = false
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Expanding Heartbeat Ripple wave
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .scale(rippleScale.value)
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(alpha = rippleAlpha.value),
                                    CircleShape
                                )
                        )

                        // Ambient halo
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(
                                    brush = Brush.radialGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                                            Color.Transparent
                                        )
                                    ),
                                    shape = CircleShape
                                )
                        )

                        // Center Pulsing Heart
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "لمسة القلوب",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(32.dp)
                                .scale(heartScale)
                        )
                    }

                    Text(
                        text = if (heartTapCount > 0) "نبضاتنا: $heartTapCount ❤️" else "المس للنبض 💓",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Partner Avatar (Left side in RTL)
                ModernCoupleAvatarItem(
                    name = partnerName,
                    cityName = partnerCity?.name ?: "وهران",
                    temp = partnerTemp,
                    avatarUri = partnerAvatarUri,
                    defaultDrawable = R.drawable.img_avatar_her,
                    roleLabel = "حبيبتي",
                    glowColor = MaterialTheme.colorScheme.primary,
                    onClick = onEditPartner,
                    modifier = Modifier.weight(1f).testTag("avatar_partner")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Geographic Telemetry & Heart Link Banner
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 7.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "المسافة: $distanceKm كم",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    if (userTemp != null && partnerTemp != null) {
                        val tempDiff = (partnerTemp - userTemp).roundToInt()
                        val diffText = when {
                            tempDiff > 0 -> "عندها أدفى بـ $tempDiff°C ☀️"
                            tempDiff < 0 -> "عندها أبرد بـ ${-tempDiff}°C 🧣"
                            else -> "نفس الدفء ($userTemp°C) 🕊️"
                        }
                        Text(
                            text = diffText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ModernCoupleAvatarItem(
    name: String,
    cityName: String,
    temp: Double?,
    avatarUri: String?,
    defaultDrawable: Int,
    roleLabel: String,
    glowColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(80.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            // Circular Avatar Frame with Gradient Border
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .border(
                        border = BorderStroke(
                            2.5.dp,
                            Brush.sweepGradient(
                                listOf(glowColor, MaterialTheme.colorScheme.primary, glowColor)
                            )
                        ),
                        shape = CircleShape
                    )
                    .padding(3.dp)
                    .clip(CircleShape)
            ) {
                if (avatarUri != null) {
                    AsyncImage(
                        model = Uri.parse(avatarUri),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(74.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Image(
                        painter = painterResource(id = defaultDrawable),
                        contentDescription = name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(74.dp)
                            .clip(CircleShape)
                    )
                }
            }

            // Edit button badge
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل",
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = name,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1
        )

        Text(
            text = cityName,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )

        if (temp != null) {
            Text(
                text = "${temp.roundToInt()}°C",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * Calculates distance in kilometers between two GPS coordinates using Haversine formula
 */
private fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
    val r = 6371.0 // Earth's radius in km
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return (r * c).roundToInt()
}
