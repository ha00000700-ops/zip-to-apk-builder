package com.example.model

enum class CastStatus {
    IDLE,
    STARTING,
    STREAMING,
    PAUSED_BY_SYSTEM, // When MediaProjection.Callback.onStop() is triggered by Messenger / external app
    STOPPED,
    ERROR
}

enum class ReceiverStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    STREAMING,
    ERROR
}

enum class AudioStatus {
    IDLE,
    STARTING,
    STREAMING,        // Active playback audio streaming
    SILENT,           // Audio engine running, no sound currently playing
    BLOCKED_BY_APP,   // Target app enforces ALLOW_CAPTURE_BY_NONE
    MUTED,            // Muted by user toggle
    CALL_EXCLUDED,    // Voice communication active (Messenger/cellular call) - voice audio excluded
    UNSUPPORTED,      // Android version < API 29
    ERROR
}

data class AudioStats(
    val isCapturing: Boolean = false,
    val sampleRate: Int = 48000,
    val channels: Int = 2,
    val bytesSent: Long = 0L,
    val currentAmplitude: Int = 0,
    val isMuted: Boolean = false,
    val status: AudioStatus = AudioStatus.IDLE,
    val statusMessage: String = "جاهز للبث"
)

data class StreamConfig(
    val width: Int = 1280,
    val height: Int = 720,
    val dpi: Int = 320,
    val fps: Int = 30,
    val bitrate: Int = 3_000_000,
    val port: Int = 8080,
    val iFrameInterval: Int = 1,
    val adaptiveQuality: Boolean = true,
    val jpegQuality: Int = 82,
    val pinSecurityEnabled: Boolean = true,
    val pairingPin: String = "4829"
)

data class StreamStats(
    val fps: Int = 0,
    val activeClients: Int = 0,
    val bytesSent: Long = 0L,
    val currentBitrateKbps: Int = 0,
    val uptimeSeconds: Long = 0L,
    val latencyMs: Long = 0L,
    val encodeDurationMs: Long = 0L,
    val droppedFrames: Int = 0,
    val currentQualityLevel: Int = 82,
    val networkRttMs: Long = 0L
)

data class DiagnosticLogEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: Long = System.currentTimeMillis(),
    val source: String,
    val message: String,
    val details: String = "",
    val level: LogLevel = LogLevel.INFO
)

enum class LogLevel {
    INFO,
    WARNING,
    ERROR,
    CRITICAL
}

data class ConcurrencyTestResult(
    val hasSingleSessionConstraint: Boolean = true,
    val messengerConflictDetected: Boolean = false,
    val onStopCallbackReceived: Boolean = false,
    val virtualDisplayReleased: Boolean = false,
    val isXiaomiDevice: Boolean = false,
    val miuiBatteryOptimizationIgnored: Boolean = false,
    val summary: String = ""
)

data class XiaomiGuideItem(
    val stepNumber: Int,
    val title: String,
    val path: String,
    val whyNeeded: String
)
