package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class NotificationHelper(private val context: Context) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createChannels()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            // Standard Channel
            val standardChannel = NotificationChannel(
                CHANNEL_ID_STANDARD,
                "إشعارات الصلاة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "الإشعارات العادية لدخول وقت الصلاة"
                enableVibration(true)
                setSound(defaultSoundUri, audioAttributes)
            }
            
            // Adhan Channel (uses alarm sound for now since adhan audio file is missing)
            val adhanSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            val adhanChannel = NotificationChannel(
                CHANNEL_ID_ADHAN,
                "الأذان",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تشغيل الأذان عند دخول وقت الصلاة"
                enableVibration(true)
                setSound(adhanSoundUri, audioAttributes)
            }

            notificationManager.createNotificationChannel(standardChannel)
            notificationManager.createNotificationChannel(adhanChannel)
        }
    }

    fun showPrayerNotification(title: String, message: String, playAdhan: Boolean, vibrate: Boolean) {
        val channelId = if (playAdhan) CHANNEL_ID_ADHAN else CHANNEL_ID_STANDARD

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher) // Should use a proper notification icon ideally
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        if (!vibrate) {
            builder.setVibrate(longArrayOf(0L))
        } else {
            builder.setVibrate(longArrayOf(0, 500, 500, 500))
        }

        notificationManager.notify(NOTIFICATION_ID, builder.build())
    }

    companion object {
        const val CHANNEL_ID_STANDARD = "prayer_notifications_standard"
        const val CHANNEL_ID_ADHAN = "prayer_notifications_adhan"
        const val NOTIFICATION_ID = 1001
    }
}
