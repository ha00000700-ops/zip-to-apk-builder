package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.Prayer
import com.example.data.PrayerTimesHelper
import com.example.receivers.PrayerAlarmReceiver
import java.util.Calendar
import java.util.Date

class AlarmScheduler(private val context: Context) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun scheduleAlarms(
        lat: Double,
        lng: Double,
        calcMethod: CalculationMethod,
        asrMethod: Madhab,
        timeZoneId: String,
        notificationsEnabled: Boolean,
        preAlertEnabled: Boolean,
        preAlertDuration: Int,
        adhanEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        cancelAllAlarms()

        if (!notificationsEnabled) return

        val timeZone = java.util.TimeZone.getTimeZone(timeZoneId)
        val now = Date()
        val calendar = Calendar.getInstance(timeZone)
        
        // Calculate for today and tomorrow to ensure we have upcoming prayers
        for (dayOffset in 0..1) {
            calendar.time = now
            calendar.add(Calendar.DAY_OF_YEAR, dayOffset)
            val prayerTimes = PrayerTimesHelper.getPrayerTimes(lat, lng, calendar.time, calcMethod, asrMethod, timeZoneId)

            schedulePrayer(Prayer.FAJR, prayerTimes.fajr, preAlertEnabled, preAlertDuration, adhanEnabled, vibrationEnabled)
            schedulePrayer(Prayer.DHUHR, prayerTimes.dhuhr, preAlertEnabled, preAlertDuration, adhanEnabled, vibrationEnabled)
            schedulePrayer(Prayer.ASR, prayerTimes.asr, preAlertEnabled, preAlertDuration, adhanEnabled, vibrationEnabled)
            schedulePrayer(Prayer.MAGHRIB, prayerTimes.maghrib, preAlertEnabled, preAlertDuration, adhanEnabled, vibrationEnabled)
            schedulePrayer(Prayer.ISHA, prayerTimes.isha, preAlertEnabled, preAlertDuration, adhanEnabled, vibrationEnabled)
        }
        
        // Also schedule a daily update alarm at midnight to calculate times for the next days
        scheduleMidnightUpdate()
    }

    private fun schedulePrayer(
        prayer: Prayer,
        time: Date,
        preAlertEnabled: Boolean,
        preAlertDuration: Int,
        adhanEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        val now = Date()
        
        // Exact time alarm
        if (time.after(now)) {
            setAlarm(
                time.time, 
                prayer.name, 
                isPreAlert = false, 
                adhanEnabled = adhanEnabled, 
                vibrationEnabled = vibrationEnabled
            )
        }

        // Pre-alert alarm
        if (preAlertEnabled) {
            val preAlertTime = Date(time.time - (preAlertDuration * 60 * 1000L))
            if (preAlertTime.after(now)) {
                setAlarm(
                    preAlertTime.time, 
                    prayer.name, 
                    isPreAlert = true, 
                    adhanEnabled = false, 
                    vibrationEnabled = vibrationEnabled
                )
            }
        }
    }

    private fun setAlarm(
        timeInMillis: Long,
        prayerName: String,
        isPreAlert: Boolean,
        adhanEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra(PrayerAlarmReceiver.EXTRA_PRAYER_NAME, prayerName)
            putExtra(PrayerAlarmReceiver.EXTRA_IS_PRE_ALERT, isPreAlert)
            putExtra(PrayerAlarmReceiver.EXTRA_ADHAN_ENABLED, adhanEnabled)
            putExtra(PrayerAlarmReceiver.EXTRA_VIBRATION_ENABLED, vibrationEnabled)
        }

        // Unique ID for each alarm type so they don't overwrite each other
        val requestCode = prayerName.hashCode() + (if (isPreAlert) 1000 else 0)
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            // PermissionSCHEDULE_EXACT_ALARM not granted on Android 14+
            // Fallback to inexact alarm if strictly needed, though we requested the permission.
            alarmManager.set(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent)
        }
    }
    
    private fun scheduleMidnightUpdate() {
        val calendar = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 5)
            set(Calendar.SECOND, 0)
        }
        
        val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
            putExtra(PrayerAlarmReceiver.EXTRA_IS_UPDATE, true)
        }
        
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            9999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
    }

    fun cancelAllAlarms() {
        // To properly cancel, we must recreate the exact intents used, or simpler: 
        // Iterate through all known request codes.
        val prayers = listOf(Prayer.FAJR, Prayer.DHUHR, Prayer.ASR, Prayer.MAGHRIB, Prayer.ISHA)
        for (prayer in prayers) {
            cancelAlarm(prayer.name.hashCode())
            cancelAlarm(prayer.name.hashCode() + 1000)
        }
        cancelAlarm(9999) // update alarm
    }

    private fun cancelAlarm(requestCode: Int) {
        val intent = Intent(context, PrayerAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
