package com.example

import android.app.Application
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import okhttp3.OkHttpClient

class KhedmatiApplication : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Log.d("KhedmatiApplication", "Application started")
    }

    override fun newImageLoader(): ImageLoader {
        Log.d("KhedmatiApplication", "Initializing custom Coil ImageLoader for Private Storage")
        
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val original = chain.request()
                val urlString = original.url.toString()
                
                // Check if this is a Supabase Storage URL
                if (urlString.contains("/storage/v1/object/")) {
                    val supabaseKey = com.example.data.remote.SupabaseConfig.SUPABASE_KEY
                    
                    // Case 1: If it's already a time-limited signed URL with token, proceed directly
                    if (urlString.contains("/storage/v1/object/sign/") && urlString.contains("token=")) {
                        val request = original.newBuilder()
                            .header("apikey", supabaseKey)
                            .build()
                        return@addInterceptor chain.proceed(request)
                    }

                    // Case 2: Extract object path and obtain a secure signed URL for the private bucket
                    val objectPath = com.example.data.remote.SupabaseConfig.extractObjectPath(urlString)
                    if (!objectPath.isNullOrBlank() && com.example.data.remote.SupabaseConfig.isConfigured()) {
                        val signedUrl = com.example.data.remote.SupabaseConfig.getSignedUrl(objectPath)
                        if (!signedUrl.isNullOrBlank()) {
                            Log.d("KhedmatiImageLoader", "Resolved private storage URL to time-limited signed URL: $signedUrl")
                            val request = original.newBuilder()
                                .url(signedUrl)
                                .header("apikey", supabaseKey)
                                .build()
                            val response = chain.proceed(request)
                            Log.d("KhedmatiImageLoader", "Supabase signed image fetch response: ${response.code}")
                            return@addInterceptor response
                        }
                    }

                    // Fallback if not configured or signing failed
                    try {
                        chain.proceed(original)
                    } catch (e: Exception) {
                        Log.w("KhedmatiImageLoader", "Unable to reach image host: ${original.url.host}", e)
                        // Return empty 404 response to allow Coil to cleanly show error/placeholder without crashing
                        okhttp3.Response.Builder()
                            .request(original)
                            .protocol(okhttp3.Protocol.HTTP_1_1)
                            .code(404)
                            .message("Image not found or unconfigured storage")
                            .body(okhttp3.ResponseBody.create(null, ByteArray(0)))
                            .build()
                    }
                } else {
                    chain.proceed(original)
                }
            }
            .build()

        return ImageLoader.Builder(this)
            .okHttpClient(okHttpClient)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(this.cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .respectCacheHeaders(false)
            .crossfade(true)
            .build()
    }
}
