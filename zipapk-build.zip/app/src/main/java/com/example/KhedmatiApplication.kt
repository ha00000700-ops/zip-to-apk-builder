package com.example

import android.app.Application
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import okhttp3.OkHttpClient

class KhedmatiApplication : Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        Log.d("KhedmatiApplication", "Application started")
    }

    override fun newImageLoader(): ImageLoader {
        Log.d("KhedmatiApplication", "Initializing custom Coil ImageLoader for Private Storage")
        
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor { chain ->
                val original = chain.request()
                val urlString = original.url.toString()
                
                // Check if this is a Supabase Storage URL and NOT a public URL
                if (urlString.contains("/storage/v1/object/") && !urlString.contains("/storage/v1/object/public/")) {
                    android.util.Log.d("KhedmatiTrace", "Interceptor: Processing URL: $urlString")
                    val supabaseKey = com.example.data.remote.SupabaseConfig.SUPABASE_KEY
                    
                    // Case 1: If it's already a time-limited signed URL with token, proceed directly
                    if (urlString.contains("/storage/v1/object/sign/") && urlString.contains("token=")) {
                        val request = original.newBuilder()
                            .header("apikey", supabaseKey)
                            .build()
                        return@addInterceptor chain.proceed(request)
                    }

                    // Case 2: Extract object path and obtain a secure signed URL for the private bucket
                    val objectPath = com.example.data.remote.SupabaseConfig.extractObjectPath(urlString)
                    android.util.Log.d("KhedmatiTrace", "Interceptor: Extracted objectPath: $objectPath")
                    if (!objectPath.isNullOrBlank() && com.example.data.remote.SupabaseConfig.isConfigured()) {
                        val signedUrl = com.example.data.remote.SupabaseConfig.getSignedUrl(objectPath)
                        if (!signedUrl.isNullOrBlank()) {
                            android.util.Log.d("KhedmatiTrace", "Interceptor: Signed URL obtained: $signedUrl")
                            val request = original.newBuilder()
                                .url(signedUrl)
                                .header("apikey", supabaseKey)
                                .build()
                            val response = chain.proceed(request)
                            android.util.Log.d("KhedmatiTrace", "Supabase signed image fetch response: ${response.code}")
                            return@addInterceptor response
                        } else {
                            android.util.Log.e("KhedmatiTrace", "Interceptor: Failed to get signed URL for path: $objectPath")
                        }
                    } else {
                        android.util.Log.e("KhedmatiTrace", "Interceptor: Failed to extract valid objectPath or Supabase not configured")
                    }

                    // Fallback if not configured or signing failed
                    try {
                        val response = chain.proceed(original)
                        android.util.Log.d("KhedmatiTrace", "Interceptor: Fallback response code: ${response.code}")
                        response
                    } catch (e: Exception) {
                        android.util.Log.e("KhedmatiTrace", "Unable to reach image host: ${original.url.host}", e)
                        // Return empty 404 response to allow Coil to cleanly show error/placeholder without crashing
                        okhttp3.Response.Builder()
                            .request(original)
                            .protocol(okhttp3.Protocol.HTTP_1_1)
                            .code(404)
                            .message("Image not found or unconfigured storage")
                            .body(okhttp3.ResponseBody.create(null, ByteArray(0)))
                            .build()
                    }
                } else {
                    chain.proceed(original)
                }
            }
            .build()

        return ImageLoader.Builder(this)
            .okHttpClient(okHttpClient)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(this.cacheDir.resolve("image_cache"))
                    .maxSizePercent(0.02)
                    .build()
            }
            .respectCacheHeaders(false)
            .crossfade(true)
            .build()
    }
}
