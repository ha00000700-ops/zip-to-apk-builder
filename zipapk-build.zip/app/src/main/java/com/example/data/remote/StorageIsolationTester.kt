package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

object StorageIsolationTester {
    private const val TAG = "KhedmatiIsolationTest"
    private val client = OkHttpClient()

    data class TestResult(
        val isCompleted: Boolean = false,
        val isSuccess: Boolean = false,
        val errorMessage: String? = null,
        
        // 1. Selected Local Image
        val localBytesSize: Int = 0,
        val localSha256: String = "",
        val localDimensions: String = "",
        
        // 2. Upload
        val uploadPath: String = "",
        val uploadHttpStatus: Int = 0,
        val uploadErrorBody: String? = null,
        
        // 3. Signed URL Generation
        val signedUrl: String? = null,
        val signedUrlError: String? = null,
        
        // 4. Download
        val downloadHttpStatus: Int = 0,
        val downloadContentType: String? = null,
        val downloadContentLength: Long = 0,
        val downloadSha256: String = "",
        val downloadDimensions: String = "",
        val hashMatches: Boolean = false,
        
        // 5. Decoded Image (For direct non-Coil display)
        val decodedBitmap: Bitmap? = null
    )

    fun sha256(bytes: ByteArray): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val hash = digest.digest(bytes)
            hash.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            "Error hashing: ${e.message}"
        }
    }

    private fun compressImage(context: Context, uri: Uri): ByteArray? {
        try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()

            val maxDimension = 1024
            var inSampleSize = 1
            val height = options.outHeight
            val width = options.outWidth
            if (height > maxDimension || width > maxDimension) {
                val halfHeight = height / 2
                val halfWidth = width / 2
                while ((halfHeight / inSampleSize) >= maxDimension && (halfWidth / inSampleSize) >= maxDimension) {
                    inSampleSize *= 2
                }
            }

            val inputStream2 = context.contentResolver.openInputStream(uri) ?: return null
            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
            }
            val bitmap = BitmapFactory.decodeStream(inputStream2, null, decodeOptions)
            inputStream2.close()

            if (bitmap == null) return null

            val outputStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
            return outputStream.toByteArray()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to compress", e)
            return null
        }
    }

    suspend fun runDiagnostic(context: Context, selectedUri: Uri, userId: String): TestResult = withContext(Dispatchers.IO) {
        var result = TestResult()
        try {
            Log.d(TAG, "Starting diagnostic isolation test for uri: $selectedUri, userId: $userId")
            
            // Step 1: Compress selected local image
            val localBytes = compressImage(context, selectedUri)
            if (localBytes == null) {
                return@withContext result.copy(
                    isCompleted = true,
                    isSuccess = false,
                    errorMessage = "فشل ضغط الصورة المحلية"
                )
            }
            
            val localSha = sha256(localBytes)
            val tempLocalOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(localBytes, 0, localBytes.size, tempLocalOpts)
            val localDims = "${tempLocalOpts.outWidth}x${tempLocalOpts.outHeight}"
            
            result = result.copy(
                localBytesSize = localBytes.size,
                localSha256 = localSha,
                localDimensions = localDims
            )
            
            // Step 2: Upload to exact Supabase Storage path
            val supabaseUrl = SupabaseConfig.SUPABASE_URL
            val supabaseKey = SupabaseConfig.SUPABASE_KEY
            val bucketName = SupabaseConfig.BUCKET_NAME
            
            if (!SupabaseConfig.isConfigured()) {
                return@withContext result.copy(
                    isCompleted = true,
                    isSuccess = false,
                    errorMessage = "تكوينات Supabase غير ممتلئة"
                )
            }
            
            val cleanPath = "providers/$userId/diagnostic_${System.currentTimeMillis()}.jpg"
            val uploadUrl = "$supabaseUrl/storage/v1/object/$bucketName/$cleanPath"
            
            Log.d(TAG, "Uploading to: $uploadUrl")
            val requestBody = localBytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
            val uploadRequest = Request.Builder()
                .url(uploadUrl)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .addHeader("x-upsert", "true")
                .post(requestBody)
                .build()
                
            val uploadResponse = client.newCall(uploadRequest).execute()
            val uploadHttpStatus = uploadResponse.code
            val uploadErrorBody = if (!uploadResponse.isSuccessful) uploadResponse.body?.string() else null
            uploadResponse.close()
            
            result = result.copy(
                uploadPath = cleanPath,
                uploadHttpStatus = uploadHttpStatus,
                uploadErrorBody = uploadErrorBody
            )
            
            if (uploadHttpStatus !in 200..299) {
                return@withContext result.copy(
                    isCompleted = true,
                    isSuccess = false,
                    errorMessage = "فشل الرفع إلى Supabase: HTTP $uploadHttpStatus"
                )
            }
            
            // Step 3: Request/download that SAME Storage object directly using private-bucket authentication/signed-URL
            Log.d(TAG, "Requesting signed URL for path: $cleanPath")
            val signedUrl = SupabaseConfig.getSignedUrl(cleanPath)
            if (signedUrl.isNullOrBlank()) {
                return@withContext result.copy(
                    isCompleted = true,
                    isSuccess = false,
                    signedUrlError = "فشل إنشاء رابط موقع آمن (Signed URL) للملف الخاص"
                )
            }
            
            result = result.copy(signedUrl = signedUrl)
            
            // Step 4: Download object directly with signed URL using fresh client
            Log.d(TAG, "Downloading object directly from: $signedUrl")
            val downloadRequest = Request.Builder()
                .url(signedUrl)
                .addHeader("apikey", supabaseKey)
                .build()
                
            val downloadResponse = client.newCall(downloadRequest).execute()
            val downloadHttpStatus = downloadResponse.code
            val downloadContentType = downloadResponse.header("Content-Type")
            val downloadContentLength = downloadResponse.body?.contentLength() ?: 0L
            val downloadBytes = downloadResponse.body?.bytes()
            downloadResponse.close()
            
            result = result.copy(
                downloadHttpStatus = downloadHttpStatus,
                downloadContentType = downloadContentType,
                downloadContentLength = downloadContentLength
            )
            
            if (downloadHttpStatus !in 200..299 || downloadBytes == null) {
                return@withContext result.copy(
                    isCompleted = true,
                    isSuccess = false,
                    errorMessage = "فشل تحميل الصورة عبر الرابط الموقع: HTTP $downloadHttpStatus"
                )
            }
            
            // Step 5: Verify response and calculate SHA-256
            val downloadSha = sha256(downloadBytes)
            val matches = localSha == downloadSha
            
            // Step 6: Decode downloaded bytes
            val downloadedBitmap = BitmapFactory.decodeByteArray(downloadBytes, 0, downloadBytes.size)
            val downloadDims = if (downloadedBitmap != null) {
                "${downloadedBitmap.width}x${downloadedBitmap.height}"
            } else {
                "فشل فك التشفير (Decoding Failed)"
            }
            
            result = result.copy(
                isCompleted = true,
                isSuccess = downloadedBitmap != null && matches,
                downloadSha256 = downloadSha,
                downloadDimensions = downloadDims,
                hashMatches = matches,
                decodedBitmap = downloadedBitmap,
                errorMessage = if (downloadedBitmap == null) "فشل تحويل البيانات المحملة إلى صورة Bitmap" else null
            )
            
            Log.d(TAG, "Diagnostic completed. Success: ${result.isSuccess}, Match: $matches")
            result
        } catch (e: Exception) {
            Log.e(TAG, "Exception in diagnostic", e)
            result.copy(
                isCompleted = true,
                isSuccess = false,
                errorMessage = "خطأ غير متوقع: ${e.message}"
            )
        }
    }
}
