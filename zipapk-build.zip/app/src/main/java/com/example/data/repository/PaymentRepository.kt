package com.example.data.repository

import com.example.data.model.PaymentInfo
import com.example.data.model.PaymentMethod
import com.example.data.model.SubscriptionPlan
import kotlinx.coroutines.flow.Flow

data class CheckoutResult(
    val checkoutId: String,
    val checkoutUrl: String,
    val amountDzd: Long,
    val paymentMethod: PaymentMethod
)

data class CheckoutVerifyResult(
    val checkoutId: String,
    val status: String,
    val isPaid: Boolean,
    val isActivated: Boolean,
    val amount: Long,
    val currency: String,
    val planId: String? = null,
    val type: String? = null
)

interface PaymentRepository {
    suspend fun createServiceRequestCheckout(
        requestId: String,
        amountDzd: Long,
        paymentMethod: PaymentMethod,
        customerName: String,
        customerEmail: String? = null
    ): AuthResult<CheckoutResult>

    suspend fun createProSubscriptionCheckout(
        plan: SubscriptionPlan = SubscriptionPlan.PREMIUM,
        paymentMethod: PaymentMethod
    ): AuthResult<CheckoutResult>

    fun observeRequestPaymentStatus(requestId: String): Flow<PaymentInfo?>

    suspend fun cancelPendingPayment(requestId: String): AuthResult<Unit>

    suspend fun verifyCheckout(checkoutId: String): AuthResult<CheckoutVerifyResult>
}
