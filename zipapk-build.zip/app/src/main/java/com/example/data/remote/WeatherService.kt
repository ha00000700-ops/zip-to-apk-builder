package com.example.data.remote

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class CityLocation(
    val wilayaNumber: Int,
    val name: String,
    val nameFrench: String,
    val country: String,
    val latitude: Double,
    val longitude: Double
)

data class AgriculturalWeatherData(
    val cityName: String,
    val temperature: Double,
    val humidity: Int,
    val precipitation: Double,
    val windSpeed: Double,
    val weatherCondition: String,
    val weatherIconCode: Int,
    val lastUpdated: String,
    val isLive: Boolean = true,
    val dataSource: String = "Open-Meteo Meteorological Service",
    val agriAlerts: List<AgriAlert>,
    val irrigationAdvice: String,
    val sprayingAdvice: String,
    val isSprayingSuitable: Boolean = true
)

data class AgriAlert(
    val title: String,
    val description: String,
    val severity: String, // "تحذير عالي", "تنبيه متوسط", "مناسب"
    val isCritical: Boolean
)

object WeatherService {
    private const val TAG = "WeatherService"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Cache of last fetched weather per city to display instantly if offline
    private val weatherCache = mutableMapOf<String, AgriculturalWeatherData>()

    val algerianWilayasAndCities: List<CityLocation> get() = allWilayas

    // Complete list of all 58 Algerian Wilayas with geographic coordinates
    val allWilayas: List<CityLocation> = listOf(
        CityLocation(1, "أدرار", "Adrar", "الجزائر", 27.8742, -0.2939),
        CityLocation(2, "الشلف", "Chlef", "الجزائر", 36.1650, 1.3340),
        CityLocation(3, "الأغواط", "Laghouat", "الجزائر", 33.8000, 2.8651),
        CityLocation(4, "أم البواقي", "Oum El Bouaghi", "الجزائر", 35.8755, 7.1135),
        CityLocation(5, "باتنة", "Batna", "الجزائر", 35.5559, 6.1741),
        CityLocation(6, "بجاية", "Béjaïa", "الجزائر", 36.7500, 5.0667),
        CityLocation(7, "بسكرة", "Biskra", "الجزائر", 34.8516, 5.7280),
        CityLocation(8, "بشار", "Béchar", "الجزائر", 31.6167, -2.2167),
        CityLocation(9, "البليدة", "Blida", "الجزائر", 36.4700, 2.8300),
        CityLocation(10, "البويرة", "Bouira", "الجزائر", 36.3749, 3.9020),
        CityLocation(11, "تمنراست", "Tamanrasset", "الجزائر", 22.7850, 5.5228),
        CityLocation(12, "تبسة", "Tébessa", "الجزائر", 35.4042, 8.1242),
        CityLocation(13, "تلمسان", "Tlemcen", "الجزائر", 34.8783, -1.3150),
        CityLocation(14, "تيارت", "Tiaret", "الجزائر", 35.3710, 1.3170),
        CityLocation(15, "تيزي وزو", "Tizi Ouzou", "الجزائر", 36.7118, 4.0459),
        CityLocation(16, "الجزائر العاصمة", "Alger", "الجزائر", 36.7538, 3.0588),
        CityLocation(17, "الجلفة", "Djelfa", "الجزائر", 34.6728, 3.2630),
        CityLocation(18, "جيجل", "Jijel", "الجزائر", 36.8206, 5.7667),
        CityLocation(19, "سطيف", "Sétif", "الجزائر", 36.1911, 5.4137),
        CityLocation(20, "سعيدة", "Saïda", "الجزائر", 34.8303, 0.1517),
        CityLocation(21, "سكيكدة", "Skikda", "الجزائر", 36.8792, 6.9069),
        CityLocation(22, "سيدي بلعباس", "Sidi Bel Abbès", "الجزائر", 35.1899, -0.6308),
        CityLocation(23, "عنابة", "Annaba", "الجزائر", 36.9000, 7.7667),
        CityLocation(24, "قالمة", "Guelma", "الجزائر", 36.4622, 7.4261),
        CityLocation(25, "قسنطينة", "Constantine", "الجزائر", 36.3650, 6.6147),
        CityLocation(26, "المدية", "Médéa", "الجزائر", 36.2642, 2.7539),
        CityLocation(27, "مستغانم", "Mostaganem", "الجزائر", 35.9312, 0.0892),
        CityLocation(28, "المسيلة", "M'Sila", "الجزائر", 35.7058, 4.5419),
        CityLocation(29, "معسكر", "Mascara", "الجزائر", 35.3969, 0.1403),
        CityLocation(30, "ورقلة", "Ouargla", "الجزائر", 31.9493, 5.3250),
        CityLocation(31, "وهران", "Oran", "الجزائر", 35.6971, -0.6331),
        CityLocation(32, "البيض", "El Bayadh", "الجزائر", 33.6832, 1.0193),
        CityLocation(33, "إليزي", "Illizi", "الجزائر", 26.4833, 8.4667),
        CityLocation(34, "برج بوعريريج", "Bordj Bou Arréridj", "الجزائر", 36.0732, 4.7611),
        CityLocation(35, "بومرداس", "Boumerdès", "الجزائر", 36.7664, 3.4772),
        CityLocation(36, "الطارف", "El Tarf", "الجزائر", 36.7672, 8.3138),
        CityLocation(37, "تندوف", "Tindouf", "الجزائر", 27.6711, -8.1474),
        CityLocation(38, "تيسمسيلت", "Tissemsilt", "الجزائر", 35.6072, 1.8108),
        CityLocation(39, "الوادي (سوف)", "El Oued", "الجزائر", 33.3683, 6.8674),
        CityLocation(40, "خنشلة", "Khenchela", "الجزائر", 35.4358, 7.1433),
        CityLocation(41, "سوق أهراس", "Souk Ahras", "الجزائر", 36.2864, 7.9511),
        CityLocation(42, "تيبازة", "Tipaza", "الجزائر", 36.5897, 2.4475),
        CityLocation(43, "ميلة", "Mila", "الجزائر", 36.4503, 6.2644),
        CityLocation(44, "عين الدفلى", "Aïn Defla", "الجزائر", 36.2642, 1.9678),
        CityLocation(45, "النعامة", "Naâma", "الجزائر", 33.2667, -0.3167),
        CityLocation(46, "عين تموشنت", "Aïn Témouchent", "الجزائر", 35.2975, -1.1404),
        CityLocation(47, "غرداية", "Ghardaïa", "الجزائر", 32.4909, 3.6735),
        CityLocation(48, "غليزان", "Relizane", "الجزائر", 35.7373, 0.5558),
        CityLocation(49, "تيميمون", "Timimoun", "الجزائر", 29.2639, 0.2310),
        CityLocation(50, "برج باجي مختار", "Bordj Badji Mokhtar", "الجزائر", 21.3281, 0.9542),
        CityLocation(51, "أولاد جلال", "Ouled Djellal", "الجزائر", 34.4250, 5.0667),
        CityLocation(52, "بني عباس", "Béni Abbès", "الجزائر", 30.1333, -2.1667),
        CityLocation(53, "عين صالح", "In Salah", "الجزائر", 27.1936, 2.4608),
        CityLocation(54, "عين قزام", "In Guezzam", "الجزائر", 19.5683, 5.7725),
        CityLocation(55, "تقرت", "Touggourt", "الجزائر", 33.1053, 6.0578),
        CityLocation(56, "جانت", "Djanet", "الجزائر", 24.5539, 9.4858),
        CityLocation(57, "المغير", "El M'Ghair", "الجزائر", 33.9500, 5.9167),
        CityLocation(58, "المنيعة", "El Meniaa", "الجزائر", 30.5833, 2.8833),
        // Brotherly Arab Capitals
        CityLocation(101, "تونس العاصمة", "Tunis", "تونس", 36.8065, 10.1815),
        CityLocation(102, "الرباط", "Rabat", "المغرب", 34.0209, -6.8416),
        CityLocation(103, "طرابلس", "Tripoli", "ليبيا", 32.8872, 13.1913),
        CityLocation(104, "القاهرة", "Cairo", "مصر", 30.0444, 31.2357),
        CityLocation(105, "الرياض", "Riyadh", "السعودية", 24.7136, 46.6753),
        CityLocation(106, "عمان", "Amman", "الأردن", 31.9539, 35.9106)
    )

    suspend fun fetchWeather(city: CityLocation): Result<AgriculturalWeatherData> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${city.latitude}&longitude=${city.longitude}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&timezone=auto"

            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                // If offline, check cache
                weatherCache[city.name]?.let { cached ->
                    return@withContext Result.success(cached.copy(isLive = false))
                }
                return@withContext Result.failure(Exception("تعذر جلب بيانات الطقس من مزود الخدمة"))
            }

            val body = response.body?.string() ?: return@withContext Result.failure(Exception("استجابة الطقس فارغة"))
            val json = JSONObject(body)
            val current = json.getJSONObject("current")

            val temp = current.getDouble("temperature_2m")
            val humidity = current.getInt("relative_humidity_2m")
            val precip = current.getDouble("precipitation")
            val wind = current.getDouble("wind_speed_10m")
            val weatherCode = current.getInt("weather_code")

            val condition = getWeatherConditionArabic(weatherCode)
            val nowTime = SimpleDateFormat("HH:mm - dd/MM/yyyy", Locale("ar")).format(Date())

            val alerts = mutableListOf<AgriAlert>()

            // 1. Heat / Sirocco check
            if (temp >= 36.0) {
                alerts.add(
                    AgriAlert(
                        title = "تنبيه موجة حر وسيروكو (حرارة مرتفعة)",
                        description = "درجة الحرارة ($temp° مئوية). ينصح بري النباتات في الصباح الباكر أو بعد الغروب، وتفادي الرش الورقي ظهراً.",
                        severity = "تحذير عالي",
                        isCritical = true
                    )
                )
            } else if (temp <= 3.0) {
                alerts.add(
                    AgriAlert(
                        title = "خطر الصقيع والجليد (Gelée)",
                        description = "درجة الحرارة منخفضة ($temp° مئوية). يرجى تغطية الشتلات الحساسة وإيقاف الري المسائي لحماية الجذور.",
                        severity = "تحذير عالي",
                        isCritical = true
                    )
                )
            }

            // 2. High humidity & fungal risk
            if (humidity >= 78) {
                alerts.add(
                    AgriAlert(
                        title = "خطر نشاط الأمراض الفطرية",
                        description = "الرطوبة العالية ($humidity%) تشجع انتشار الفطريات كالبياض والميلديو. احرص على تهوية الحقول والبيوت البلاستيكية.",
                        severity = "تنبيه متوسط",
                        isCritical = false
                    )
                )
            }

            // 3. Wind speed & pesticide spraying
            val isWindHigh = wind >= 20.0
            val isRainy = precip > 0.5
            val isTooHot = temp > 33.0
            val isSprayingSuitable = !isWindHigh && !isRainy && !isTooHot

            if (isWindHigh) {
                alerts.add(
                    AgriAlert(
                        title = "رياح نشطة (غير ملائم للرش)",
                        description = "سرعة الرياح ($wind كم/س). لا يُنصح برش المبيدات أو الأسمدة الورقية منعاً لظاهرة الانجراف الهوائي (Drift).",
                        severity = "تنبيه متوسط",
                        isCritical = false
                    )
                )
            }

            if (alerts.isEmpty()) {
                alerts.add(
                    AgriAlert(
                        title = "ظروف زراعية مستقرة",
                        description = "درجات الحرارة والرطوبة في المستويات المثالية لنمو النباتات وأعمال الري والتسميد.",
                        severity = "مناسب",
                        isCritical = false
                    )
                )
            }

            val irrigationAdvice = when {
                precip > 5.0 -> "هطول أمطار كافٍ اليوم ($precip ملم). يمكنك وقف الري مؤقتاً لتفادي تشبع الجذور بالمياه."
                temp > 30.0 -> "الطقس حار، احرص على ري النباتات مساءً وزيادة وتيرة الري للأصص والحدائق المنزلية."
                temp < 10.0 -> "الطقس بارد، قلل كمية الري وتحقق من جفاف سطح التربة بعمق 2 سم قبل السقاية."
                else -> "الطقس معتدل، التزم بالجدول الدوري المعتاد لري نباتاتك."
            }

            val sprayingAdvice = when {
                isWindHigh -> "غير مناسب للرش اليوم: سرعة الرياح ($wind كم/س) تتجاوز الحد الآمن (أقصى حد 15-20 كم/س)."
                isRainy -> "غير مناسب للرش اليوم: توقع هطول أمطار ($precip ملم) قد تغسل المحلول وتلغي فاعليته."
                isTooHot -> "تجنب الرش خلال ساعات النهار الحارة ($temp° مئوية)، رُش بعد الخامسة مساءً لتجنب احتراق الأوراق."
                else -> "الظروف ممتازة ومثالية للرش الوقائي، التسميد الورقي، أو مكافحة الآفات."
            }

            val result = AgriculturalWeatherData(
                cityName = if (city.wilayaNumber in 1..58) "${city.wilayaNumber}. ${city.name}" else city.name,
                temperature = temp,
                humidity = humidity,
                precipitation = precip,
                windSpeed = wind,
                weatherCondition = condition,
                weatherIconCode = weatherCode,
                lastUpdated = nowTime,
                isLive = true,
                dataSource = "Open-Meteo Meteorological Service",
                agriAlerts = alerts,
                irrigationAdvice = irrigationAdvice,
                sprayingAdvice = sprayingAdvice,
                isSprayingSuitable = isSprayingSuitable
            )

            weatherCache[city.name] = result
            Result.success(result)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching live weather", e)
            weatherCache[city.name]?.let { cached ->
                return@withContext Result.success(cached.copy(isLive = false))
            }
            Result.failure(e)
        }
    }

    private fun getWeatherConditionArabic(code: Int): String {
        return when (code) {
            0 -> "سماء صافية ومشمسة"
            1, 2, 3 -> "غائم جزئياً إلى لطيف"
            45, 48 -> "ضباب أو رطوبة كثيفة"
            51, 53, 55 -> "رذاذ مطري خفيف"
            61, 63, 65 -> "أمطار مستمرة"
            71, 73, 75 -> "تساقط ثلوج"
            80, 81, 82 -> "زخات مطرية غزيرة"
            95, 96, 99 -> "عواصف رعدية"
            else -> "طقس معتدل"
        }
    }
}
