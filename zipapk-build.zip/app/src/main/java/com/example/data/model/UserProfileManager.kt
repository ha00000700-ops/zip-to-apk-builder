package com.example.data.model

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class UserProfile(
    val isLoggedIn: Boolean = false,
    val name: String = "",
    val email: String = "",
    val wilayaOrCity: String = "",
    val farmingType: String = "حديقة منزلية وأصص", // حديقة منزلية، مزرعة حقلية، بيوت بلاستيكية، زراعة أسطح
    val preferredLanguage: String = "العربية", // "العربية" or "Français"
    val notificationsEnabled: Boolean = true,
    val units: String = "متري (°C, لتر)",
    val cloudSyncStatus: String = "تخزين محلي آمن ومحمي",
    val dailyAiUsageCount: Int = 0,
    val dailyAiQuotaLimit: Int = 15,
    val customProxyUrl: String = "",
    val favoriteItems: Set<String> = emptySet(),
    val recentViews: List<String> = emptyList()
)

class UserProfileManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("plant_doctor_user_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private fun getTodayDateString(): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        return sdf.format(java.util.Date())
    }

    private fun loadProfile(): UserProfile {
        val today = getTodayDateString()
        val lastDate = prefs.getString("last_ai_usage_date", "") ?: ""
        var count = prefs.getInt("daily_ai_usage_count", 0)
        if (lastDate != today) {
            count = 0
            prefs.edit()
                .putString("last_ai_usage_date", today)
                .putInt("daily_ai_usage_count", 0)
                .apply()
        }

        val favs = prefs.getStringSet("favorite_items", emptySet()) ?: emptySet()
        val recentsStr = prefs.getString("recent_views_csv", "") ?: ""
        val recents = if (recentsStr.isBlank()) emptyList() else recentsStr.split(";;").filter { it.isNotBlank() }

        return UserProfile(
            isLoggedIn = prefs.getBoolean("is_logged_in", false),
            name = prefs.getString("user_name", "") ?: "",
            email = prefs.getString("user_email", "") ?: "",
            wilayaOrCity = prefs.getString("user_wilaya", "") ?: "",
            farmingType = prefs.getString("farming_type", "حديقة منزلية وأصص") ?: "حديقة منزلية وأصص",
            preferredLanguage = prefs.getString("language", "العربية") ?: "العربية",
            notificationsEnabled = prefs.getBoolean("notifications", true),
            units = prefs.getString("units", "متري (°C, لتر)") ?: "متري (°C, لتر)",
            cloudSyncStatus = prefs.getString("cloud_sync", "تخزين محلي آمن ومحمي") ?: "تخزين محلي آمن ومحمي",
            dailyAiUsageCount = count,
            dailyAiQuotaLimit = prefs.getInt("daily_quota_limit", 15),
            customProxyUrl = prefs.getString("custom_proxy_url", "") ?: "",
            favoriteItems = favs,
            recentViews = recents
        )
    }

    fun canMakeAiRequest(): Boolean {
        val profile = _userProfile.value
        return profile.dailyAiUsageCount < profile.dailyAiQuotaLimit
    }

    fun recordAiRequest() {
        val today = getTodayDateString()
        val currentCount = _userProfile.value.dailyAiUsageCount + 1
        prefs.edit()
            .putString("last_ai_usage_date", today)
            .putInt("daily_ai_usage_count", currentCount)
            .apply()
        _userProfile.value = loadProfile()
    }

    fun setCustomProxy(url: String) {
        prefs.edit().putString("custom_proxy_url", url.trim()).apply()
        _userProfile.value = loadProfile()
    }

    fun setPreferredLanguage(lang: String) {
        prefs.edit().putString("language", lang).apply()
        _userProfile.value = loadProfile()
    }

    fun toggleFavorite(itemId: String) {
        val current = _userProfile.value.favoriteItems.toMutableSet()
        if (current.contains(itemId)) {
            current.remove(itemId)
        } else {
            current.add(itemId)
        }
        prefs.edit().putStringSet("favorite_items", current).apply()
        _userProfile.value = loadProfile()
    }

    fun isFavorite(itemId: String): Boolean {
        return _userProfile.value.favoriteItems.contains(itemId)
    }

    fun addRecentView(title: String) {
        val current = _userProfile.value.recentViews.toMutableList()
        current.remove(title)
        current.add(0, title)
        val limited = current.take(10)
        prefs.edit().putString("recent_views_csv", limited.joinToString(";;")).apply()
        _userProfile.value = loadProfile()
    }

    fun updateProfile(
        name: String,
        email: String,
        wilaya: String,
        farmingType: String,
        language: String,
        notifications: Boolean
    ) {
        prefs.edit()
            .putString("user_name", name)
            .putString("user_email", email)
            .putString("user_wilaya", wilaya)
            .putString("farming_type", farmingType)
            .putString("language", language)
            .putBoolean("notifications", notifications)
            .apply()
        _userProfile.value = loadProfile()
    }

    fun login(email: String, name: String) {
        prefs.edit()
            .putBoolean("is_logged_in", true)
            .putString("user_email", email)
            .putString("user_name", name.ifBlank { "مزارع الطبيعة" })
            .apply()
        _userProfile.value = loadProfile()
    }

    fun logout() {
        prefs.edit()
            .putBoolean("is_logged_in", false)
            .apply()
        _userProfile.value = loadProfile()
    }

    fun clearAllData() {
        prefs.edit().clear().apply()
        _userProfile.value = loadProfile()
    }
}
