package com.example.data.repository

import com.example.data.model.MedicineItem
import com.example.data.model.OrganicItem
import com.example.data.model.PlantDiagnosis

data class SamplePlantPreset(
    val title: String,
    val subtitle: String,
    val disease: String,
    val diagnosis: PlantDiagnosis
)

object SamplePlants {
    val presets = listOf(
        SamplePlantPreset(
            title = "أوراق الطماطم (مصابة)",
            subtitle = "بقع بنية بحلقات متداخلة واصفرار الحواف",
            disease = "اللفحة المبكرة (Early Blight)",
            diagnosis = PlantDiagnosis(
                plantName = "نبات الطماطم (Solanum lycopersicum)",
                commonName = "طماطم حقلية أو منزلية",
                isHealthy = false,
                diseaseName = "Early Blight (Alternaria solani)",
                diseaseNameArabic = "اللفحة المبكرة الفطرية",
                confidenceScore = 0.95f,
                severity = "متوسط",
                symptoms = listOf(
                    "بقع بنية إلى داكنة دائرية ذات حلقات متحدة المركز تشبه لوحة الهدف",
                    "اصفرار الأنسجة المحيطة بالبقع (هالة كلوروتية)",
                    "جفاف الأوراق السفلية وتساقطها التدريجي",
                    "تقزم حبات الثمار وتأخر نمو القمة"
                ),
                causes = listOf(
                    "فطر ألترناريا سولاني (Alternaria solani) الكامن في التربة ومخلفات النبات",
                    "رطوبة مرتفعة على سطح الأوراق بسبب الرش العلوي",
                    "درجات حرارة دافئة بين 24-29 درجة مئوية"
                ),
                chemicalMedicines = listOf(
                    MedicineItem(
                        tradeName = "أوكسي كلورور النحاس 50% (Copper Oxychloride)",
                        activeIngredient = "Copper Oxychloride 50% WP",
                        dosage = "2.5 جم لكل لتر ماء (250 جم/100 لتر)",
                        precautions = "الرش في الصباح الباكر أو قبل الغروب، تجنب الرش وقت الظهيرة والرياح القوية، فترة الأمان (PHI) 7 أيام قبل الجني."
                    ),
                    MedicineItem(
                        tradeName = "سكور 250 إي سي (Score 250 EC)",
                        activeIngredient = "Difenoconazole 25%",
                        dosage = "0.5 مل لكل لتر ماء",
                        precautions = "مبيد جهازي علاجي، يكرر بعد 10-14 يوماً عند استمرار الإصابة، مع تبديل مجموعة المبيد لمنع المقاومة."
                    )
                ),
                organicTreatments = listOf(
                    OrganicItem(
                        name = "زيت النيم النقي المعصور على البارد",
                        preparation = "خلط 5 مل زيت نيم مع نصف ملعقة صغيرة صابون زراعي طبيعي في لتر ماء دافئ ورجه جيداً.",
                        benefits = "يشكل طبقة واقية تمنع نمو الجراثيم الفطرية ويطرد الحشرات الناقلة."
                    ),
                    OrganicItem(
                        name = "محلول مستخلص الثوم والخل الطبيعي",
                        preparation = "نقع 4 فصوص ثوم مهروسة مع ملعقة خل تفاح طبيعي في لتر ماء لمدة 24 ساعة ثم تصفيته.",
                        benefits = "مضاد حيوي طبيعي قوي للفطريات السطحية على سطح الأوراق."
                    )
                ),
                careTips = listOf(
                    "قص وإزالة جميع الأوراق المصابة السفلية فوراً بمقص معقم بالكحول والتخلص منها بحرقها أو كبها خارج الحديقة.",
                    "تغيير طريقة الري ليكون رياً بالتنقيط عند قاعدة الساق، وتجنب تبليل الأوراق نهائياً.",
                    "وضع طبقة نشارة خشب أو قش (Mulch) بسمك 4 سم حول الساق لعزل التربة عن الأوراق."
                ),
                preventionSteps = listOf(
                    "عدم زراعة الطماطم أو البطاطس في نفس الحوض لمدة موسمين زراعيين متعاقبين.",
                    "ترك مسافة لا تقل عن 60 سم بين الشتلات لتأمين حركة الهواء.",
                    "دعم التسميد بالبوتاسيوم والكالسيوم لتقوية جدران الخلايا النباتية."
                ),
                treatmentStatus = "تحت العلاج"
            )
        ),
        SamplePlantPreset(
            title = "أوراق الخيار والقرعيات",
            subtitle = "طبقة بيضاء دقيقة شبيهة بالطحين",
            disease = "البياض الدقيقي (Powdery Mildew)",
            diagnosis = PlantDiagnosis(
                plantName = "نبات الخيار (Cucumis sativus)",
                commonName = "خيار البيوت المحمية أو الحديقة",
                isHealthy = false,
                diseaseName = "Powdery Mildew (Podosphaera xanthii)",
                diseaseNameArabic = "البياض الدقيقي",
                confidenceScore = 0.98f,
                severity = "حرج",
                symptoms = listOf(
                    "بقع دائرية بيضاء تشبه المسحوق المغبر تغطي الوجه العلوي للورقة",
                    "اصفرار الورقة وانحناؤها نحو الأسفل",
                    "ضعف عملية التمثيل الضوئي ومرارة في طعم الثمار",
                    "جفاف الأوراق ومظهر شبيه بالحرق"
                ),
                causes = listOf(
                    "فطريات العائلة الإريزيفية في بيئة دافئة وظليلة مع رطوبة جوية",
                    "ضعف دوران الهواء بين الشجيرات الكثيفة",
                    "الإفراط في التسميد النيتروجيني الذي يفرز أوراقاً رخوة"
                ),
                chemicalMedicines = listOf(
                    MedicineItem(
                        tradeName = "ثيوفيت جيت (Thiovit Jet) كبريت ميكروني 80%",
                        activeIngredient = "Micronized Sulfur 80% WG",
                        dosage = "2 جم لكل لتر ماء",
                        precautions = "لا يرش إذا كانت درجة الحرارة تتجاوز 30°C حتى لا يحرق الأوراق، ويمنع خلطه مع الزيوت المعدنية."
                    ),
                    MedicineItem(
                        tradeName = "توباس 100 إي سي (Topas 100 EC)",
                        activeIngredient = "Penconazole 10%",
                        dosage = "0.25 مل لكل لتر ماء",
                        precautions = "مبيد جهازي علاجي وقائي سريع الامتصاص، فترة الأمان 3 أيام في الخيار."
                    )
                ),
                organicTreatments = listOf(
                    OrganicItem(
                        name = "محلول بيكربونات الصوديوم (صودا الخبز)",
                        preparation = "ملعقة صغيرة بيكربونات صوديوم + نصف ملعقة صابون قشتالي سائل في لتر ماء دافئ.",
                        benefits = "يرفع درجة حموضة سطح الورقة إلى قلوية تمنع الفطر من التكاثر فوراً."
                    ),
                    OrganicItem(
                        name = "محلول الحليب المخفف",
                        preparation = "خلط 100 مل حليب طبيعي طازج مع 900 مل ماء ورش النباتات المشمسة.",
                        benefits = "بروتينات الحليب تتفاعل مع ضوء الشمس لإنتاج مركبات مطهرة مضادة للفطريات."
                    )
                ),
                careTips = listOf(
                    "تحسين التهوية بتقليم الأوراق الزائدة والمصابة.",
                    "تقليل التسميد النيتروجيني وزيادة البوتاسيوم والسيليكون.",
                    "الري في الصباح الباكر حتى تجف أي قطرات قبل الليل."
                ),
                preventionSteps = listOf(
                    "اختيار أصناف بذور مقاومة للبياض الدقيقي.",
                    "تعقيم أدوات التقليم بمحلول كحولي 70% بين شجرة وأخرى."
                ),
                treatmentStatus = "تحت العلاج"
            )
        ),
        SamplePlantPreset(
            title = "أوراق شجرة الليمون والحمضيات",
            subtitle = "خطوط فضية متعرجة وتشوه نمو الأوراق",
            disease = "صانعات الأنفاق (Citrus Leafminer)",
            diagnosis = PlantDiagnosis(
                plantName = "شجرة الليمون الشهري (Citrus limon)",
                commonName = "ليمون / حمضيات",
                isHealthy = false,
                diseaseName = "Citrus Leafminer (Phyllocnistis citrella)",
                diseaseNameArabic = "حشرة صانعة أنفاق الحمضيات",
                confidenceScore = 0.94f,
                severity = "خفيف",
                symptoms = listOf(
                    "أنفاق ومسارات فضية متعرجة براقة على الأوراق الغضة الحديثة",
                    "التفاف وتجعد الأوراق الجديدة حول نفسها",
                    "تقزم النموات الربيعية والصيفية للأشجار الفتية",
                    "تمزق نسيج الورقة في النهايات"
                ),
                causes = listOf(
                    "يرقة فراشة صانعة الأنفاق التي تضع بيضها في الأوراق الحديثة وتتغذى بين طبقتي البشرة",
                    "خروج نموات ورقية غضة كثيفة بدون حماية وقائية"
                ),
                chemicalMedicines = listOf(
                    MedicineItem(
                        tradeName = "أكتارا 25 دبليو جي (Actara 25 WG)",
                        activeIngredient = "Thiamethoxam 25%",
                        dosage = "0.2 جم لكل لتر ماء أو سقياً مع ماء الري",
                        precautions = "سام للنحل، يمنع استخدامه نهائياً خلال فترة تزهير الأشجار."
                    ),
                    MedicineItem(
                        tradeName = "فيرتيمك 1.8% إي سي (Vertimec)",
                        activeIngredient = "Abamectin 1.8%",
                        dosage = "0.5 مل لكل لتر ماء مع إضافة زيت صيفي 2 مل/لتر لزيادة النفاذية",
                        precautions = "يرش عند بداية ظهور النموات الغضة الجديدة بطول 2-3 سم."
                    )
                ),
                organicTreatments = listOf(
                    OrganicItem(
                        name = "الزيت الصيفي الخفيف العضوي مع النيم",
                        preparation = "خلط 15 مل زيت صيفي نباتي مع 5 مل زيت نيم في 5 لتر ماء ورش النموات الفتية.",
                        benefits = "يخنق بيض الفراشات ويمنع الإناث من وضع بيض جديد على سطح الورقة."
                    )
                ),
                careTips = listOf(
                    "تجنب التقليم الجائر في الصيف لتفادي تحفيز نموات غضة في أوقات نشاط الحشرة.",
                    "إزالة الأوراق المتضررة بشدة يدوياً وسحقها لإتلاف اليرقات داخل الأنفاق."
                ),
                preventionSteps = listOf(
                    "استخدام المصائد الفرمونية الجاذبة لذكور الفراشات لمراقبة وبدء الرش في التوقيت المثالي.",
                    "تنظيم مواعيد التسميد لتكون دورات النمو متزامنة وليست مستمرة طوال الصيف."
                ),
                treatmentStatus = "تحت العلاج"
            )
        ),
        SamplePlantPreset(
            title = "نبتة المونستيرا المنزلية (سليمة)",
            subtitle = "أوراق خضراء يانعة لامعة ومفتحة بشكل ممتاز",
            disease = "نبات سليم وصحي (Healthy Plant)",
            diagnosis = PlantDiagnosis(
                plantName = "مونستيرا ديليسيوسا (Monstera deliciosa)",
                commonName = "قفص صدري / نبتة المونستيرا",
                isHealthy = true,
                diseaseName = "None (Healthy Botanical Specimen)",
                diseaseNameArabic = "نبات سليم ومثالي",
                confidenceScore = 0.99f,
                severity = "سليم",
                symptoms = listOf(
                    "أوراق خضراء زمردية موحدة خالية من أي تبقع أو تقرحات",
                    "فتحات أوراق طبيعية وعريضة تدل على إضاءة ممتازة",
                    "جذور هوائية قوية ونظيفة",
                    "نسيج ورقي متماسك ورطب بدون جفاف في الحواف"
                ),
                causes = listOf(
                    "عناية منتظمة بإضاءة ساطعة غير مباشرة",
                    "جدول سقاية متوازن وتصريف ممتاز للتربة"
                ),
                chemicalMedicines = emptyList(),
                organicTreatments = listOf(
                    OrganicItem(
                        name = "سماد بحري مغذي دوري (Seaweed Extract)",
                        preparation = "إضافة 2 مل مستخلص أعشاب بحرية لكل لتر ماء ري مرة كل أسبوعين في الربيع والصيف.",
                        benefits = "يحافظ على لمعان الأوراق ويزيد من مناعة الجذور وقوة السيقان."
                    )
                ),
                careTips = listOf(
                    "مسح الأوراق بقطعة قماش مبللة بماء فاتر لإزالة الغبار وزيادة كفاءة التمثيل الضوئي.",
                    "الري فقط عندما يجف النصف العلوي من التربة (كل 7 إلى 10 أيام تقريباً).",
                    "توفير دعامة من ألياف جوز الهند لتسلق الجذور الهوائية."
                ),
                preventionSteps = listOf(
                    "تجنب تعريض النبتة لتيارات التكييف الباردة المباشرة.",
                    "تدوير النبتة ربع دورة أسبوعياً لنمو متناسق ومتزن نحو مصدر الضوء."
                ),
                treatmentStatus = "سليم"
            )
        )
    )
}
