package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Madhab
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    companion object {
        val CALCULATION_METHOD = stringPreferencesKey("calculation_method")
        val ASR_METHOD = stringPreferencesKey("asr_method")
        val LATITUDE = doublePreferencesKey("latitude")
        val LONGITUDE = doublePreferencesKey("longitude")
        val CITY_NAME = stringPreferencesKey("city_name")
        val TIME_ZONE_ID = stringPreferencesKey("time_zone_id")
        val USE_MANUAL_LOCATION = booleanPreferencesKey("use_manual_location")
        
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val PRE_ALERT_ENABLED = booleanPreferencesKey("pre_alert_enabled")
        val PRE_ALERT_DURATION = intPreferencesKey("pre_alert_duration")
        val ADHAN_ENABLED = booleanPreferencesKey("adhan_enabled")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
    }

    val notificationsEnabledFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[NOTIFICATIONS_ENABLED] ?: true
    }

    val preAlertEnabledFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[PRE_ALERT_ENABLED] ?: false
    }

    val preAlertDurationFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[PRE_ALERT_DURATION] ?: 15
    }

    val adhanEnabledFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[ADHAN_ENABLED] ?: false
    }

    val vibrationEnabledFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[VIBRATION_ENABLED] ?: true
    }

    val calculationMethodFlow: Flow<CalculationMethod> = context.dataStore.data.map { preferences ->
        val methodStr = preferences[CALCULATION_METHOD] ?: CalculationMethod.MUSLIM_WORLD_LEAGUE.name
        try {
            CalculationMethod.valueOf(methodStr)
        } catch (e: Exception) {
            CalculationMethod.MUSLIM_WORLD_LEAGUE
        }
    }

    val asrMethodFlow: Flow<Madhab> = context.dataStore.data.map { preferences ->
        val methodStr = preferences[ASR_METHOD] ?: Madhab.SHAFI.name
        try {
            Madhab.valueOf(methodStr)
        } catch (e: Exception) {
            Madhab.SHAFI
        }
    }

    val latitudeFlow: Flow<Double?> = context.dataStore.data.map { preferences ->
        preferences[LATITUDE]
    }

    val longitudeFlow: Flow<Double?> = context.dataStore.data.map { preferences ->
        preferences[LONGITUDE]
    }
    
    val cityNameFlow: Flow<String?> = context.dataStore.data.map { preferences ->
        preferences[CITY_NAME]
    }

    val timeZoneIdFlow: Flow<String> = context.dataStore.data.map { preferences ->
        preferences[TIME_ZONE_ID] ?: java.util.TimeZone.getDefault().id
    }

    val useManualLocationFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[USE_MANUAL_LOCATION] ?: false
    }

    suspend fun updateCalculationMethod(method: CalculationMethod) {
        context.dataStore.edit { preferences ->
            preferences[CALCULATION_METHOD] = method.name
        }
    }

    suspend fun updateAsrMethod(method: Madhab) {
        context.dataStore.edit { preferences ->
            preferences[ASR_METHOD] = method.name
        }
    }

    suspend fun updateLocation(lat: Double, lng: Double, cityName: String? = null, timeZoneId: String? = null) {
        context.dataStore.edit { preferences ->
            preferences[LATITUDE] = lat
            preferences[LONGITUDE] = lng
            if (cityName != null) {
                preferences[CITY_NAME] = cityName
            }
            if (timeZoneId != null) {
                preferences[TIME_ZONE_ID] = timeZoneId
            }
        }
    }

    suspend fun updateUseManualLocation(useManual: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[USE_MANUAL_LOCATION] = useManual
        }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun updatePreAlertEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PRE_ALERT_ENABLED] = enabled
        }
    }

    suspend fun updatePreAlertDuration(duration: Int) {
        context.dataStore.edit { preferences ->
            preferences[PRE_ALERT_DURATION] = duration
        }
    }

    suspend fun updateAdhanEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[ADHAN_ENABLED] = enabled
        }
    }

    suspend fun updateVibrationEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[VIBRATION_ENABLED] = enabled
        }
    }
}
