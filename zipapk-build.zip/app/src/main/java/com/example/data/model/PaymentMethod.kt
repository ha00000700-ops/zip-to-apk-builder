package com.example.data.model

enum class PaymentMethod(val code: String, val titleAr: String) {
    CASH("CASH", "الدفع نقداً عند الخدمة"),
    EDAHABIA("EDAHABIA", "البطاقة الذهبية (Chargily Pay)"),
    CIB("CIB", "بطاقة CIB البنكية (Chargily Pay)");

    companion object {
        fun fromCode(code: String?): PaymentMethod {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: CASH
        }
    }
}
