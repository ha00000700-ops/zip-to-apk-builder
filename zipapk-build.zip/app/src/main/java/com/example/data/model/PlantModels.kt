package com.example.data.model

import java.util.UUID

data class MedicineItem(
    val tradeName: String,
    val activeIngredient: String,
    val dosage: String,
    val precautions: String
)

data class OrganicItem(
    val name: String,
    val preparation: String,
    val benefits: String
)

data class PlantDiagnosis(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val plantName: String,
    val commonName: String,
    val isHealthy: Boolean,
    val diseaseName: String,
    val diseaseNameArabic: String,
    val confidenceScore: Float,
    val severity: String, // "سليم", "خفيف", "متوسط", "حرج"
    val symptoms: List<String>,
    val causes: List<String>,
    val chemicalMedicines: List<MedicineItem>,
    val organicTreatments: List<OrganicItem>,
    val careTips: List<String>,
    val preventionSteps: List<String>,
    val imageUri: String? = null,
    val treatmentStatus: String = if (isHealthy) "سليم" else "تحت العلاج" // "سليم", "تحت العلاج", "تم الشفاء"
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedReplies: List<String> = emptyList()
)

data class GardenPlant(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val plantType: String,
    val wateringFrequencyDays: Int = 3,
    val lastWateredTimestamp: Long = System.currentTimeMillis(),
    val diagnosisNote: String = "",
    val isUnderTreatment: Boolean = false,
    val imageUri: String? = null
) {
    fun daysUntilNextWatering(): Int {
        val diffMillis = System.currentTimeMillis() - lastWateredTimestamp
        val daysPassed = (diffMillis / (1000 * 60 * 60 * 24)).toInt()
        val remaining = wateringFrequencyDays - daysPassed
        return if (remaining < 0) 0 else remaining
    }

    fun isWateringDue(): Boolean = daysUntilNextWatering() == 0
}

data class EncyclopediaDisease(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val category: String, // فطرية, بكتيرية, حشرية, نقص عناصر
    val affectedPlants: String,
    val symptoms: String,
    val chemicalTreatment: String,
    val organicTreatment: String,
    val prevention: String
)
