package com.example.data.model

enum class UserRole {
    CUSTOMER,       // زبون
    PROFESSIONAL,   // حرفي
    ADMIN           // مدير المنصة
}

enum class RequestStatus(val labelAr: String, val labelFr: String) {
    NEW("جديد", "Nouveau"),
    REVIEWING("قيد المراجعة", "En examen"),
    ACCEPTED("مقبول", "Accepté"),
    ON_THE_WAY("في الطريق", "En route"),
    IN_PROGRESS("قيد التنفيذ", "En cours"),
    COMPLETED("مكتمل", "Terminé"),
    CANCELLED("ملغى", "Annulé")
}

enum class RequestUrgency(val labelAr: String, val labelFr: String) {
    NORMAL("عادي (خلال 24-48 ساعة)", "Normal (24-48h)"),
    URGENT("مستعجل (اليوم)", "Urgent (Aujourd'hui)"),
    EMERGENCY("طارئ جداً (الآن)", "Urgence immédiate")
}

enum class VerificationStatus(val labelAr: String) {
    NOT_SUBMITTED("غير موثق"),
    PENDING("قيد المراجعة من الإدارة"),
    APPROVED("حرفي موثوق معتمد ✓"),
    REJECTED("تم رفض التوثيق"),
    REVOKED("تم سحب التوثيق لمخالفة")
}

enum class ReportReason(val labelAr: String) {
    FRAUD("احتيال أو نصب مالي"),
    INAPPROPRIATE_BEHAVIOR("سلوك غير لائق أو سوء معاملة"),
    FAKE_ACCOUNT("حساب وهمي أو بيانات غير صحيحة"),
    POOR_SERVICE("خدمة رديئة أو إتلاف ممتلكات"),
    OFF_PLATFORM_PAYMENT("محاولة دفع خارج النظام بطريقة مشبوهة"),
    INAPPROPRIATE_CONTENT("محتوى أو صور مخالفة"),
    IMPERSONATION("انتحال شخصية أو استخدام هوية غير حقيقية"),
    OTHER("سبب آخر")
}

enum class ReportStatus(val labelAr: String) {
    NEW("جديد"),
    UNDER_REVIEW("قيد المراجعة"),
    RESOLVED("تمت المعالجة"),
    CLOSED("مغلق / مرفوض")
}

enum class NotificationType(val labelAr: String) {
    NEW_REQUEST("طلب خدمة جديد"),
    REQUEST_ACCEPTED("تم قبول طلبك"),
    REQUEST_REJECTED("تم رفض الطلب"),
    STATUS_UPDATE("تحديث حالة الطلب"),
    NEW_MESSAGE("رسالة جديدة"),
    VERIFICATION_UPDATE("تحديث حالة التوثيق"),
    REVIEW_RECEIVED("تقييم جديد"),
    ADMIN_ALERT("تنبيه من الإدارة"),
    SYSTEM("إشعار النظام")
}
