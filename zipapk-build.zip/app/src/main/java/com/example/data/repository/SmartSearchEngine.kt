package com.example.data.repository

import com.example.data.model.ProfessionalEntity

object SmartSearchEngine {

    private val FRENCH_TO_ARABIC_KEYWORDS = mapOf(
        "plombier" to listOf("سباك", "ترصيص", "تسريب", "سخان", "مياه", "مرحاض", "روبيني"),
        "plomberie" to listOf("سباكة", "ترصيص", "مواسير", "قنوات"),
        "fuite" to listOf("تسريب", "ماء", "خرير", "قطرة"),
        "electricien" to listOf("كهربائي", "كهرباء", "قاطع", "مأخذ", "إنارة", "طبلون"),
        "electricite" to listOf("كهرباء", "كابل", "شورت"),
        "clim" to listOf("مكيف", "تكييف", "تبريد", "غاز", "كومبريسور"),
        "climatiseur" to listOf("مكيف", "تكييف", "سبليت", "شارب", "كوندور"),
        "froid" to listOf("تبريد", "ثلاجة", "غرفة تبريد"),
        "frigo" to listOf("ثلاجة", "فريزر", "تبريد"),
        "mecanicien" to listOf("ميكانيكي", "ميكانيك", "سيارات", "محرك", "فرامل"),
        "scanner" to listOf("سكانير", "فحص", "دياغنوستيك", "diagnostic"),
        "peintre" to listOf("دهان", "صباغ", "طلاء", "ديكور", "بلاتين"),
        "peinture" to listOf("صباغة", "دهان", "ستيكو", "سابلي"),
        "menuisier" to listOf("نجار", "خشب", "مطبخ", "خزانة", "أثاث", "dressing"),
        "macon" to listOf("بناء", "ماصو", "سيراميك", "فايونس", "دالة"),
        "serrurier" to listOf("أقفال", "مفاتيح", "قفل", "باب مغلق"),
        "nettoyage" to listOf("تنظيف", "غسيل", "سجاد", "نظافة"),
        "demenagement" to listOf("نقل", "عفش", "أثاث", "شاحنة", "حمل"),
        "camera" to listOf("كاميرا", "مراقبة", "إنذار", "حماية")
    )

    fun normalize(text: String): String {
        var res = text.lowercase().trim()
        // Remove Arabic diacritics (tashkeel)
        res = res.replace(Regex("[\u064B-\u065F\u0670]"), "")
        // Normalize Arabic letters
        res = res.replace(Regex("[إأآا]"), "ا")
        res = res.replace("ة", "ه")
        res = res.replace("ى", "ي")
        res = res.replace("گ", "ك")
        res = res.replace("ڤ", "ف")
        res = res.replace("ؤ", "ء")
        res = res.replace("ئ", "ي")
        return res
    }

    fun matchesQuery(pro: ProfessionalEntity, query: String): Boolean {
        if (query.isBlank()) return true
        val normalizedQuery = normalize(query)
        val tokens = normalizedQuery.split("\\s+".toRegex()).filter { it.isNotBlank() }

        val proNameNorm = normalize(pro.fullName)
        val proProfArNorm = normalize(pro.professionNameAr)
        val proProfFrNorm = normalize(pro.professionNameFr)
        val proBioNorm = normalize(pro.bio)
        val proWilayaNorm = normalize(pro.wilayaNameAr)
        val proCommuneNorm = normalize(pro.communeNameAr)

        // Expand query tokens with synonyms
        val expandedSearchTerms = mutableListOf<String>()
        tokens.forEach { token ->
            expandedSearchTerms.add(token)
            FRENCH_TO_ARABIC_KEYWORDS.forEach { (frKey, arList) ->
                if (frKey.contains(token) || token.contains(frKey)) {
                    arList.forEach { expandedSearchTerms.add(normalize(it)) }
                }
            }
        }

        return expandedSearchTerms.any { term ->
            proNameNorm.contains(term) ||
            proProfArNorm.contains(term) ||
            proProfFrNorm.contains(term) ||
            proBioNorm.contains(term) ||
            proWilayaNorm.contains(term) ||
            proCommuneNorm.contains(term)
        }
    }

    fun calculateRankingScore(pro: ProfessionalEntity, query: String): Double {
        var score = 0.0

        // 1. Verification weight (Trust Badge)
        if (pro.isVerified) score += 100.0

        // 2. Pro Subscriber Priority
        if (pro.isProSubscriber) score += 35.0

        // 3. Real-Time Availability
        if (pro.isAvailable) score += 25.0

        // 4. Rating & Reviews Confidence
        score += pro.ratingAverage * 12.0
        score += kotlin.math.min(pro.ratingCount, 30) * 1.5

        // 5. Completed Jobs Track Record
        score += kotlin.math.min(pro.completedJobsCount, 50) * 1.0

        // 6. Direct Keyword Relevance
        if (query.isNotBlank()) {
            val normQuery = normalize(query)
            if (normalize(pro.professionNameAr).contains(normQuery) || normalize(pro.professionNameFr).contains(normQuery)) {
                score += 50.0
            }
            if (normalize(pro.fullName).contains(normQuery)) {
                score += 30.0
            }
        }

        return score
    }

    fun rankProfessionals(
        list: List<ProfessionalEntity>,
        query: String,
        sortByRating: Boolean = true
    ): List<ProfessionalEntity> {
        val filtered = list.filter { matchesQuery(it, query) }
        return if (sortByRating) {
            filtered.sortedByDescending { calculateRankingScore(it, query) }
        } else {
            filtered.sortedByDescending { it.createdAt }
        }
    }
}
