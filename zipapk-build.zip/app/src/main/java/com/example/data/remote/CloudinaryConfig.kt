package com.example.data.remote

object CloudinaryConfig {
    /**
     * Cloudinary Cloud Name.
     * Configure this value with your Cloudinary cloud name.
     */
    var CLOUD_NAME: String = "demo"

    /**
     * Cloudinary Unsigned Upload Preset.
     * Configure this value with your Cloudinary unsigned upload preset.
     * IMPORTANT: Never put your Cloudinary API Secret in the Android app.
     */
    var UPLOAD_PRESET: String = "ml_default"
}
