package com.example.data.model

data class Profession(
    val id: String,
    val nameAr: String,
    val nameFr: String,
    val categoryId: String,
    val categoryAr: String,
    val iconKey: String,
    val descriptionAr: String
)

data class ServiceCategory(
    val id: String,
    val nameAr: String,
    val iconKey: String,
    val descriptionAr: String
)

object ProfessionData {
    val categories: List<ServiceCategory> = listOf(
        ServiceCategory("plumbing_sanitary", "الترصيص الصحي والغاز", "plumbing", "أشغال السباكة، تصليح التسريبات وتركيب التجهيزات الصحية"),
        ServiceCategory("electricity_electronics", "الكهرباء المنزلية والصناعية", "bolt", "تركيب وتصليح الشبكات الكهربائية واللوحات"),
        ServiceCategory("cooling_heating", "التكييف والتبريد والتدفئة", "ac_unit", "تركيب وصيانة المكيفات وسخانات الماء والمراجل"),
        ServiceCategory("finishing_painting", "الدهان والتشطيب والديكور", "format_paint", "صباغة الجدران، ورق الحائط، الجبس بورد والديكور"),
        ServiceCategory("carpentry_aluminum", "النجارة والألمنيوم وPVC", "carpenter", "صناعة وتركيب الأبواب والنوافذ والمطابخ والخزائن"),
        ServiceCategory("appliances_repair", "تصليح الأجهزة الكهرومنزلية", "home_repair_service", "تصليح الغسالات، الثلاجات، الأفران والتلفزيونات"),
        ServiceCategory("construction_masonry", "البناء والترميم والتلبيس", "construction", "أشغال البناء، البلاط (الفايونس والكارلاج) والترميم"),
        ServiceCategory("blacksmith_iron", "الحدادة واللحام", "hardware", "صناعة الشباك، الأبواب الحديدية والهياكل المعدنية"),
        ServiceCategory("mechanic_auto", "الميكانيك والسيارات", "directions_car", "ميكانيك السيارات، كهرباء السيارات وتصليح العجلات"),
        ServiceCategory("cleaning_moving", "التنظيف ونقل الأثاث", "cleaning_services", "تنظيف المنازل والمكاتب وخدمات نقل العفش والبضائع"),
        ServiceCategory("other_custom", "مهن وحرف أخرى", "handyman", "تخصصات ومهن حرة ومخصصة غير مدرجة")
    )

    val professions: List<Profession> = listOf(
        // Plumbing & Sanitary
        Profession(
            id = "plumber",
            nameAr = "سباك / ترصيص صحي وغاز",
            nameFr = "Plombier Chauffagiste",
            categoryId = "plumbing_sanitary",
            categoryAr = "الترصيص الصحي والغاز",
            iconKey = "plumbing",
            descriptionAr = "تركيب شبكات المياه والغاز، تصليح التسربات وتركيب سخانات الماء"
        ),
        // Electricity
        Profession(
            id = "electrician",
            nameAr = "كهربائي مباني وصناعي",
            nameFr = "Électricien Bâtiment",
            categoryId = "electricity_electronics",
            categoryAr = "الكهرباء المنزلية والصناعية",
            iconKey = "bolt",
            descriptionAr = "تمديد الأسلاك، تركيب الإنارة والقواطع، وتصليح الأعطال الكهربائية"
        ),
        // Cooling & Heating
        Profession(
            id = "ac_technician",
            nameAr = "تقني تكييف وتبريد",
            nameFr = "Technicien Climatisation & Froid",
            categoryId = "cooling_heating",
            categoryAr = "التكييف والتبريد والتدفئة",
            iconKey = "ac_unit",
            descriptionAr = "شحن غاز المكيفات، تنظيف الفلاتر وتركيب وصيانة وحدات التبريد"
        ),
        Profession(
            id = "heater_technician",
            nameAr = "مختص سخانات ومدافئ ومراجل",
            nameFr = "Chauffagiste / Chaudière",
            categoryId = "cooling_heating",
            categoryAr = "التكييف والتبريد والتدفئة",
            iconKey = "local_fire_department",
            descriptionAr = "صيانة المدافئ، الشوفاج سنترال والشوفومات وضمان سلامة قنوات التهوية"
        ),
        // Painting & Decor
        Profession(
            id = "painter",
            nameAr = "صباغ / دهان منازل وديكور",
            nameFr = "Peintre en Bâtiment",
            categoryId = "finishing_painting",
            categoryAr = "الدهان والتشطيب والديكور",
            iconKey = "format_paint",
            descriptionAr = "صباغة داخلية وخارجية، معالجة الرطوبة، دهان الديكور وتركيب ورق الجدران"
        ),
        Profession(
            id = "plasterer_ba13",
            nameAr = "حرفي جبس وBA13 وديكور",
            nameFr = "Plâtrier / Placo Plâtre BA13",
            categoryId = "finishing_painting",
            categoryAr = "الدهان والتشطيب والديكور",
            iconKey = "layers",
            descriptionAr = "تركيب الأسقف المستعارة، الإضاءة المخفية والفواصل الجبسية"
        ),
        // Carpentry & Aluminum
        Profession(
            id = "wood_carpenter",
            nameAr = "نجار خشب ومطابخ",
            nameFr = "Menuisier Bois",
            categoryId = "carpentry_aluminum",
            categoryAr = "النجارة والألمنيوم وPVC",
            iconKey = "carpenter",
            descriptionAr = "تفصيل وتركيب غرف النوم، المطابخ العصرية والأبواب الخشبية"
        ),
        Profession(
            id = "aluminum_pvc",
            nameAr = "حرفي ألمنيوم وPVC ورويدو",
            nameFr = "Menuisier Aluminium & PVC",
            categoryId = "carpentry_aluminum",
            categoryAr = "النجارة والألمنيوم وPVC",
            iconKey = "window",
            descriptionAr = "تركيب النوافذ والأبواب العازلة، والستائر الكهربائية (Rideaux)"
        ),
        // Appliances Repair
        Profession(
            id = "appliance_repair",
            nameAr = "مصلح أجهزة كهرومنزلية",
            nameFr = "Réparateur Électroménager",
            categoryId = "appliances_repair",
            categoryAr = "تصليح الأجهزة الكهرومنزلية",
            iconKey = "home_repair_service",
            descriptionAr = "تصليح الغسالات، الثلاجات، غسالات الأواني والميكروويف"
        ),
        Profession(
            id = "tv_electronics_repair",
            nameAr = "تقني تلفزيونات وإلكترونيات",
            nameFr = "Réparateur TV & Électronique",
            categoryId = "appliances_repair",
            categoryAr = "تصليح الأجهزة الكهرومنزلية",
            iconKey = "tv",
            descriptionAr = "تصليح شاشات LED/Smart، اللوحات الإلكترونية وتغيير ليدات الإضاءة"
        ),
        // Construction & Masonry
        Profession(
            id = "mason",
            nameAr = "بناء وترميم وتلبيس",
            nameFr = "Maçon",
            categoryId = "construction_masonry",
            categoryAr = "البناء والترميم والتلبيس",
            iconKey = "construction",
            descriptionAr = "أشغال البناء العامة، بناء الجدران، التلبيس والترميمات الإنشائية"
        ),
        Profession(
            id = "tiler",
            nameAr = "مركب بلاط وفايونس وكارلاج",
            nameFr = "Poseur de Faïence & Carrelage",
            categoryId = "construction_masonry",
            categoryAr = "البناء والترميم والتلبيس",
            iconKey = "grid_view",
            descriptionAr = "تركيب البورسلان، سيراميك الأرضيات والحمامات والمطابخ بدقة عالية"
        ),
        // Blacksmith & Metal
        Profession(
            id = "blacksmith",
            nameAr = "حداد ولحام وتأمين",
            nameFr = "Serrurier / Ferronnier",
            categoryId = "blacksmith_iron",
            categoryAr = "الحدادة واللحام",
            iconKey = "hardware",
            descriptionAr = "صناعة الأبواب والحواجز الحديدية، تصليح الأقفال واللحام الاحترافي"
        ),
        // Automotive
        Profession(
            id = "auto_mechanic",
            nameAr = "ميكانيكي سيارات متنقل",
            nameFr = "Mécanicien Auto",
            categoryId = "mechanic_auto",
            categoryAr = "الميكانيك والسيارات",
            iconKey = "directions_car",
            descriptionAr = "تشخيص الأعطال بالكمبيوتر (Scanner)، صيانة المحركات وتغيير الزيت والفرامل"
        ),
        Profession(
            id = "auto_electrician",
            nameAr = "كهربائي سيارات",
            nameFr = "Électricien Auto",
            categoryId = "mechanic_auto",
            categoryAr = "الميكانيك والسيارات",
            iconKey = "electric_car",
            descriptionAr = "شحن البطاريات، فحص الدينامو والإنارة وحل أعطال الكهرباء في السيارات"
        ),
        // Cleaning & Moving
        Profession(
            id = "cleaning_pro",
            nameAr = "أخصائي تنظيف منازل ومكاتب",
            nameFr = "Agent de Nettoyage",
            categoryId = "cleaning_moving",
            categoryAr = "التنظيف ونقل الأثاث",
            iconKey = "cleaning_services",
            descriptionAr = "تنظيف عميق بعد البناء، غسيل السجاد والزرابي وتنظيف الواجهات"
        ),
        Profession(
            id = "mover_transport",
            nameAr = "نقل أثاث وبضائع (ديميناجمون)",
            nameFr = "Transport & Déménagement",
            categoryId = "cleaning_moving",
            categoryAr = "التنظيف ونقل الأثاث",
            iconKey = "local_shipping",
            descriptionAr = "نقل الأثاث والمعدات مع التغليف والعمال بين البلديات والولايات"
        )
    )

    fun normalizeArabicText(text: String): String {
        return text.trim()
            .lowercase()
            .replace(Regex("[أإآ]"), "ا")
            .replace('ة', 'ه')
            .replace('ى', 'ي')
            .replace(Regex("\\s+"), " ")
    }

    fun getProfessionById(id: String): Profession? {
        if (id.isBlank()) return null
        if (id.startsWith("custom_")) {
            val rawName = id.removePrefix("custom_").trim()
            if (rawName.isNotBlank()) {
                return Profession(
                    id = id,
                    nameAr = rawName,
                    nameFr = rawName,
                    categoryId = "other_custom",
                    categoryAr = "مهن وحرف أخرى",
                    iconKey = "handyman",
                    descriptionAr = "تخصص مهني مخصص"
                )
            }
        }
        return professions.find { it.id.equals(id, ignoreCase = true) }
    }

    fun getProfessionsByCategory(categoryId: String): List<Profession> =
        professions.filter { it.categoryId == categoryId }

    fun searchProfessions(query: String): List<Profession> {
        val normQuery = normalizeArabicText(query)
        if (normQuery.isEmpty()) return professions
        return professions.filter {
            normalizeArabicText(it.nameAr).contains(normQuery) ||
            normalizeArabicText(it.nameFr).contains(normQuery) ||
            normalizeArabicText(it.categoryAr).contains(normQuery) ||
            normalizeArabicText(it.descriptionAr).contains(normQuery)
        }
    }

    fun validateCustomProfessionName(name: String): String? {
        val trimmed = name.trim()
        if (trimmed.isBlank()) {
            return "يرجى كتابة اسم المهنة أو التخصص"
        }
        if (trimmed.length < 2) {
            return "اسم المهنة قصير جداً (حرفين على الأقل)"
        }
        if (trimmed.length > 50) {
            return "اسم المهنة طويل جداً (أقل من 50 حرف)"
        }
        // Ensure name contains at least some letters (Arabic or Latin)
        if (trimmed.all { !it.isLetter() && !it.isWhitespace() }) {
            return "يرجى كتابة اسم مهنة صحيح يحتوي على حروف واضحة"
        }
        return null
    }

    fun createCustomProfession(customNameAr: String): Profession {
        val trimmed = customNameAr.trim()
        val norm = normalizeArabicText(trimmed)
        
        // Check if there is an exact or close match in predefined professions to prevent duplicates
        val existingMatch = professions.find { 
            normalizeArabicText(it.nameAr) == norm ||
            normalizeArabicText(it.nameAr.replace(" / ", " ")) == norm
        }
        if (existingMatch != null) {
            return existingMatch
        }

        val safeId = "custom_${trimmed}"
        return Profession(
            id = safeId,
            nameAr = trimmed,
            nameFr = trimmed,
            categoryId = "other_custom",
            categoryAr = "مهن وحرف أخرى",
            iconKey = "handyman",
            descriptionAr = "تخصص مهني مخصص"
        )
    }
}
