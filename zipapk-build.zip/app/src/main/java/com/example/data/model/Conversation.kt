package com.example.data.model

data class Conversation(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhotoUrl: String = "",
    val providerId: String = "",
    val providerName: String = "",
    val providerPhotoUrl: String = "",
    val providerProfession: String = "",
    val serviceRequestId: String? = null,
    val serviceRequestTitle: String? = null,
    val lastMessage: String = "",
    val lastMessageAt: Long = System.currentTimeMillis(),
    val lastMessageSenderId: String = "",
    val customerUnreadCount: Int = 0,
    val providerUnreadCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "customerId" to customerId,
            "customerName" to customerName,
            "customerPhotoUrl" to customerPhotoUrl,
            "providerId" to providerId,
            "providerName" to providerName,
            "providerPhotoUrl" to providerPhotoUrl,
            "providerProfession" to providerProfession,
            "serviceRequestId" to serviceRequestId,
            "serviceRequestTitle" to serviceRequestTitle,
            "lastMessage" to lastMessage,
            "lastMessageAt" to lastMessageAt,
            "lastMessageSenderId" to lastMessageSenderId,
            "customerUnreadCount" to customerUnreadCount,
            "providerUnreadCount" to providerUnreadCount,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun generateId(customerId: String, providerId: String, serviceRequestId: String?): String {
            return if (!serviceRequestId.isNullOrBlank()) {
                "req_${serviceRequestId}"
            } else {
                "chat_${customerId}_${providerId}"
            }
        }

        fun fromFirestoreMap(id: String, map: Map<String, Any?>): Conversation {
            return Conversation(
                id = id,
                customerId = map["customerId"] as? String ?: "",
                customerName = map["customerName"] as? String ?: "",
                customerPhotoUrl = map["customerPhotoUrl"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                providerName = map["providerName"] as? String ?: "",
                providerPhotoUrl = map["providerPhotoUrl"] as? String ?: "",
                providerProfession = map["providerProfession"] as? String ?: "",
                serviceRequestId = map["serviceRequestId"] as? String,
                serviceRequestTitle = map["serviceRequestTitle"] as? String,
                lastMessage = map["lastMessage"] as? String ?: "",
                lastMessageAt = (map["lastMessageAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                lastMessageSenderId = map["lastMessageSenderId"] as? String ?: "",
                customerUnreadCount = (map["customerUnreadCount"] as? Number)?.toInt() ?: 0,
                providerUnreadCount = (map["providerUnreadCount"] as? Number)?.toInt() ?: 0,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
