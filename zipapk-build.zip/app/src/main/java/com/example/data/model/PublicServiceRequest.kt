package com.example.data.model

enum class PublicRequestStatus(val titleAr: String, val descriptionAr: String) {
    OPEN("مفتوح لاستقبال العروض", "الطلب معروض للحرفيين والمهنيين لتقديم عروضهم"),
    ASSIGNED("تم اختيار الحرفي", "تم قبول عرض الحرفي والطلب قيد التنفيذ"),
    COMPLETED("مكتمل", "تم إنجاز الخدمة بنجاح"),
    CANCELLED("ملغى", "تم إلغاء الطلب من قبل صاحب الطلب");

    companion object {
        fun fromString(value: String?): PublicRequestStatus {
            return when (value?.uppercase()) {
                "ASSIGNED" -> ASSIGNED
                "COMPLETED" -> COMPLETED
                "CANCELLED" -> CANCELLED
                else -> OPEN
            }
        }
    }
}

data class PublicServiceRequest(
    val id: String = "",
    val customerId: String = "",
    val providerId: String? = null,
    val creatorId: String? = null,
    val customerName: String = "",
    val customerPhone: String = "",
    val title: String = "",
    val description: String = "",
    val professionId: String = "",
    val professionNameAr: String = "",
    val professionCategoryAr: String = "",
    val wilayaCode: Int = 0,
    val wilayaName: String = "",
    val communeName: String = "",
    val addressDetails: String = "",
    val budgetDzd: Long? = null,
    val scheduledDate: Long? = null,
    val imageUrl: String? = null,
    val status: PublicRequestStatus = PublicRequestStatus.OPEN,
    val assignedProviderId: String? = null,
    val assignedProviderName: String? = null,
    val assignedOfferId: String? = null,
    val offersCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "customerId" to customerId,
            "providerId" to providerId,
            "creatorId" to creatorId,
            "customerName" to customerName,
            "customerPhone" to customerPhone,
            "title" to title,
            "description" to description,
            "professionId" to professionId,
            "professionNameAr" to professionNameAr,
            "professionCategoryAr" to professionCategoryAr,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "addressDetails" to addressDetails,
            "budgetDzd" to budgetDzd,
            "scheduledDate" to scheduledDate,
            "imageUrl" to imageUrl,
            "status" to status.name,
            "assignedProviderId" to assignedProviderId,
            "assignedProviderName" to assignedProviderName,
            "assignedOfferId" to assignedOfferId,
            "offersCount" to offersCount,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): PublicServiceRequest {
            return PublicServiceRequest(
                id = (map["id"] as? String)?.ifBlank { id } ?: id,
                customerId = map["customerId"] as? String ?: "",
                providerId = map["providerId"] as? String,
                creatorId = map["creatorId"] as? String,
                customerName = map["customerName"] as? String ?: "",
                customerPhone = map["customerPhone"] as? String ?: "",
                title = map["title"] as? String ?: "",
                description = map["description"] as? String ?: "",
                professionId = map["professionId"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                professionCategoryAr = map["professionCategoryAr"] as? String ?: "",
                wilayaCode = (map["wilayaCode"] as? Number)?.toInt() ?: 0,
                wilayaName = map["wilayaName"] as? String ?: "",
                communeName = map["communeName"] as? String ?: "",
                addressDetails = map["addressDetails"] as? String ?: "",
                budgetDzd = (map["budgetDzd"] as? Number)?.toLong(),
                scheduledDate = (map["scheduledDate"] as? Number)?.toLong(),
                imageUrl = map["imageUrl"] as? String,
                status = PublicRequestStatus.fromString(map["status"] as? String),
                assignedProviderId = map["assignedProviderId"] as? String,
                assignedProviderName = map["assignedProviderName"] as? String,
                assignedOfferId = map["assignedOfferId"] as? String,
                offersCount = (map["offersCount"] as? Number)?.toInt() ?: 0,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
