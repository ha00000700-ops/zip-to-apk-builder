package com.example.data.model

data class EncyclopediaPlant(
    val id: String,
    val arabicName: String,
    val frenchName: String,
    val commonName: String,
    val scientificName: String,
    val category: String, // أشجار مثمرة، خضروات، نباتات زينة، نباتات عطرية، نخيل
    val frenchCategory: String,
    val lightRequirement: String,
    val wateringRequirement: String,
    val wateringIntervalDays: Int,
    val fertilizingIntervalDays: Int,
    val soilType: String,
    val optimalTemperature: String,
    val plantingSeason: String,
    val propagationMethods: String,
    val commonDiseases: List<String>,
    val preventionAndCare: String,
    val commonProblemsAndSolutions: List<Pair<String, String>>,
    val description: String,
    val imageEmoji: String
)

data class DiseaseLibraryItem(
    val id: String,
    val arabicName: String,
    val frenchName: String,
    val scientificName: String,
    val pathogenType: String, // فطري / بكتيري / فيروسي / آفة حشرية / نقص عناصر / ري وحرارة
    val affectedPlants: List<String>,
    val symptomsSummary: String,
    val ipmPreventiveSteps: List<String>,
    val activeSubstances: List<String>,
    val phiDays: String,
    val safetyAndBeePrecautions: String,
    val authoritativeSource: String,
    val sourceUrl: String
)

object PlantEncyclopediaData {
    val plants = listOf(
        EncyclopediaPlant(
            id = "olive",
            arabicName = "شجرة الزيتون",
            frenchName = "Olivier",
            commonName = "الزيتون المتوسطي (سيقواز، شملال)",
            scientificName = "Olea europaea",
            category = "أشجار مثمرة",
            frenchCategory = "Arbres fruitiers",
            lightRequirement = "شمس مباشرة وكاملة (6-8 ساعات يومياً)",
            wateringRequirement = "مقاوم للجفاف، ري معتدل صيفاً في مرحلة الإزهار وعقد الثمار",
            wateringIntervalDays = 7,
            fertilizingIntervalDays = 30,
            soilType = "تربة جيدة الصرف، طينية كلسية أو رملية خفيفة",
            optimalTemperature = "15° إلى 30° مئوية، تحتاج لساعات برودة شتوية لكسر السكون",
            plantingSeason = "الخريف والشتاء وبداية الربيع (نوفمبر - مارس)",
            propagationMethods = "العقل الساقية، التطعيم، وزراعة الغراس المجذرة",
            commonDiseases = listOf(
                "عين الطاووس (Spilocaea oleagina)",
                "ذبابة ثمار الزيتون (Bactrocera oleae)",
                "سل الزيتون البكتيري (Pseudomonas savastanoi)",
                "حشرة الزيتون القشرية وبسيلا الزيتون"
            ),
            preventionAndCare = "التقليم الدوري لفتح قلب الشجرة لأشعة الشمس والتهوية، الرش بالنحاس الوقائي بعد التقليم وقبل الأمطار.",
            commonProblemsAndSolutions = listOf(
                "تساقط الثمار قبل النضج" to "تذبذب الري أثناء الصيف أو الإصابة بذبابة ثمار الزيتون.",
                "بقع دائرية رمادية على الأوراق" to "مرض عين الطاووس؛ رش بمركبات أوكسيكلورور النحاس.",
                "درنات وتورمات على الأغصان" to "سل الزيتون البكتيري؛ عقم أدوات التقليم واقطع الأغصان المصابة."
            ),
            description = "رمز بركة حوض البحر المتوسط وشمال أفريقيا، شجرة معمرة وصبورة ومصدر أجود أنواع زيت الزيتون في الجزائر.",
            imageEmoji = "🫒"
        ),
        EncyclopediaPlant(
            id = "tomato",
            arabicName = "نبات الطماطم",
            frenchName = "Tomate",
            commonName = "بندورة / طماطم الحقل والبيوت البلاستيكية",
            scientificName = "Solanum lycopersicum",
            category = "خضروات",
            frenchCategory = "Légumes",
            lightRequirement = "شمس مباشرة وفيرة (لا تقل عن 6 ساعات)",
            wateringRequirement = "ري منتظم ثابت لتفادي تشقق الثمار وعفن الطرف الزهري",
            wateringIntervalDays = 2,
            fertilizingIntervalDays = 10,
            soilType = "تربة طميية خصبة غنية بالمادة العضوية مع درجة حموضة 6.0 - 6.8",
            optimalTemperature = "20° إلى 28° مئوية نهاراً و 15° إلى 18° ليلاً",
            plantingSeason = "الربيع بعد زوال خطر الصقيع (فبراير - أبريل) وللمحصول الخريفي في أغسطس",
            propagationMethods = "البذور في مشاتل ثم تشتيل الغراس بعد 4-5 أسابيع",
            commonDiseases = listOf(
                "اللفحة المتأخرة واللفحة المبكرة (Phytophthora / Alternaria)",
                "عثة الطماطم (توتا أبسولوتا Tuta absoluta)",
                "البياض الدقيقي",
                "الذبول الفيوزاريومي والنيماتودا",
                "عفن الطرف الزهري (نقص الكالسيوم مع عدم انتظام الري)"
            ),
            preventionAndCare = "تهوية البيوت البلاستيكية، التخلص من الأوراق السفلية الملامسة للتربة، استخدام مصائد الفيرمون لعثة الطماطم.",
            commonProblemsAndSolutions = listOf(
                "اسوداد قاع الثمرة" to "عفن الطرف الزهري الناتج عن تذبذب الري ونقص امتصاص الكالسيوم.",
                "أنفاق شفافة داخل أنسجة الورقة" to "يرقات التوتا أبسولوتا؛ الرش بالباسيلوس أو مبيد حشري نوعي.",
                "اصفرار والتفاف الأوراق للأعلى" to "فيروس تجعد الأوراق المنقول بالذبابة البيضاء أو إجهاد حراري."
            ),
            description = "من أهم المحاصيل الاستهلاكية والتجارية، تتطلب عناية دقيقة بالري والوقاية من الآفات.",
            imageEmoji = "🍅"
        ),
        EncyclopediaPlant(
            id = "date_palm",
            arabicName = "نخلة التمر (دقلة نور)",
            frenchName = "Palmier Dattier",
            commonName = "النخيل الصحراوي (بسكرة، ورقلة، الوادي)",
            scientificName = "Phoenix dactylifera",
            category = "نخيل",
            frenchCategory = "Palmiers",
            lightRequirement = "شمس ساطعة كاملة وحرارة عالية",
            wateringRequirement = "ري عميق على فترات متباعدة، تفضل الري بالتنقيط أو الأحواض",
            wateringIntervalDays = 5,
            fertilizingIntervalDays = 45,
            soilType = "تتحمل الملوحة العالية والتربة الرملية الصحراوية جيدة النفاذية",
            optimalTemperature = "30° إلى 45° مئوية لنضج الثمار وجودتها العالية",
            plantingSeason = "الربيع وأوائل الصيف لغرس الفسائل",
            propagationMethods = "فصل الفسائل (الخلفات) المجاورة للأم أو زراعة الأنسجة",
            commonDiseases = listOf(
                "سوسة النخيل الحمراء (Rhynchophorus ferrugineus)",
                "مرض البيوض الفطري (Fusarium oxysporum albedinis)",
                "دودة البلح وحلم الغبار (بوفروة)",
                "مرض خياس طلع النخيل"
            ),
            preventionAndCare = "المراقبة الدقيقة لقواعد السعف لاكتشاف سوسة النخيل مبكراً، التعفير بالكبريت لمكافحة حلم الغبار (بوفروة)، التكريب الدوري.",
            commonProblemsAndSolutions = listOf(
                "نسيج عنكبوتي وغبار على الشماريخ" to "الإصابة بحلم الغبار (بوفروة)؛ التعفير بالكبريت الميكروني.",
                "اصفرار وموت السعف من جانب واحد" to "اشتباه بمرض البيوض؛ يجب عزل النخلة فوراً وإبلاغ الإرشاد الزراعي.",
                "نشارة خشبية ورائحة تخمر في الجذع" to "سوسة النخيل الحمراء الخطيرة؛ حقن مبيد متخصص فوراً."
            ),
            description = "شجرة الصحراء المباركة وثروة الجنوب الجزائري، تنتج أرقى تمور دقلة نور المشهورة عالمياً.",
            imageEmoji = "🌴"
        ),
        EncyclopediaPlant(
            id = "citrus",
            arabicName = "شجرة الليمون والموالح",
            frenchName = "Citronnier & Agrumes",
            commonName = "الحمضيات (الليمون، البرتقال، الكليمنتين)",
            scientificName = "Citrus limon / Citrus sinensis",
            category = "أشجار مثمرة",
            frenchCategory = "Arbres fruitiers",
            lightRequirement = "شمس كاملة مباشرة (6-8 ساعات)",
            wateringRequirement = "ري منتظم وفير في الصيف مع تجنب ملامسة الماء لجذع الشجرة",
            wateringIntervalDays = 4,
            fertilizingIntervalDays = 20,
            soilType = "تربة خفيفة عميقة غنية جيدة الصرف خالية من الكلس المفرط",
            optimalTemperature = "18° إلى 30° مئوية، حساسة جداً للصقيع والانجماد",
            plantingSeason = "نهاية الشتاء وبداية الربيع (فبراير - أبريل)",
            propagationMethods = "التطعيم على أصول مقاومة كالنارنج والفولكاماريانا",
            commonDiseases = listOf(
                "صانعة أنفاق أوراق الحمضيات (Phyllocnistis citrella)",
                "حشرات المن والحشرة القشرية والعفن الهبابي",
                "عفن الجذور والتصمغ الفطري (Phytophthora)",
                "نقص الحديد والزنك والمنغنيز (كلوروز اصفرار بين العروق)"
            ),
            preventionAndCare = "تسميد شيلات الحديد في الربيع، طلاء الجذوع بعجينة بوردو لحمايتها من التصمغ، عدم زراعة الشتلة عميقاً.",
            commonProblemsAndSolutions = listOf(
                "خطوط فضية متعرجة مع التفاف الأوراق الحديثة" to "صانعة أنفاق الحمضيات؛ رش مبيد زيت صيفي أو أبامكتين.",
                "اصفرار الأوراق مع بقاء العروق خضراء" to "نقص حاد في عنصر الحديد (الكلوروز)؛ أضف شيلات الحديد Sequestrene.",
                "صمغ يفرز من أسفل الجذع مع تشقق اللحاء" to "تصمغ الفيتوفثورا؛ اكشط المكان المصاب واطلِ بعجينة بوردو النحاسية."
            ),
            description = "أشجار خضراء يانعة تزين بساتين المتيجة والساحل، عطر أزهارها زكي وثمارها غنية بفيتامين C.",
            imageEmoji = "🍋"
        ),
        EncyclopediaPlant(
            id = "mint",
            arabicName = "النعناع الأخضر البلدي",
            frenchName = "Menthe Verte",
            commonName = "نعناع الحديقة والأصص",
            scientificName = "Mentha spicata",
            category = "نباتات عطرية",
            frenchCategory = "Plantes aromatiques",
            lightRequirement = "شمس صباحية أو ظل خفيف مفلتر",
            wateringRequirement = "يحب الرطوبة العالية وري متكرر دون إغراق",
            wateringIntervalDays = 1,
            fertilizingIntervalDays = 20,
            soilType = "تربة طميية غنية بالدبال والسماد العضوي",
            optimalTemperature = "18° إلى 25° مئوية",
            plantingSeason = "طوال فصلي الربيع والخريف",
            propagationMethods = "العقل الطرفية، الترقيد، وتقسيم الجذور والمدادات",
            commonDiseases = listOf(
                "صدأ النعناع (Puccinia menthae)",
                "العنكبوت الأحمر في الجفاف والحرارة",
                "ديدان الأوراق الخضراء"
            ),
            preventionAndCare = "قص الأغصان بانتظام لتشجيع نمو أوراق فتية جديدة، زراعته في أصيص منفصل لمنع غزوه للحديقة.",
            commonProblemsAndSolutions = listOf(
                "بثور برتقالية أسفل الورقة" to "صدأ النعناع الفطري؛ احلق النبات بالكامل ولا ترطب الأوراق.",
                "شحوب الأوراق ووجود خيوط ناعمة" to "عنكبوت أحمر؛ رش الماء بضغط على الأوراق واستخدم زيت النيم.",
                "استطالة الأغصان وضعف الرائحة" to "نقص الإضاءة، انقله لمكان يتلقى ضوءاً ساطعاً."
            ),
            description = "النبات العطري الأول في البيوت المغاربية والعربية لتحضير الشاي المنعش وتنكيه الأطباق.",
            imageEmoji = "🌿"
        ),
        EncyclopediaPlant(
            id = "fig",
            arabicName = "شجرة التين الشائع",
            frenchName = "Figuier",
            commonName = "التين / الكرموس / الباكور",
            scientificName = "Ficus carica",
            category = "أشجار مثمرة",
            frenchCategory = "Arbres fruitiers",
            lightRequirement = "شمس كاملة مباشرة",
            wateringRequirement = "ري معتدل، وتخفيف الري وقت نضج الثمار لمنع تشققها وتخمرها",
            wateringIntervalDays = 6,
            fertilizingIntervalDays = 30,
            soilType = "تتحمل جميع أنواع الأتربة وحتى التربة الكلسية والحجرية",
            optimalTemperature = "20° إلى 35° مئوية",
            plantingSeason = "فصل الشتاء والربيع أثناء فترة السكون",
            propagationMethods = "العقل الخشبية الناضجة في الشتاء والترقيد الهوائي",
            commonDiseases = listOf(
                "صدأ أوراق التين الفطري",
                "ذبابة ثمار التين",
                "نيماتودا تعقد الجذور",
                "خنفساء قلف التين"
            ),
            preventionAndCare = "جمع الثمار المتساقطة والمصابة أولاً بأول، دهن الجذوع بالجير الأبيض، رش مركب نحاسي شتوي.",
            commonProblemsAndSolutions = listOf(
                "تساقط الثمار وهي صغيرة وخضراء" to "إما عدم إتمام التلقيح (الكابريفيكاسيون) في بعض الأصناف، أو تذبذب مائي حاد.",
                "تشقق الثمار قبيل النضج" to "ري زائد أو هطول مفاجئ للأمطار وقت النضج.",
                "بقع بنية جافة تؤدي لسقوط مبكر للأوراق" to "صدأ التين؛ رش وقائي بالنحاس في بداية الموسم."
            ),
            description = "شجرة تراثية عظيمة تنتشر في جبال القبائل ومختلف ربوع الجزائر، ثمارها عسلية حلوة المذاق.",
            imageEmoji = "🫐"
        ),
        EncyclopediaPlant(
            id = "pothos",
            arabicName = "نبات البوتوس المنزلي",
            frenchName = "Pothos doré",
            commonName = "قلب عبد الوهاب / لبلاب الشيطان",
            scientificName = "Epipremnum aureum",
            category = "نباتات زينة",
            frenchCategory = "Plantes d'intérieur",
            lightRequirement = "ضوء ساطع غير مباشر، يتحمل الإضاءة المنخفضة",
            wateringRequirement = "ري عند جفاف السطح العلوي للتربة (بعمق 2-3 سم)",
            wateringIntervalDays = 6,
            fertilizingIntervalDays = 25,
            soilType = "تربة بيتموس أو كمبوست خفيفة مع بيرلايت ممتاز الصرف",
            optimalTemperature = "18° إلى 27° مئوية، لا يتحمل البرودة تحت 12°",
            plantingSeason = "طوال العام داخل المنزل",
            propagationMethods = "تجذير العقل في الماء بسهولة فائقة أو غرسها مباشرة في التربة",
            commonDiseases = listOf(
                "تعفن الجذور نتيجة الإفراط في الري",
                "البق الدقيقي في آباط الأوراق",
                "احتراق أطراف الأوراق بسبب الجفاف أو ملوحة الماء"
            ),
            preventionAndCare = "تأكد من وجود ثقوب تصريف في الأصيص، مسح الأوراق بقطعة قماش رطبة لإزالة الغبار، رشه برذاذ ماء خفيف صيفاً.",
            commonProblemsAndSolutions = listOf(
                "اصفرار الأوراق وتدليها مع رطوبة التربة" to "تعفن الجذور؛ توقف فوراً عن الري وافحص الجذور.",
                "أطراف الأوراق بنية ومقرمشة" to "جفاف الهواء الشديد أو استخدام ماء صنبور غني بالكلور والأملاح.",
                "فقدان اللون المموج وتحول الورقة للأخضر الداكن" to "قلة الإضاءة؛ انقله إلى قرب نافذة ساطعة بدون شمس حارقة."
            ),
            description = "أشهر وأسهل نبات زينة داخلي للمبتدئين، ينقي هواء المنزل ويعطي رونقاً حيوياً للغرف والمكاتب.",
            imageEmoji = "🪴"
        ),
        EncyclopediaPlant(
            id = "pepper",
            arabicName = "الفلفل الحلو والحار",
            frenchName = "Poivron et Piment",
            commonName = "فلفل حار / حلو / دريس",
            scientificName = "Capsicum annuum",
            category = "خضروات",
            frenchCategory = "Légumes",
            lightRequirement = "شمس مباشرة دافئة 6-8 ساعات",
            wateringRequirement = "ري منتظم معتدل، التعطيش الخفيف يزيد من حرارة الفلفل الحار",
            wateringIntervalDays = 3,
            fertilizingIntervalDays = 12,
            soilType = "تربة دافئة خصبة متعادلة مع تصريف ممتاز",
            optimalTemperature = "22° إلى 30° مئوية",
            plantingSeason = "من مارس إلى مايو بعد انتهاء البرد",
            propagationMethods = "البذور في صواني تشتيل دافئة",
            commonDiseases = listOf(
                "الذبول البكتيري والفيتوفثورا",
                "فيروس موزاييك الفلفل (TMV)",
                "العنكبوت الأبيض وحشرة التربس",
                "لفحة الشمس على الثمار"
            ),
            preventionAndCare = "التغطية البلاستيكية للقضاء على الأعشاب، التسميد بالبوتاسيوم والفوسفور أثناء التزهير والعقد.",
            commonProblemsAndSolutions = listOf(
                "تساقط الأزهار دون عقد ثمار" to "ارتفاع الحرارة فوق 35° أو تذبذب حاد في الرطوبة والري.",
                "بقع بيضاء جلدية على جانب الثمرة المعرض للشمس" to "لفحة الشمس؛ احرص على وجود مجموع خضري يظلل الثمار.",
                "تجعد والتواء الأوراق الفتية" to "إصابة بالتربس أو العناكب الدقيقة؛ رش بزيت النيم أو صابون زراعي."
            ),
            description = "عنصر أساسي في المطبخ الجزائري (الهريسة والشليطة والحميس)، محصول اقتصادي ووفير الإنتاج.",
            imageEmoji = "🌶️"
        ),
        EncyclopediaPlant(
            id = "rosemary",
            arabicName = "إكليل الجبل (الروزماري)",
            frenchName = "Romarin",
            commonName = "حصى البان / إكليل الجبل",
            scientificName = "Salvia rosmarinus",
            category = "نباتات عطرية",
            frenchCategory = "Plantes aromatiques",
            lightRequirement = "شمس كاملة قوية ومباشرة",
            wateringRequirement = "قليل ومقاوم جداً للجفاف، اسقِ فقط عند جفاف التربة تماماً",
            wateringIntervalDays = 7,
            fertilizingIntervalDays = 40,
            soilType = "تربة صخرية كلسية أو رملية خفيفة جافة الصرف",
            optimalTemperature = "15° إلى 32° مئوية، يتحمل برودة الشتاء",
            plantingSeason = "فصل الربيع أو الخريف",
            propagationMethods = "العقل شبه الخشبية، الترقيد، والبذور",
            commonDiseases = listOf(
                "تعفن الجذور بسبب ركود الماء",
                "البياض الدقيقي في الأماكن المغلقة سيئة التهوية"
            ),
            preventionAndCare = "لا تغدق عليه بالماء مطلقاً، وضعه في أشد أماكن الحديقة أو الشرفة تعرضاً للشمس والهواء الطلق.",
            commonProblemsAndSolutions = listOf(
                "تحول الأوراق إلى اللون البني ثم السقوط" to "تعفن الجذور بفعل الري الزائد؛ قلل الري فوراً وغير الأصيص بتربة جافة.",
                "طبقة بيضاء دقيقة على أوراقه الإبرية" to "بياض دقيقي نتيجة الرطوبة العالية وقلة التهوية."
            ),
            description = "شجيرة عطرية طبية متوسطية أصيلة، دائمة الخضرة، تنعش الحواس وتقاوم أصعب الظروف المناخية.",
            imageEmoji = "🌱"
        ),
        EncyclopediaPlant(
            id = "grapevine",
            arabicName = "شجرة الكرمة (العنب)",
            frenchName = "Vigne (Raisin)",
            commonName = "الدالية / الكرمة الجزائرية (المسكا والداتي)",
            scientificName = "Vitis vinifera",
            category = "أشجار مثمرة",
            frenchCategory = "Arbres fruitiers",
            lightRequirement = "شمس كاملة مباشرة",
            wateringRequirement = "ري منتظم أثناء النمو، وتقليله عند بدء تلون العناقيد لرفع نسبة السكر",
            wateringIntervalDays = 5,
            fertilizingIntervalDays = 25,
            soilType = "تربة عميقة نفاذة تفضل الترب الكلسية والحصوية",
            optimalTemperature = "20° إلى 32° مئوية",
            plantingSeason = "أواخر الشتاء (فبراير - مارس) غراس عارية الجذور",
            propagationMethods = "العقل الشتوية الخشبية والتطعيم على أصول مقاومة للفلوكسيرا",
            commonDiseases = listOf(
                "البياض الدقيقي (الأوديوم Oidium)",
                "البياض الزغبي (الميلديو Plasmopara viticola)",
                "العفن الرمادي (البوتريتس Botrytis cinerea)",
                "حشرة الفلوكسيرا وعثة العنب"
            ),
            preventionAndCare = "التقليم الشتوي والأخضر، الرش الوقائي بالكبريت للأوديوم والنحاس للميلديو، تهوية العناقيد بتوريق الأغصان المحيطة بها.",
            commonProblemsAndSolutions = listOf(
                "غبار أبيض رمادي ورائحة فطرية على الحبات والورق" to "البياض الدقيقي (الأوديوم)؛ التعفير بالكبريت الأصفر.",
                "بقع زيتية صفراء على وجه الورقة وزغب أبيض في ظهرها" to "البياض الزغبي (الميلديو)؛ رش بمركبات أوكسيكلورور النحاس.",
                "تعفن العناقيد قبل القطف" to "العفن الرمادي (البوتريتس) بفعل الرطوبة الشديدة وملاصقة الحبات."
            ),
            description = "دوالي العنب تغطي ساحات البيوت وتزين مزارع معسكر والمدية وتيزي وزو، عناقيدها لذيذة وأوراقها شهية للمحاشي.",
            imageEmoji = "🍇"
        )
    )

    // Scientific Treatment & Integrated Pest Management (IPM) Library
    val diseases = listOf(
        DiseaseLibraryItem(
            id = "powdery_mildew",
            arabicName = "البياض الدقيقي (الأوديوم)",
            frenchName = "Oïdium",
            scientificName = "Leveillula taurica / Erysiphe necator",
            pathogenType = "فطري",
            affectedPlants = listOf("طماطم", "عنب", "قرعيات", "فلفل", "ورد الزينة"),
            symptomsSummary = "ظهور مسحوق دقيقي أبيض على السطح العلوي أو السفلي للأوراق مع جفافها والتفاف حوافها.",
            ipmPreventiveSteps = listOf(
                "تهوية المزروعات وزيادة مسافات الزراعة للحد من الرطوبة المحصورة",
                "الرش الوقائي بمحلول بيكربونات البوتاسيوم المخفف (5غ/لتر)",
                "إزالة الأوراق القديمة المصابة في بداية ظهورها والتخلص منها بعيداً",
                "تجنب الإفراط في التسميد النتروجيني الذي يضعف جدران الخلايا النباتية"
            ),
            activeSubstances = listOf(
                "الكبريت الميكروني (Wettable Sulfur)",
                "أزوكسيستروبين (Azoxystrobin)",
                "ديفينوكونازول (Difenoconazole)"
            ),
            phiDays = "الكبريت: يوم واحد إلى 3 أيام | المبيدات الجهازية: 7 إلى 14 يوماً بحسب الملصق الرسمي",
            safetyAndBeePrecautions = "لا ترش الكبريت عند درجات حرارة تتجاوز 30°C لتجنب احتراق الأوراق. لا ترش وقت نشاط النحل صباحاً.",
            authoritativeSource = "المعهد الوطني الجزائري للأبحاث الزراعية (INRAA) / دليل منظمة FAO",
            sourceUrl = "https://www.inraa.dz"
        ),
        DiseaseLibraryItem(
            id = "downy_mildew",
            arabicName = "البياض الزغبي (الميلديو)",
            frenchName = "Mildiou",
            scientificName = "Plasmopara viticola / Phytophthora infestans",
            pathogenType = "فطري (شبه فطري Oomycete)",
            affectedPlants = listOf("عنب", "بطاطا", "طماطم", "بصل"),
            symptomsSummary = "بقع زيتية صفراء شفافة على الوجه العلوي للورقة يتبعها نمو زغبي رمادي/أبيض على الوجه السفلي، وسرعان ما تجف وتموت.",
            ipmPreventiveSteps = listOf(
                "عدم ترطيب أوراق النبات أثناء السقاية واعتماد الري بالتنقيط",
                "التوريق الصيفي لتهوية قلب الشجرة أو الشتلة وتسريع جفاف الندى",
                "التخلص التام من بقايا المحصول المصاب في نهاية الموسم"
            ),
            activeSubstances = listOf(
                "أوكسي كلوريد النحاس (Copper Oxychloride)",
                "مانكوزيب (Mancozeb)",
                "ميتالاكسيل (Metalaxyl)"
            ),
            phiDays = "المركبات النحاسية: 7 إلى 15 يوماً بحسب نوع المحصول المذكور في الملصق",
            safetyAndBeePrecautions = "ارتداء القفازات والنظارات الواقية، وتجنب تلويث المسطحات المائية بالمركبات النحاسية.",
            authoritativeSource = "المعهد التقني للمحاصيل الكبرى (ITGC) / INRAA",
            sourceUrl = "https://www.inraa.dz"
        ),
        DiseaseLibraryItem(
            id = "peacock_spot",
            arabicName = "عين الطاووس في الزيتون",
            frenchName = "Oeil de Paon",
            scientificName = "Spilocaea oleagina",
            pathogenType = "فطري",
            affectedPlants = listOf("زيتون"),
            symptomsSummary = "بقع دائرية رمادية محاطة بهالة صفراء تشبه ريشة الطاووس على وجه أوراق الزيتون، تؤدي لسقوط كثيف للأوراق وضعف الإنتاج.",
            ipmPreventiveSteps = listOf(
                "تقليم أشجار الزيتون السنوي لتفتيح تاج الشجرة ومرور الرياح وأشعة الشمس",
                "الرش بالنحاس الوقائي فور الانتهاء من التقليم الخريفي وقبل أمطار الشتاء",
                "غرس أصناف محلية مقاومة في المناطق الرطبة المنخفضة"
            ),
            activeSubstances = listOf(
                "هيدروكسيد النحاس (Copper Hydroxide)",
                "كبريتات النحاس الجيرية (عجينة بوردو Bouillie Bordelaise)",
                "كوبوكسيد"
            ),
            phiDays = "15-21 يوماً قبل جني ثمار الزيتون",
            safetyAndBeePrecautions = "سام للكائنات المائية. يحظر رش الأشجار أثناء ذروة التزهير الربيعي لحماية النحل.",
            authoritativeSource = "المعهد التقني لتربية الأشجار المثمرة والكروم (ITAF) / INRAA",
            sourceUrl = "https://www.inraa.dz"
        ),
        DiseaseLibraryItem(
            id = "tuta_absoluta",
            arabicName = "عثة الطماطم (توتا أبسولوتا)",
            frenchName = "Mineuse de la tomate (Tuta absoluta)",
            scientificName = "Tuta absoluta",
            pathogenType = "آفة حشرية",
            affectedPlants = listOf("طماطم", "باذنجان", "بطاطا"),
            symptomsSummary = "أنفاق عريضة وشفافة داخل نسيج الأوراق مع فضلات سوداء داخل النفق، وثقوب دقيقة حول عنق الثمار تؤدي لتعفنها.",
            ipmPreventiveSteps = listOf(
                "تركيب شبك حشري مانع على مداخل ونوافذ البيوت البلاستيكية",
                "استخدام مصائد الفيرمونات المائية واللاصقة للرصد والصيد المكثف للذكور",
                "إطلاق الأعداء الحيوية المفترسة (بق الميريد Nesidiocoris tenuis)",
                "الرش بالمكافحة الحيوية ببكتيريا باسيلوس ثورينجينسيس (Bacillus thuringiensis)"
            ),
            activeSubstances = listOf(
                "باسيلوس ثورينجينسيس (Bacillus thuringiensis)",
                "سبينوساد (Spinosad)",
                "إيمامكتين بنزوات (Emamectin benzoate)"
            ),
            phiDays = "باسيلوس: 0 يوم | سبينوساد: 3 أيام للطماطم",
            safetyAndBeePrecautions = "سبينوساد عالي السمية للنحل عند الرش الرطب، لذلك يرش مساءً بعد غروب الشمس فقط.",
            authoritativeSource = "المنظمة الدولية للمكافحة الحيوية (IOBC) / الفاو FAO",
            sourceUrl = "https://www.fao.org"
        ),
        DiseaseLibraryItem(
            id = "iron_chlorosis",
            arabicName = "الكلوروز (نقص عنصر الحديد)",
            frenchName = "Chlorose ferrique",
            scientificName = "Iron Deficiency Chlorosis (Fe)",
            pathogenType = "نقص عناصر فسيولوجي",
            affectedPlants = listOf("ليمون", "حمضيات", "دالية العنب", "أشجار اللوزيات", "غاردينيا"),
            symptomsSummary = "اصفرار شبكي واضح يبدأ في الأوراق الفتية العلوية مع بقاء العروق خضراء داكنة، وفي الحالات المتقدمة تتحول الورقة للبياض وتحترق حوافها.",
            ipmPreventiveSteps = listOf(
                "تجنب التربة الكلسية شديدة القلوية أو تحسينها بإضافة السماد العضوي المخمر والكمبوست",
                "عدم الإفراط في الري وتفادي اختناق الجذور بركود الماء",
                "إضافة شيلات الحديد ذات الرابطة القوية المقاومة للكلس (EDDHA Fe) مع ماء الري في بداية نشاط الربيع"
            ),
            activeSubstances = listOf(
                "شيلات الحديد Fe-EDDHA (مخصصة للتربة الكلسية والقلوية)",
                "شيلات الحديد Fe-EDTA أو Fe-DTPA (للأراضي المتعادلة والرش الورقي)"
            ),
            phiDays = "مغذي ومخصب ورقي وتربي، ليس له فترة أمان PHI كيميائية سامة",
            safetyAndBeePrecautions = "آمن تماماً على النحل والبيئة مع مراعاة الجرعات الموصوفة لتفادي التسمم بالعناصر الدقيقة.",
            authoritativeSource = "المعهد الوطني الجزائري للأبحاث الزراعية (INRAA) / دليل التسميد المتوسطي",
            sourceUrl = "https://www.inraa.dz"
        ),
        DiseaseLibraryItem(
            id = "red_palm_mite",
            arabicName = "حلم الغبار في النخيل (بوفروة)",
            frenchName = "Acarien du palmier (Boufaroua)",
            scientificName = "Oligonychus afrasiaticus",
            pathogenType = "آفة حشرية / أكاروس",
            affectedPlants = listOf("نخيل التمر"),
            symptomsSummary = "نسيج عنكبوتي دقيق يحبس الغبار على عراجين البلح الأخضر، تتغذى اليرقات والحشرات على قشرة الحبة فتتحول للون الفضي البني وتصبح صلبة غير صالحة للاستهلاك.",
            ipmPreventiveSteps = listOf(
                "غسيل العراجين بضغط ماء نظيف في بداية ظهور الإصابة",
                "التعفير الوقائي بالكبريت الأصفر الناعم أو الكبريت الميكروني في مرحلة الحبابوك",
                "نظافة الواحة وإزالة الحشائش المحيطة بجذوع النخيل"
            ),
            activeSubstances = listOf(
                "الكبريت الميكروني (Sulfur dust)",
                "هيكسياثيازوكس (Hexythiazox)",
                "زيت النيم العضوي (Azadirachtin)"
            ),
            phiDays = "الكبريت: آمن مع مراعاة الغسيل | المبيدات المتخصصة: 14 إلى 28 يوماً قبل نضج التمر",
            safetyAndBeePrecautions = "تجنب التعفير في الأيام شديدة الحرارة والرياح، حماية العيون والجهاز التنفسي أثناء التعفير.",
            authoritativeSource = "محطة أبحاث النخيل بسكرة - INRAA / FAO",
            sourceUrl = "https://www.inraa.dz"
        )
    )

    fun searchAll(query: String): List<Any> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return plants

        val matchingPlants = plants.filter {
            it.arabicName.contains(q, ignoreCase = true) ||
            it.frenchName.contains(q, ignoreCase = true) ||
            it.scientificName.contains(q, ignoreCase = true) ||
            it.category.contains(q, ignoreCase = true) ||
            it.commonDiseases.any { d -> d.contains(q, ignoreCase = true) }
        }

        val matchingDiseases = diseases.filter {
            it.arabicName.contains(q, ignoreCase = true) ||
            it.frenchName.contains(q, ignoreCase = true) ||
            it.scientificName.contains(q, ignoreCase = true) ||
            it.pathogenType.contains(q, ignoreCase = true) ||
            it.affectedPlants.any { p -> p.contains(q, ignoreCase = true) } ||
            it.activeSubstances.any { a -> a.contains(q, ignoreCase = true) }
        }

        val result = mutableListOf<Any>()
        result.addAll(matchingPlants)
        result.addAll(matchingDiseases)
        return result
    }
}
