package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlantDao {
    @Query("SELECT * FROM plants ORDER BY createdAt DESC")
    fun getAllPlants(): Flow<List<PlantEntity>>

    @Query("SELECT * FROM plants WHERE id = :id LIMIT 1")
    suspend fun getPlantById(id: Long): PlantEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlant(plant: PlantEntity): Long

    @Update
    suspend fun updatePlant(plant: PlantEntity)

    @Delete
    suspend fun deletePlant(plant: PlantEntity)

    @Query("SELECT COUNT(*) FROM plants")
    fun getPlantCount(): Flow<Int>
}

@Dao
interface DiagnosisDao {
    @Query("SELECT * FROM diagnoses ORDER BY timestamp DESC")
    fun getAllDiagnoses(): Flow<List<DiagnosisEntity>>

    @Query("SELECT * FROM diagnoses WHERE plantId = :plantId ORDER BY timestamp DESC")
    fun getDiagnosesForPlant(plantId: Long): Flow<List<DiagnosisEntity>>

    @Query("SELECT * FROM diagnoses WHERE plantCommonName = :plantName ORDER BY timestamp DESC")
    fun getDiagnosesByPlantName(plantName: String): Flow<List<DiagnosisEntity>>

    @Query("SELECT * FROM diagnoses WHERE id = :id LIMIT 1")
    suspend fun getDiagnosisById(id: Long): DiagnosisEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDiagnosis(diagnosis: DiagnosisEntity): Long

    @Update
    suspend fun updateDiagnosis(diagnosis: DiagnosisEntity)

    @Delete
    suspend fun deleteDiagnosis(diagnosis: DiagnosisEntity)

    @Query("SELECT * FROM diagnoses ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentDiagnoses(limit: Int): Flow<List<DiagnosisEntity>>
}

@Dao
interface CareTaskDao {
    @Query("SELECT * FROM care_tasks WHERE isCompleted = 0 ORDER BY dueDate ASC")
    fun getPendingTasks(): Flow<List<CareTaskEntity>>

    @Query("SELECT * FROM care_tasks WHERE plantId = :plantId ORDER BY dueDate ASC")
    fun getTasksForPlant(plantId: Long): Flow<List<CareTaskEntity>>

    @Query("SELECT * FROM care_tasks WHERE isCompleted = 1 ORDER BY completedAt DESC LIMIT 50")
    fun getCompletedTasks(): Flow<List<CareTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: CareTaskEntity): Long

    @Update
    suspend fun updateTask(task: CareTaskEntity)

    @Delete
    suspend fun deleteTask(task: CareTaskEntity)

    @Query("UPDATE care_tasks SET isCompleted = 1, completedAt = :completedAt WHERE id = :taskId")
    suspend fun markTaskCompleted(taskId: Long, completedAt: Long)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE linkedPlantId = :plantId ORDER BY timestamp ASC")
    fun getMessagesForPlant(plantId: Long): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Dao
interface PlantGrowthDao {
    @Query("SELECT * FROM plant_growth_entries WHERE plantId = :plantId ORDER BY timestamp ASC")
    fun getGrowthEntriesForPlant(plantId: Long): Flow<List<PlantGrowthEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrowthEntry(entry: PlantGrowthEntryEntity): Long

    @Delete
    suspend fun deleteGrowthEntry(entry: PlantGrowthEntryEntity)
}

@Dao
interface IssueReportDao {
    @Query("SELECT * FROM issue_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<IssueReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: IssueReportEntity): Long
}
