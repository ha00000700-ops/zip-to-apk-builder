package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY id DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE phone = :phone LIMIT 1")
    suspend fun getUserByPhone(phone: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isBlocked = :isBlocked WHERE id = :userId")
    suspend fun setUserBlockedStatus(userId: Long, isBlocked: Boolean)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUserById(id: Long)
}

@Dao
interface ProfessionalDao {
    @Query("SELECT * FROM professionals WHERE isApprovedByAdmin = 1 ORDER BY isVerified DESC, ratingAverage DESC")
    fun getAllApprovedProfessionals(): Flow<List<ProfessionalEntity>>

    @Query("SELECT * FROM professionals ORDER BY id DESC")
    fun getAllProfessionalsForAdmin(): Flow<List<ProfessionalEntity>>

    @Query("SELECT * FROM professionals WHERE id = :id LIMIT 1")
    fun getProfessionalById(id: Long): Flow<ProfessionalEntity?>

    @Query("SELECT * FROM professionals WHERE userId = :userId LIMIT 1")
    fun getProfessionalByUserId(userId: Long): Flow<ProfessionalEntity?>

    @Query("""
        SELECT * FROM professionals 
        WHERE isApprovedByAdmin = 1
        AND (:wilayaCode = 0 OR wilayaCode = :wilayaCode)
        AND (:serviceId = 0 OR serviceCategoryId = :serviceId)
        AND (:onlyAvailable = 0 OR isAvailable = 1)
        AND (:searchQuery = '' OR fullName LIKE '%' || :searchQuery || '%' OR professionNameAr LIKE '%' || :searchQuery || '%' OR professionNameFr LIKE '%' || :searchQuery || '%' OR bio LIKE '%' || :searchQuery || '%')
        ORDER BY isVerified DESC, ratingAverage DESC, completedJobsCount DESC
    """)
    fun filterProfessionals(
        wilayaCode: Int,
        serviceId: Long,
        onlyAvailable: Int,
        searchQuery: String
    ): Flow<List<ProfessionalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfessional(professional: ProfessionalEntity): Long

    @Update
    suspend fun updateProfessional(professional: ProfessionalEntity)

    @Query("UPDATE professionals SET isAvailable = :isAvailable WHERE id = :id")
    suspend fun setAvailability(id: Long, isAvailable: Boolean)

    @Query("UPDATE professionals SET isVerified = :isVerified, verificationStatus = :status WHERE id = :id")
    suspend fun setVerification(id: Long, isVerified: Boolean, status: VerificationStatus)

    @Query("UPDATE professionals SET isApprovedByAdmin = :isApproved WHERE id = :id")
    suspend fun setApprovalStatus(id: Long, isApproved: Boolean)

    @Query("UPDATE professionals SET ratingAverage = :avg, ratingCount = :count WHERE id = :id")
    suspend fun updateRating(id: Long, avg: Double, count: Int)

    @Query("UPDATE professionals SET completedJobsCount = completedJobsCount + 1 WHERE id = :id")
    suspend fun incrementCompletedJobs(id: Long)

    @Query("DELETE FROM professionals WHERE id = :id")
    suspend fun deleteProfessionalById(id: Long)
}

@Dao
interface VerificationRequestDao {
    @Query("SELECT * FROM verification_requests ORDER BY createdAt DESC")
    fun getAllVerificationRequests(): Flow<List<VerificationRequestEntity>>

    @Query("SELECT * FROM verification_requests WHERE status = 'PENDING' ORDER BY createdAt ASC")
    fun getPendingVerificationRequests(): Flow<List<VerificationRequestEntity>>

    @Query("SELECT * FROM verification_requests WHERE professionalId = :proId ORDER BY createdAt DESC LIMIT 1")
    fun getVerificationRequestForPro(proId: Long): Flow<VerificationRequestEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVerificationRequest(request: VerificationRequestEntity): Long

    @Query("UPDATE verification_requests SET status = :status, adminRejectionReason = :reason, reviewedAt = :reviewedAt WHERE id = :id")
    suspend fun updateVerificationRequestStatus(id: Long, status: VerificationStatus, reason: String = "", reviewedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM verification_requests WHERE id = :id")
    suspend fun deleteVerificationRequest(id: Long)
}

@Dao
interface ServiceCategoryDao {
    @Query("SELECT * FROM services WHERE isActive = 1 ORDER BY displayOrder ASC")
    fun getActiveServices(): Flow<List<ServiceCategoryEntity>>

    @Query("SELECT * FROM services ORDER BY displayOrder ASC")
    fun getAllServices(): Flow<List<ServiceCategoryEntity>>

    @Query("SELECT * FROM services WHERE id = :id LIMIT 1")
    fun getServiceById(id: Long): Flow<ServiceCategoryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertService(service: ServiceCategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllServices(services: List<ServiceCategoryEntity>)

    @Update
    suspend fun updateService(service: ServiceCategoryEntity)

    @Query("DELETE FROM services WHERE id = :id")
    suspend fun deleteService(id: Long)
}

@Dao
interface WilayaDao {
    @Query("SELECT * FROM wilayas ORDER BY code ASC")
    fun getAllWilayas(): Flow<List<WilayaEntity>>

    @Query("SELECT * FROM communes WHERE wilayaCode = :wilayaCode ORDER BY nameAr ASC")
    fun getCommunesByWilaya(wilayaCode: Int): Flow<List<CommuneEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWilayas(wilayas: List<WilayaEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunes(communes: List<CommuneEntity>)
}

@Dao
interface ServiceRequestDao {
    @Query("SELECT * FROM service_requests ORDER BY createdAt DESC")
    fun getAllRequests(): Flow<List<ServiceRequestEntity>>

    @Query("SELECT * FROM service_requests WHERE customerId = :customerId ORDER BY createdAt DESC")
    fun getRequestsByCustomer(customerId: Long): Flow<List<ServiceRequestEntity>>

    @Query("SELECT * FROM service_requests WHERE professionalId = :professionalId OR (professionalId IS NULL AND wilayaCode = :wilayaCode AND serviceCategoryId = :serviceCategoryId) ORDER BY createdAt DESC")
    fun getRequestsForProfessional(professionalId: Long, wilayaCode: Int, serviceCategoryId: Long): Flow<List<ServiceRequestEntity>>

    @Query("SELECT * FROM service_requests WHERE id = :id LIMIT 1")
    fun getRequestById(id: Long): Flow<ServiceRequestEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequest(request: ServiceRequestEntity): Long

    @Update
    suspend fun updateRequest(request: ServiceRequestEntity)

    @Query("UPDATE service_requests SET status = :status, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateRequestStatus(id: Long, status: RequestStatus, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE service_requests SET status = 'CANCELLED', cancellationReason = :reason, updatedAt = :updatedAt WHERE id = :id")
    suspend fun cancelRequest(id: Long, reason: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE service_requests SET agreedPriceDzd = :price, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateAgreedPrice(id: Long, price: Double, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE service_requests SET professionalId = :proId, professionalName = :proName, professionalPhone = :proPhone, status = 'ACCEPTED', updatedAt = :updatedAt WHERE id = :id")
    suspend fun assignProfessionalToRequest(id: Long, proId: Long, proName: String, proPhone: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE service_requests SET isRated = 1 WHERE id = :id")
    suspend fun markRequestRated(id: Long)

    @Query("DELETE FROM service_requests WHERE id = :id")
    suspend fun deleteRequestById(id: Long)
}

@Dao
interface RequestOfferDao {
    @Query("SELECT * FROM request_offers WHERE requestId = :requestId ORDER BY createdAt DESC")
    fun getOffersForRequest(requestId: Long): Flow<List<RequestOfferEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOffer(offer: RequestOfferEntity): Long

    @Query("UPDATE request_offers SET status = :status WHERE id = :offerId")
    suspend fun updateOfferStatus(offerId: Long, status: OfferStatus)

    @Query("UPDATE request_offers SET status = 'REJECTED' WHERE requestId = :requestId AND id != :acceptedOfferId")
    suspend fun rejectOtherOffersForRequest(requestId: Long, acceptedOfferId: Long)
}


@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE professionalId = :professionalId ORDER BY createdAt DESC")
    fun getReviewsForProfessional(professionalId: Long): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews ORDER BY createdAt DESC")
    fun getAllReviews(): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews WHERE isFlagged = 1 ORDER BY createdAt DESC")
    fun getFlaggedReviews(): Flow<List<ReviewEntity>>

    @Query("SELECT * FROM reviews WHERE requestId = :requestId LIMIT 1")
    suspend fun getReviewForRequest(requestId: Long): ReviewEntity?

    @Query("SELECT * FROM reviews WHERE id = :id LIMIT 1")
    suspend fun getReviewById(id: Long): ReviewEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity): Long

    @Query("UPDATE reviews SET isFlagged = 1, flagReason = :reason WHERE id = :id")
    suspend fun flagReview(id: Long, reason: String)

    @Query("DELETE FROM reviews WHERE id = :id")
    suspend fun deleteReview(id: Long)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE requestId = :requestId ORDER BY timestamp ASC")
    fun getMessagesForRequest(requestId: Long): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE recipientUserId = :userId OR recipientUserId = 0 ORDER BY createdAt DESC")
    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE (recipientUserId = :userId OR recipientUserId = 0) AND isRead = 0")
    fun getUnreadNotificationsCount(userId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markNotificationAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1 WHERE recipientUserId = :userId OR recipientUserId = 0")
    suspend fun markAllNotificationsAsRead(userId: Long)

    @Query("DELETE FROM notifications WHERE recipientUserId = :userId")
    suspend fun clearUserNotifications(userId: Long)
}

@Dao
interface ReportDao {
    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<ReportEntity>>

    @Query("SELECT * FROM reports WHERE status = :status ORDER BY createdAt DESC")
    fun getReportsByStatus(status: ReportStatus): Flow<List<ReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity): Long

    @Query("UPDATE reports SET status = :status, adminActionTaken = :actionTaken WHERE id = :id")
    suspend fun updateReportStatus(id: Long, status: ReportStatus, actionTaken: String = "")

    @Query("DELETE FROM reports WHERE id = :id")
    suspend fun deleteReport(id: Long)
}

@Dao
interface AdminSettingsDao {
    @Query("SELECT * FROM admin_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<AdminSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: AdminSettingsEntity)
}
