package com.example.data.model

enum class PaymentStatus(val code: String, val titleAr: String) {
    UNPAID("UNPAID", "غير مدفوع"),
    PENDING("PENDING", "قيد انتظار المعالجة"),
    SUCCESSFUL("SUCCESSFUL", "مدفوع بنجاح"),
    FAILED("FAILED", "فشلت عملية الدفع"),
    CANCELLED("CANCELLED", "ملغاة");

    companion object {
        fun fromCode(code: String?): PaymentStatus {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: UNPAID
        }
    }
}
