package com.example.data.future

/**
 * Clean architectural contracts and abstractions for future integrations:
 * 1. Algerian E-Payment (Edahabia / CIB / SATIM / BaridiMob)
 * 2. Platform Commission System
 * 3. AI Multi-modal Problem Diagnostics (Gemini)
 * 4. Pro Subscription Manager
 */

data class PaymentTransactionResult(
    val isSuccess: Boolean,
    val transactionId: String,
    val paymentMethod: DzPaymentMethod,
    val amountDzd: Double,
    val receiptUrl: String? = null,
    val message: String
)

enum class DzPaymentMethod(val titleAr: String, val titleFr: String) {
    EDAHABIA("البطاقة الذهبية (بريد الجزائر)", "Carte Edahabia"),
    CIB("بطاقة بنكية CIB / SATIM", "Carte Interbancaire CIB"),
    BARIDIMOB("تطبيق بريدي موب BaridiMob", "Application BaridiMob"),
    CASH_ON_DELIVERY("الدفع نقداً بعد المعاينة", "Paiement en espèces")
}

interface DzEPaymentGateway {
    suspend fun initiateServicePayment(
        requestId: Long,
        amountDzd: Double,
        method: DzPaymentMethod,
        customerPhone: String
    ): PaymentTransactionResult

    suspend fun verifyPaymentStatus(transactionId: String): Boolean
}

class MockDzEPaymentGateway : DzEPaymentGateway {
    override suspend fun initiateServicePayment(
        requestId: Long,
        amountDzd: Double,
        method: DzPaymentMethod,
        customerPhone: String
    ): PaymentTransactionResult {
        return PaymentTransactionResult(
            isSuccess = true,
            transactionId = "DZ-TXN-${System.currentTimeMillis().toString().takeLast(6)}",
            paymentMethod = method,
            amountDzd = amountDzd,
            message = "تمت محاكاة عملية الدفع بنجاح عبر ${method.titleAr}"
        )
    }

    override suspend fun verifyPaymentStatus(transactionId: String): Boolean = true
}

data class AiDiagnosisResult(
    val detectedProblem: String,
    val suggestedCategoryKey: String,
    val estimatedUrgency: String,
    val safetyTips: List<String>,
    val estimatedRepairCostDzd: String
)

interface AiProblemDiagnosticService {
    suspend fun analyzeProblem(
        problemDescription: String,
        imageKeywords: List<String> = emptyList()
    ): AiDiagnosisResult
}

class RuleBasedAiDiagnosticService : AiProblemDiagnosticService {
    override suspend fun analyzeProblem(
        problemDescription: String,
        imageKeywords: List<String>
    ): AiDiagnosisResult {
        val text = problemDescription.lowercase()
        return when {
            text.contains("ماء") || text.contains("تسريب") || text.contains("حوض") || text.contains("سخان") || text.contains("مجاري") -> {
                AiDiagnosisResult(
                    detectedProblem = "خلل أو تسريب في شبكة المياه / الصرف الصحي",
                    suggestedCategoryKey = "plumbing",
                    estimatedUrgency = "مستعجل",
                    safetyTips = listOf("أغلق صمام المياه الرئيسي للشقة فوراً", "تجنب تشغيل الأجهزة الكهربائية القريبة من البلل"),
                    estimatedRepairCostDzd = "1500 - 4000 دج"
                )
            }
            text.contains("كهرباء") || text.contains("ماس") || text.contains("قاطع") || text.contains("شورت") || text.contains("ضوء") -> {
                AiDiagnosisResult(
                    detectedProblem = "عطل في التغذية الكهربائية أو قصر دارة (ماس)",
                    suggestedCategoryKey = "electricity",
                    estimatedUrgency = "طارئ جداً",
                    safetyTips = listOf("افصل القاطع الرئيسي (Disjoncteur)", "لا تلمس الأسلاك المكشوفة نهائياً"),
                    estimatedRepairCostDzd = "2000 - 5000 دج"
                )
            }
            text.contains("مكيف") || text.contains("تبريد") || text.contains("غاز") || text.contains("سخانة") -> {
                AiDiagnosisResult(
                    detectedProblem = "نقص غاز التبريد أو انسداد في فلاتر المكيف",
                    suggestedCategoryKey = "hvac",
                    estimatedUrgency = "عادي",
                    safetyTips = listOf("أطفئ المكيف لتجنب احتراق الضاغط (Compresseur)", "تأكد من تنظيف الفلاتر الخارجية"),
                    estimatedRepairCostDzd = "2500 - 6000 دج"
                )
            }
            text.contains("سيارة") || text.contains("موتور") || text.contains("فرامل") || text.contains("بان") -> {
                AiDiagnosisResult(
                    detectedProblem = "عطل ميكانيكي أو كهربائي في المحرك / منظومة الفرامل",
                    suggestedCategoryKey = "mechanic",
                    estimatedUrgency = "مستعجل",
                    safetyTips = listOf("أوقف المركبة في مكان آمن واشعل أضواء الخطر (Warning)", "لا تفتح غطاء ماء الرديتر وهو ساخن"),
                    estimatedRepairCostDzd = "2000 - 8000 دج"
                )
            }
            else -> {
                AiDiagnosisResult(
                    detectedProblem = "طلب صيانة أو خدمة عامة",
                    suggestedCategoryKey = "general",
                    estimatedUrgency = "عادي",
                    safetyTips = listOf("قم بتصوير العطل بوضوح للحرفي", "حدد الموقع بدقة لتسهيل وصول الحرفي"),
                    estimatedRepairCostDzd = "حسب المعاينة المباشرة"
                )
            }
        }
    }
}
