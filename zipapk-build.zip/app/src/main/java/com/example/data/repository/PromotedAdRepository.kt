package com.example.data.repository

import com.example.data.model.*
import com.example.data.remote.FirestoreConstants
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/**
 * Repository handling Promoted Advertisements CRUD, Real-time Observers, and Chargily Checkout creation.
 */
class PromotedAdRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    val currentUserId: String?
        get() = auth.currentUser?.uid

    /**
     * Create or initialize a new promotional advertisement in PENDING_PAYMENT status.
     */
    suspend fun createPromotedAd(
        adTitle: String,
        adDescription: String,
        adImageUrl: String,
        packageChoice: AdBoostPackage,
        providerProfile: ServiceProviderProfile
    ): AuthResult<PromotedAd> {
        val uid = currentUserId ?: return AuthResult.Error("يجب تسجيل الدخول أولاً كحرفي")

        return try {
            val docRef = firestore.collection(FirestoreConstants.PROMOTED_ADS).document()
            val newAd = PromotedAd(
                id = docRef.id,
                providerId = uid,
                providerName = providerProfile.fullName,
                providerAvatarUrl = providerProfile.effectiveAvatarUrl(),
                providerPhone = providerProfile.phone,
                professionId = providerProfile.professionId,
                professionNameAr = providerProfile.professionNameAr,
                categoryId = providerProfile.professionCategoryAr,
                adTitle = adTitle.trim(),
                adDescription = adDescription.trim(),
                adImageUrl = adImageUrl.trim(),
                wilayaCode = providerProfile.wilayaCode.toString(),
                wilayaName = providerProfile.wilayaName,
                communeCode = "",
                communeName = providerProfile.communeName,
                packageId = packageChoice.id,
                priceDzd = packageChoice.priceDzd,
                durationDays = packageChoice.durationDays,
                priorityLevel = packageChoice.priorityLevel,
                status = AdStatus.PENDING_PAYMENT,
                paymentStatus = PaymentStatus.UNPAID,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            docRef.set(newAd.toFirestoreMap()).await()
            AuthResult.Success(newAd)
        } catch (e: Exception) {
            AuthResult.Error(e.localizedMessage ?: "حدث خطأ أثناء إنشاء الإعلان الترويجي")
        }
    }

    /**
     * Initiates a secure Chargily Pay checkout session for the promotional advertisement via Cloud Functions.
     */
    suspend fun initiateAdBoostCheckout(
        adId: String,
        paymentMethod: PaymentMethod
    ): AuthResult<CheckoutResult> {
        val user = auth.currentUser ?: return AuthResult.Error("يجب تسجيل الدخول أولاً")

        return try {
            val tokenResult = user.getIdToken(false).await()
            val idToken = tokenResult.token
                ?: return AuthResult.Error("تعذر الحصول على رمز المصادقة الآمن")

            // Fetch the existing ad to get the correct packageId
            val adSnapshot = firestore.collection("promotedAds").document(adId).get().await()
            val packageId = adSnapshot.getString("packageId") ?: com.example.data.model.AdBoostPackage.BASIC.id

            val supabaseEdgeUrl = com.example.data.remote.ChargilyConfig.SUPABASE_CHARGILY_EDGE_URL
            val jsonPayload = JSONObject().apply {
                put("action", "ad_checkout")
                put("adId", adId)
                put("packageId", packageId)
                put("paymentMethod", paymentMethod.code)
            }

            val client = OkHttpClient()
            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val edgeReqBuilder = Request.Builder()
                .url(supabaseEdgeUrl)
                .addHeader("Authorization", "Bearer $idToken")
                .addHeader("Content-Type", "application/json")
            if (com.example.data.remote.SupabaseConfig.SUPABASE_KEY.isNotBlank()) {
                edgeReqBuilder.addHeader("apikey", com.example.data.remote.SupabaseConfig.SUPABASE_KEY)
            }

            var response = withContext(Dispatchers.IO) {
                client.newCall(edgeReqBuilder.post(requestBody).build()).execute()
            }

            var responseStr = response.body?.string()

            // Fallback to Firebase Cloud Functions if Supabase Edge Function is not yet deployed (404)
            if (response.code == 404) {
                val projectId = firestore.app.options.projectId
                val cloudFunctionUrl = "https://us-central1-$projectId.cloudfunctions.net/chargilyAdCheckout"
                val fbReq = Request.Builder()
                    .url(cloudFunctionUrl)
                    .addHeader("Authorization", "Bearer $idToken")
                    .post(requestBody)
                    .build()
                response = withContext(Dispatchers.IO) {
                    client.newCall(fbReq).execute()
                }
                responseStr = response.body?.string()
            }

            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(responseStr ?: "").optString("error", "فشل تهيئة جلسة دفع الترويج")
                } catch (e: Exception) {
                    "فشل الاتصال بخادم الدفع الترويجي"
                }
                return AuthResult.Error(errorMsg)
            }

            val responseJson = JSONObject(responseStr ?: "")
            val checkoutId = responseJson.getString("checkoutId")
            val checkoutUrl = responseJson.getString("checkoutUrl")
            val amountDzd = responseJson.optLong("amountDzd", 1000L)

            AuthResult.Success(
                CheckoutResult(
                    checkoutId = checkoutId,
                    checkoutUrl = checkoutUrl,
                    amountDzd = amountDzd,
                    paymentMethod = paymentMethod
                )
            )
        } catch (e: Exception) {
            AuthResult.Error(e.localizedMessage ?: "حدث خطأ أثناء تهيئة دفع الإعلان الترويجي")
        }
    }

    /**
     * Observes real-time updates for a single promoted ad.
     */
    fun observePromotedAd(adId: String): Flow<PromotedAd?> = callbackFlow {
        val listener = firestore.collection(FirestoreConstants.PROMOTED_ADS)
            .document(adId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val map = snapshot.data ?: emptyMap<String, Any?>()
                    trySend(PromotedAd.fromFirestoreMap(map, snapshot.id))
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Observes the current provider's promotional advertisements.
     */
    fun observeProviderAds(providerId: String): Flow<List<PromotedAd>> = callbackFlow {
        val listener = firestore.collection(FirestoreConstants.PROMOTED_ADS)
            .whereEqualTo("providerId", providerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val ads = snapshot.documents.mapNotNull { doc ->
                        val map = doc.data ?: return@mapNotNull null
                        PromotedAd.fromFirestoreMap(map, doc.id)
                    }.sortedByDescending { it.createdAt }
                    trySend(ads)
                } else {
                    trySend(emptyList())
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Observes all active promoted ads for marketplace discovery.
     */
    fun observeActivePromotedAds(): Flow<List<PromotedAd>> = callbackFlow {
        val listener = firestore.collection(FirestoreConstants.PROMOTED_ADS)
            .whereEqualTo("status", AdStatus.ACTIVE.name)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val now = System.currentTimeMillis()
                    val activeAds = snapshot.documents.mapNotNull { doc ->
                        val map = doc.data ?: return@mapNotNull null
                        val ad = PromotedAd.fromFirestoreMap(map, doc.id)
                        // Filter out expired ads on client side as well for safety
                        if (ad.endDate == 0L || ad.endDate > now) ad else null
                    }.sortedWith(
                        compareByDescending<PromotedAd> { it.priorityLevel }
                            .thenByDescending { it.createdAt }
                    )
                    trySend(activeAds)
                } else {
                    trySend(emptyList())
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Cancel an advertisement if it is in PENDING_PAYMENT or ACTIVE status.
     */
    suspend fun cancelPromotedAd(adId: String): AuthResult<Unit> {
        val uid = currentUserId ?: return AuthResult.Error("يجب تسجيل الدخول أولاً")
        return try {
            val docRef = firestore.collection(FirestoreConstants.PROMOTED_ADS).document(adId)
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) return AuthResult.Error("الإعلان غير موجود")

            val ownerId = snapshot.getString("providerId") ?: ""
            if (ownerId != uid) return AuthResult.Error("لا تملك صلاحية تعديل هذا الإعلان")

            docRef.update(
                mapOf(
                    "status" to AdStatus.CANCELLED.name,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Error(e.localizedMessage ?: "فشل إلغاء الإعلان الترويجي")
        }
    }
}
