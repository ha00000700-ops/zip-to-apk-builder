package com.example.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class PlantDiagnosisResult(
    val plantCommonName: String,
    val plantScientificName: String,
    val generalHealth: String,
    val diseaseName: String,
    val scientificDiseaseName: String,
    val pathogenType: String = "غير محدد", // فطري / بكتيري / فيروسي / آفة حشرية / نقص عناصر / ري وحرارة
    val confidenceLevel: String,
    val severity: String,
    val urgency: String,
    val affectedPart: String,
    val symptomsSummary: String,
    val possibleCauses: String,
    val alternativeDiagnoses: String,
    val environmentalFactors: String,
    val immediateActions: String,
    val preventiveCare: String,
    val chemicalTreatments: String,
    val isUnclearImage: Boolean = false,
    val clarifyingQuestions: List<String> = emptyList(),
    val scientificSources: String = "المعهد الوطني للأبحاث الزراعية (INRAA) / FAO",
    val advisoryNote: String = ""
)

data class DiagnosticLogEntry(
    val timestamp: String,
    val httpCode: Int?,
    val endpointType: String,
    val sanitizedReason: String,
    val errorCategory: String
)

object GeminiService {
    private const val TAG = "GeminiService"
    const val MODEL_NAME = "gemini-3.8-flash"
    const val FALLBACK_MODEL_NAME = "gemini-3.5-flash"
    const val SECONDARY_FALLBACK_MODEL_NAME = "gemini-3.6-flash"
    val SUPPORTED_MODELS = listOf(MODEL_NAME, FALLBACK_MODEL_NAME, SECONDARY_FALLBACK_MODEL_NAME)
    private const val DEFAULT_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val _lastDiagnosticLog = MutableStateFlow<DiagnosticLogEntry?>(null)
    val lastDiagnosticLog: StateFlow<DiagnosticLogEntry?> = _lastDiagnosticLog.asStateFlow()

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isApiKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return !key.isNullOrBlank() && key != "MY_GEMINI_API_KEY" && key != "YOUR_GEMINI_API_KEY"
    }

    fun recordDiagnosticLog(
        httpCode: Int?,
        endpointType: String,
        sanitizedReason: String,
        errorCategory: String
    ) {
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        _lastDiagnosticLog.value = DiagnosticLogEntry(
            timestamp = time,
            httpCode = httpCode,
            endpointType = endpointType,
            sanitizedReason = sanitizeErrorMessage(sanitizedReason),
            errorCategory = errorCategory
        )
    }

    fun sanitizeErrorMessage(raw: String): String {
        if (raw.isBlank()) return ""
        var sanitized = raw
        sanitized = sanitized.replace(Regex("([?&])key=[^&\\s\"'<>]+"), "$1key=***REDACTED***")
        sanitized = sanitized.replace(Regex("AIza[0-9A-Za-z-_]{35}"), "***REDACTED_API_KEY***")
        sanitized = sanitized.replace(Regex("Bearer\\s+[a-zA-Z0-9_\\-\\.]+"), "Bearer ***REDACTED***")
        return sanitized
    }

    fun determineCategory(code: Int?, errorBody: String?): String {
        return when {
            code == null -> "NETWORK_ERROR"
            code == 400 && (errorBody?.contains("API_KEY") == true || errorBody?.contains("API key") == true) -> "AUTH_INVALID_KEY"
            code == 400 -> "BAD_REQUEST"
            code == 401 || code == 403 -> "AUTH_PERMISSION_DENIED"
            code == 404 -> "ENDPOINT_NOT_FOUND"
            code == 429 || (errorBody?.contains("RESOURCE_EXHAUSTED") == true) -> "RATE_LIMIT_QUOTA"
            code == 503 && (errorBody?.contains("maintenance", ignoreCase = true) == true || errorBody?.contains("صيانة") == true) -> "SERVER_MAINTENANCE"
            code == 503 -> "SERVICE_UNAVAILABLE"
            code == 502 -> "BAD_GATEWAY"
            code == 504 -> "GATEWAY_TIMEOUT"
            code == 500 -> "INTERNAL_SERVER_ERROR"
            code in 501..599 -> "SERVER_ERROR"
            else -> "UNKNOWN_HTTP_ERROR"
        }
    }

    fun extractReasonFromErrorBody(errorBody: String): String {
        if (errorBody.isBlank()) return ""
        try {
            val json = JSONObject(errorBody)
            val errorObj = json.optJSONObject("error")
            if (errorObj != null) {
                val msg = errorObj.optString("message", "")
                val status = errorObj.optString("status", "")
                if (msg.isNotBlank() && status.isNotBlank()) return "$status: $msg"
                if (msg.isNotBlank()) return msg
                if (status.isNotBlank()) return status
            }
        } catch (_: Exception) {}
        return if (!errorBody.startsWith("{")) errorBody.take(150) else ""
    }

    fun getEndpointLabel(customProxyUrl: String?, activeModel: String = MODEL_NAME): String {
        return if (!customProxyUrl.isNullOrBlank()) {
            try {
                val uri = URI(customProxyUrl)
                "خادم وسيط (${uri.host ?: customProxyUrl})"
            } catch (_: Exception) {
                "خادم وسيط مخصص"
            }
        } else {
            "الاتصال المباشر (Direct Gemini API: $activeModel)"
        }
    }

    private fun buildRequestUrl(baseUrl: String, modelName: String, isProxy: Boolean): String {
        val cleanBase = baseUrl.trim().trimEnd('/')
        return if (isProxy) {
            when {
                cleanBase.endsWith(":generateContent") -> cleanBase
                cleanBase.contains("/models") -> "$cleanBase/$modelName:generateContent"
                else -> "$cleanBase/v1beta/models/$modelName:generateContent"
            }
        } else {
            "$cleanBase/$modelName:generateContent?key=${BuildConfig.GEMINI_API_KEY}"
        }
    }

    suspend fun diagnosePlant(
        imageFile: File,
        additionalImages: List<File> = emptyList(),
        plantTypeInput: String = "",
        plantLocation: String = "",
        affectedPart: String = "",
        userSymptoms: String = "",
        customProxyUrl: String? = null
    ): Result<PlantDiagnosisResult> = withContext(Dispatchers.IO) {
        val isProxy = !customProxyUrl.isNullOrBlank()
        val candidateModels = if (isProxy) listOf(MODEL_NAME) else SUPPORTED_MODELS
        var activeEndpointLabel = getEndpointLabel(customProxyUrl, MODEL_NAME)

        if (!isApiKeyConfigured() && !isProxy) {
            val msg = "لم يتم ضبط مفتاح Gemini API. يرجى إضافة GEMINI_API_KEY في لوحة Secrets في AI Studio للتحليل المباشر، أو تحديد عنوان خادم وسيط في الإعدادات."
            recordDiagnosticLog(
                httpCode = null,
                endpointType = activeEndpointLabel,
                sanitizedReason = "مفتاح API غير مضبوط في Secrets ولا يوجد خادم وسيط مفعّل",
                errorCategory = "CONFIG_MISSING_KEY"
            )
            return@withContext Result.failure(IllegalStateException(msg))
        }

        // Validate custom proxy URL syntax if configured
        if (isProxy) {
            val trimmedProxy = customProxyUrl!!.trim()
            if (!trimmedProxy.startsWith("http://", ignoreCase = true) && !trimmedProxy.startsWith("https://", ignoreCase = true)) {
                val msg = "عنوان الخادم الوسيط غير صالح: يجب أن يبدأ بـ https:// أو http://"
                recordDiagnosticLog(
                    httpCode = null,
                    endpointType = "خادم وسيط غير صالح",
                    sanitizedReason = msg,
                    errorCategory = "CONFIG_INVALID_PROXY"
                )
                return@withContext Result.failure(IllegalArgumentException(msg))
            }
        }

        try {
            // Safely decode and downsample primary image
            val primaryBitmap = decodeSampledBitmap(imageFile, 1024, 1024)
            if (primaryBitmap == null) {
                val msg = "تعذر قراءة ملف الصورة الأساسي أو الملف تالف"
                recordDiagnosticLog(
                    httpCode = null,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = msg,
                    errorCategory = "IMAGE_DECODE_FAIL"
                )
                return@withContext Result.failure(IllegalArgumentException(msg))
            }

            val primaryBaos = ByteArrayOutputStream()
            primaryBitmap.compress(Bitmap.CompressFormat.JPEG, 80, primaryBaos)
            val primaryBase64 = Base64.encodeToString(primaryBaos.toByteArray(), Base64.NO_WRAP)

            val prompt = """
أنت خبير زراعي وطبيب نباتات أول متخصص في تشخيص أمراض وآفات واضطرابات النباتات في الجزائر والمنطقة العربية وحوض البحر المتوسط.
المعلومات المدخلة من المزارع:
- نوع النبات المقترح: ${if (plantTypeInput.isNotBlank()) plantTypeInput else "غير محدد (تعرف عليه من الصورة)"}
- مكان الزراعة: ${if (plantLocation.isNotBlank()) plantLocation else "غير محدد"}
- الجزء المتضرر: ${if (affectedPart.isNotBlank()) affectedPart else "من خلال الفحص البصري"}
- الأعراض الملاحظة من المستخدم: ${if (userSymptoms.isNotBlank()) userSymptoms else "فحص الصورة بالرؤية الحاسوبية"}
- عدد الصور المرفقة: ${1 + additionalImages.size} (صورة أساسية + صور إضافية لأجزاء النبات: ورقة / ساق / ثمرة)

إرشادات التحليل والأمان العلمي:
1. ميز بدقة بين: الأمراض الفطرية، البكتيرية، الفيروسية، الآفات الحشرية، نقص العناصر، ومشاكل الري والحرارة.
2. لا تخترع نسب مئوية وهمية للثقة (مثل 96% أو 88%)؛ بل صف مستوى الثقة بأمانة علمية: "مرتفع (تشخيص مؤكد بالأعراض النمطية)" أو "متوسط (أعراض متداخلة تحتاج تأكيد)" أو "تقديري إرشادي (صورة غير قريبة أو أولية)".
3. إذا كانت الصورة غير واضحة تماماً أو الأعراض غير كافية، ضع isUnclearImage=true واقترح في clarifyingQuestions 2 إلى 3 أسئلة متابعة ذكية للمزارع (مثل: هل تفحصت ظهر الورقة؟ هل انتشر المرض فجأة؟ كيف هو نظام الري؟).
4. في العلاجات: أعط الأولوية للحلول الزراعية والوقائية غير الكيميائية أولاً (IPM).
5. لا تخترع أسماء تجارية أو جرعات عشوائية للمبيدات؛ اذكر فقط المواد الفعالة المسجلة (Active Ingredients) وفترات الأمان قبل الحصاد PHI، وسمية النحل.
6. اذكر المراجع العلمية المعتمدة (مثل: INRAA الجزائر، منظمة FAO، ITGC).

قدم النتيجة بصيغة JSON فقط دون أي markdown أو شروح خارجها:
{
  "isUnclearImage": false,
  "plantCommonName": "اسم النبات الشائع بالعربية",
  "plantScientificName": "الاسم العلمي اللاتيني",
  "generalHealth": "تقييم عام لحالة النبات",
  "diseaseName": "المرض أو المشكلة الأساسية بالعربية",
  "scientificDiseaseName": "الاسم العلمي للمسبب المرضي",
  "pathogenType": "فطري / بكتيري / فيروسي / آفة حشرية / نقص عناصر / ري وحرارة",
  "confidenceLevel": "مرتفع / متوسط / تقديري إرشادي",
  "severity": "منخفض / متوسط / مرتفع / حرج",
  "urgency": "تدخل فوري / خلال 24-48 ساعة / متابعة دورية",
  "affectedPart": "الأوراق / الساق / الثمار / الجذور / عام",
  "symptomsSummary": "وصف مفصل للأعراض المرئية على النبات",
  "possibleCauses": "الأسباب والعوامل المشجعة لظهور الإصابة",
  "alternativeDiagnoses": "تشخيصات محتملة أخرى إن وجدت",
  "environmentalFactors": "تقييم تأثير الري، الرطوبة، الحرارة، نقص العناصر أو التربة",
  "immediateActions": "خطوات عاجلة فورية (عزل النبات، إزالة الأجزاء المصابة، ضبط الري)",
  "preventiveCare": "طرق الوقاية الزراعية والبيئية غير الكيميائية أولاً (IPM)",
  "chemicalTreatments": "المواد الفعالة للمبيدات الموصى بها فقط، فترات الأمان PHI، وسمية النحل",
  "clarifyingQuestions": ["سؤال متابعة 1 إذا لزم الأمر", "سؤال متابعة 2"],
  "scientificSources": "المعهد الوطني الجزائري للأبحاث الزراعية (INRAA) / دليل FAO لحماية النباتات",
  "advisoryNote": "التشخيص استرشادي مدعوم بالذكاء الاصطناعي، يرجى استشارة المهندس الزراعي المحلي."
}
            """.trimIndent()

            val partsArray = JSONArray()
            partsArray.put(JSONObject().put("text", prompt))

            // Primary image
            partsArray.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject()
                        .put("mimeType", "image/jpeg")
                        .put("data", primaryBase64)
                )
            )

            // Additional images (leaf, stem, fruit)
            for (file in additionalImages) {
                if (file.exists()) {
                    val bitmap = decodeSampledBitmap(file, 800, 800)
                    if (bitmap != null) {
                        val baos = ByteArrayOutputStream()
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                        val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                        partsArray.put(
                            JSONObject().put(
                                "inlineData",
                                JSONObject()
                                    .put("mimeType", "image/jpeg")
                                    .put("data", b64)
                            )
                        )
                    }
                }
            }

            val contentObject = JSONObject().put("parts", partsArray)
            val contentsArray = JSONArray().put(contentObject)

            val requestJson = JSONObject()
                .put("contents", contentsArray)
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("responseMimeType", "application/json")
                        .put("temperature", 0.2)
                )

            val baseUrl = if (isProxy) customProxyUrl!!.trim() else DEFAULT_BASE_URL
            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())

            var responseText: String? = null
            var lastResponseCode: Int? = null
            var lastErrorBody: String = ""
            var lastRetryAfter: Long? = null
            var modelUsed = MODEL_NAME

            for (model in candidateModels) {
                modelUsed = model
                activeEndpointLabel = getEndpointLabel(customProxyUrl, model)
                val url = buildRequestUrl(baseUrl, model, isProxy)
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                try {
                    val response = client.newCall(request).execute()
                    if (response.isSuccessful) {
                        responseText = response.body?.string() ?: ""
                        Log.i(TAG, "Diagnosis succeeded using model: $model")
                        break
                    } else {
                        val errorBody = response.body?.string() ?: ""
                        lastResponseCode = response.code
                        lastErrorBody = errorBody
                        lastRetryAfter = response.header("Retry-After")?.toLongOrNull()
                        Log.w(TAG, "Diagnosis model $model returned HTTP ${response.code}: $errorBody")

                        // Retry next model if 404 (model deprecated/not found), 503 (service unavailable / high demand), or 500/502/504
                        if (response.code in listOf(404, 500, 502, 503, 504)) {
                            continue
                        } else {
                            // Non-transient error (e.g. 400 bad image payload, 401 invalid key, 403)
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Diagnosis model $model execution failed: ${e.message}")
                    if (model == candidateModels.last()) {
                        throw e
                    }
                }
            }

            if (responseText == null) {
                val friendlyMsg = formatErrorMessage(lastResponseCode ?: 500, lastErrorBody, lastRetryAfter)
                val category = determineCategory(lastResponseCode, lastErrorBody)
                val sanitizedReason = extractReasonFromErrorBody(lastErrorBody).ifBlank { "HTTP $lastResponseCode ($modelUsed)" }

                recordDiagnosticLog(
                    httpCode = lastResponseCode,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = sanitizedReason,
                    errorCategory = category
                )
                Log.e(TAG, "Gemini diagnosis failed: code=$lastResponseCode, category=$category")
                return@withContext Result.failure(Exception(friendlyMsg))
            }

            if (responseText.isBlank()) {
                val msg = "استجابة غير صالحة: استلم التطبيق رداً فارغاً من الخادم (Empty Response). يرجى إعادة المحاولة."
                recordDiagnosticLog(
                    httpCode = 200,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = "الرد من الخادم فارغ تماماً",
                    errorCategory = "EMPTY_RESPONSE"
                )
                return@withContext Result.failure(Exception(msg))
            }

            val jsonResponse = JSONObject(responseText)
            val promptFeedback = jsonResponse.optJSONObject("promptFeedback")
            val blockReason = promptFeedback?.optString("blockReason")
            if (!blockReason.isNullOrBlank()) {
                val msg = "تم حجب الفحص بواسطة مرشح الأمان للخادم ($blockReason). يرجى التقاط صورة أخرى أوضح للنبات."
                recordDiagnosticLog(
                    httpCode = 200,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = "promptFeedback blockReason: $blockReason",
                    errorCategory = "SAFETY_FILTER_BLOCKED"
                )
                return@withContext Result.failure(Exception(msg))
            }

            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val finishReason = firstCandidate?.optString("finishReason")
            if (finishReason == "SAFETY") {
                val msg = "تم حجب نتيجة التحليل بواسطة مرشح الأمان للخادم. يرجى التقاط صورة أوضح للنبات."
                recordDiagnosticLog(
                    httpCode = 200,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = "Candidate finishReason: SAFETY",
                    errorCategory = "SAFETY_FILTER_BLOCKED"
                )
                return@withContext Result.failure(Exception(msg))
            }

            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val resultText = parts?.optJSONObject(0)?.optString("text") ?: ""

            if (resultText.isBlank()) {
                val msg = "استجابة غير مكتملة: تعذر استخراج تقرير التشخيص من استجابة النموذج. يرجى إعادة المحاولة."
                recordDiagnosticLog(
                    httpCode = 200,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = "Candidate content text is missing",
                    errorCategory = "INCOMPLETE_RESPONSE"
                )
                return@withContext Result.failure(Exception(msg))
            }

            val parsed = parseDiagnosisJson(resultText)
            recordDiagnosticLog(
                httpCode = 200,
                endpointType = activeEndpointLabel,
                sanitizedReason = "تم الفحص والتحليل بنجاح بواسطة $modelUsed (${parsed.plantCommonName} - ${parsed.diseaseName})",
                errorCategory = "SUCCESS"
            )
            Result.success(parsed)
        } catch (e: Exception) {
            Log.e(TAG, "Error diagnosing plant", e)
            val friendlyMsg = formatExceptionMessage(e)
            val category = when (e) {
                is UnknownHostException -> "NETWORK_OFFLINE"
                is SocketTimeoutException -> "NETWORK_TIMEOUT"
                is ConnectException -> "NETWORK_CONNECT_FAIL"
                is IOException -> "NETWORK_IO_ERROR"
                else -> "UNEXPECTED_EXCEPTION"
            }
            recordDiagnosticLog(
                httpCode = null,
                endpointType = activeEndpointLabel,
                sanitizedReason = sanitizeErrorMessage(e.localizedMessage ?: e.javaClass.simpleName),
                errorCategory = category
            )
            Result.failure(Exception(friendlyMsg))
        }
    }

    suspend fun chatWithDoctor(
        messages: List<Pair<String, String>>, // sender ("user"/"model"), text
        newPrompt: String,
        imageFile: File? = null,
        plantContext: String? = null,
        customProxyUrl: String? = null
    ): Result<Pair<String, List<String>>> = withContext(Dispatchers.IO) {
        val isProxy = !customProxyUrl.isNullOrBlank()
        val candidateModels = if (isProxy) listOf(MODEL_NAME) else SUPPORTED_MODELS
        var activeEndpointLabel = getEndpointLabel(customProxyUrl, MODEL_NAME)

        if (!isApiKeyConfigured() && !isProxy) {
            val msg = "لم يتم ضبط مفتاح Gemini API. يرجى إضافة GEMINI_API_KEY في لوحة Secrets في AI Studio لتشغيل المحادثة الذكية."
            recordDiagnosticLog(
                httpCode = null,
                endpointType = activeEndpointLabel,
                sanitizedReason = "مفتاح API غير مضبوط في Secrets ولا يوجد خادم وسيط مفعّل",
                errorCategory = "CONFIG_MISSING_KEY"
            )
            return@withContext Result.failure(IllegalStateException(msg))
        }

        if (isProxy) {
            val trimmedProxy = customProxyUrl!!.trim()
            if (!trimmedProxy.startsWith("http://", ignoreCase = true) && !trimmedProxy.startsWith("https://", ignoreCase = true)) {
                val msg = "عنوان الخادم الوسيط غير صالح: يجب أن يبدأ بـ https:// أو http://"
                recordDiagnosticLog(
                    httpCode = null,
                    endpointType = "خادم وسيط غير صالح",
                    sanitizedReason = msg,
                    errorCategory = "CONFIG_INVALID_PROXY"
                )
                return@withContext Result.failure(IllegalArgumentException(msg))
            }
        }

        try {
            val systemInstructionText = """
أنت "طبيب النباتات الذكي" (Plant Doctor AI)، مرشد زراعي وخبير أمراض نباتات وري وبستنة محترف متخصص في الجزائر والدول العربية والمناخ المتوسطي.
صفاتك وإرشاداتك:
- تتحدث باللغة العربية الفصحى المبسطة والودودة، وتفهم وتجيب بالدارجة الجزائرية أو الفرنسية إذا سألك المستخدم بها.
- تجيب بإيجاز واحترافية وبأسلوب منظم وواضح للمبتدئين والمزارعين على حد سواء.
- تفرق بوضوح بين الحقائق المؤكدة والاحتمالات التقديرية، ولا تقدم نصائح عشوائية.
- في العلاج: تركز على الحلول الوقائية والزراعية أولاً (IPM)، وعند ذكر مواد علاجية تذكر المادة الفعالة وتحذيرات الأمان.
${if (!plantContext.isNullOrBlank()) "- سياق النبتة المفحوصة حالياً للمستخدم:\n$plantContext" else ""}
- في نهاية كل جواب، اقترح دائماً سطرين يحتويان على 2 أو 3 أسئلة متابعة ذكية تبدأ بـ:
[FOLLOW_UPS]: سؤال 1؟ | سؤال 2؟ | سؤال 3؟
            """.trimIndent()

            val contentsArray = JSONArray()

            // Add previous history (last 6 turns for context efficiency and token savings)
            val recentMessages = messages.takeLast(6)
            for ((sender, text) in recentMessages) {
                val role = if (sender == "user") "user" else "model"
                contentsArray.put(
                    JSONObject()
                        .put("role", role)
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }

            // Current prompt
            val currentParts = JSONArray()
            currentParts.put(JSONObject().put("text", newPrompt))

            if (imageFile != null && imageFile.exists()) {
                val bitmap = decodeSampledBitmap(imageFile, 800, 800)
                if (bitmap != null) {
                    val baos = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                    val base64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
                    currentParts.put(
                        JSONObject().put(
                            "inlineData",
                            JSONObject()
                                .put("mimeType", "image/jpeg")
                                .put("data", base64)
                        )
                    )
                }
            }

            contentsArray.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", currentParts)
            )

            val requestJson = JSONObject()
                .put("contents", contentsArray)
                .put(
                    "systemInstruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstructionText)))
                )
                .put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.6)
                        .put("topP", 0.95)
                )

            val baseUrl = if (isProxy) customProxyUrl!!.trim() else DEFAULT_BASE_URL
            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())

            var responseText: String? = null
            var lastResponseCode: Int? = null
            var lastErrorBody: String = ""
            var lastRetryAfter: Long? = null
            var modelUsed = MODEL_NAME

            for (model in candidateModels) {
                modelUsed = model
                activeEndpointLabel = getEndpointLabel(customProxyUrl, model)
                val url = buildRequestUrl(baseUrl, model, isProxy)
                val request = Request.Builder()
                    .url(url)
                    .post(requestBody)
                    .build()

                try {
                    val response = client.newCall(request).execute()
                    if (response.isSuccessful) {
                        responseText = response.body?.string() ?: ""
                        Log.i(TAG, "Chat succeeded using model: $model")
                        break
                    } else {
                        val errorBody = response.body?.string() ?: ""
                        lastResponseCode = response.code
                        lastErrorBody = errorBody
                        lastRetryAfter = response.header("Retry-After")?.toLongOrNull()
                        Log.w(TAG, "Chat model $model returned HTTP ${response.code}: $errorBody")

                        if (response.code in listOf(404, 500, 502, 503, 504)) {
                            continue
                        } else {
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Chat model $model execution failed: ${e.message}")
                    if (model == candidateModels.last()) {
                        throw e
                    }
                }
            }

            if (responseText == null) {
                val friendlyMsg = formatErrorMessage(lastResponseCode ?: 500, lastErrorBody, lastRetryAfter)
                val category = determineCategory(lastResponseCode, lastErrorBody)
                val sanitizedReason = extractReasonFromErrorBody(lastErrorBody).ifBlank { "HTTP $lastResponseCode ($modelUsed)" }

                recordDiagnosticLog(
                    httpCode = lastResponseCode,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = sanitizedReason,
                    errorCategory = category
                )
                Log.e(TAG, "Chat API error: $lastResponseCode - $lastErrorBody")
                return@withContext Result.failure(Exception(friendlyMsg))
            }

            if (responseText.isBlank()) {
                val msg = "استجابة غير صالحة: استلم التطبيق رداً فارغاً من الخادم."
                recordDiagnosticLog(
                    httpCode = 200,
                    endpointType = activeEndpointLabel,
                    sanitizedReason = "الرد من الخادم فارغ تماماً",
                    errorCategory = "EMPTY_RESPONSE"
                )
                return@withContext Result.failure(Exception(msg))
            }

            val jsonResponse = JSONObject(responseText)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawOutput = parts?.optJSONObject(0)?.optString("text") ?: ""

            // Extract follow-ups
            val followUps = mutableListOf<String>()
            var cleanedOutput = rawOutput
            if (rawOutput.contains("[FOLLOW_UPS]:")) {
                val split = rawOutput.split("[FOLLOW_UPS]:")
                cleanedOutput = split[0].trim()
                if (split.size > 1) {
                    val questions = split[1].split("|").map { it.trim() }.filter { it.isNotBlank() }
                    followUps.addAll(questions)
                }
            }

            recordDiagnosticLog(
                httpCode = 200,
                endpointType = activeEndpointLabel,
                sanitizedReason = "تم الرد على المحادثة بنجاح بواسطة $modelUsed",
                errorCategory = "SUCCESS"
            )
            Result.success(Pair(cleanedOutput, followUps))
        } catch (e: Exception) {
            Log.e(TAG, "Error in chatWithDoctor", e)
            val friendlyMsg = formatExceptionMessage(e)
            val category = when (e) {
                is UnknownHostException -> "NETWORK_OFFLINE"
                is SocketTimeoutException -> "NETWORK_TIMEOUT"
                is ConnectException -> "NETWORK_CONNECT_FAIL"
                is IOException -> "NETWORK_IO_ERROR"
                else -> "UNEXPECTED_EXCEPTION"
            }
            recordDiagnosticLog(
                httpCode = null,
                endpointType = activeEndpointLabel,
                sanitizedReason = sanitizeErrorMessage(e.localizedMessage ?: e.javaClass.simpleName),
                errorCategory = category
            )
            Result.failure(Exception(friendlyMsg))
        }
    }

    private fun decodeSampledBitmap(file: File, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(file.absolutePath, options)

            var inSampleSize = 1
            if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            val sampled = BitmapFactory.decodeFile(file.absolutePath, decodeOptions) ?: return null
            scaleBitmapDown(sampled, maxOf(reqWidth, reqHeight))
        } catch (e: OutOfMemoryError) {
            Log.e(TAG, "OOM while decoding bitmap, falling back to minimal scale", e)
            null
        } catch (e: Exception) {
            Log.e(TAG, "Exception decoding image", e)
            null
        }
    }

    fun formatErrorMessage(code: Int, errorBody: String, retryAfterSeconds: Long? = null): String {
        val sanitized = sanitizeErrorMessage(errorBody)
        var extractedMsg = ""
        var extractedStatus = ""
        try {
            val json = JSONObject(sanitized)
            val errorObj = json.optJSONObject("error")
            if (errorObj != null) {
                extractedMsg = errorObj.optString("message", "")
                extractedStatus = errorObj.optString("status", "")
            }
        } catch (_: Exception) {}

        val detail = if (extractedMsg.isNotBlank()) extractedMsg else sanitized.take(150)

        return when {
            // HTTP 400: Bad Request
            code == 400 -> {
                when {
                    extractedStatus == "INVALID_ARGUMENT" && (detail.contains("API_KEY", ignoreCase = true) || detail.contains("API key", ignoreCase = true)) ->
                        "مفتاح Gemini API غير صالح أو غير معتمد. يرجى التحقق من صحة المفتاح في لوحة Secrets في AI Studio."
                    detail.contains("image", ignoreCase = true) || detail.contains("payload", ignoreCase = true) ->
                        "طلب غير صالح (HTTP 400): تعذر على الخادم معالجة بيانات الصورة المرفقة. يرجى التقاط صورة أخرى أوضح."
                    detail.isNotBlank() && !detail.startsWith("{") ->
                        "طلب غير صالح (HTTP 400): $detail."
                    else ->
                        "طلب غير صالح (HTTP 400). يرجى مراجعة بيانات الفحص والصورة المرفقة."
                }
            }
            // HTTP 401 & 403: Authentication / Forbidden
            code == 401 || code == 403 -> {
                "فشل في المصادقة أو تم رفض الإذن (HTTP $code). تأكد من صحة مفتاح Gemini API وتفعيل خدمة Generative Language API، أو تحقق من أذونات الخادم الوسيط."
            }
            // HTTP 404: Not Found
            code == 404 -> {
                val modelHint = if (detail.isNotBlank() && !detail.startsWith("{")) detail else "النموذج $MODEL_NAME غير متوفر"
                "النموذج أو مسار الخدمة غير موجود (HTTP 404): $modelHint. يرجى التأكد من مسار API وعنوان الخدمة."
            }
            // HTTP 429: Too Many Requests / Quota Exceeded
            code == 429 || extractedStatus == "RESOURCE_EXHAUSTED" || detail.contains("quota", ignoreCase = true) -> {
                if (retryAfterSeconds != null && retryAfterSeconds > 0) {
                    "تم تجاوز معدل الطلبات المسموح به أو استنفاد الحصة المؤقتة (HTTP 429). يرجى الانتظار $retryAfterSeconds ثانية قبل إعادة المحاولة."
                } else {
                    "تم استهلاك الحصة المتاحة مؤقتاً لمفتاح الذكاء الاصطناعي (HTTP 429 Quota Exceeded). يرجى المحاولة بعد قليل أو تجديد الحصة."
                }
            }
            // HTTP 503: Service Unavailable
            code == 503 -> {
                val isMaintenance = detail.contains("maintenance", ignoreCase = true) ||
                    detail.contains("صيانة") ||
                    detail.contains("under maintenance", ignoreCase = true)
                if (isMaintenance) {
                    "خوادم الذكاء الاصطناعي تحت الصيانة المجدولة حالياً (HTTP 503 Service Unavailable). يرجى المحاولة بعد انتهاء أعمال الصيانة."
                } else {
                    "خدمة الذكاء الاصطناعي غير متوفرة مؤقتاً بسبب ضغط الطلبات (HTTP 503 Service Unavailable). يرجى إعادة المحاولة بعد لحظات."
                }
            }
            // HTTP 502: Bad Gateway
            code == 502 -> {
                "خطأ في بوابة الاتصال (HTTP 502 Bad Gateway). تعذر على البوابة أو الخادم الوسيط الوصول لخدمة الذكاء الاصطناعي. يرجى المحاولة مجدداً."
            }
            // HTTP 504: Gateway Timeout
            code == 504 -> {
                "انتهت مهلة استجابة بوابة الخدمة (HTTP 504 Gateway Timeout). لم يستجب الخادم في الوقت المحدد. يرجى إعادة المحاولة."
            }
            // HTTP 500: Internal Server Error
            code == 500 -> {
                "حدث خطأ داخلي مؤقت في خادم الخدمة (HTTP 500 Internal Server Error). يرجى إعادة المحاولة."
            }
            // Other 5xx
            code in 501..599 -> {
                "واجهت الخدمة مشكلة مؤقتة في الخادم (HTTP $code). يرجى المحاولة بعد قليل."
            }
            // Other 4xx
            code in 405..499 -> {
                "تعذر إتمام طلب الفحص (HTTP $code): ${if (detail.isNotBlank() && !detail.startsWith("{")) detail else "خطأ في المعالجة"}"
            }
            else -> {
                "خطأ في الاتصال بالذكاء الاصطناعي ($code)"
            }
        }
    }

    fun formatExceptionMessage(e: Exception): String {
        return when (e) {
            is UnknownHostException -> "لا يوجد اتصال بالإنترنت أو تعذر العثور على خادم الخدمة. يرجى التحقق من الشبكة وإعادة المحاولة."
            is SocketTimeoutException -> "انتهت مهلة انتظار الخادم أثناء رفع ومعالجة صورة النبات. يرجى التأكد من سرعة الإنترنت وإعادة المحاولة."
            is ConnectException -> "فشل الاتصال بالخادم (Connection Refused). تأكد من اتصال هاتفك بالإنترنت أو تحقق من تشغيل الخادم الوسيط."
            is IOException -> "انقطع اتصال الشبكة أثناء إرسال الفحص: ${sanitizeErrorMessage(e.localizedMessage ?: "انقطاع الاتصال")}. يرجى المحاولة مجدداً."
            else -> sanitizeErrorMessage(e.message ?: "حدث خطأ غير متوقع أثناء معالجة فحص النبات.")
        }
    }

    private fun parseDiagnosisJson(rawJson: String): PlantDiagnosisResult {
        try {
            var clean = rawJson.trim()
            if (clean.startsWith("```json")) {
                clean = clean.removePrefix("```json")
            } else if (clean.startsWith("```")) {
                clean = clean.removePrefix("```")
            }
            if (clean.endsWith("```")) {
                clean = clean.removeSuffix("```")
            }
            clean = clean.trim()

            val obj = JSONObject(clean)
            val questionsList = mutableListOf<String>()
            val questionsArray = obj.optJSONArray("clarifyingQuestions")
            if (questionsArray != null) {
                for (i in 0 until questionsArray.length()) {
                    val q = questionsArray.optString(i)
                    if (!q.isNullOrBlank()) questionsList.add(q)
                }
            }

            return PlantDiagnosisResult(
                plantCommonName = obj.optString("plantCommonName", "نبات غير محدد"),
                plantScientificName = obj.optString("plantScientificName", ""),
                generalHealth = obj.optString("generalHealth", "يحتاج إلى عناية"),
                diseaseName = obj.optString("diseaseName", "حالة غير مؤكدة"),
                scientificDiseaseName = obj.optString("scientificDiseaseName", ""),
                pathogenType = obj.optString("pathogenType", "غير محدد"),
                confidenceLevel = obj.optString("confidenceLevel", "تقديري إرشادي"),
                severity = obj.optString("severity", "متوسط"),
                urgency = obj.optString("urgency", "خلال 24-48 ساعة"),
                affectedPart = obj.optString("affectedPart", "الأوراق"),
                symptomsSummary = obj.optString("symptomsSummary", "أعراض مبكرة تتطلب الفحص والمتابعة"),
                possibleCauses = obj.optString("possibleCauses", "عوامل مناخية وظروف رطوبة أو تربة غير متوازنة"),
                alternativeDiagnoses = obj.optString("alternativeDiagnoses", "نقص عناصر أو صدمة بيئية محتملة"),
                environmentalFactors = obj.optString("environmentalFactors", "تأكد من اعتدال الري وتصريف التربة والإضاءة المناسبة"),
                immediateActions = obj.optString("immediateActions", "عزل النبات، تنظيف الأجزاء المصابة، وضبط الري"),
                preventiveCare = obj.optString("preventiveCare", "التهوية الجيدة، تجنب ترطيب الأوراق ليلاً، والتسميد المتوازن"),
                chemicalTreatments = obj.optString("chemicalTreatments", "استخدم مبيدات فطرية أو حشرية معتمدة بالمادة الفعالة وتحت إشراف مختص مع مراعاة فترات الأمان PHI"),
                isUnclearImage = obj.optBoolean("isUnclearImage", false),
                clarifyingQuestions = questionsList,
                scientificSources = obj.optString("scientificSources", "المعهد الوطني للأبحاث الزراعية (INRAA) / FAO"),
                advisoryNote = obj.optString("advisoryNote", "هذا التشخيص استرشادي مدعوم بالذكاء الاصطناعي، يرجى دائماً مراجعة المهندس الزراعي المحلي قبل تطبيق مبيدات كيميائية مكثفة.")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed parsing JSON, falling back to structured representation", e)
            return PlantDiagnosisResult(
                plantCommonName = "نبات مفحوص",
                plantScientificName = "",
                generalHealth = "تحت الفحص والملاحظة",
                diseaseName = "أعراض تحتاج متابعة دقيقة",
                scientificDiseaseName = "",
                pathogenType = "غير محدد",
                confidenceLevel = "تقديري إرشادي",
                severity = "متوسط",
                urgency = "متابعة دورية",
                affectedPart = "الأوراق",
                symptomsSummary = rawJson.take(250),
                possibleCauses = "ظروف ري أو تربة أو تغيرات مناخية غير ملائمة",
                alternativeDiagnoses = "تأثير نقص المغذيات الصغرى",
                environmentalFactors = "مراجعة نسبة الرطوبة وضوء الشمس ودرجة حرارة المكان",
                immediateActions = "إزالة الأوراق الصفراء أو الذابلة، وتفقد أسفل الأوراق بحثاً عن الحشرات",
                preventiveCare = "الري عند جفاف السطح، والتهوية المناسبة للنبات",
                chemicalTreatments = "يُفضل استشارة صيدلي زراعي محلي قبل رش أي مركب كيميائي",
                isUnclearImage = false,
                clarifyingQuestions = emptyList(),
                scientificSources = "المعهد الوطني للأبحاث الزراعية (INRAA)",
                advisoryNote = "التشخيص استرشادي. يجب التأكد من الملصق الرسمي لأي علاج."
            )
        }
    }

    private fun scaleBitmapDown(bitmap: Bitmap, maxDimension: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDimension && height <= maxDimension) return bitmap

        val ratio = width.toFloat() / height.toFloat()
        val targetWidth: Int
        val targetHeight: Int
        if (width > height) {
            targetWidth = maxDimension
            targetHeight = (maxDimension / ratio).toInt()
        } else {
            targetHeight = maxDimension
            targetWidth = (maxDimension * ratio).toInt()
        }
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }
}
