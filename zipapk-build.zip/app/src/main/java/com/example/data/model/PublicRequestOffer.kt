package com.example.data.model

enum class OfferStatus(val titleAr: String) {
    PENDING("قيد المراجعة"),
    ACCEPTED("تم القبول"),
    REJECTED("تم اختيار عرض آخر"),
    CANCELLED("ملغى");

    companion object {
        fun fromString(value: String?): OfferStatus {
            return when (value?.uppercase()) {
                "ACCEPTED" -> ACCEPTED
                "REJECTED" -> REJECTED
                "CANCELLED" -> CANCELLED
                else -> PENDING
            }
        }
    }
}

data class PublicRequestOffer(
    val id: String = "",
    val requestId: String = "",
    val providerId: String = "",
    val providerName: String = "",
    val providerProfession: String = "",
    val providerPhone: String = "",
    val providerAvatarUrl: String = "",
    val providerRating: Double = 0.0,
    val providerRatingCount: Int = 0,
    val providerWilayaName: String = "",
    val providerCommuneName: String = "",
    val priceDzd: Long = 0L,
    val message: String = "",
    val estimatedTime: String = "",
    val status: OfferStatus = OfferStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "requestId" to requestId,
            "providerId" to providerId,
            "providerName" to providerName,
            "providerProfession" to providerProfession,
            "providerPhone" to providerPhone,
            "providerAvatarUrl" to providerAvatarUrl,
            "providerRating" to providerRating,
            "providerRatingCount" to providerRatingCount,
            "providerWilayaName" to providerWilayaName,
            "providerCommuneName" to providerCommuneName,
            "priceDzd" to priceDzd,
            "message" to message,
            "estimatedTime" to estimatedTime,
            "status" to status.name,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): PublicRequestOffer {
            return PublicRequestOffer(
                id = (map["id"] as? String)?.ifBlank { id } ?: id,
                requestId = map["requestId"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                providerName = map["providerName"] as? String ?: "",
                providerProfession = map["providerProfession"] as? String ?: "",
                providerPhone = map["providerPhone"] as? String ?: "",
                providerAvatarUrl = map["providerAvatarUrl"] as? String ?: "",
                providerRating = (map["providerRating"] as? Number)?.toDouble() ?: 0.0,
                providerRatingCount = (map["providerRatingCount"] as? Number)?.toInt() ?: 0,
                providerWilayaName = map["providerWilayaName"] as? String ?: "",
                providerCommuneName = map["providerCommuneName"] as? String ?: "",
                priceDzd = (map["priceDzd"] as? Number)?.toLong() ?: 0L,
                message = map["message"] as? String ?: "",
                estimatedTime = map["estimatedTime"] as? String ?: "",
                status = OfferStatus.fromString(map["status"] as? String),
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
