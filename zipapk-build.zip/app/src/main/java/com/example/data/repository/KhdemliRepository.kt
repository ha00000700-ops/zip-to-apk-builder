package com.example.data.repository

import com.example.data.local.KhdemliDatabase
import com.example.data.model.*
import com.example.data.remote.FirebaseManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class KhdemliRepository(
    private val database: KhdemliDatabase,
    private val firebaseManager: FirebaseManager? = null,
    private val context: android.content.Context? = null
) {

    // Services
    val activeServices: Flow<List<ServiceCategoryEntity>> = database.serviceCategoryDao().getActiveServices()
    val allServicesForAdmin: Flow<List<ServiceCategoryEntity>> = database.serviceCategoryDao().getAllServices()

    suspend fun saveServiceCategory(service: ServiceCategoryEntity) {
        if (service.id == 0L) {
            database.serviceCategoryDao().insertService(service)
        } else {
            database.serviceCategoryDao().updateService(service)
        }
    }

    suspend fun deleteServiceCategory(id: Long) {
        database.serviceCategoryDao().deleteService(id)
    }

    // Wilayas & Communes
    val allWilayas: Flow<List<WilayaEntity>> = database.wilayaDao().getAllWilayas()

    fun getCommunesForWilaya(wilayaCode: Int): Flow<List<CommuneEntity>> {
        return database.wilayaDao().getCommunesByWilaya(wilayaCode)
    }

    // Professionals
    val approvedProfessionals: Flow<List<ProfessionalEntity>> = database.professionalDao().getAllApprovedProfessionals()
    val allProfessionalsForAdmin: Flow<List<ProfessionalEntity>> = database.professionalDao().getAllProfessionalsForAdmin()

    fun getProfessionalById(id: Long): Flow<ProfessionalEntity?> {
        return database.professionalDao().getProfessionalById(id)
    }

    fun getProfessionalByUserId(userId: Long): Flow<ProfessionalEntity?> {
        return database.professionalDao().getProfessionalByUserId(userId)
    }

    fun filterProfessionals(
        wilayaCode: Int,
        serviceId: Long,
        onlyAvailable: Boolean,
        query: String
    ): Flow<List<ProfessionalEntity>> {
        return database.professionalDao().filterProfessionals(
            wilayaCode = wilayaCode,
            serviceId = serviceId,
            onlyAvailable = if (onlyAvailable) 1 else 0,
            searchQuery = query.trim()
        )
    }

    suspend fun updateProfessionalAvailability(id: Long, isAvailable: Boolean) {
        database.professionalDao().setAvailability(id, isAvailable)
    }

    suspend fun updateProfessionalVerification(id: Long, isVerified: Boolean, status: VerificationStatus = if (isVerified) VerificationStatus.APPROVED else VerificationStatus.NOT_SUBMITTED) {
        database.professionalDao().setVerification(id, isVerified, status)
    }

    suspend fun updateProfessionalApproval(id: Long, isApproved: Boolean) {
        database.professionalDao().setApprovalStatus(id, isApproved)
    }

    suspend fun updateProfessionalProfile(professional: ProfessionalEntity) {
        database.professionalDao().updateProfessional(professional)
    }

    // Verification Workflow
    val allVerificationRequests: Flow<List<VerificationRequestEntity>> = database.verificationRequestDao().getAllVerificationRequests()
    val pendingVerificationRequests: Flow<List<VerificationRequestEntity>> = database.verificationRequestDao().getPendingVerificationRequests()

    fun getVerificationRequestForPro(proId: Long): Flow<VerificationRequestEntity?> {
        return database.verificationRequestDao().getVerificationRequestForPro(proId)
    }

    suspend fun submitVerificationRequest(request: VerificationRequestEntity): Long {
        val reqId = database.verificationRequestDao().insertVerificationRequest(request)
        database.professionalDao().setVerification(request.professionalId, false, VerificationStatus.PENDING)
        
        // Notify admin
        sendNotification(
            recipientUserId = 0,
            title = "طلب توثيق جديد من ${request.professionalName}",
            body = "قدم الحرفي ملف التحقق المهني والهوية الوطنية لمراجعة الإدارة.",
            type = NotificationType.VERIFICATION_UPDATE,
            targetId = reqId
        )
        return reqId
    }

    suspend fun approveVerificationRequest(requestId: Long, proId: Long) {
        database.verificationRequestDao().updateVerificationRequestStatus(
            id = requestId,
            status = VerificationStatus.APPROVED,
            reviewedAt = System.currentTimeMillis()
        )
        database.professionalDao().setVerification(proId, true, VerificationStatus.APPROVED)

        val pro = database.professionalDao().getProfessionalById(proId).firstOrNull()
        if (pro != null) {
            sendNotification(
                recipientUserId = pro.userId,
                title = "تهانينا! تم منحك شارة الحرفي الموثوق 🛡️✓",
                body = "تمت مراجعة وثائقك والموافقة عليها. أصبحت الآن تظهر كـ حرفي موثوق ومعتمد رسمياً.",
                type = NotificationType.VERIFICATION_UPDATE,
                targetId = proId
            )
        }
    }

    suspend fun rejectVerificationRequest(requestId: Long, proId: Long, reason: String) {
        database.verificationRequestDao().updateVerificationRequestStatus(
            id = requestId,
            status = VerificationStatus.REJECTED,
            reason = reason,
            reviewedAt = System.currentTimeMillis()
        )
        database.professionalDao().setVerification(proId, false, VerificationStatus.REJECTED)

        val pro = database.professionalDao().getProfessionalById(proId).firstOrNull()
        if (pro != null) {
            sendNotification(
                recipientUserId = pro.userId,
                title = "تحديث بخصوص طلب التوثيق",
                body = "تم رفض طلب التوثيق للسبب التالي: ${reason.ifBlank { "عدم مطابقة الوثائق للشروط" }}",
                type = NotificationType.VERIFICATION_UPDATE,
                targetId = proId
            )
        }
    }

    suspend fun revokeVerification(proId: Long, reason: String) {
        database.professionalDao().setVerification(proId, false, VerificationStatus.REVOKED)
        val pro = database.professionalDao().getProfessionalById(proId).firstOrNull()
        if (pro != null) {
            sendNotification(
                recipientUserId = pro.userId,
                title = "تم سحب شارة التوثيق ⚠️",
                body = "تم سحب شارة التوثيق بسبب: ${reason.ifBlank { "مخالفة معايير الجودة والسلامة" }}",
                type = NotificationType.ADMIN_ALERT,
                targetId = proId
            )
        }
    }

    // Service Requests
    val allRequestsForAdmin: Flow<List<ServiceRequestEntity>> = database.serviceRequestDao().getAllRequests()

    fun getRequestsForCustomer(customerId: Long): Flow<List<ServiceRequestEntity>> {
        return database.serviceRequestDao().getRequestsByCustomer(customerId)
    }

    fun getRequestsForProfessional(proId: Long, wilayaCode: Int, serviceId: Long): Flow<List<ServiceRequestEntity>> {
        return database.serviceRequestDao().getRequestsForProfessional(proId, wilayaCode, serviceId)
    }

    fun getRequestById(id: Long): Flow<ServiceRequestEntity?> {
        return database.serviceRequestDao().getRequestById(id)
    }

    suspend fun createServiceRequest(request: ServiceRequestEntity): Long {
        val reqId = database.serviceRequestDao().insertRequest(request)
        val fullReq = request.copy(id = reqId)
        firebaseManager?.saveServiceRequest(fullReq)
        if (request.professionalId != null) {
            val pro = database.professionalDao().getProfessionalById(request.professionalId).firstOrNull()
            if (pro != null) {
                sendNotification(
                    recipientUserId = pro.userId,
                    title = "طلب خدمة جديد من ${request.customerName}",
                    body = "طلب ${request.serviceNameAr} في ${request.wilayaNameAr} (${request.communeNameAr})",
                    type = NotificationType.NEW_REQUEST,
                    targetId = reqId
                )
            }
        } else {
            val matchingPros = database.professionalDao().getMatchingProfessionals(
                wilayaCode = request.wilayaCode,
                serviceCategoryId = request.serviceCategoryId
            )
            matchingPros.forEach { pro ->
                sendNotification(
                    recipientUserId = pro.userId,
                    title = "طلب خدمة جديد يناسب تخصصك 🛠️",
                    body = "طلب جديد في تخصص ${request.serviceNameAr} بولاية ${request.wilayaNameAr} (${request.communeNameAr})",
                    type = NotificationType.NEW_REQUEST,
                    targetId = reqId
                )
            }
        }
        return reqId
    }

    suspend fun updateRequestStatus(id: Long, status: RequestStatus) {
        database.serviceRequestDao().updateRequestStatus(id, status)
        val req = database.serviceRequestDao().getRequestById(id).firstOrNull()
        if (req != null) {
            firebaseManager?.saveServiceRequest(req)
            sendNotification(
                recipientUserId = req.customerId,
                title = "تحديث حالة الطلب #${req.id}",
                body = "أصبحت حالة طلبك: ${status.labelAr}",
                type = NotificationType.STATUS_UPDATE,
                targetId = req.id
            )
        }
    }

    suspend fun assignProfessionalToRequest(requestId: Long, proId: Long, proName: String, proPhone: String) {
        database.serviceRequestDao().assignProfessionalToRequest(requestId, proId, proName, proPhone)
        val req = database.serviceRequestDao().getRequestById(requestId).firstOrNull()
        if (req != null) {
            firebaseManager?.saveServiceRequest(req)
            sendNotification(
                recipientUserId = req.customerId,
                title = "تم قبول طلبك من الحرفي $proName",
                body = "وافق الحرفي على طلب ${req.serviceNameAr} وهو بصدد التواصل معك.",
                type = NotificationType.REQUEST_ACCEPTED,
                targetId = requestId
            )
        }
    }

    suspend fun cancelRequest(requestId: Long, reason: String, cancelledByUserId: Long) {
        database.serviceRequestDao().cancelRequest(requestId, reason)
        val req = database.serviceRequestDao().getRequestById(requestId).firstOrNull()
        if (req != null) {
            firebaseManager?.saveServiceRequest(req)
            // Notify other party
            val recipientId = if (cancelledByUserId == req.customerId) {
                if (req.professionalId != null) {
                    val pro = database.professionalDao().getProfessionalById(req.professionalId).firstOrNull()
                    pro?.userId ?: 0L
                } else 0L
            } else {
                req.customerId
            }

            if (recipientId > 0) {
                sendNotification(
                    recipientUserId = recipientId,
                    title = "تم إلغاء الطلب #${req.id} ❌",
                    body = "سبب الإلغاء: ${reason.ifBlank { "لم يذكر سبب" }}",
                    type = NotificationType.STATUS_UPDATE,
                    targetId = requestId
                )
            }
        }
    }

    // Request Offers (Price Offers)
    fun getOffersForRequest(requestId: Long): Flow<List<RequestOfferEntity>> {
        return database.requestOfferDao().getOffersForRequest(requestId)
    }

    suspend fun submitPriceOffer(
        requestId: Long,
        professionalId: Long,
        professionalName: String,
        professionalPhone: String,
        priceDzd: Double,
        note: String
    ): Long {
        val offer = RequestOfferEntity(
            requestId = requestId,
            professionalId = professionalId,
            professionalName = professionalName,
            professionalPhone = professionalPhone,
            priceDzd = priceDzd,
            note = note.trim()
        )
        val offerId = database.requestOfferDao().insertOffer(offer)
        val fullOffer = offer.copy(id = offerId)
        firebaseManager?.saveRequestOffer(fullOffer)
        val req = database.serviceRequestDao().getRequestById(requestId).firstOrNull()
        if (req != null) {
            sendNotification(
                recipientUserId = req.customerId,
                title = "عرض سعر جديد من الحرفي $professionalName 💰",
                body = "قدم الحرفي عرض سعر بمبلغ ${priceDzd.toInt()} دج لطلب ${req.serviceNameAr}",
                type = NotificationType.PRICE_OFFER,
                targetId = requestId
            )
        }
        return offerId
    }

    suspend fun acceptPriceOffer(offer: RequestOfferEntity) {
        database.requestOfferDao().updateOfferStatus(offer.id, OfferStatus.ACCEPTED)
        database.requestOfferDao().rejectOtherOffersForRequest(offer.requestId, offer.id)
        database.serviceRequestDao().updateAgreedPrice(offer.requestId, offer.priceDzd)
        database.serviceRequestDao().assignProfessionalToRequest(
            id = offer.requestId,
            proId = offer.professionalId,
            proName = offer.professionalName,
            proPhone = offer.professionalPhone
        )

        val updatedOffer = offer.copy(status = OfferStatus.ACCEPTED)
        firebaseManager?.saveRequestOffer(updatedOffer)
        val req = database.serviceRequestDao().getRequestById(offer.requestId).firstOrNull()
        if (req != null) {
            firebaseManager?.saveServiceRequest(req)
        }

        val pro = database.professionalDao().getProfessionalById(offer.professionalId).firstOrNull()
        if (pro != null) {
            sendNotification(
                recipientUserId = pro.userId,
                title = "تم قبول عرض السعر الخاص بك! 🎉",
                body = "وافق الزبون على عرض السعر بمبلغ ${offer.priceDzd.toInt()} دج. يمكنك التواصل والبدء بالعمل.",
                type = NotificationType.OFFER_ACCEPTED,
                targetId = offer.requestId
            )
        }
    }

    suspend fun rejectPriceOffer(offerId: Long) {
        database.requestOfferDao().updateOfferStatus(offerId, OfferStatus.REJECTED)
        val offer = database.requestOfferDao().getOfferById(offerId)
        if (offer != null) {
            val updatedOffer = offer.copy(status = OfferStatus.REJECTED)
            firebaseManager?.saveRequestOffer(updatedOffer)
            val req = database.serviceRequestDao().getRequestById(offer.requestId).firstOrNull()
            val pro = database.professionalDao().getProfessionalById(offer.professionalId).firstOrNull()
            if (pro != null) {
                sendNotification(
                    recipientUserId = pro.userId,
                    title = "تحديث بخصوص عرض السعر ❌",
                    body = "اعتذر الزبون عن قبول عرض السعر لطلب ${req?.serviceNameAr ?: ""}",
                    type = NotificationType.STATUS_UPDATE,
                    targetId = offer.requestId
                )
            }
        }
    }

    suspend fun requestClarificationForOffer(offer: RequestOfferEntity, customerId: Long, customerName: String) {
        database.requestOfferDao().updateOfferStatus(offer.id, OfferStatus.CLARIFICATION_REQUESTED)
        val pro = database.professionalDao().getProfessionalById(offer.professionalId).firstOrNull()
        if (pro != null) {
            sendMessage(
                requestId = offer.requestId,
                senderId = customerId,
                senderName = customerName,
                recipientId = pro.userId,
                content = "أرجو توضيح تفاصيل عرض السعر (${offer.priceDzd.toInt()} دج): ${offer.note}"
            )
        }
    }

    suspend fun deleteRequest(id: Long) {
        database.serviceRequestDao().deleteRequestById(id)
    }


    // Reviews System
    fun getReviewsForProfessional(proId: Long): Flow<List<ReviewEntity>> {
        return database.reviewDao().getReviewsForProfessional(proId)
    }

    val allReviewsForAdmin: Flow<List<ReviewEntity>> = database.reviewDao().getAllReviews()
    val flaggedReviewsForAdmin: Flow<List<ReviewEntity>> = database.reviewDao().getFlaggedReviews()

    suspend fun submitReview(
        requestId: Long,
        customerId: Long,
        customerName: String,
        professionalId: Long,
        rating: Int,
        comment: String
    ): Result<Long> {
        // Enforce anti-gaming: must be linked to completed request and not already rated
        if (requestId > 0) {
            val existing = database.reviewDao().getReviewForRequest(requestId)
            if (existing != null) {
                return Result.failure(IllegalStateException("تم تقييم هذا الطلب مسبقاً"))
            }
        }

        val clampedRating = rating.coerceIn(1, 5)
        val review = ReviewEntity(
            requestId = requestId,
            customerId = customerId,
            customerName = customerName,
            professionalId = professionalId,
            rating = clampedRating,
            comment = comment.trim()
        )
        val reviewId = database.reviewDao().insertReview(review)
        val fullReview = review.copy(id = reviewId)
        firebaseManager?.saveReview(fullReview)
        if (requestId > 0) {
            database.serviceRequestDao().markRequestRated(requestId)
        }

        // Recalculate Pro's Rating
        val pro = database.professionalDao().getProfessionalById(professionalId).firstOrNull()
        if (pro != null) {
            val totalRatings = pro.ratingCount + 1
            val newAvg = ((pro.ratingAverage * pro.ratingCount) + clampedRating) / totalRatings
            database.professionalDao().updateRating(professionalId, (newAvg * 10).toInt() / 10.0, totalRatings)
            database.professionalDao().incrementCompletedJobs(professionalId)

            sendNotification(
                recipientUserId = pro.userId,
                title = "تقييم جديد من $customerName ★$clampedRating",
                body = comment.ifBlank { "حصلت على تقييم جديد لخدمتك المنجزة." },
                type = NotificationType.REVIEW_RECEIVED,
                targetId = reviewId
            )
        }

        return Result.success(reviewId)
    }

    suspend fun flagReview(reviewId: Long, reason: String, reporterId: Long, reporterName: String) {
        database.reviewDao().flagReview(reviewId, reason)
        val review = database.reviewDao().getReviewById(reviewId)
        if (review != null) {
            submitReport(
                ReportEntity(
                    reporterId = reporterId,
                    reporterName = reporterName,
                    targetType = "REVIEW",
                    targetId = reviewId,
                    targetName = "تقييم من ${review.customerName}",
                    reason = "تقييم مسيء أو كيدي",
                    details = "سبب الإبلاغ: $reason | نص التقييم: ${review.comment}",
                    status = ReportStatus.NEW
                )
            )
        }
    }

    suspend fun deleteReviewByAdmin(reviewId: Long) {
        val review = database.reviewDao().getReviewById(reviewId)
        if (review != null) {
            val proId = review.professionalId
            database.reviewDao().deleteReview(reviewId)
            
            // Recalculate Pro's rating
            val remainingReviews = database.reviewDao().getReviewsForProfessional(proId).firstOrNull() ?: emptyList()
            if (remainingReviews.isNotEmpty()) {
                val newAvg = remainingReviews.map { it.rating }.average()
                database.professionalDao().updateRating(proId, (newAvg * 10).toInt() / 10.0, remainingReviews.size)
            } else {
                database.professionalDao().updateRating(proId, 5.0, 1)
            }
        }
    }

    // Messages
    fun getMessagesForRequest(requestId: Long): Flow<List<MessageEntity>> {
        return database.messageDao().getMessagesForRequest(requestId)
    }

    suspend fun sendMessage(
        requestId: Long,
        senderId: Long,
        senderName: String,
        recipientId: Long,
        content: String
    ): Long {
        val msg = MessageEntity(
            requestId = requestId,
            senderId = senderId,
            senderName = senderName,
            recipientId = recipientId,
            content = content
        )
        val msgId = database.messageDao().insertMessage(msg)
        val fullMsg = msg.copy(id = msgId)
        firebaseManager?.sendMessage(fullMsg)
        sendNotification(
            recipientUserId = recipientId,
            title = "رسالة جديدة من $senderName",
            body = content.take(60),
            type = NotificationType.NEW_MESSAGE,
            targetId = requestId
        )
        return msgId
    }

    // Reports System
    val allReportsForAdmin: Flow<List<ReportEntity>> = database.reportDao().getAllReports()

    suspend fun submitReport(report: ReportEntity): Long {
        val reportId = database.reportDao().insertReport(report)
        sendNotification(
            recipientUserId = 0,
            title = "بلاغ جديد عن ${report.targetName}",
            body = "السبب: ${report.reason} - من ${report.reporterName}",
            type = NotificationType.ADMIN_ALERT,
            targetId = reportId
        )
        return reportId
    }

    suspend fun updateReportStatusAndAction(id: Long, status: ReportStatus, actionTaken: String) {
        database.reportDao().updateReportStatus(id, status, actionTaken)
    }

    suspend fun deleteReport(id: Long) {
        database.reportDao().deleteReport(id)
    }

    // Notifications
    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>> {
        return database.notificationDao().getNotificationsForUser(userId)
    }

    fun getUnreadNotificationsCount(userId: Long): Flow<Int> {
        return database.notificationDao().getUnreadNotificationsCount(userId)
    }

    suspend fun sendNotification(
        recipientUserId: Long,
        title: String,
        body: String,
        type: NotificationType,
        targetId: Long = 0
    ): Long {
        val notif = NotificationEntity(
            recipientUserId = recipientUserId,
            title = title,
            body = body,
            type = type,
            targetId = targetId
        )
        val id = database.notificationDao().insertNotification(notif)
        val fullNotif = notif.copy(id = id)

        firebaseManager?.saveNotificationToFirestore(fullNotif)

        if (context != null) {
            com.example.util.NotificationHelper.showNotification(
                context = context,
                title = title,
                body = body,
                targetId = targetId,
                notificationType = type.name
            )
        }

        return id
    }

    suspend fun markNotificationAsRead(id: Long) {
        database.notificationDao().markNotificationAsRead(id)
    }

    suspend fun markAllNotificationsAsRead(userId: Long) {
        database.notificationDao().markAllNotificationsAsRead(userId)
    }

    suspend fun clearUserNotifications(userId: Long) {
        database.notificationDao().clearUserNotifications(userId)
    }

    // Users
    val allUsersForAdmin: Flow<List<UserEntity>> = database.userDao().getAllUsers()

    suspend fun setUserBlockedStatus(userId: Long, isBlocked: Boolean) {
        database.userDao().setUserBlockedStatus(userId, isBlocked)
        if (isBlocked) {
            sendNotification(
                recipientUserId = userId,
                title = "تم تجميد حسابك مؤقتاً ⚠️",
                body = "تم تجميد الحساب لمراجعة المخالفات من قبل إدارة المنصة.",
                type = NotificationType.ADMIN_ALERT
            )
        }
    }

    suspend fun updateUserProfile(user: UserEntity) {
        database.userDao().updateUser(user)
    }

    suspend fun deleteUser(userId: Long) {
        database.userDao().deleteUserById(userId)
    }

    suspend fun uploadImageToStorage(imageBytes: ByteArray, path: String): String? {
        return firebaseManager?.uploadImageBytes(imageBytes, path)
    }

    // Admin Settings
    val adminSettings: Flow<AdminSettingsEntity?> = database.adminSettingsDao().getSettings()

    suspend fun updateAdminSettings(settings: AdminSettingsEntity) {
        database.adminSettingsDao().insertOrUpdateSettings(settings)
    }
}

