package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.CityInfo
import com.example.data.model.EventType
import com.example.data.model.SpecialEvent
import com.example.data.model.UserLoveNote
import org.json.JSONArray
import org.json.JSONObject

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("couples_weather_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_PARTNER_NAME = "partner_name"
        private const val KEY_USER_AVATAR = "user_avatar_uri"
        private const val KEY_PARTNER_AVATAR = "partner_avatar_uri"

        private const val KEY_USER_CITY_NAME = "user_city_name"
        private const val KEY_USER_CITY_COUNTRY = "user_city_country"
        private const val KEY_USER_CITY_LAT = "user_city_lat"
        private const val KEY_USER_CITY_LON = "user_city_lon"

        private const val KEY_PARTNER_CITY_NAME = "partner_city_name"
        private const val KEY_PARTNER_CITY_COUNTRY = "partner_city_country"
        private const val KEY_PARTNER_CITY_LAT = "partner_city_lat"
        private const val KEY_PARTNER_CITY_LON = "partner_city_lon"

        private const val KEY_ANNIVERSARIES_JSON = "anniversaries_json"
        private const val KEY_LOVE_NOTES_JSON = "love_notes_json"
        private const val KEY_START_YEAR = "start_year"
        private const val KEY_START_MONTH = "start_month"
        private const val KEY_START_DAY = "start_day"

        private const val KEY_ROMANTIC_THEME = "romantic_theme"
        private const val KEY_CARD_STYLE = "card_style"
        private const val KEY_WEATHER_EFFECT_OVERRIDE = "weather_effect_override"
        private const val KEY_PARTICLES_ENABLED = "particles_enabled"
    }

    var selectedThemeId: String
        get() = prefs.getString(KEY_ROMANTIC_THEME, "ROSE_RUBY") ?: "ROSE_RUBY"
        set(value) = prefs.edit().putString(KEY_ROMANTIC_THEME, value).apply()

    var cardStyleId: String
        get() = prefs.getString(KEY_CARD_STYLE, "TRANSLUCENT_GLASS") ?: "TRANSLUCENT_GLASS"
        set(value) = prefs.edit().putString(KEY_CARD_STYLE, value).apply()

    var weatherEffectOverride: String?
        get() = prefs.getString(KEY_WEATHER_EFFECT_OVERRIDE, null)
        set(value) = prefs.edit().putString(KEY_WEATHER_EFFECT_OVERRIDE, value).apply()

    var particlesEnabled: Boolean
        get() = prefs.getBoolean(KEY_PARTICLES_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_PARTICLES_ENABLED, value).apply()

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "حسام") ?: "حسام"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var partnerName: String
        get() = prefs.getString(KEY_PARTNER_NAME, "حبيبتي") ?: "حبيبتي"
        set(value) = prefs.edit().putString(KEY_PARTNER_NAME, value).apply()

    var userAvatarUri: String?
        get() = prefs.getString(KEY_USER_AVATAR, null)
        set(value) = prefs.edit().putString(KEY_USER_AVATAR, value).apply()

    var partnerAvatarUri: String?
        get() = prefs.getString(KEY_PARTNER_AVATAR, null)
        set(value) = prefs.edit().putString(KEY_PARTNER_AVATAR, value).apply()

    fun getUserCity(): CityInfo {
        val name = prefs.getString(KEY_USER_CITY_NAME, "الجزائر العاصمة") ?: "الجزائر العاصمة"
        val country = prefs.getString(KEY_USER_CITY_COUNTRY, "الجزائر") ?: "الجزائر"
        val lat = prefs.getString(KEY_USER_CITY_LAT, "36.7538")?.toDoubleOrNull() ?: 36.7538
        val lon = prefs.getString(KEY_USER_CITY_LON, "3.0588")?.toDoubleOrNull() ?: 3.0588
        return CityInfo(name = name, country = country, latitude = lat, longitude = lon)
    }

    fun saveUserCity(city: CityInfo) {
        prefs.edit()
            .putString(KEY_USER_CITY_NAME, city.name)
            .putString(KEY_USER_CITY_COUNTRY, city.country)
            .putString(KEY_USER_CITY_LAT, city.latitude.toString())
            .putString(KEY_USER_CITY_LON, city.longitude.toString())
            .apply()
    }

    fun getPartnerCity(): CityInfo {
        val name = prefs.getString(KEY_PARTNER_CITY_NAME, "وهران") ?: "وهران"
        val country = prefs.getString(KEY_PARTNER_CITY_COUNTRY, "الجزائر") ?: "الجزائر"
        val lat = prefs.getString(KEY_PARTNER_CITY_LAT, "35.6987")?.toDoubleOrNull() ?: 35.6987
        val lon = prefs.getString(KEY_PARTNER_CITY_LON, "-0.6349")?.toDoubleOrNull() ?: -0.6349
        return CityInfo(name = name, country = country, latitude = lat, longitude = lon)
    }

    fun savePartnerCity(city: CityInfo) {
        prefs.edit()
            .putString(KEY_PARTNER_CITY_NAME, city.name)
            .putString(KEY_PARTNER_CITY_COUNTRY, city.country)
            .putString(KEY_PARTNER_CITY_LAT, city.latitude.toString())
            .putString(KEY_PARTNER_CITY_LON, city.longitude.toString())
            .apply()
    }

    fun getAnniversaries(): List<SpecialEvent> {
        val raw = prefs.getString(KEY_ANNIVERSARIES_JSON, null)
        if (raw.isNullOrEmpty()) {
            return listOf(
                SpecialEvent(
                    id = "init_1",
                    title = "أول مرة تلاقينا",
                    year = 2024,
                    month = 2,
                    day = 14,
                    eventType = EventType.FIRST_MET,
                    note = "أجمل يوم في حياتي حين التقت عيناي بعينيكِ"
                ),
                SpecialEvent(
                    id = "init_2",
                    title = "عيد ميلاد حبيبتي",
                    year = 2002,
                    month = 8,
                    day = 25,
                    eventType = EventType.HER_BIRTHDAY,
                    note = "يوم ولدت أميرتي الجميلة ونور عالمي"
                ),
                SpecialEvent(
                    id = "init_3",
                    title = "ذكرى أول اعتراف بالحب",
                    year = 2024,
                    month = 4,
                    day = 10,
                    eventType = EventType.FIRST_LOVE,
                    note = "قلتلك نحبك وقلتيلي وأنا كثر يا روحي"
                )
            )
        }

        val list = mutableListOf<SpecialEvent>()
        try {
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val typeName = obj.optString("eventType", EventType.CUSTOM.name)
                val eventType = try {
                    EventType.valueOf(typeName)
                } catch (_: Exception) {
                    EventType.CUSTOM
                }
                list.add(
                    SpecialEvent(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        title = obj.optString("title", ""),
                        year = obj.optInt("year", 2024),
                        month = obj.optInt("month", 1),
                        day = obj.optInt("day", 1),
                        eventType = eventType,
                        note = obj.optString("note", "")
                    )
                )
            }
        } catch (_: Exception) {
            // fallback
        }
        return list
    }

    fun saveAnniversaries(list: List<SpecialEvent>) {
        val jsonArray = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("year", item.year)
                put("month", item.month)
                put("day", item.day)
                put("eventType", item.eventType.name)
                put("note", item.note)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_ANNIVERSARIES_JSON, jsonArray.toString()).apply()
    }

    fun getLoveNotes(): List<UserLoveNote> {
        val raw = prefs.getString(KEY_LOVE_NOTES_JSON, null)
        if (raw.isNullOrEmpty()) {
            return listOf(
                UserLoveNote(
                    id = "default_1",
                    content = "مهما طالت المسافة، قلبي عندك يا روحي وعيني ديما تستنى شوفتك 💖",
                    isFavorite = true
                ),
                UserLoveNote(
                    id = "default_2",
                    content = "سقسيت الميتيو قالولي الجو دافي، قلتلهم دافي بحنانتها وضحكتها لي تسوى الدنيا ☕🌸",
                    isFavorite = true
                )
            )
        }

        val list = mutableListOf<UserLoveNote>()
        try {
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    UserLoveNote(
                        id = obj.optString("id", System.currentTimeMillis().toString()),
                        content = obj.optString("content", ""),
                        dateAdded = obj.optLong("dateAdded", System.currentTimeMillis()),
                        isFavorite = obj.optBoolean("isFavorite", false)
                    )
                )
            }
        } catch (_: Exception) {
            // fallback
        }
        return list
    }

    fun saveLoveNotes(list: List<UserLoveNote>) {
        val jsonArray = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("content", item.content)
                put("dateAdded", item.dateAdded)
                put("isFavorite", item.isFavorite)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_LOVE_NOTES_JSON, jsonArray.toString()).apply()
    }
}
