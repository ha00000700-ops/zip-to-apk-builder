package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.data.model.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Remote Data Source for Firebase Services (Auth, Firestore, Storage, FCM)
 * Fully connected using google-services.json
 */
class FirebaseManager private constructor(context: Context) {

    private var auth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null
    private var storage: FirebaseStorage? = null
    private var isFcmAvailable: Boolean = true

    init {
        try {
            val app = if (FirebaseApp.getApps(context).isNotEmpty()) {
                FirebaseApp.getInstance()
            } else {
                FirebaseApp.initializeApp(context)
            }
            if (app != null) {
                auth = FirebaseAuth.getInstance(app)
                firestore = FirebaseFirestore.getInstance(app)
                storage = FirebaseStorage.getInstance(app)
                Log.d("FirebaseManager", "Firebase successfully initialized for package: ${context.packageName}")
                ensureAuthenticated()
            }
        } catch (t: Throwable) {
            Log.e("FirebaseManager", "Firebase initialization error: ${t.message}", t)
        }
    }

    fun ensureAuthenticated(onDone: (() -> Unit)? = null) {
        val a = auth ?: return
        if (a.currentUser == null) {
            a.signInAnonymously().addOnSuccessListener { res ->
                Log.d("KhdemliDebug", "[KhdemliDebug] Anonymous auth established: ${res.user?.uid}")
                onDone?.invoke()
            }.addOnFailureListener { err ->
                Log.w("KhdemliDebug", "[KhdemliDebug] Anonymous auth failed: ${err.message}")
                onDone?.invoke()
            }
        } else {
            onDone?.invoke()
        }
    }

    val isFirebaseAvailable: Boolean
        get() = auth != null && firestore != null

    // --- FIREBASE AUTHENTICATION (EMAIL / PASSWORD) ---
    suspend fun signUpWithEmailPassword(email: String, password: String): String? {
        val a = auth ?: return null
        return try {
            val result = a.createUserWithEmailAndPassword(email.trim(), password).await()
            result.user?.uid
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Sign up with email/password failed: ${e.message}", e)
            throw e
        }
    }

    suspend fun signInWithEmailPassword(email: String, password: String): String? {
        val a = auth ?: return null
        return try {
            val result = a.signInWithEmailAndPassword(email.trim(), password).await()
            result.user?.uid
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Sign in with email/password failed: ${e.message}", e)
            throw e
        }
    }

    fun getCurrentFirebaseUid(): String? {
        return auth?.currentUser?.uid
    }

    fun getCurrentUserEmail(): String? {
        return auth?.currentUser?.email
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Error signing out", e)
        }
    }

    suspend fun fetchUserByEmail(email: String): UserEntity? {
        val db = firestore ?: return null
        return try {
            val snapshot = db.collection("users")
                .whereEqualTo("email", email.trim())
                .limit(1)
                .get()
                .await()
            val doc = snapshot.documents.firstOrNull() ?: return null
            mapDocToUser(doc.id, doc.data ?: emptyMap())
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to fetch user by email: ${e.message}")
            null
        }
    }

    suspend fun fetchUserByPhone(phone: String): UserEntity? {
        val db = firestore ?: return null
        return try {
            val snapshot = db.collection("users")
                .whereEqualTo("phone", phone.trim())
                .limit(1)
                .get()
                .await()
            val doc = snapshot.documents.firstOrNull() ?: return null
            mapDocToUser(doc.id, doc.data ?: emptyMap())
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to fetch user by phone: ${e.message}")
            null
        }
    }

    suspend fun fetchUserByUid(uid: String): UserEntity? {
        val db = firestore ?: return null
        var attempt = 0
        while (attempt < 3) {
            try {
                val doc = db.collection("users").document(uid).get().await()
                if (doc.exists()) {
                    return mapDocToUser(doc.id, doc.data ?: emptyMap())
                }
                return null
            } catch (e: Exception) {
                attempt++
                if (attempt >= 3) {
                    Log.e("FirebaseManager", "Failed to fetch user by uid: ${e.message}")
                    return null
                }
                // Wait briefly before retrying in case authentication token is still refreshing
                kotlinx.coroutines.delay(400L * attempt)
            }
        }
        return null
    }

    private fun mapDocToUser(docId: String, data: Map<String, Any>): UserEntity {
        val idVal = (data["id"] as? Long) ?: (docId.hashCode().toLong() and 0x7FFFFFFF)
        return UserEntity(
            id = idVal,
            fullName = data["fullName"] as? String ?: "",
            phone = data["phone"] as? String ?: "",
            email = data["email"] as? String ?: "",
            role = try { UserRole.valueOf(data["role"] as? String ?: "CUSTOMER") } catch (_: Exception) { UserRole.CUSTOMER },
            wilayaCode = (data["wilayaCode"] as? Long)?.toInt() ?: 16,
            wilayaNameAr = data["wilayaNameAr"] as? String ?: "الجزائر",
            communeNameAr = data["communeNameAr"] as? String ?: "الجزائر الوسطى",
            avatarUrl = data["avatarUrl"] as? String ?: "",
            isBlocked = data["isBlocked"] as? Boolean ?: false,
            fcmToken = data["fcmToken"] as? String ?: "",
            createdAt = (data["createdAt"] as? Long) ?: System.currentTimeMillis()
        )
    }

    suspend fun getFcmToken(): String? {
        if (!isFcmAvailable) return null
        return try {
            FirebaseMessaging.getInstance().token.await()
        } catch (e: Exception) {
            isFcmAvailable = false
            Log.w("FirebaseManager", "FCM token registration skipped or failed: ${e.message}")
            null
        }
    }

    suspend fun updateUserFcmToken(uid: String, fcmToken: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(uid).update("fcmToken", fcmToken).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to update FCM token for user $uid", e)
            false
        }
    }

    suspend fun clearUserFcmTokenOnLogout(): Boolean {
        val uid = getCurrentFirebaseUid() ?: return false
        val db = firestore ?: return false
        return try {
            db.collection("users").document(uid).update("fcmToken", "").await()
            if (isFcmAvailable) {
                try {
                    FirebaseMessaging.getInstance().deleteToken().await()
                } catch (e: Exception) {
                    isFcmAvailable = false
                    Log.w("FirebaseManager", "Failed to delete local FCM token: ${e.message}")
                }
            }
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to clear FCM token on logout", e)
            false
        }
    }

    suspend fun saveNotificationToFirestore(notification: NotificationEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection("notifications").document()
            val map = mapOf(
                "id" to if (notification.id > 0) notification.id else docRef.id.hashCode().toLong(),
                "recipientUserId" to notification.recipientUserId,
                "title" to notification.title,
                "body" to notification.body,
                "type" to notification.type.name,
                "targetId" to notification.targetId,
                "isRead" to notification.isRead,
                "createdAt" to notification.createdAt
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save notification to Firestore", e)
            false
        }
    }

    fun observeUserNotifications(userId: Long): Flow<List<NotificationEntity>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("notifications")
            .whereIn("recipientUserId", listOf(userId, 0L))
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error listening to notifications", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    val notifId = (data["id"] as? Long) ?: (doc.id.hashCode().toLong() and 0x7FFFFFFF)
                    NotificationEntity(
                        id = notifId,
                        recipientUserId = (data["recipientUserId"] as? Long) ?: userId,
                        title = data["title"] as? String ?: "",
                        body = data["body"] as? String ?: "",
                        type = try { NotificationType.valueOf(data["type"] as? String ?: "SYSTEM") } catch (_: Exception) { NotificationType.SYSTEM },
                        targetId = (data["targetId"] as? Long) ?: 0L,
                        isRead = data["isRead"] as? Boolean ?: false,
                        createdAt = (data["createdAt"] as? Long) ?: System.currentTimeMillis()
                    )
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    // --- FIREBASE STORAGE FOR IMAGES ---
    suspend fun uploadImageBytes(imageBytes: ByteArray, destinationPath: String): String? {
        val st = storage ?: return null
        return try {
            val ref = st.reference.child(destinationPath)
            ref.putBytes(imageBytes).await()
            val url = ref.downloadUrl.await()
            url.toString()
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Firebase Storage upload failed", e)
            null
        }
    }

    // --- FIRESTORE SYNC FOR SERVICE REQUESTS ---
    fun mapDocToServiceRequest(docId: String, data: Map<String, Any>): ServiceRequestEntity {
        val reqId = (data["id"] as? Number)?.toLong() ?: (docId.toLongOrNull() ?: (docId.hashCode().toLong() and 0x7FFFFFFF))
        val statusStr = data["status"] as? String ?: "NEW"
        val status = try { RequestStatus.valueOf(statusStr) } catch (_: Exception) { RequestStatus.NEW }
        val urgencyStr = data["urgency"] as? String ?: "NORMAL"
        val urgency = try { RequestUrgency.valueOf(urgencyStr) } catch (_: Exception) { RequestUrgency.NORMAL }

        val proIdVal = when (val p = data["professionalId"]) {
            is Long -> if (p > 0) p else null
            is Int -> if (p > 0) p.toLong() else null
            is Number -> if (p.toLong() > 0) p.toLong() else null
            else -> null
        }

        val agreedPriceVal = when (val ap = data["agreedPriceDzd"]) {
            is Double -> if (ap > 0.0) ap else null
            is Number -> if (ap.toDouble() > 0.0) ap.toDouble() else null
            else -> null
        }

        return ServiceRequestEntity(
            id = reqId,
            customerId = (data["customerId"] as? Number)?.toLong() ?: 0L,
            customerName = data["customerName"] as? String ?: "",
            customerPhone = data["customerPhone"] as? String ?: "",
            professionalId = proIdVal,
            professionalName = (data["professionalName"] as? String)?.ifBlank { null },
            professionalPhone = (data["professionalPhone"] as? String)?.ifBlank { null },
            serviceCategoryId = (data["serviceCategoryId"] as? Number)?.toLong() ?: 0L,
            serviceNameAr = data["serviceNameAr"] as? String ?: "",
            title = data["title"] as? String ?: "",
            description = data["description"] as? String ?: "",
            images = data["images"] as? String ?: "",
            urgency = urgency,
            wilayaCode = (data["wilayaCode"] as? Number)?.toInt() ?: 16,
            wilayaNameAr = data["wilayaNameAr"] as? String ?: "الجزائر",
            communeNameAr = data["communeNameAr"] as? String ?: "الجزائر الوسطى",
            addressDetails = data["addressDetails"] as? String ?: "",
            status = status,
            agreedPriceDzd = agreedPriceVal,
            customerNotes = data["customerNotes"] as? String ?: "",
            professionalNotes = data["professionalNotes"] as? String ?: "",
            cancellationReason = data["cancellationReason"] as? String ?: "",
            isRated = (data["isRated"] as? Boolean) ?: false,
            createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            updatedAt = (data["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    fun observeServiceRequests(): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("service_requests")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error listening to service requests", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.data?.plus("id" to (doc.id.toLongOrNull() ?: 0L))
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    fun observeAllServiceRequests(): Flow<List<ServiceRequestEntity>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val proUid = auth?.currentUser?.uid ?: "anonymous"
        Log.d("KhdemliDebug", "[KhdemliDebug] CRAFTSMAN_UID=$proUid")
        Log.d("KhdemliDebug", "[KhdemliDebug] QUERY_START")

        val listener = db.collection("service_requests")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("KhdemliDebug", "[KhdemliDebug] QUERY_ERROR=${error.message}", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    mapDocToServiceRequest(doc.id, data)
                }?.sortedByDescending { it.createdAt } ?: emptyList()

                Log.d("KhdemliDebug", "[KhdemliDebug] QUERY_RESULT_COUNT=${list.size}")
                list.forEach { req ->
                    Log.d("KhdemliDebug", "[KhdemliDebug] REQUEST_FOUND=id=${req.id}, title='${req.title}', status=${req.status.name}, wilaya=${req.wilayaCode}, category=${req.serviceCategoryId}, proId=${req.professionalId}")
                }
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveServiceRequest(request: ServiceRequestEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val reqId = if (request.id > 0) request.id else System.currentTimeMillis()
            val docRef = db.collection("service_requests").document(reqId.toString())

            val currentUid = auth?.currentUser?.uid ?: request.customerId.toString()
            val craftsmanUid = if (request.professionalId != null && request.professionalId > 0) request.professionalId.toString() else ""
            val map = mapOf(
                "id" to reqId,
                "customerUid" to currentUid,
                "customerId" to request.customerId,
                "customerName" to request.customerName,
                "customerPhone" to request.customerPhone,
                "professionalUid" to craftsmanUid,
                "professionalId" to (request.professionalId ?: 0L),
                "professionalName" to (request.professionalName ?: ""),
                "professionalPhone" to (request.professionalPhone ?: ""),
                "serviceCategoryId" to request.serviceCategoryId,
                "serviceNameAr" to request.serviceNameAr,
                "title" to request.title,
                "description" to request.description,
                "images" to request.images,
                "urgency" to request.urgency.name,
                "wilayaCode" to request.wilayaCode,
                "wilayaNameAr" to request.wilayaNameAr,
                "communeNameAr" to request.communeNameAr,
                "addressDetails" to request.addressDetails,
                "status" to request.status.name,
                "agreedPriceDzd" to (request.agreedPriceDzd ?: 0.0),
                "customerNotes" to request.customerNotes,
                "professionalNotes" to request.professionalNotes,
                "cancellationReason" to request.cancellationReason,
                "isRated" to request.isRated,
                "createdAt" to request.createdAt,
                "updatedAt" to request.updatedAt
            )
            docRef.set(map).await()

            Log.d("KhdemliDebug", "[KhdemliDebug] CREATE_REQUEST_SUCCESS")
            Log.d("KhdemliDebug", "[KhdemliDebug] REQUEST_PATH=service_requests/$reqId")
            Log.d("KhdemliDebug", "[KhdemliDebug] REQUEST_ID=$reqId")
            Log.d("KhdemliDebug", "[KhdemliDebug] CUSTOMER_UID=$currentUid")
            Log.d("KhdemliDebug", "[KhdemliDebug] WILAYA=${request.wilayaCode}")
            Log.d("KhdemliDebug", "[KhdemliDebug] CATEGORY=${request.serviceCategoryId}")
            Log.d("KhdemliDebug", "[KhdemliDebug] CRAFTSMAN_UID=$craftsmanUid")

            true
        } catch (e: Exception) {
            Log.e("KhdemliDebug", "[KhdemliDebug] QUERY_ERROR=Failed to save request to Firestore: ${e.message}", e)
            false
        }
    }

    // --- FIRESTORE SYNC FOR REQUEST OFFERS ---
    fun mapDocToRequestOffer(docId: String, data: Map<String, Any>): RequestOfferEntity {
        val offerId = (data["id"] as? Number)?.toLong() ?: (docId.toLongOrNull() ?: (docId.hashCode().toLong() and 0x7FFFFFFF))
        val statusStr = data["status"] as? String ?: "PENDING"
        val status = try { OfferStatus.valueOf(statusStr) } catch (_: Exception) { OfferStatus.PENDING }

        return RequestOfferEntity(
            id = offerId,
            requestId = (data["requestId"] as? Number)?.toLong() ?: 0L,
            professionalId = (data["professionalId"] as? Number)?.toLong() ?: 0L,
            professionalName = data["professionalName"] as? String ?: "",
            professionalPhone = data["professionalPhone"] as? String ?: "",
            priceDzd = (data["priceDzd"] as? Number)?.toDouble() ?: 0.0,
            note = data["note"] as? String ?: "",
            status = status,
            createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    fun observeRequestOffers(requestId: Long): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("request_offers")
            .whereEqualTo("requestId", requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing offers", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.data } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    fun observeRequestOffersList(requestId: Long): Flow<List<RequestOfferEntity>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("request_offers")
            .whereEqualTo("requestId", requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing offers list", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    mapDocToRequestOffer(doc.id, data)
                }?.sortedByDescending { it.createdAt } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveRequestOffer(offer: RequestOfferEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = if (offer.id > 0) db.collection("request_offers").document(offer.id.toString())
            else db.collection("request_offers").document()

            val proUid = auth?.currentUser?.uid ?: offer.professionalId.toString()
            val map = mapOf(
                "id" to if (offer.id > 0) offer.id else docRef.id.hashCode().toLong(),
                "requestId" to offer.requestId,
                "professionalUid" to proUid,
                "professionalId" to offer.professionalId,
                "professionalName" to offer.professionalName,
                "professionalPhone" to offer.professionalPhone,
                "priceDzd" to offer.priceDzd,
                "note" to offer.note,
                "status" to offer.status.name,
                "createdAt" to offer.createdAt
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save offer to Firestore", e)
            false
        }
    }

    // --- FIRESTORE CHAT MESSAGES (REAL-TIME) ---
    fun observeMessages(requestId: Long): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("messages")
            .whereEqualTo("requestId", requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing messages", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.data } ?: emptyList()
                val sortedList = list.sortedBy { (it["timestamp"] as? Long) ?: 0L }
                trySend(sortedList)
            }

        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(message: MessageEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = if (message.id > 0) db.collection("messages").document(message.id.toString())
            else db.collection("messages").document()

            val map = mapOf(
                "id" to if (message.id > 0) message.id else docRef.id.hashCode().toLong(),
                "requestId" to message.requestId,
                "senderId" to message.senderId,
                "senderName" to message.senderName,
                "recipientId" to message.recipientId,
                "content" to message.content,
                "timestamp" to message.timestamp,
                "isRead" to message.isRead
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to send message to Firestore", e)
            false
        }
    }

    // --- FIRESTORE USERS & PROFESSIONALS ---
    suspend fun saveUser(user: UserEntity, documentUid: String? = null): Boolean {
        val db = firestore ?: return false
        return try {
            val map = mapOf(
                "id" to user.id,
                "fullName" to user.fullName,
                "phone" to user.phone,
                "email" to user.email,
                "role" to user.role.name,
                "wilayaCode" to user.wilayaCode,
                "wilayaNameAr" to user.wilayaNameAr,
                "communeNameAr" to user.communeNameAr,
                "avatarUrl" to user.avatarUrl,
                "isBlocked" to user.isBlocked,
                "fcmToken" to user.fcmToken,
                "createdAt" to user.createdAt
            )
            val docId = documentUid ?: auth?.currentUser?.uid ?: user.id.toString()
            db.collection("users").document(docId).set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save user to Firestore", e)
            false
        }
    }

    fun mapDocToProfessional(docId: String, data: Map<String, Any>): ProfessionalEntity {
        val proId = (data["id"] as? Number)?.toLong() ?: (docId.toLongOrNull() ?: (docId.hashCode().toLong() and 0x7FFFFFFF))
        val vStatusStr = data["verificationStatus"] as? String ?: "NOT_SUBMITTED"
        val vStatus = try { VerificationStatus.valueOf(vStatusStr) } catch (_: Exception) { VerificationStatus.NOT_SUBMITTED }

        return ProfessionalEntity(
            id = proId,
            userId = (data["userId"] as? Number)?.toLong() ?: proId,
            fullName = data["fullName"] as? String ?: "",
            phone = data["phone"] as? String ?: "",
            whatsapp = data["whatsapp"] as? String ?: "",
            serviceCategoryId = (data["serviceCategoryId"] as? Number)?.toLong() ?: 1L,
            professionNameAr = data["professionNameAr"] as? String ?: "",
            professionNameFr = data["professionNameFr"] as? String ?: "",
            wilayaCode = (data["wilayaCode"] as? Number)?.toInt() ?: 16,
            wilayaNameAr = data["wilayaNameAr"] as? String ?: "الجزائر",
            communeNameAr = data["communeNameAr"] as? String ?: "الجزائر الوسطى",
            experienceYears = (data["experienceYears"] as? Number)?.toInt() ?: 1,
            bio = data["bio"] as? String ?: "",
            workingHours = data["workingHours"] as? String ?: "08:00 - 18:00",
            priceEstimate = data["priceEstimate"] as? String ?: "حسب المعاينة",
            isAvailable = (data["isAvailable"] as? Boolean) ?: true,
            isVerified = (data["isVerified"] as? Boolean) ?: false,
            verificationStatus = vStatus,
            isApprovedByAdmin = (data["isApprovedByAdmin"] as? Boolean) ?: true,
            ratingAverage = (data["ratingAverage"] as? Number)?.toDouble() ?: 5.0,
            ratingCount = (data["ratingCount"] as? Number)?.toInt() ?: 1,
            completedJobsCount = (data["completedJobsCount"] as? Number)?.toInt() ?: 0,
            createdAt = (data["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    suspend fun fetchProfessionalByUserId(userId: Long): ProfessionalEntity? {
        val db = firestore ?: return null
        return try {
            val snapshot = db.collection("professionals")
                .whereEqualTo("userId", userId)
                .limit(1)
                .get()
                .await()
            val doc = snapshot.documents.firstOrNull() ?: return null
            mapDocToProfessional(doc.id, doc.data ?: emptyMap())
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to fetch pro by userId: ${e.message}")
            null
        }
    }

    suspend fun fetchProfessionalByPhone(phone: String): ProfessionalEntity? {
        val db = firestore ?: return null
        return try {
            val snapshot = db.collection("professionals")
                .whereEqualTo("phone", phone.trim())
                .limit(1)
                .get()
                .await()
            val doc = snapshot.documents.firstOrNull() ?: return null
            mapDocToProfessional(doc.id, doc.data ?: emptyMap())
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to fetch pro by phone: ${e.message}")
            null
        }
    }

    fun observeAllProfessionals(): Flow<List<ProfessionalEntity>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("professionals")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing professionals", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    mapDocToProfessional(doc.id, data)
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveProfessional(pro: ProfessionalEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val map = mapOf(
                "id" to pro.id,
                "userId" to pro.userId,
                "fullName" to pro.fullName,
                "phone" to pro.phone,
                "whatsapp" to pro.whatsapp,
                "serviceCategoryId" to pro.serviceCategoryId,
                "professionNameAr" to pro.professionNameAr,
                "wilayaCode" to pro.wilayaCode,
                "wilayaNameAr" to pro.wilayaNameAr,
                "communeNameAr" to pro.communeNameAr,
                "bio" to pro.bio,
                "isAvailable" to pro.isAvailable,
                "isVerified" to pro.isVerified,
                "verificationStatus" to pro.verificationStatus.name,
                "ratingAverage" to pro.ratingAverage,
                "ratingCount" to pro.ratingCount,
                "completedJobsCount" to pro.completedJobsCount,
                "createdAt" to pro.createdAt
            )
            val docId = if (pro.id > 0) pro.id.toString() else pro.userId.toString()
            db.collection("professionals").document(docId).set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save pro to Firestore", e)
            false
        }
    }

    // --- FIRESTORE REVIEWS ---
    suspend fun saveReview(review: ReviewEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = if (review.id > 0) db.collection("reviews").document(review.id.toString())
            else db.collection("reviews").document()

            val map = mapOf(
                "id" to if (review.id > 0) review.id else docRef.id.hashCode().toLong(),
                "requestId" to review.requestId,
                "customerId" to review.customerId,
                "customerName" to review.customerName,
                "professionalId" to review.professionalId,
                "rating" to review.rating,
                "comment" to review.comment,
                "isFlagged" to review.isFlagged,
                "flagReason" to review.flagReason,
                "createdAt" to review.createdAt
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save review to Firestore", e)
            false
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: FirebaseManager? = null

        fun getInstance(context: Context): FirebaseManager {
            return INSTANCE ?: synchronized(this) {
                val instance = FirebaseManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
