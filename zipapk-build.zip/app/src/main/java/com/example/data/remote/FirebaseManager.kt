package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Remote Data Source for Firebase Services (Auth, Firestore, Storage)
 * Operates gracefully with local fallback if Firebase is not yet configured with google-services.json.
 */
class FirebaseManager private constructor(context: Context) {

    private var auth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    init {
        try {
            if (com.google.firebase.FirebaseApp.getApps(context).isNotEmpty()) {
                auth = FirebaseAuth.getInstance()
                firestore = FirebaseFirestore.getInstance()
                Log.d("FirebaseManager", "Firebase successfully initialized.")
            } else {
                Log.w("FirebaseManager", "FirebaseApp is empty. Running in Offline/Room-Cache mode.")
            }
        } catch (t: Throwable) {
            Log.w("FirebaseManager", "Firebase not initialized. Running in Offline/Room-Cache mode: ${t.message}")
        }
    }

    val isFirebaseAvailable: Boolean
        get() = auth != null && firestore != null

    // --- FIRESTORE SYNC FOR SERVICE REQUESTS ---
    fun observeServiceRequests(): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("service_requests")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error listening to service requests", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { doc ->
                    doc.data?.plus("id" to (doc.id.toLongOrNull() ?: 0L))
                } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveServiceRequest(request: ServiceRequestEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = if (request.id > 0) db.collection("service_requests").document(request.id.toString())
            else db.collection("service_requests").document()

            val map = mapOf(
                "id" to if (request.id > 0) request.id else docRef.id.hashCode().toLong(),
                "customerId" to request.customerId,
                "customerName" to request.customerName,
                "customerPhone" to request.customerPhone,
                "professionalId" to request.professionalId,
                "professionalName" to request.professionalName,
                "professionalPhone" to request.professionalPhone,
                "serviceCategoryId" to request.serviceCategoryId,
                "serviceNameAr" to request.serviceNameAr,
                "title" to request.title,
                "description" to request.description,
                "images" to request.images,
                "urgency" to request.urgency.name,
                "wilayaCode" to request.wilayaCode,
                "wilayaNameAr" to request.wilayaNameAr,
                "communeNameAr" to request.communeNameAr,
                "addressDetails" to request.addressDetails,
                "status" to request.status.name,
                "agreedPriceDzd" to request.agreedPriceDzd,
                "customerNotes" to request.customerNotes,
                "professionalNotes" to request.professionalNotes,
                "cancellationReason" to request.cancellationReason,
                "isRated" to request.isRated,
                "createdAt" to request.createdAt,
                "updatedAt" to request.updatedAt
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save request to Firestore", e)
            false
        }
    }

    // --- FIRESTORE SYNC FOR REQUEST OFFERS ---
    fun observeRequestOffers(requestId: Long): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("request_offers")
            .whereEqualTo("requestId", requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing offers", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.data } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveRequestOffer(offer: RequestOfferEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection("request_offers").document()
            val map = mapOf(
                "id" to docRef.id.hashCode().toLong(),
                "requestId" to offer.requestId,
                "professionalId" to offer.professionalId,
                "professionalName" to offer.professionalName,
                "professionalPhone" to offer.professionalPhone,
                "priceDzd" to offer.priceDzd,
                "note" to offer.note,
                "status" to offer.status.name,
                "createdAt" to offer.createdAt
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to save offer to Firestore", e)
            false
        }
    }

    // --- FIRESTORE CHAT MESSAGES ---
    fun observeMessages(requestId: Long): Flow<List<Map<String, Any>>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("messages")
            .whereEqualTo("requestId", requestId)
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("FirebaseManager", "Error observing messages", error)
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.data } ?: emptyList()
                trySend(list)
            }

        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(message: MessageEntity): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection("messages").document()
            val map = mapOf(
                "id" to docRef.id.hashCode().toLong(),
                "requestId" to message.requestId,
                "senderId" to message.senderId,
                "senderName" to message.senderName,
                "recipientId" to message.recipientId,
                "content" to message.content,
                "timestamp" to message.timestamp,
                "isRead" to message.isRead
            )
            docRef.set(map).await()
            true
        } catch (e: Exception) {
            Log.e("FirebaseManager", "Failed to send message to Firestore", e)
            false
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: FirebaseManager? = null

        fun getInstance(context: Context): FirebaseManager {
            return INSTANCE ?: synchronized(this) {
                val instance = FirebaseManager(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
