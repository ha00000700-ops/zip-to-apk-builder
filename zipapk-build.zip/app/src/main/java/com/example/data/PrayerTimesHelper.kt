package com.example.data

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.CalculationParameters
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.Madhab
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.util.Calendar
import java.util.Date

object PrayerTimesHelper {

    fun getPrayerTimes(
        lat: Double,
        lng: Double,
        date: Date,
        calculationMethod: CalculationMethod,
        asrMethod: Madhab,
        timeZoneId: String
    ): PrayerTimes {
        val timeZone = java.util.TimeZone.getTimeZone(timeZoneId)
        val calendar = Calendar.getInstance(timeZone)
        calendar.time = date
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        
        val coordinates = Coordinates(lat, lng)
        val dateComponents = DateComponents(year, month, day)
        val parameters = calculationMethod.parameters
        parameters.madhab = asrMethod
        
        return PrayerTimes(coordinates, dateComponents, parameters)
    }

    fun getNextPrayerTimes(
        lat: Double,
        lng: Double,
        date: Date,
        calculationMethod: CalculationMethod,
        asrMethod: Madhab,
        timeZoneId: String
    ): PrayerTimes {
        val timeZone = java.util.TimeZone.getTimeZone(timeZoneId)
        val calendar = Calendar.getInstance(timeZone)
        calendar.time = date
        calendar.add(Calendar.DAY_OF_YEAR, 1)
        return getPrayerTimes(lat, lng, calendar.time, calculationMethod, asrMethod, timeZoneId)
    }
}
