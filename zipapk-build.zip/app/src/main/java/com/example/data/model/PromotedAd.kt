package com.example.data.model

/**
 * Promotional Advertisement Packages available for Service Providers.
 * Completely separate from the monthly subscription tiers.
 */
enum class AdBoostPackage(
    val id: String,
    val priceDzd: Long,
    val durationDays: Int,
    val priorityLevel: Int,
    val titleAr: String,
    val subtitleAr: String,
    val badgeLabelAr: String,
    val isRecommended: Boolean = false
) {
    BASIC(
        id = "BOOST_BASIC",
        priceDzd = 100L,
        durationDays = 3,
        priorityLevel = 1,
        titleAr = "ترويج أساسي (Boost Basic)",
        subtitleAr = "ظهور ترويجي في مقدمة نتائج البحث لمدة 3 أيام",
        badgeLabelAr = "إعلان مروّج 🚀",
        isRecommended = false
    ),
    STANDARD(
        id = "BOOST_STANDARD",
        priceDzd = 250L,
        durationDays = 7,
        priorityLevel = 2,
        titleAr = "ترويج متقدم (Boost Standard)",
        subtitleAr = "أولوية ظهور أعلى ومضاعفة مرات المشاهدة لمدة أسبوع كامل",
        badgeLabelAr = "مروّج متقدم ⚡",
        isRecommended = false
    ),
    PREMIUM(
        id = "BOOST_PREMIUM",
        priceDzd = 500L,
        durationDays = 30,
        priorityLevel = 3,
        titleAr = "ترويج شامل مميز (Boost Premium)",
        subtitleAr = "أقصى أولوية ترويجية وظهور بصدارة السوق لشهر كامل مع شارة ذهبية",
        badgeLabelAr = "إعلان ذهبي مميز ⭐",
        isRecommended = true
    );

    companion object {
        fun fromId(id: String?): AdBoostPackage {
            if (id.isNullOrBlank()) return BASIC
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) || it.name.equals(id, ignoreCase = true) } ?: BASIC
        }
    }
}

/**
 * Advertisement status lifecycle.
 */
enum class AdStatus(val displayNameAr: String) {
    PENDING_PAYMENT("في انتظار الدفع"),
    PENDING_VERIFICATION("قيد التحقق"),
    ACTIVE("نشط ومروّج"),
    EXPIRED("منتهي الصلاحية"),
    REJECTED("مرفوض"),
    CANCELLED("ملغى");

    companion object {
        fun fromCode(code: String?): AdStatus {
            if (code.isNullOrBlank()) return PENDING_PAYMENT
            return values().firstOrNull { it.name.equals(code, ignoreCase = true) } ?: PENDING_PAYMENT
        }
    }
}

/**
 * Model representing a Promoted Service Advertisement.
 */
data class PromotedAd(
    val id: String = "",
    val providerId: String = "",
    val providerName: String = "",
    val providerAvatarUrl: String = "",
    val providerPhone: String = "",
    val professionId: String = "",
    val professionNameAr: String = "",
    val categoryId: String = "",
    val adTitle: String = "",
    val adDescription: String = "",
    val adImageUrl: String = "",
    val wilayaCode: String = "",
    val wilayaName: String = "",
    val communeCode: String = "",
    val communeName: String = "",
    val packageId: String = AdBoostPackage.BASIC.id,
    val priceDzd: Long = AdBoostPackage.BASIC.priceDzd,
    val durationDays: Int = AdBoostPackage.BASIC.durationDays,
    val priorityLevel: Int = AdBoostPackage.BASIC.priorityLevel,
    val status: AdStatus = AdStatus.PENDING_PAYMENT,
    val paymentStatus: PaymentStatus = PaymentStatus.UNPAID,
    val checkoutId: String = "",
    val checkoutUrl: String = "",
    val paymentMethod: PaymentMethod? = null,
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    val impressionsCount: Long = 0L,
    val clicksCount: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val boostPackage: AdBoostPackage
        get() = AdBoostPackage.fromId(packageId)

    val isActive: Boolean
        get() = status == AdStatus.ACTIVE &&
                (endDate == 0L || endDate > System.currentTimeMillis())

    val isPending: Boolean
        get() = status == AdStatus.PENDING_PAYMENT || status == AdStatus.PENDING_VERIFICATION

    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "providerId" to providerId,
            "providerName" to providerName,
            "providerAvatarUrl" to providerAvatarUrl,
            "providerPhone" to providerPhone,
            "professionId" to professionId,
            "professionNameAr" to professionNameAr,
            "categoryId" to categoryId,
            "adTitle" to adTitle,
            "adDescription" to adDescription,
            "adImageUrl" to adImageUrl,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeCode" to communeCode,
            "communeName" to communeName,
            "packageId" to packageId,
            "priceDzd" to priceDzd,
            "durationDays" to durationDays,
            "priorityLevel" to priorityLevel,
            "status" to status.name,
            "paymentStatus" to paymentStatus.name,
            "checkoutId" to checkoutId,
            "checkoutUrl" to checkoutUrl,
            "paymentMethod" to paymentMethod?.code,
            "startDate" to startDate,
            "endDate" to endDate,
            "impressionsCount" to impressionsCount,
            "clicksCount" to clicksCount,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>, documentId: String): PromotedAd {
            return PromotedAd(
                id = documentId,
                providerId = map["providerId"] as? String ?: "",
                providerName = map["providerName"] as? String ?: "",
                providerAvatarUrl = map["providerAvatarUrl"] as? String ?: "",
                providerPhone = map["providerPhone"] as? String ?: "",
                professionId = map["professionId"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                categoryId = map["categoryId"] as? String ?: "",
                adTitle = map["adTitle"] as? String ?: "",
                adDescription = map["adDescription"] as? String ?: "",
                adImageUrl = map["adImageUrl"] as? String ?: "",
                wilayaCode = map["wilayaCode"] as? String ?: "",
                wilayaName = map["wilayaName"] as? String ?: "",
                communeCode = map["communeCode"] as? String ?: "",
                communeName = map["communeName"] as? String ?: "",
                packageId = map["packageId"] as? String ?: AdBoostPackage.BASIC.id,
                priceDzd = (map["priceDzd"] as? Number)?.toLong() ?: AdBoostPackage.BASIC.priceDzd,
                durationDays = (map["durationDays"] as? Number)?.toInt() ?: AdBoostPackage.BASIC.durationDays,
                priorityLevel = (map["priorityLevel"] as? Number)?.toInt() ?: AdBoostPackage.BASIC.priorityLevel,
                status = AdStatus.fromCode(map["status"] as? String),
                paymentStatus = PaymentStatus.fromCode(map["paymentStatus"] as? String),
                checkoutId = map["checkoutId"] as? String ?: "",
                checkoutUrl = map["checkoutUrl"] as? String ?: "",
                paymentMethod = PaymentMethod.fromCode(map["paymentMethod"] as? String),
                startDate = (map["startDate"] as? Number)?.toLong() ?: 0L,
                endDate = (map["endDate"] as? Number)?.toLong() ?: 0L,
                impressionsCount = (map["impressionsCount"] as? Number)?.toLong() ?: 0L,
                clicksCount = (map["clicksCount"] as? Number)?.toLong() ?: 0L,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
