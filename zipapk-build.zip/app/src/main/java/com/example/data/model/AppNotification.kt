package com.example.data.model

object AppNotificationType {
    const val NEW_OFFER = "NEW_OFFER"
    const val OFFER_ACCEPTED = "OFFER_ACCEPTED"
    const val REQUEST_ACCEPTED = "REQUEST_ACCEPTED"
    const val NEW_MESSAGE = "NEW_MESSAGE"
    const val SERVICE_COMPLETED = "SERVICE_COMPLETED"
    const val REQUEST_ASSIGNED = "REQUEST_ASSIGNED"
    const val REQUEST_CANCELLED = "REQUEST_CANCELLED"
    const val NEW_PUBLIC_REQUEST = "NEW_PUBLIC_REQUEST"
    const val VERIFICATION_APPROVED = "VERIFICATION_APPROVED"
    const val VERIFICATION_REJECTED = "VERIFICATION_REJECTED"
}

object AppNotificationTargetType {
    const val PUBLIC_REQUEST = "PUBLIC_REQUEST"
    const val CONVERSATION = "CONVERSATION"
    const val SERVICE_REQUEST = "SERVICE_REQUEST"
}

data class AppNotification(
    val id: String = "",
    val recipientId: String = "",
    val senderId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "",
    val targetId: String = "",
    val targetType: String = "",
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "recipientId" to recipientId,
            "senderId" to senderId,
            "title" to title,
            "body" to body,
            "type" to type,
            "targetId" to targetId,
            "targetType" to targetType,
            "isRead" to isRead,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): AppNotification {
            return AppNotification(
                id = id,
                recipientId = map["recipientId"] as? String ?: "",
                senderId = map["senderId"] as? String ?: "",
                title = map["title"] as? String ?: "",
                body = map["body"] as? String ?: "",
                type = map["type"] as? String ?: "",
                targetId = map["targetId"] as? String ?: "",
                targetType = map["targetType"] as? String ?: "",
                isRead = map["isRead"] as? Boolean ?: false,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }

        fun generateOfferNotificationId(requestId: String, providerId: String): String {
            return "notif_offer_${requestId}_${providerId}"
        }

        fun generateOfferAcceptedNotificationId(requestId: String, providerId: String): String {
            return "notif_accepted_${requestId}_${providerId}"
        }

        fun generateMessageNotificationId(messageId: String): String {
            return "notif_msg_${messageId}"
        }

        fun generateServiceCompletedNotificationId(requestId: String): String {
            return "notif_completed_${requestId}"
        }

        fun generatePublicRequestNotificationId(requestId: String, providerId: String): String {
            return "notif_public_request_${requestId}_${providerId}"
        }
    }
}
