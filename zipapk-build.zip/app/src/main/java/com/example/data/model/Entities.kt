package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String,
    val email: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val wilayaCode: Int = 16, // Default Alger (16)
    val wilayaNameAr: String = "الجزائر",
    val communeNameAr: String = "الجزائر الوسطى",
    val avatarUrl: String = "",
    val isBlocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "professionals")
data class ProfessionalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long, // Links to UserEntity
    val fullName: String,
    val phone: String,
    val whatsapp: String = "",
    val serviceCategoryId: Long,
    val professionNameAr: String,
    val professionNameFr: String = "",
    val wilayaCode: Int,
    val wilayaNameAr: String,
    val communeNameAr: String,
    val experienceYears: Int = 3,
    val bio: String = "",
    val workingHours: String = "08:00 - 18:00 (السبت - الخميس)",
    val isAvailable: Boolean = true,
    val isVerified: Boolean = false, // شارة موثوق
    val verificationStatus: VerificationStatus = VerificationStatus.NOT_SUBMITTED,
    val idCardNumber: String = "",
    val qualificationNumber: String = "",
    val isPhoneVerified: Boolean = true,
    val isApprovedByAdmin: Boolean = true,
    val ratingAverage: Double = 5.0,
    val ratingCount: Int = 1,
    val completedJobsCount: Int = 0,
    val priceEstimate: String = "حسب المعاينة",
    val portfolioImages: String = "", // Comma-separated or tag list
    val isProSubscriber: Boolean = false, // اشتراك مميز
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "verification_requests")
data class VerificationRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val professionalId: Long,
    val userId: Long,
    val professionalName: String,
    val professionNameAr: String,
    val phone: String,
    val wilayaCode: Int,
    val wilayaNameAr: String,
    val communeNameAr: String,
    val idCardNumber: String, // رقم بطاقة التعريف أو جواز السفر
    val qualificationOrTradeRegister: String, // بطاقة حرفي أو شهادة كفاءة أو سجل
    val documentNotes: String = "", // تفاصيل الوثائق والخبرة
    val status: VerificationStatus = VerificationStatus.PENDING,
    val adminRejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val reviewedAt: Long? = null
)

@Entity(tableName = "services")
data class ServiceCategoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val nameAr: String,
    val nameFr: String,
    val descriptionAr: String,
    val iconName: String,
    val isActive: Boolean = true,
    val displayOrder: Int = 0
)

@Entity(tableName = "wilayas")
data class WilayaEntity(
    @PrimaryKey val code: Int, // 1 to 58
    val nameAr: String,
    val nameFr: String,
    val isCovered: Boolean = true
)

@Entity(tableName = "communes")
data class CommuneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wilayaCode: Int,
    val nameAr: String,
    val nameFr: String,
    val postalCode: String = ""
)

@Entity(tableName = "service_requests")
data class ServiceRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val customerName: String,
    val customerPhone: String,
    val professionalId: Long? = null, // Can be null if broadcast to Wilaya/Service
    val professionalName: String? = null,
    val professionalPhone: String? = null,
    val serviceCategoryId: Long,
    val serviceNameAr: String,
    val description: String,
    val urgency: RequestUrgency = RequestUrgency.NORMAL,
    val wilayaCode: Int,
    val wilayaNameAr: String,
    val communeNameAr: String,
    val addressDetails: String = "",
    val status: RequestStatus = RequestStatus.NEW,
    val agreedPriceDzd: Double? = null,
    val customerNotes: String = "",
    val professionalNotes: String = "",
    val isRated: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val requestId: Long,
    val customerId: Long,
    val customerName: String,
    val professionalId: Long,
    val rating: Int, // 1 to 5
    val comment: String,
    val isFlagged: Boolean = false,
    val flagReason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val requestId: Long,
    val senderId: Long,
    val senderName: String,
    val recipientId: Long,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipientUserId: Long, // 0 for Admin / Global
    val title: String,
    val body: String,
    val type: NotificationType = NotificationType.SYSTEM,
    val targetId: Long = 0, // RequestId or ProId
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reporterId: Long,
    val reporterName: String,
    val targetType: String, // "PROFESSIONAL", "USER", "REQUEST", "REVIEW"
    val targetId: Long,
    val targetName: String,
    val reason: String,
    val details: String,
    val status: ReportStatus = ReportStatus.NEW,
    val adminActionTaken: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "admin_settings")
data class AdminSettingsEntity(
    @PrimaryKey val id: Long = 1,
    val appName: String = "خدملي DZ",
    val appSlogan: String = "لقى لي يخدمها",
    val commissionRatePercent: Double = 5.0,
    val proSubscriptionPriceDzd: Double = 1500.0,
    val supportPhone: String = "0550123456",
    val supportEmail: String = "contact@khdemli-dz.com",
    val isMaintenanceMode: Boolean = false,
    val isAutoApproveCraftsmen: Boolean = false,
    val ePaymentGatewayEnabled: Boolean = false
)
