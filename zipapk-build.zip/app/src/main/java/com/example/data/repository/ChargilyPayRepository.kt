package com.example.data.repository

import com.example.data.model.PaymentInfo
import com.example.data.model.PaymentMethod
import com.example.data.model.PaymentStatus
import com.example.data.model.SubscriptionPlan
import com.example.data.remote.ChargilyConfig
import com.example.data.remote.FirestoreConstants
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.UUID

data class CheckoutResult(
    val checkoutId: String,
    val checkoutUrl: String,
    val amountDzd: Long,
    val paymentMethod: PaymentMethod
)

class ChargilyPayRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    /**
     * Initiates a Chargily Pay checkout session for a service request.
     * Sets the payment state to PENDING in Firestore.
     * NOTE: Client never marks status as SUCCESSFUL. Only server/webhook updates status to SUCCESSFUL upon verification.
     */
    suspend fun createServiceRequestCheckout(
        requestId: String,
        amountDzd: Long,
        paymentMethod: PaymentMethod,
        customerName: String,
        customerEmail: String? = null
    ): AuthResult<CheckoutResult> {
        return try {
            // 1. Get Firebase User ID Token for secure authentication
            val currentUser = FirebaseAuth.getInstance().currentUser
                ?: return AuthResult.Error("يرجى تسجيل الدخول أولاً لإتمام عملية الدفع")
            
            val tokenResult = currentUser.getIdToken(true).await()
            val idToken = tokenResult.token
                ?: return AuthResult.Error("تعذر الحصول على رمز المصادقة الآمن")

            // 2. Try Supabase Edge Function Endpoint first
            val supabaseEdgeUrl = ChargilyConfig.SUPABASE_CHARGILY_EDGE_URL
            val jsonPayload = JSONObject().apply {
                put("action", "service_checkout")
                put("requestId", requestId)
                put("amountDzd", amountDzd)
                put("paymentMethod", paymentMethod.code)
                put("customerName", customerName)
            }
            
            val client = OkHttpClient()
            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            
            val edgeReqBuilder = Request.Builder()
                .url(supabaseEdgeUrl)
                .addHeader("Authorization", "Bearer $idToken")
                .addHeader("Content-Type", "application/json")
            if (com.example.data.remote.SupabaseConfig.SUPABASE_KEY.isNotBlank()) {
                edgeReqBuilder.addHeader("apikey", com.example.data.remote.SupabaseConfig.SUPABASE_KEY)
            }

            var response = withContext(Dispatchers.IO) {
                client.newCall(edgeReqBuilder.post(requestBody).build()).execute()
            }

            var responseStr = response.body?.string()

            // Fallback to Firebase Cloud Functions if Supabase Edge Function is not yet deployed (404)
            if (response.code == 404) {
                val projectId = firestore.app.options.projectId
                val cloudFunctionUrl = "https://us-central1-$projectId.cloudfunctions.net/chargilyCheckout"
                val fbReq = Request.Builder()
                    .url(cloudFunctionUrl)
                    .addHeader("Authorization", "Bearer $idToken")
                    .post(requestBody)
                    .build()
                response = withContext(Dispatchers.IO) {
                    client.newCall(fbReq).execute()
                }
                responseStr = response.body?.string()
            }

            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(responseStr ?: "").optString("error", "فشل تهيئة الدفع")
                } catch (e: Exception) {
                    "فشل الاتصال بخادم الدفع الآمن"
                }
                return AuthResult.Error(errorMsg)
            }

            val responseJson = JSONObject(responseStr ?: "")
            val checkoutId = responseJson.getString("checkoutId")
            val checkoutUrl = responseJson.getString("checkoutUrl")

            AuthResult.Success(
                CheckoutResult(
                    checkoutId = checkoutId,
                    checkoutUrl = checkoutUrl,
                    amountDzd = amountDzd,
                    paymentMethod = paymentMethod
                )
            )
        } catch (e: Exception) {
            AuthResult.Error(e.localizedMessage ?: "حدث خطأ أثناء تهيئة بوابة الدفع Chargily Pay")
        }
    }

    /**
     * Initiates a secure Khedmati subscription checkout session for the chosen plan.
     * Calls Supabase Edge Function server-side.
     */
    suspend fun createProSubscriptionCheckout(
        plan: SubscriptionPlan = SubscriptionPlan.PREMIUM,
        paymentMethod: PaymentMethod
    ): AuthResult<CheckoutResult> {
        return try {
            // 1. Get Firebase User ID Token for secure authentication
            val currentUser = FirebaseAuth.getInstance().currentUser
                ?: return AuthResult.Error("يرجى تسجيل الدخول أولاً لإتمام عملية الاشتراك")
            
            val tokenResult = currentUser.getIdToken(true).await()
            val idToken = tokenResult.token
                ?: return AuthResult.Error("تعذر الحصول على رمز المصادقة الآمن")

            // 2. Call Supabase Edge Function
            val supabaseEdgeUrl = ChargilyConfig.SUPABASE_CHARGILY_EDGE_URL
            val jsonPayload = JSONObject().apply {
                put("action", "pro_checkout")
                put("paymentMethod", paymentMethod.code)
                put("planId", plan.code)
            }
            
            val client = OkHttpClient()
            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val edgeReqBuilder = Request.Builder()
                .url(supabaseEdgeUrl)
                .addHeader("Authorization", "Bearer $idToken")
                .addHeader("Content-Type", "application/json")
            if (com.example.data.remote.SupabaseConfig.SUPABASE_KEY.isNotBlank()) {
                edgeReqBuilder.addHeader("apikey", com.example.data.remote.SupabaseConfig.SUPABASE_KEY)
            }

            var response = withContext(Dispatchers.IO) {
                client.newCall(edgeReqBuilder.post(requestBody).build()).execute()
            }

            var responseStr = response.body?.string()

            // Fallback to Firebase Cloud Functions if Supabase Edge Function returns 404
            if (response.code == 404) {
                val projectId = firestore.app.options.projectId
                val cloudFunctionUrl = "https://us-central1-$projectId.cloudfunctions.net/chargilyProCheckout"
                val fbReq = Request.Builder()
                    .url(cloudFunctionUrl)
                    .addHeader("Authorization", "Bearer $idToken")
                    .post(requestBody)
                    .build()
                response = withContext(Dispatchers.IO) {
                    client.newCall(fbReq).execute()
                }
                responseStr = response.body?.string()
            }

            if (!response.isSuccessful) {
                val errorMsg = try {
                    JSONObject(responseStr ?: "").optString("error", "فشل تهيئة الاشتراك")
                } catch (e: Exception) {
                    "فشل الاتصال بخادم الاشتراك الآمن"
                }
                return AuthResult.Error(errorMsg)
            }

            val responseJson = JSONObject(responseStr ?: "")
            val checkoutId = responseJson.getString("checkoutId")
            val checkoutUrl = responseJson.getString("checkoutUrl")

            AuthResult.Success(
                CheckoutResult(
                    checkoutId = checkoutId,
                    checkoutUrl = checkoutUrl,
                    amountDzd = plan.priceDzd,
                    paymentMethod = paymentMethod
                )
            )
        } catch (e: Exception) {
            AuthResult.Error(e.localizedMessage ?: "حدث خطأ أثناء تهيئة اشتراك خدمتي")
        }
    }

    /**
     * Observes real-time payment updates for a service request from Firestore.
     * Updated by the Chargily Webhook / Backend.
     */
    fun observeRequestPaymentStatus(requestId: String): Flow<PaymentInfo?> = callbackFlow {
        val listener = firestore.collection(FirestoreConstants.SERVICE_REQUESTS)
            .document(requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val rawMap = snapshot.get("paymentInfo") as? Map<String, Any?>
                    val paymentInfo = PaymentInfo.fromFirestoreMap(rawMap)
                    trySend(paymentInfo)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Cancels a pending checkout session safely.
     */
    suspend fun cancelPendingPayment(requestId: String): AuthResult<Unit> {
        if (requestId == "pro_subscription") {
            return AuthResult.Success(Unit)
        }
        return try {
            val docRef = firestore.collection(FirestoreConstants.SERVICE_REQUESTS).document(requestId)
            val snapshot = docRef.get().await()
            val rawMap = snapshot.get("paymentInfo") as? Map<String, Any?>
            val currentPayment = PaymentInfo.fromFirestoreMap(rawMap)

            if (currentPayment.status == PaymentStatus.PENDING) {
                val cancelledPayment = currentPayment.copy(
                    status = PaymentStatus.CANCELLED,
                    failureReason = "تم إلغاء عملية الدفع من قبل المستخدم"
                )
                docRef.update(
                    mapOf(
                        "paymentInfo" to cancelledPayment.toFirestoreMap(),
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            }
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            AuthResult.Error("تعذر إلغاء عملية الدفع: ${e.localizedMessage}")
        }
    }
}
