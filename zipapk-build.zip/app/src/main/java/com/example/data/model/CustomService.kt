package com.example.data.model

data class CustomService(
    val id: String = "",
    val providerId: String = "",
    val name: String = "",
    val description: String = "",
    val priceDzd: Long? = null,
    val priceType: String? = null, // e.g., "بالساعة", "بالخدمة", "ابتداءً من"
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "providerId" to providerId,
            "name" to name,
            "description" to description,
            "priceDzd" to priceDzd,
            "priceType" to priceType,
            "isActive" to isActive,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): CustomService {
            return CustomService(
                id = map["id"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                name = map["name"] as? String ?: "",
                description = map["description"] as? String ?: "",
                priceDzd = (map["priceDzd"] as? Number)?.toLong(),
                priceType = map["priceType"] as? String,
                isActive = map["isActive"] as? Boolean ?: true,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
