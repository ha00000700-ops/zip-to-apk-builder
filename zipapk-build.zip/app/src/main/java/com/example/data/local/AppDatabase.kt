package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlantEntity::class,
        DiagnosisEntity::class,
        CareTaskEntity::class,
        ChatMessageEntity::class,
        PlantGrowthEntryEntity::class,
        IssueReportEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun plantDao(): PlantDao
    abstract fun diagnosisDao(): DiagnosisDao
    abstract fun careTaskDao(): CareTaskDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun plantGrowthDao(): PlantGrowthDao
    abstract fun issueReportDao(): IssueReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "plant_doctor_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
