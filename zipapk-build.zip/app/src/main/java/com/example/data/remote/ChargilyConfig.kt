package com.example.data.remote

object ChargilyConfig {
    /**
     * Chargily Pay Test Mode Base URL (for API v2)
     */
    const val CHARGILY_TEST_API_BASE = "https://pay.chargily.net/test/api/v2"

    /**
     * Chargily Pay Production Base URL (for API v2)
     */
    const val CHARGILY_PROD_API_BASE = "https://pay.chargily.net/api/v2"

    /**
     * Default Checkout Mode: TEST
     */
    const val IS_TEST_MODE = true

    /**
     * Primary Supabase Edge Function URL for Chargily Pay
     * Uses Supabase Edge Function Secrets (CHARGILY_SECRET_KEY) server-side.
     */
    val SUPABASE_CHARGILY_EDGE_URL: String
        get() = "${SupabaseConfig.SUPABASE_URL}/functions/v1/chargily-pay"

    /**
     * Proxy Backend / Cloud Function Server Base URL
     */
    var BACKEND_PROXY_URL = "https://us-central1-khedmati-dz.cloudfunctions.net/chargilyCheckout"

    /**
     * Fallback Test Checkout Gateway URL for Chargily Pay Sandbox testing
     */
    const val TEST_CHECKOUT_GATEWAY_URL = "https://pay.chargily.net/test/checkout"
}
