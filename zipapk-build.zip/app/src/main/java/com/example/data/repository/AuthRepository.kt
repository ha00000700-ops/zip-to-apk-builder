package com.example.data.repository

import android.util.Log
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.OfferStatus
import com.example.data.model.PublicRequestOffer
import com.example.data.model.PublicRequestStatus
import com.example.data.model.PublicServiceRequest
import com.example.data.model.RequestStatus
import com.example.data.model.Review
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.ServiceRequest
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.remote.FirestoreConstants
import com.example.data.remote.FirebaseStatusHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Error(val messageAr: String, val rawError: Throwable? = null) : AuthResult<Nothing>()
    object Loading : AuthResult<Nothing>()
    data class ProfileMissing(
        val uid: String,
        val email: String,
        val role: UserRole? = null
    ) : AuthResult<Nothing>()
}

class AuthRepository() {
    private val tag = "AuthRepository"

    private val auth: FirebaseAuth?
        get() = FirebaseStatusHelper.getFirebaseAuth()

    private val firestore: FirebaseFirestore?
        get() = FirebaseStatusHelper.getFirestore()

    val isFirebaseReady: Boolean
        get() = auth != null && firestore != null

    val currentUserId: String?
        get() = auth?.currentUser?.uid

    fun observeAuthState(onStateChanged: (String?) -> Unit) {
        val firebaseAuth = auth
        if (firebaseAuth == null) {
            onStateChanged(null)
            return
        }
        val listener = FirebaseAuth.AuthStateListener { auth ->
            onStateChanged(auth.currentUser?.uid)
        }
        firebaseAuth.addAuthStateListener(listener)
    }

    val currentAuthUserEmail: String?
        get() = auth?.currentUser?.email

    val isUserLoggedIn: Boolean
        get() = auth?.currentUser != null

    suspend fun login(email: String, password: String): AuthResult<UserProfile> {
        val firebaseAuth = auth
            ?: return AuthResult.Error(
                "خدمة Firebase Auth غير مهيأة. يرجى التأكد من ربط المشروع وإضافة google-services.json"
            )

        val firestoreDb = firestore
            ?: return AuthResult.Error(
                "خدمة Cloud Firestore غير مهيأة. يرجى مراجعة إعدادات Firebase"
            )

        return try {
            val authResult = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = authResult.user
                ?: return AuthResult.Error("تعذر تسجيل الدخول، لم يتم استلام بيانات المستخدم")

            val uid = user.uid

            // Step 1: Fetch user profile from 'users' collection
            val userDoc = firestoreDb.collection(FirestoreConstants.USERS)
                .document(uid)
                .get()
                .await()

            if (userDoc.exists() && userDoc.data != null) {
                val profile = UserProfile.fromFirestoreMap(userDoc.data!!)
                updateFcmToken(uid)
                AuthResult.Success(profile)
            } else {
                // Step 2: Check if provider profile exists in 'serviceProviders' collection
                val providerDoc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                    .document(uid)
                    .get()
                    .await()

                if (providerDoc.exists() && providerDoc.data != null) {
                    val pProfile = ServiceProviderProfile.fromFirestoreMap(providerDoc.data!!)
                    val uProfile = UserProfile(
                        uid = uid,
                        fullName = pProfile.fullName,
                        email = pProfile.email,
                        phone = pProfile.phone,
                        role = UserRole.SERVICE_PROVIDER,
                        wilayaCode = pProfile.wilayaCode,
                        wilayaName = pProfile.wilayaName,
                        communeName = pProfile.communeName,
                        createdAt = pProfile.createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    // Auto-repair missing 'users' profile in Firestore
                    firestoreDb.collection(FirestoreConstants.USERS)
                        .document(uid)
                        .set(uProfile.toFirestoreMap())
                        .await()

                    updateFcmToken(uid)
                    AuthResult.Success(uProfile)
                } else {
                    // Step 3: Profile missing in Firestore for this valid Auth user
                    AuthResult.ProfileMissing(
                        uid = uid,
                        email = user.email ?: email.trim()
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Login error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun registerCustomer(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ): AuthResult<UserProfile> {
        val firebaseAuth = auth
            ?: return AuthResult.Error("خدمة Firebase Auth غير مهيأة")
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير مهيأة")

        return try {
            val uid = if (firebaseAuth.currentUser != null) {
                firebaseAuth.currentUser!!.uid
            } else {
                try {
                    val authResult = firebaseAuth.createUserWithEmailAndPassword(email.trim(), password).await()
                    authResult.user?.uid ?: return AuthResult.Error("تم إنشاء الحساب ولكن تعذر الحصول على معرف المستخدم")
                } catch (e: Exception) {
                    val signInRes = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
                    signInRes.user?.uid ?: throw e
                }
            }

            val profile = UserProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.CUSTOMER,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            firestoreDb.collection(FirestoreConstants.USERS)
                .document(uid)
                .set(profile.toFirestoreMap())
                .await()

            updateFcmToken(uid)
            AuthResult.Success(profile)
        } catch (e: Exception) {
            Log.e(tag, "Customer registration error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun registerServiceProvider(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        serviceDescription: String,
        experienceYears: Int
    ): AuthResult<Pair<UserProfile, ServiceProviderProfile>> {
        val firebaseAuth = auth
            ?: return AuthResult.Error("خدمة Firebase Auth غير مهيأة")
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير مهيأة")

        return try {
            val uid = if (firebaseAuth.currentUser != null) {
                firebaseAuth.currentUser!!.uid
            } else {
                try {
                    val authResult = firebaseAuth.createUserWithEmailAndPassword(email.trim(), password).await()
                    authResult.user?.uid ?: return AuthResult.Error("تم إنشاء الحساب ولكن تعذر الحصول على معرف المستخدم")
                } catch (e: Exception) {
                    val signInRes = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
                    signInRes.user?.uid ?: throw e
                }
            }

            val userProfile = UserProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.SERVICE_PROVIDER,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val providerProfile = ServiceProviderProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                serviceDescription = serviceDescription.trim(),
                experienceYears = experienceYears,
                isAvailable = true,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val batch = firestoreDb.batch()
            val userRef = firestoreDb.collection(FirestoreConstants.USERS).document(uid)
            val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid)

            batch.set(userRef, userProfile.toFirestoreMap())
            batch.set(providerRef, providerProfile.toFirestoreMap())
            batch.commit().await()

            updateFcmToken(uid)
            AuthResult.Success(Pair(userProfile, providerProfile))
        } catch (e: Exception) {
            Log.e(tag, "Service provider registration error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getUserProfile(uid: String): AuthResult<UserProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val doc = firestoreDb.collection(FirestoreConstants.USERS).document(uid).get().await()
            if (doc.exists() && doc.data != null) {
                AuthResult.Success(UserProfile.fromFirestoreMap(doc.data!!))
            } else {
                val providerDoc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid).get().await()
                if (providerDoc.exists() && providerDoc.data != null) {
                    val pProfile = ServiceProviderProfile.fromFirestoreMap(providerDoc.data!!)
                    val uProfile = UserProfile(
                        uid = uid,
                        fullName = pProfile.fullName,
                        email = pProfile.email,
                        phone = pProfile.phone,
                        role = UserRole.SERVICE_PROVIDER,
                        wilayaCode = pProfile.wilayaCode,
                        wilayaName = pProfile.wilayaName,
                        communeName = pProfile.communeName,
                        createdAt = pProfile.createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    firestoreDb.collection(FirestoreConstants.USERS)
                        .document(uid)
                        .set(uProfile.toFirestoreMap())
                        .await()

                    AuthResult.Success(uProfile)
                } else {
                    val currentEmail = auth?.currentUser?.email ?: ""
                    AuthResult.ProfileMissing(uid = uid, email = currentEmail)
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error fetching user profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getServiceProviderProfile(uid: String): AuthResult<ServiceProviderProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val doc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid).get().await()
            if (doc.exists() && doc.data != null) {
                var profile = ServiceProviderProfile.fromFirestoreMap(doc.data!!)
                // Ensure completed services count reflects public completed requests accurately
                try {
                    val publicCompletedSnap = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
                        .whereEqualTo("assignedProviderId", uid)
                        .whereEqualTo("status", PublicRequestStatus.COMPLETED.name)
                        .get()
                        .await()
                    val publicCompletedCount = publicCompletedSnap.size()
                    if (publicCompletedCount > 0 && profile.completedServices < publicCompletedCount) {
                        val reconciledCount = maxOf(profile.completedServices, publicCompletedCount)
                        profile = profile.copy(completedServices = reconciledCount)
                        if (auth?.currentUser?.uid == uid) {
                            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                                .document(uid)
                                .update("completedServices", reconciledCount)
                        }
                    }
                } catch (e: Exception) {
                    Log.d(tag, "Reconciling public completed count: ${e.message}")
                }
                AuthResult.Success(profile)
            } else {
                val currentEmail = auth?.currentUser?.email ?: ""
                AuthResult.ProfileMissing(uid = uid, email = currentEmail, role = UserRole.SERVICE_PROVIDER)
            }
        } catch (e: Exception) {
            Log.e(tag, "Error fetching provider profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun fetchServiceProviders(
        professionId: String? = null,
        wilayaCode: Int? = null
    ): AuthResult<List<ServiceProviderProfile>> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            var query: com.google.firebase.firestore.Query = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
            
            if (!professionId.isNullOrBlank()) {
                query = query.whereEqualTo("professionId", professionId)
            }
            
            val querySnapshot = query.limit(50).get().await()

            val list = querySnapshot.documents.mapNotNull { doc ->
                doc.data?.let { ServiceProviderProfile.fromFirestoreMap(it) }
            }.filter { provider ->
                var matches = true
                if (wilayaCode != null && wilayaCode > 0) {
                    matches = matches && (provider.wilayaCode == wilayaCode)
                }
                matches
            }

            AuthResult.Success(list)
        } catch (e: Exception) {
            Log.e(tag, "Error fetching service providers", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateProviderAvailability(uid: String, isAvailable: Boolean): AuthResult<Boolean> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(uid)
                .update(
                    mapOf(
                        "isAvailable" to isAvailable,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .await()
            AuthResult.Success(isAvailable)
        } catch (e: Exception) {
            Log.e(tag, "Error updating availability", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateServiceProviderProfile(profile: ServiceProviderProfile): AuthResult<ServiceProviderProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val updated = profile.copy(updatedAt = System.currentTimeMillis())
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(profile.uid)
                .set(updated.toFirestoreMap(), SetOptions.merge())
                .await()

            // Also update basic info in 'users'
            firestoreDb.collection(FirestoreConstants.USERS)
                .document(profile.uid)
                .update(
                    mapOf(
                        "fullName" to profile.fullName,
                        "phone" to profile.phone,
                        "wilayaCode" to profile.wilayaCode,
                        "wilayaName" to profile.wilayaName,
                        "communeName" to profile.communeName,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .await()

            AuthResult.Success(updated)
        } catch (e: Exception) {
            Log.e(tag, "Error updating provider profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun createServiceRequest(request: com.example.data.model.ServiceRequest): AuthResult<com.example.data.model.ServiceRequest> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS).document()
            val finalRequest = request.copy(
                id = if (request.id.isBlank()) docRef.id else request.id,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS)
                .document(finalRequest.id)
                .set(finalRequest.toFirestoreMap())
                .await()

            AuthResult.Success(finalRequest)
        } catch (e: Exception) {
            Log.e(tag, "Error creating service request", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun addCustomService(service: com.example.data.model.CustomService): AuthResult<com.example.data.model.CustomService> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(service.providerId)
                .collection(FirestoreConstants.CUSTOM_SERVICES)
                .document()
            val finalService = service.copy(
                id = docRef.id,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            docRef.set(finalService.toFirestoreMap()).await()
            AuthResult.Success(finalService)
        } catch (e: Exception) {
            Log.e(tag, "Error adding custom service", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getCustomServices(providerId: String): AuthResult<List<com.example.data.model.CustomService>> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val snapshot = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(providerId)
                .collection(FirestoreConstants.CUSTOM_SERVICES)
                .get()
                .await()
            val list = snapshot.documents.mapNotNull { doc ->
                doc.data?.let { com.example.data.model.CustomService.fromFirestoreMap(it) }
            }
            AuthResult.Success(list)
        } catch (e: Exception) {
            Log.e(tag, "Error getting custom services", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateCustomService(service: com.example.data.model.CustomService): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(service.providerId)
                .collection(FirestoreConstants.CUSTOM_SERVICES)
                .document(service.id)
                .set(service.copy(updatedAt = System.currentTimeMillis()).toFirestoreMap(), SetOptions.merge())
                .await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error updating custom service", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun deleteCustomService(providerId: String, serviceId: String): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(providerId)
                .collection(FirestoreConstants.CUSTOM_SERVICES)
                .document(serviceId)
                .delete()
                .await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error deleting custom service", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun getServiceRequestsFlowForCustomer(customerId: String): Flow<AuthResult<List<ServiceRequest>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS)
            .whereEqualTo("customerId", customerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error fetching customer requests", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val requests = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { ServiceRequest.fromFirestoreMap(it) }
                    }.sortedByDescending { it.createdAt }
                    trySend(AuthResult.Success(requests))
                }
            }

        awaitClose { listener.remove() }
    }

    fun getServiceRequestsFlowForProvider(providerId: String): Flow<AuthResult<List<ServiceRequest>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS)
            .whereEqualTo("providerId", providerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error fetching provider requests", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val requests = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { ServiceRequest.fromFirestoreMap(it) }
                    }.sortedByDescending { it.createdAt }
                    trySend(AuthResult.Success(requests))
                }
            }

        awaitClose { listener.remove() }
    }

    fun getServiceRequestByIdFlow(requestId: String): Flow<AuthResult<ServiceRequest?>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS)
            .document(requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error fetching service request details", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    val request = snapshot.data?.let { ServiceRequest.fromFirestoreMap(it) }
                    trySend(AuthResult.Success(request))
                } else {
                    trySend(AuthResult.Success(null))
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun updateServiceRequestStatus(
        requestId: String,
        newStatus: RequestStatus,
        userUid: String,
        userRole: UserRole
    ): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.SERVICE_REQUESTS).document(requestId)
            val snapshot = docRef.get().await()
            if (!snapshot.exists()) {
                return AuthResult.Error("طلب الخدمة غير موجود")
            }

            val currentRequest = ServiceRequest.fromFirestoreMap(snapshot.data ?: emptyMap())

            // Security / Authorization check
            if (userRole == UserRole.CUSTOMER && currentRequest.customerId != userUid) {
                return AuthResult.Error("غير مصرح لك بتحديث هذا الطلب")
            }
            if (userRole == UserRole.SERVICE_PROVIDER && currentRequest.providerId != userUid) {
                return AuthResult.Error("غير مصرح لك بتحديث هذا الطلب")
            }

            // Logical state transition checks
            val currentStatus = currentRequest.status
            val isValidTransition = when (newStatus) {
                RequestStatus.ACCEPTED -> userRole == UserRole.SERVICE_PROVIDER && currentStatus == RequestStatus.PENDING
                RequestStatus.REJECTED -> userRole == UserRole.SERVICE_PROVIDER && currentStatus == RequestStatus.PENDING
                RequestStatus.IN_PROGRESS -> userRole == UserRole.SERVICE_PROVIDER && (currentStatus == RequestStatus.ACCEPTED || currentStatus == RequestStatus.PENDING)
                RequestStatus.COMPLETED -> userRole == UserRole.SERVICE_PROVIDER && (currentStatus == RequestStatus.IN_PROGRESS || currentStatus == RequestStatus.ACCEPTED)
                RequestStatus.CANCELLED -> userRole == UserRole.CUSTOMER && (currentStatus == RequestStatus.PENDING || currentStatus == RequestStatus.ACCEPTED)
                RequestStatus.PENDING -> false
            }

            if (!isValidTransition) {
                return AuthResult.Error("تغيير حالة الطلب غير متاح من ${currentStatus.titleAr} إلى ${newStatus.titleAr}")
            }

            val updates = mapOf(
                "status" to newStatus.name,
                "updatedAt" to System.currentTimeMillis()
            )
            docRef.update(updates).await()

            // If completed, increment completedServices counter on provider profile
            if (newStatus == RequestStatus.COMPLETED && currentRequest.providerId.isNotBlank()) {
                try {
                    val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(currentRequest.providerId)
                    val providerDoc = providerRef.get().await()
                    if (providerDoc.exists()) {
                        val currentCompleted = (providerDoc.get("completedServices") as? Number)?.toInt() ?: 0
                        providerRef.update("completedServices", currentCompleted + 1).await()
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Failed to increment provider completedServices", e)
                }
            }

            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error updating request status", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun submitReview(review: Review): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val reviewRef = firestoreDb.collection(FirestoreConstants.REVIEWS).document()
            val finalReview = review.copy(
                id = if (review.id.isBlank()) reviewRef.id else review.id,
                createdAt = System.currentTimeMillis()
            )
            reviewRef.set(finalReview.toFirestoreMap()).await()

            // Update provider's average rating in serviceProviders collection
            if (finalReview.providerId.isNotBlank()) {
                try {
                    val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(finalReview.providerId)
                    val providerDoc = providerRef.get().await()
                    if (providerDoc.exists()) {
                        val currentRating = (providerDoc.get("rating") as? Number)?.toDouble() ?: 0.0
                        val currentCount = (providerDoc.get("ratingCount") as? Number)?.toInt() ?: 0
                        val newCount = currentCount + 1
                        val newAverage = ((currentRating * currentCount) + finalReview.rating) / newCount
                        providerRef.update(
                            mapOf(
                                "rating" to newAverage,
                                "ratingCount" to newCount
                            )
                        ).await()
                    }
                } catch (e: Exception) {
                    Log.e(tag, "Failed to update provider rating", e)
                }
            }

            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error submitting review", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    // Chat Repository Methods
    suspend fun getOrCreateConversation(
        customerId: String,
        customerName: String,
        customerPhotoUrl: String,
        providerId: String,
        providerName: String,
        providerPhotoUrl: String,
        providerProfession: String,
        serviceRequestId: String? = null,
        serviceRequestTitle: String? = null,
        isPublicRequest: Boolean = false
    ): AuthResult<Conversation> {
        val firebaseAuth = auth
        val currentAuthUid = firebaseAuth?.currentUser?.uid ?: ""
        if (currentAuthUid.isBlank()) {
            return AuthResult.Error("يجب تسجيل الدخول أولاً")
        }

        val convId = try {
            Conversation.generateId(customerId, providerId, serviceRequestId)
        } catch (e: Exception) {
            return AuthResult.Error("تعذر إنشاء معرّف المحادثة")
        }

        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(convId)
            val newConv = Conversation(
                id = convId,
                customerId = customerId,
                customerName = customerName,
                customerPhotoUrl = customerPhotoUrl,
                providerId = providerId,
                providerName = providerName,
                providerPhotoUrl = providerPhotoUrl,
                providerProfession = providerProfession,
                serviceRequestId = serviceRequestId,
                serviceRequestTitle = serviceRequestTitle,
                isPublicRequest = isPublicRequest,
                lastMessage = "محادثة جديدة",
                lastMessageAt = System.currentTimeMillis(),
                lastMessageSenderId = "",
                customerUnreadCount = 0,
                providerUnreadCount = 0,
                createdAt = System.currentTimeMillis()
            )
            docRef.set(newConv.toFirestoreMap(), com.google.firebase.firestore.SetOptions.merge()).await()
            AuthResult.Success(newConv)
        } catch (e: Exception) {
            val firestoreExc = e as? com.google.firebase.firestore.FirebaseFirestoreException
            val errorCodeStr = firestoreExc?.code?.name ?: "UNKNOWN_CODE"
            AuthResult.Error("تعذر فتح المحادثة ($errorCodeStr)", e)
        }
    }

    suspend fun getConversationById(conversationId: String): AuthResult<Conversation> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val snapshot = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(conversationId).get().await()
            if (snapshot.exists() && snapshot.data != null) {
                val conversation = Conversation.fromFirestoreMap(conversationId, snapshot.data!!)
                AuthResult.Success(conversation)
            } else {
                AuthResult.Error("المحادثة غير موجودة")
            }
        } catch (e: Exception) {
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun observeConversationsForUser(userId: String): Flow<AuthResult<List<Conversation>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || userId.isBlank()) {
            trySend(AuthResult.Error("المستخدم غير مسجل الدخول"))
            close()
            return@callbackFlow
        }

        var customerConvs = emptyList<Conversation>()
        var providerConvs = emptyList<Conversation>()

        fun updateCombined() {
            val map = (customerConvs + providerConvs).associateBy { it.id }
            val sortedList = map.values.sortedByDescending { it.lastMessageAt }
            trySend(AuthResult.Success(sortedList))
        }

        val l1 = firestoreDb.collection(FirestoreConstants.CONVERSATIONS)
            .whereEqualTo("customerId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to customer conversations", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    customerConvs = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { Conversation.fromFirestoreMap(doc.id, it) }
                    }
                    updateCombined()
                }
            }

        val l2 = firestoreDb.collection(FirestoreConstants.CONVERSATIONS)
            .whereEqualTo("providerId", userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to provider conversations", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    providerConvs = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { Conversation.fromFirestoreMap(doc.id, it) }
                    }
                    updateCombined()
                }
            }

        awaitClose {
            l1.remove()
            l2.remove()
        }
    }

    fun observeChatMessages(conversationId: String): Flow<AuthResult<List<ChatMessage>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || conversationId.isBlank()) {
            trySend(AuthResult.Error("معرّف المحادثة غير صالح"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.CONVERSATIONS)
            .document(conversationId)
            .collection(FirestoreConstants.MESSAGES)
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to chat messages", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { ChatMessage.fromFirestoreMap(doc.id, it) }
                    }
                    trySend(AuthResult.Success(messages))
                }
            }

        awaitClose {
            listener.remove()
        }
    }

    suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        receiverId: String,
        text: String
    ): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val cleanText = text.trim()
        if (cleanText.isBlank()) {
            return AuthResult.Error("لا يمكن إرسال رسالة فارغة")
        }

        return try {
            val convRef = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(conversationId)
            val convSnap = convRef.get().await()
            if (!convSnap.exists()) {
                return AuthResult.Error("المحادثة غير موجودة")
            }
            val conv = Conversation.fromFirestoreMap(conversationId, convSnap.data ?: emptyMap())

            val msgRef = convRef.collection(FirestoreConstants.MESSAGES).document()
            val now = System.currentTimeMillis()
            val msg = ChatMessage(
                id = msgRef.id,
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                text = cleanText,
                createdAt = now,
                read = false
            )

            val batch = firestoreDb.batch()
            batch.set(msgRef, msg.toFirestoreMap())

            val isSenderCustomer = (senderId == conv.customerId)
            val updates = mutableMapOf<String, Any?>(
                "lastMessage" to cleanText,
                "lastMessageAt" to now,
                "lastMessageSenderId" to senderId
            )
            if (isSenderCustomer) {
                updates["providerUnreadCount"] = FieldValue.increment(1)
            } else {
                updates["customerUnreadCount"] = FieldValue.increment(1)
            }
            batch.update(convRef, updates)

            batch.commit().await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error sending message", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun sendVoiceMessage(
        conversationId: String,
        senderId: String,
        receiverId: String,
        audioUrl: String,
        duration: Long
    ): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        if (audioUrl.isBlank()) {
            return AuthResult.Error("ملف الصوت غير صالح")
        }

        return try {
            val convRef = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(conversationId)
            val convSnap = convRef.get().await()
            if (!convSnap.exists()) {
                return AuthResult.Error("المحادثة غير موجودة")
            }
            val conv = Conversation.fromFirestoreMap(conversationId, convSnap.data ?: emptyMap())

            val msgRef = convRef.collection(FirestoreConstants.MESSAGES).document()
            val now = System.currentTimeMillis()
            val msg = ChatMessage(
                id = msgRef.id,
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                text = "🎤 رسالة صوتية (${duration}ث)",
                type = "voice",
                audioUrl = audioUrl,
                duration = duration,
                createdAt = now,
                read = false
            )

            val batch = firestoreDb.batch()
            batch.set(msgRef, msg.toFirestoreMap())

            val isSenderCustomer = (senderId == conv.customerId)
            val updates = mutableMapOf<String, Any?>(
                "lastMessage" to "🎤 رسالة صوتية",
                "lastMessageAt" to now,
                "lastMessageSenderId" to senderId
            )
            if (isSenderCustomer) {
                updates["providerUnreadCount"] = FieldValue.increment(1)
            } else {
                updates["customerUnreadCount"] = FieldValue.increment(1)
            }
            batch.update(convRef, updates)

            batch.commit().await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error sending voice message", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun sendMediaMessage(
        conversationId: String,
        senderId: String,
        receiverId: String,
        mediaUrl: String,
        type: String, // "image" or "video"
        duration: Long = 0L,
        caption: String = ""
    ): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        if (mediaUrl.isBlank()) {
            return AuthResult.Error("ملف الوسائط غير صالح")
        }

        return try {
            val convRef = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(conversationId)
            val convSnap = convRef.get().await()
            if (!convSnap.exists()) {
                return AuthResult.Error("المحادثة غير موجودة")
            }
            val conv = Conversation.fromFirestoreMap(conversationId, convSnap.data ?: emptyMap())

            val msgRef = convRef.collection(FirestoreConstants.MESSAGES).document()
            val now = System.currentTimeMillis()
            val displayText = if (type == "image") {
                if (caption.isNotBlank()) "📷 صورة: $caption" else "📷 صورة"
            } else {
                if (caption.isNotBlank()) "🎥 فيديو: $caption" else "🎥 فيديو"
            }

            val msg = ChatMessage(
                id = msgRef.id,
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                text = displayText,
                type = type,
                mediaUrl = mediaUrl,
                duration = duration,
                createdAt = now,
                read = false
            )

            val batch = firestoreDb.batch()
            batch.set(msgRef, msg.toFirestoreMap())

            val isSenderCustomer = (senderId == conv.customerId)
            val updates = mutableMapOf<String, Any?>(
                "lastMessage" to displayText,
                "lastMessageAt" to now,
                "lastMessageSenderId" to senderId
            )
            if (isSenderCustomer) {
                updates["providerUnreadCount"] = FieldValue.increment(1)
            } else {
                updates["customerUnreadCount"] = FieldValue.increment(1)
            }
            batch.update(convRef, updates)

            batch.commit().await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error sending media message", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun markMessagesAsRead(conversationId: String, currentUserId: String): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val convRef = firestoreDb.collection(FirestoreConstants.CONVERSATIONS).document(conversationId)
            val convSnap = convRef.get().await()
            if (convSnap.exists() && convSnap.data != null) {
                val conv = Conversation.fromFirestoreMap(conversationId, convSnap.data!!)
                val isCustomer = (currentUserId == conv.customerId)
                val isProvider = (currentUserId == conv.providerId)

                if (isCustomer || isProvider) {
                    val batch = firestoreDb.batch()
                    if (isCustomer) {
                        batch.update(convRef, "customerUnreadCount", 0)
                    } else {
                        batch.update(convRef, "providerUnreadCount", 0)
                    }

                    val unreadMessagesSnap = convRef.collection(FirestoreConstants.MESSAGES)
                        .whereEqualTo("receiverId", currentUserId)
                        .whereEqualTo("read", false)
                        .get()
                        .await()

                    for (doc in unreadMessagesSnap.documents) {
                        batch.update(doc.reference, "read", true)
                    }
                    batch.commit().await()
                }
            }
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error marking messages read", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateFcmToken(uid: String) {
        val firestoreDb = firestore ?: return
        try {
            val token = FirebaseMessaging.getInstance().token.await()
            if (token.isNotBlank()) {
                val updates = mapOf(
                    "fcmToken" to token,
                    "updatedAt" to System.currentTimeMillis()
                )
                firestoreDb.collection(FirestoreConstants.USERS).document(uid).update(updates).await()
                
                // Also update provider profile if it exists
                val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid)
                val providerDoc = providerRef.get().await()
                if (providerDoc.exists()) {
                    providerRef.update(updates).await()
                }
                Log.d(tag, "FCM token updated successfully for user $uid")
            }
        } catch (e: Exception) {
            Log.e(tag, "Error updating FCM token", e)
        }
    }

    // Public Service Requests
    suspend fun createPublicServiceRequest(request: PublicServiceRequest): AuthResult<PublicServiceRequest> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val authUid = FirebaseAuth.getInstance().currentUser?.uid
        if (authUid.isNullOrBlank()) {
            return AuthResult.Error("يجب تسجيل الدخول لنشر طلب خدمة")
        }
        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document()
            val now = System.currentTimeMillis()
            val finalRequest = request.copy(
                id = docRef.id,
                customerId = authUid,
                providerId = authUid,
                creatorId = authUid,
                status = PublicRequestStatus.OPEN,
                offersCount = 0,
                createdAt = now,
                updatedAt = now
            )
            Log.d(tag, "DIAGNOSTIC - Authenticated Firebase UID: $authUid")
            Log.d(tag, "DIAGNOSTIC - customerId: ${finalRequest.customerId}")
            Log.d(tag, "DIAGNOSTIC - providerId: ${finalRequest.providerId}")
            Log.d(tag, "DIAGNOSTIC - creatorId: ${finalRequest.creatorId}")
            Log.d(tag, "DIAGNOSTIC - Firestore Path: ${FirestoreConstants.PUBLIC_SERVICE_REQUESTS}/${docRef.id}")
            docRef.set(finalRequest.toFirestoreMap()).await()
            Log.d(tag, "Successfully created public service request docId=${docRef.id}")
            AuthResult.Success(finalRequest)
        } catch (e: Exception) {
            Log.e(tag, "Error creating public service request at path ${FirestoreConstants.PUBLIC_SERVICE_REQUESTS}. Exception: ${e.javaClass.simpleName} - ${e.message}", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun getOpenPublicServiceRequestsFlow(): Flow<AuthResult<List<PublicServiceRequest>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
            .whereEqualTo("status", PublicRequestStatus.OPEN.name)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to open public requests", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val requests = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { PublicServiceRequest.fromFirestoreMap(doc.id, it) }
                    }.sortedByDescending { it.createdAt }
                    trySend(AuthResult.Success(requests))
                }
            }

        awaitClose { listener.remove() }
    }

    fun getCustomerPublicRequestsFlow(customerId: String): Flow<AuthResult<List<PublicServiceRequest>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || customerId.isBlank()) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
            .whereEqualTo("customerId", customerId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to customer public requests", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val requests = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { PublicServiceRequest.fromFirestoreMap(doc.id, it) }
                    }.sortedByDescending { it.createdAt }
                    trySend(AuthResult.Success(requests))
                }
            }

        awaitClose { listener.remove() }
    }

    fun getPublicServiceRequestByIdFlow(requestId: String): Flow<AuthResult<PublicServiceRequest?>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || requestId.isBlank()) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
            .document(requestId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error fetching public request details", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists() && snapshot.data != null) {
                    val request = PublicServiceRequest.fromFirestoreMap(snapshot.id, snapshot.data!!)
                    trySend(AuthResult.Success(request))
                } else {
                    trySend(AuthResult.Success(null))
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun cancelPublicServiceRequest(requestId: String, customerId: String): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val docRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document(requestId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                return AuthResult.Error("الطلب غير موجود")
            }
            val req = PublicServiceRequest.fromFirestoreMap(requestId, snap.data ?: emptyMap())
            if (req.customerId != customerId) {
                return AuthResult.Error("غير مصرح لك بإلغاء هذا الطلب")
            }
            if (req.status != PublicRequestStatus.OPEN) {
                return AuthResult.Error("لا يمكن إلغاء الطلب في حالته الحالية (${req.status.titleAr})")
            }
            docRef.update(
                mapOf(
                    "status" to PublicRequestStatus.CANCELLED.name,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error cancelling public request", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun submitPublicRequestOffer(offer: PublicRequestOffer): AuthResult<PublicRequestOffer> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        if (offer.priceDzd <= 0) {
            return AuthResult.Error("يرجى إدخال سعر مقترح صالح")
        }
        if (offer.providerId.isBlank() || offer.requestId.isBlank()) {
            return AuthResult.Error("بيانات العرض غير مكتملة")
        }

        return try {
            val reqRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document(offer.requestId)
            val reqSnap = reqRef.get().await()
            if (!reqSnap.exists()) {
                return AuthResult.Error("طلب الخدمة غير موجود")
            }
            val request = PublicServiceRequest.fromFirestoreMap(offer.requestId, reqSnap.data ?: emptyMap())
            if (request.status != PublicRequestStatus.OPEN) {
                return AuthResult.Error("هذا الطلب مغلق ولم يعد يستقبل عروضاً جديدة")
            }

            val offerRef = reqRef.collection(FirestoreConstants.OFFERS).document(offer.providerId)
            val existingOfferSnap = offerRef.get().await()
            val isNew = !existingOfferSnap.exists()

            val now = System.currentTimeMillis()
            val finalOffer = offer.copy(
                id = offer.providerId,
                status = OfferStatus.PENDING,
                createdAt = if (isNew) now else (existingOfferSnap.getLong("createdAt") ?: now),
                updatedAt = now
            )

            offerRef.set(finalOffer.toFirestoreMap(), SetOptions.merge()).await()

            AuthResult.Success(finalOffer)
        } catch (e: Exception) {
            Log.e(tag, "Error submitting offer", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun getPublicRequestOffersFlow(requestId: String): Flow<AuthResult<List<PublicRequestOffer>>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || requestId.isBlank()) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        val listener = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
            .document(requestId)
            .collection(FirestoreConstants.OFFERS)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(tag, "Error listening to request offers", error)
                    trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val offers = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { PublicRequestOffer.fromFirestoreMap(doc.id, it) }
                    }.sortedByDescending { it.createdAt }
                    trySend(AuthResult.Success(offers))
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun getProviderOfferForRequest(requestId: String, providerId: String): AuthResult<PublicRequestOffer?> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        return try {
            val docSnap = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
                .document(requestId)
                .collection(FirestoreConstants.OFFERS)
                .document(providerId)
                .get()
                .await()

            if (docSnap.exists() && docSnap.data != null) {
                val offer = PublicRequestOffer.fromFirestoreMap(docSnap.id, docSnap.data!!)
                AuthResult.Success(offer)
            } else {
                AuthResult.Success(null)
            }
        } catch (e: Exception) {
            Log.e(tag, "Error getting provider offer", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun getMyPublicRequestOfferFlow(requestId: String, providerId: String): Flow<AuthResult<PublicRequestOffer?>> = callbackFlow {
        val firestoreDb = firestore
        if (firestoreDb == null || requestId.isBlank()) {
            trySend(AuthResult.Error("خدمة Cloud Firestore غير متوفرة"))
            close()
            return@callbackFlow
        }

        if (providerId.isBlank()) {
            trySend(AuthResult.Success(null))
            close()
            return@callbackFlow
        }

        val docRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
            .document(requestId)
            .collection(FirestoreConstants.OFFERS)
            .document(providerId)

        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e(tag, "Error listening to my public request offer", error)
                trySend(AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(error), error))
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists() && snapshot.data != null) {
                val offer = PublicRequestOffer.fromFirestoreMap(snapshot.id, snapshot.data!!)
                trySend(AuthResult.Success(offer))
            } else {
                trySend(AuthResult.Success(null))
            }
        }

        awaitClose { listener.remove() }
    }

    suspend fun isPublicRequest(requestId: String): Boolean {
        val firestoreDb = firestore ?: return false
        if (requestId.isBlank()) return false
        return try {
            val docSnap = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS)
                .document(requestId)
                .get()
                .await()
            docSnap.exists()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun acceptPublicRequestOffer(
        requestId: String,
        selectedOffer: PublicRequestOffer,
        customerId: String,
        customerName: String,
        customerPhotoUrl: String = ""
    ): AuthResult<Conversation> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val currentAuthUid = auth?.currentUser?.uid ?: return AuthResult.Error("يجب تسجيل الدخول لإجراء هذه العملية")
        if (currentAuthUid != customerId) {
            return AuthResult.Error("غير مصرح لك باختيار عرض لهذا الطلب")
        }

        return try {
            val reqRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document(requestId)
            val selectedOfferRef = reqRef.collection(FirestoreConstants.OFFERS).document(selectedOffer.providerId)

            // Pre-fetch other offer document references so they can be included in transaction
            val offersSnap = reqRef.collection(FirestoreConstants.OFFERS).get().await()
            val otherOfferRefs = offersSnap.documents
                .filter { it.id != selectedOffer.providerId }
                .map { it.reference }

            var requestTitle = ""

            firestoreDb.runTransaction { transaction ->
                // 1. Re-read public request inside transaction
                val reqSnap = transaction.get(reqRef)
                if (!reqSnap.exists()) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "الطلب غير موجود",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.NOT_FOUND
                    )
                }

                // 2. Verify request is still in status OPEN
                val statusStr = reqSnap.getString("status")
                if (statusStr != PublicRequestStatus.OPEN.name) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "تم اختيار حرفي آخر لهذا الطلب.",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.ABORTED
                    )
                }

                // 3. Verify current authenticated user is the customer who created the request
                val docCustomerId = reqSnap.getString("customerId") ?: ""
                if (docCustomerId != currentAuthUid) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "غير مصرح لك باختيار عرض لهذا الطلب",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
                    )
                }

                // 4. Verify selected offer still exists
                val selectedOfferSnap = transaction.get(selectedOfferRef)
                if (!selectedOfferSnap.exists()) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "عرض السعر المحدد لم يعد متاحاً",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.NOT_FOUND
                    )
                }

                // In Firestore transactions, all reads must happen before any writes
                val otherOfferSnaps = otherOfferRefs.map { transaction.get(it) }

                requestTitle = reqSnap.getString("title") ?: ""
                val now = System.currentTimeMillis()

                // 5. Update public request: status = ASSIGNED, assignedProviderId = selected provider ID, updatedAt
                transaction.update(
                    reqRef,
                    mapOf(
                        "status" to PublicRequestStatus.ASSIGNED.name,
                        "assignedProviderId" to selectedOffer.providerId,
                        "assignedProviderName" to selectedOffer.providerName,
                        "assignedOfferId" to selectedOffer.id,
                        "updatedAt" to now
                    )
                )

                // 6. Update selected offer status to ACCEPTED
                transaction.update(
                    selectedOfferRef,
                    mapOf(
                        "status" to OfferStatus.ACCEPTED.name,
                        "updatedAt" to now
                    )
                )

                // 7. Update all other offers to REJECTED
                for (otherSnap in otherOfferSnaps) {
                    if (otherSnap.exists()) {
                        transaction.update(
                            otherSnap.reference,
                            mapOf(
                                "status" to OfferStatus.REJECTED.name,
                                "updatedAt" to now
                            )
                        )
                    }
                }
            }.await()

            // 8. Open or get Conversation in chat system (deterministic ID, no duplicates)
            val convResult = getOrCreateConversation(
                customerId = customerId,
                customerName = customerName,
                customerPhotoUrl = customerPhotoUrl,
                providerId = selectedOffer.providerId,
                providerName = selectedOffer.providerName,
                providerPhotoUrl = selectedOffer.providerAvatarUrl,
                providerProfession = selectedOffer.providerProfession,
                serviceRequestId = requestId,
                serviceRequestTitle = requestTitle.ifBlank { "طلب خدمة" },
                isPublicRequest = true
            )

            when (convResult) {
                is AuthResult.Success -> {
                    // Send introductory message only if this conversation is newly opened (no prior messages)
                    try {
                        val messagesCheck = firestoreDb.collection(FirestoreConstants.CONVERSATIONS)
                            .document(convResult.data.id)
                            .collection(FirestoreConstants.MESSAGES)
                            .limit(1)
                            .get()
                            .await()
                        if (messagesCheck.isEmpty) {
                            sendMessage(
                                conversationId = convResult.data.id,
                                senderId = customerId,
                                receiverId = selectedOffer.providerId,
                                text = "مرحباً ${selectedOffer.providerName}، تم قبول عرضك لطلب الخدمة: '${requestTitle}' بسعر ${selectedOffer.priceDzd} د.ج."
                            )
                        }
                    } catch (e: Exception) {
                        Log.w(tag, "Could not send initial message, conversation is still valid", e)
                    }
                    AuthResult.Success(convResult.data)
                }
                is AuthResult.Error -> convResult
                else -> AuthResult.Error("تم قبول العرض ولكن تعذر فتح المحادثة تلقائياً")
            }
        } catch (e: Exception) {
            Log.e(tag, "Error accepting offer", e)
            val msg = e.message ?: ""
            if (msg.contains("تم اختيار حرفي آخر") ||
                (e is com.google.firebase.firestore.FirebaseFirestoreException && e.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.ABORTED)) {
                AuthResult.Error("تم اختيار حرفي آخر لهذا الطلب.")
            } else {
                AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
            }
        }
    }

    suspend fun completePublicServiceRequest(
        requestId: String,
        userUid: String
    ): AuthResult<Unit> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val currentAuthUid = auth?.currentUser?.uid ?: return AuthResult.Error("يجب تسجيل الدخول لإجراء هذه العملية")
        if (currentAuthUid != userUid) {
            return AuthResult.Error("غير مصرح لك بإتمام هذا الطلب")
        }

        return try {
            val reqRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document(requestId)
            var assignedProviderId = ""

            firestoreDb.runTransaction { transaction ->
                val reqSnap = transaction.get(reqRef)
                if (!reqSnap.exists()) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "طلب الخدمة غير موجود",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.NOT_FOUND
                    )
                }

                val currentStatus = reqSnap.getString("status") ?: ""
                // Idempotent completion check
                if (currentStatus == PublicRequestStatus.COMPLETED.name) {
                    return@runTransaction
                }

                if (currentStatus != PublicRequestStatus.ASSIGNED.name) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "لا يمكن إتمام الخدمة إلا إذا كان الطلب قيد التنفيذ (ASSIGNED)",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.FAILED_PRECONDITION
                    )
                }

                val customerId = reqSnap.getString("customerId") ?: ""
                assignedProviderId = reqSnap.getString("assignedProviderId") ?: ""

                // Security check: Only customer who created request or assigned provider may complete
                if (currentAuthUid != customerId && currentAuthUid != assignedProviderId) {
                    throw com.google.firebase.firestore.FirebaseFirestoreException(
                        "غير مصرح لك بإتمام هذا الطلب",
                        com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED
                    )
                }

                val now = System.currentTimeMillis()
                transaction.update(
                    reqRef,
                    mapOf(
                        "status" to PublicRequestStatus.COMPLETED.name,
                        "completedAt" to now,
                        "updatedAt" to now
                    )
                )
            }.await()

            // Update assigned provider's completedServices counter safely and idempotently
            if (assignedProviderId.isNotBlank()) {
                try {
                    val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(assignedProviderId)
                    val providerDoc = providerRef.get().await()
                    if (providerDoc.exists()) {
                        val currentCompleted = (providerDoc.get("completedServices") as? Number)?.toInt() ?: 0
                        providerRef.update("completedServices", currentCompleted + 1).await()
                    }
                } catch (e: Exception) {
                    Log.w(tag, "Could not directly update provider completedServices counter: ${e.message}")
                }
            }

            AuthResult.Success(Unit)
        } catch (e: Exception) {
            Log.e(tag, "Error completing public service request", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun submitPublicRequestReview(
        requestId: String,
        rating: Int,
        comment: String,
        customerName: String
    ): AuthResult<Review> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val currentAuthUid = auth?.currentUser?.uid ?: return AuthResult.Error("يجب تسجيل الدخول لتقييم الخدمة")

        return try {
            val reqRef = firestoreDb.collection(FirestoreConstants.PUBLIC_SERVICE_REQUESTS).document(requestId)
            val reqSnap = reqRef.get().await()
            if (!reqSnap.exists()) {
                return AuthResult.Error("طلب الخدمة غير موجود")
            }

            val request = PublicServiceRequest.fromFirestoreMap(requestId, reqSnap.data ?: emptyMap())
            if (request.customerId != currentAuthUid) {
                return AuthResult.Error("يحق لصاحب الطلب فقط تقييم الخدمة")
            }

            if (request.status != PublicRequestStatus.COMPLETED) {
                return AuthResult.Error("لا يمكن التقييم إلا بعد إتمام الخدمة بالكامل")
            }

            val providerId = request.assignedProviderId
            if (providerId.isNullOrBlank()) {
                return AuthResult.Error("لم يتم تعيين حرفي لهذا الطلب ليتم تقييمه")
            }

            // Deterministic document ID to prevent duplicate reviews for the same completed request
            val reviewDocId = "review_${requestId}_${currentAuthUid}"
            val reviewRef = firestoreDb.collection(FirestoreConstants.REVIEWS).document(reviewDocId)

            val existingReviewSnap = reviewRef.get().await()
            if (existingReviewSnap.exists()) {
                return AuthResult.Error("تم تقييم الخدمة مسبقًا.")
            }

            val cleanRating = rating.coerceIn(1, 5)
            val cleanComment = comment.trim()
            val now = System.currentTimeMillis()

            val finalReview = Review(
                id = reviewDocId,
                serviceRequestId = requestId,
                requestId = requestId,
                customerId = currentAuthUid,
                customerName = customerName.ifBlank { request.customerName },
                providerId = providerId,
                rating = cleanRating,
                comment = cleanComment,
                createdAt = now
            )

            reviewRef.set(finalReview.toFirestoreMap()).await()

            // Update provider rating statistics safely
            try {
                val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(providerId)
                val providerDoc = providerRef.get().await()
                if (providerDoc.exists()) {
                    val currentRating = (providerDoc.get("rating") as? Number)?.toDouble() ?: 0.0
                    val currentCount = (providerDoc.get("ratingCount") as? Number)?.toInt()
                        ?: (providerDoc.get("reviewCount") as? Number)?.toInt() ?: 0
                    val newCount = currentCount + 1
                    val newAverage = ((currentRating * currentCount) + cleanRating) / newCount
                    providerRef.update(
                        mapOf(
                            "rating" to newAverage,
                            "ratingCount" to newCount,
                            "reviewCount" to newCount
                        )
                    ).await()
                }
            } catch (e: Exception) {
                Log.w(tag, "Could not directly update provider rating: ${e.message}")
            }

            AuthResult.Success(finalReview)
        } catch (e: Exception) {
            Log.e(tag, "Error submitting public request review", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getReviewForPublicRequest(requestId: String): AuthResult<Review?> {
        val firestoreDb = firestore ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")
        val currentAuthUid = auth?.currentUser?.uid ?: ""

        return try {
            if (currentAuthUid.isNotBlank()) {
                val deterministicDocId = "review_${requestId}_${currentAuthUid}"
                val doc = firestoreDb.collection(FirestoreConstants.REVIEWS).document(deterministicDocId).get().await()
                if (doc.exists() && doc.data != null) {
                    return AuthResult.Success(Review.fromFirestoreMap(doc.data!!))
                }
            }

            // Fallback: search by requestId or serviceRequestId
            val querySnap = firestoreDb.collection(FirestoreConstants.REVIEWS)
                .whereEqualTo("serviceRequestId", requestId)
                .limit(1)
                .get()
                .await()

            if (!querySnap.isEmpty) {
                val firstDoc = querySnap.documents[0]
                AuthResult.Success(Review.fromFirestoreMap(firstDoc.data ?: emptyMap()))
            } else {
                AuthResult.Success(null)
            }
        } catch (e: Exception) {
            Log.e(tag, "Error fetching review for request", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun logout() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e(tag, "Logout error", e)
        }
    }
}
