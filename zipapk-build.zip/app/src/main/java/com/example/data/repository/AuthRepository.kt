package com.example.data.repository

import android.util.Log
import com.example.data.model.ServiceProviderProfile
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.remote.FirestoreConstants
import com.example.data.remote.FirebaseStatusHelper
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

sealed class AuthResult<out T> {
    data class Success<T>(val data: T) : AuthResult<T>()
    data class Error(val messageAr: String, val rawError: Throwable? = null) : AuthResult<Nothing>()
    object Loading : AuthResult<Nothing>()
    data class ProfileMissing(
        val uid: String,
        val email: String,
        val role: UserRole? = null
    ) : AuthResult<Nothing>()
}

class AuthRepository() {
    private val tag = "AuthRepository"

    private val auth: FirebaseAuth?
        get() = FirebaseStatusHelper.getFirebaseAuth()

    private val firestore: FirebaseFirestore?
        get() = FirebaseStatusHelper.getFirestore()

    val isFirebaseReady: Boolean
        get() = auth != null && firestore != null

    val currentUserId: String?
        get() = auth?.currentUser?.uid

    fun observeAuthState(onStateChanged: (String?) -> Unit) {
        val firebaseAuth = auth
        if (firebaseAuth == null) {
            onStateChanged(null)
            return
        }
        val listener = FirebaseAuth.AuthStateListener { auth ->
            onStateChanged(auth.currentUser?.uid)
        }
        firebaseAuth.addAuthStateListener(listener)
    }

    val currentAuthUserEmail: String?
        get() = auth?.currentUser?.email

    val isUserLoggedIn: Boolean
        get() = auth?.currentUser != null

    suspend fun login(email: String, password: String): AuthResult<UserProfile> {
        val firebaseAuth = auth
            ?: return AuthResult.Error(
                "خدمة Firebase Auth غير مهيأة. يرجى التأكد من ربط المشروع وإضافة google-services.json"
            )

        val firestoreDb = firestore
            ?: return AuthResult.Error(
                "خدمة Cloud Firestore غير مهيأة. يرجى مراجعة إعدادات Firebase"
            )

        return try {
            val authResult = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
            val user = authResult.user
                ?: return AuthResult.Error("تعذر تسجيل الدخول، لم يتم استلام بيانات المستخدم")

            val uid = user.uid

            // Step 1: Fetch user profile from 'users' collection
            val userDoc = firestoreDb.collection(FirestoreConstants.USERS)
                .document(uid)
                .get()
                .await()

            if (userDoc.exists() && userDoc.data != null) {
                val profile = UserProfile.fromFirestoreMap(userDoc.data!!)
                AuthResult.Success(profile)
            } else {
                // Step 2: Check if provider profile exists in 'serviceProviders' collection
                val providerDoc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                    .document(uid)
                    .get()
                    .await()

                if (providerDoc.exists() && providerDoc.data != null) {
                    val pProfile = ServiceProviderProfile.fromFirestoreMap(providerDoc.data!!)
                    val uProfile = UserProfile(
                        uid = uid,
                        fullName = pProfile.fullName,
                        email = pProfile.email,
                        phone = pProfile.phone,
                        role = UserRole.SERVICE_PROVIDER,
                        wilayaCode = pProfile.wilayaCode,
                        wilayaName = pProfile.wilayaName,
                        communeName = pProfile.communeName,
                        createdAt = pProfile.createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    // Auto-repair missing 'users' profile in Firestore
                    firestoreDb.collection(FirestoreConstants.USERS)
                        .document(uid)
                        .set(uProfile.toFirestoreMap())
                        .await()

                    AuthResult.Success(uProfile)
                } else {
                    // Step 3: Profile missing in Firestore for this valid Auth user
                    AuthResult.ProfileMissing(
                        uid = uid,
                        email = user.email ?: email.trim()
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Login error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun registerCustomer(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String
    ): AuthResult<UserProfile> {
        val firebaseAuth = auth
            ?: return AuthResult.Error("خدمة Firebase Auth غير مهيأة")
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير مهيأة")

        return try {
            val uid = if (firebaseAuth.currentUser != null) {
                firebaseAuth.currentUser!!.uid
            } else {
                try {
                    val authResult = firebaseAuth.createUserWithEmailAndPassword(email.trim(), password).await()
                    authResult.user?.uid ?: return AuthResult.Error("تم إنشاء الحساب ولكن تعذر الحصول على معرف المستخدم")
                } catch (e: Exception) {
                    val signInRes = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
                    signInRes.user?.uid ?: throw e
                }
            }

            val profile = UserProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.CUSTOMER,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            firestoreDb.collection(FirestoreConstants.USERS)
                .document(uid)
                .set(profile.toFirestoreMap())
                .await()

            AuthResult.Success(profile)
        } catch (e: Exception) {
            Log.e(tag, "Customer registration error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun registerServiceProvider(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        professionId: String,
        professionNameAr: String,
        professionCategoryAr: String,
        wilayaCode: Int,
        wilayaName: String,
        communeName: String,
        serviceDescription: String,
        experienceYears: Int
    ): AuthResult<Pair<UserProfile, ServiceProviderProfile>> {
        val firebaseAuth = auth
            ?: return AuthResult.Error("خدمة Firebase Auth غير مهيأة")
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير مهيأة")

        return try {
            val uid = if (firebaseAuth.currentUser != null) {
                firebaseAuth.currentUser!!.uid
            } else {
                try {
                    val authResult = firebaseAuth.createUserWithEmailAndPassword(email.trim(), password).await()
                    authResult.user?.uid ?: return AuthResult.Error("تم إنشاء الحساب ولكن تعذر الحصول على معرف المستخدم")
                } catch (e: Exception) {
                    val signInRes = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
                    signInRes.user?.uid ?: throw e
                }
            }

            val userProfile = UserProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = UserRole.SERVICE_PROVIDER,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val providerProfile = ServiceProviderProfile(
                uid = uid,
                fullName = fullName.trim(),
                email = email.trim(),
                phone = phone.trim(),
                professionId = professionId,
                professionNameAr = professionNameAr,
                professionCategoryAr = professionCategoryAr,
                wilayaCode = wilayaCode,
                wilayaName = wilayaName,
                communeName = communeName,
                serviceDescription = serviceDescription.trim(),
                experienceYears = experienceYears,
                isAvailable = true,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            val batch = firestoreDb.batch()
            val userRef = firestoreDb.collection(FirestoreConstants.USERS).document(uid)
            val providerRef = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid)

            batch.set(userRef, userProfile.toFirestoreMap())
            batch.set(providerRef, providerProfile.toFirestoreMap())
            batch.commit().await()

            AuthResult.Success(Pair(userProfile, providerProfile))
        } catch (e: Exception) {
            Log.e(tag, "Service provider registration error", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getUserProfile(uid: String): AuthResult<UserProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val doc = firestoreDb.collection(FirestoreConstants.USERS).document(uid).get().await()
            if (doc.exists() && doc.data != null) {
                AuthResult.Success(UserProfile.fromFirestoreMap(doc.data!!))
            } else {
                val providerDoc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid).get().await()
                if (providerDoc.exists() && providerDoc.data != null) {
                    val pProfile = ServiceProviderProfile.fromFirestoreMap(providerDoc.data!!)
                    val uProfile = UserProfile(
                        uid = uid,
                        fullName = pProfile.fullName,
                        email = pProfile.email,
                        phone = pProfile.phone,
                        role = UserRole.SERVICE_PROVIDER,
                        wilayaCode = pProfile.wilayaCode,
                        wilayaName = pProfile.wilayaName,
                        communeName = pProfile.communeName,
                        createdAt = pProfile.createdAt,
                        updatedAt = System.currentTimeMillis()
                    )
                    firestoreDb.collection(FirestoreConstants.USERS)
                        .document(uid)
                        .set(uProfile.toFirestoreMap())
                        .await()

                    AuthResult.Success(uProfile)
                } else {
                    val currentEmail = auth?.currentUser?.email ?: ""
                    AuthResult.ProfileMissing(uid = uid, email = currentEmail)
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Error fetching user profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun getServiceProviderProfile(uid: String): AuthResult<ServiceProviderProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val doc = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS).document(uid).get().await()
            if (doc.exists() && doc.data != null) {
                AuthResult.Success(ServiceProviderProfile.fromFirestoreMap(doc.data!!))
            } else {
                val currentEmail = auth?.currentUser?.email ?: ""
                AuthResult.ProfileMissing(uid = uid, email = currentEmail, role = UserRole.SERVICE_PROVIDER)
            }
        } catch (e: Exception) {
            Log.e(tag, "Error fetching provider profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun fetchServiceProviders(
        professionId: String? = null,
        wilayaCode: Int? = null
    ): AuthResult<List<ServiceProviderProfile>> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val querySnapshot = firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .get()
                .await()

            val list = querySnapshot.documents.mapNotNull { doc ->
                doc.data?.let { ServiceProviderProfile.fromFirestoreMap(it) }
            }.filter { provider ->
                var matches = true
                if (!professionId.isNullOrBlank()) {
                    matches = matches && (provider.professionId == professionId)
                }
                if (wilayaCode != null && wilayaCode > 0) {
                    matches = matches && (provider.wilayaCode == wilayaCode)
                }
                matches
            }

            AuthResult.Success(list)
        } catch (e: Exception) {
            Log.e(tag, "Error fetching service providers", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateProviderAvailability(uid: String, isAvailable: Boolean): AuthResult<Boolean> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(uid)
                .update(
                    mapOf(
                        "isAvailable" to isAvailable,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .await()
            AuthResult.Success(isAvailable)
        } catch (e: Exception) {
            Log.e(tag, "Error updating availability", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    suspend fun updateServiceProviderProfile(profile: ServiceProviderProfile): AuthResult<ServiceProviderProfile> {
        val firestoreDb = firestore
            ?: return AuthResult.Error("خدمة Cloud Firestore غير متوفرة")

        return try {
            val updated = profile.copy(updatedAt = System.currentTimeMillis())
            firestoreDb.collection(FirestoreConstants.SERVICE_PROVIDERS)
                .document(profile.uid)
                .set(updated.toFirestoreMap(), SetOptions.merge())
                .await()

            // Also update basic info in 'users'
            firestoreDb.collection(FirestoreConstants.USERS)
                .document(profile.uid)
                .update(
                    mapOf(
                        "fullName" to profile.fullName,
                        "phone" to profile.phone,
                        "wilayaCode" to profile.wilayaCode,
                        "wilayaName" to profile.wilayaName,
                        "communeName" to profile.communeName,
                        "updatedAt" to System.currentTimeMillis()
                    )
                )
                .await()

            AuthResult.Success(updated)
        } catch (e: Exception) {
            Log.e(tag, "Error updating provider profile", e)
            AuthResult.Error(FirebaseStatusHelper.translateFirebaseError(e), e)
        }
    }

    fun logout() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.e(tag, "Logout error", e)
        }
    }
}
