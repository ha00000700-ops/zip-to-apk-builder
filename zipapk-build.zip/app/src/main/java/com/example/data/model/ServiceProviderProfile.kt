package com.example.data.model

data class ServiceProviderProfile(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val professionId: String = "",
    val professionNameAr: String = "",
    val professionCategoryAr: String = "",
    val specialization: String = "",
    val wilayaCode: Int = 16,
    val wilayaName: String = "الجزائر",
    val communeName: String = "الجزائر الوسطى",
    val serviceDescription: String = "",
    val bio: String = "",
    val experienceYears: Int = 1,
    val isAvailable: Boolean = true,
    val rating: Double = 0.0,
    val reviewCount: Int = 0,
    val isVerified: Boolean = false,
    val pricingInfo: String = "حسب المعاينة وطبيعة العمل",
    val completedJobsCount: Int = 0,
    val completedServices: Int = 0,
    val avatarUrl: String = "",
    val profileImageUrl: String = "",
    val portfolioImageUrls: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun effectiveAvatarUrl(): String = profileImageUrl.ifBlank { avatarUrl }
    fun effectiveBio(): String = bio.ifBlank { serviceDescription }
    fun effectiveCompletedJobs(): Int = if (completedServices > 0) completedServices else completedJobsCount

    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "uid" to uid,
            "fullName" to fullName,
            "email" to email,
            "phone" to phone,
            "professionId" to professionId,
            "professionNameAr" to professionNameAr,
            "professionCategoryAr" to professionCategoryAr,
            "specialization" to specialization,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "serviceDescription" to serviceDescription,
            "bio" to bio,
            "experienceYears" to experienceYears,
            "isAvailable" to isAvailable,
            "rating" to rating,
            "reviewCount" to reviewCount,
            "isVerified" to isVerified,
            "pricingInfo" to pricingInfo,
            "completedJobsCount" to completedJobsCount,
            "completedServices" to completedServices,
            "avatarUrl" to avatarUrl,
            "profileImageUrl" to profileImageUrl,
            "portfolioImageUrls" to portfolioImageUrls,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): ServiceProviderProfile {
            val pImg = map["profileImageUrl"] as? String ?: ""
            val aImg = map["avatarUrl"] as? String ?: ""
            val desc = map["serviceDescription"] as? String ?: ""
            val bioVal = map["bio"] as? String ?: desc
            val jobsCount = (map["completedJobsCount"] as? Number)?.toInt() ?: 0
            val servCount = (map["completedServices"] as? Number)?.toInt() ?: jobsCount

            return ServiceProviderProfile(
                uid = map["uid"] as? String ?: "",
                fullName = map["fullName"] as? String ?: "",
                email = map["email"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                professionId = map["professionId"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                professionCategoryAr = map["professionCategoryAr"] as? String ?: "",
                specialization = map["specialization"] as? String ?: "",
                wilayaCode = (map["wilayaCode"] as? Number)?.toInt() ?: 16,
                wilayaName = map["wilayaName"] as? String ?: "الجزائر",
                communeName = map["communeName"] as? String ?: "الجزائر الوسطى",
                serviceDescription = desc,
                bio = bioVal,
                experienceYears = (map["experienceYears"] as? Number)?.toInt() ?: 1,
                isAvailable = map["isAvailable"] as? Boolean ?: true,
                rating = (map["rating"] as? Number)?.toDouble() ?: 0.0,
                reviewCount = (map["reviewCount"] as? Number)?.toInt() ?: 0,
                isVerified = map["isVerified"] as? Boolean ?: false,
                pricingInfo = map["pricingInfo"] as? String ?: "حسب المعاينة وطبيعة العمل",
                completedJobsCount = jobsCount,
                completedServices = servCount,
                avatarUrl = aImg.ifBlank { pImg },
                profileImageUrl = pImg.ifBlank { aImg },
                portfolioImageUrls = (map["portfolioImageUrls"] as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
