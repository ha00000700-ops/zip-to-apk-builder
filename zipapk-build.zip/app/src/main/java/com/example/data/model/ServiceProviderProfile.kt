package com.example.data.model

data class ServiceProviderProfile(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val professionId: String = "",
    val professionNameAr: String = "",
    val professionCategoryAr: String = "",
    val wilayaCode: Int = 16,
    val wilayaName: String = "الجزائر",
    val communeName: String = "الجزائر الوسطى",
    val serviceDescription: String = "",
    val experienceYears: Int = 1,
    val isAvailable: Boolean = true,
    val rating: Double = 0.0,
    val reviewCount: Int = 0,
    val isVerified: Boolean = false,
    val pricingInfo: String = "حسب المعاينة وطبيعة العمل",
    val completedJobsCount: Int = 0,
    val avatarUrl: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "uid" to uid,
            "fullName" to fullName,
            "email" to email,
            "phone" to phone,
            "professionId" to professionId,
            "professionNameAr" to professionNameAr,
            "professionCategoryAr" to professionCategoryAr,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "serviceDescription" to serviceDescription,
            "experienceYears" to experienceYears,
            "isAvailable" to isAvailable,
            "rating" to rating,
            "reviewCount" to reviewCount,
            "isVerified" to isVerified,
            "pricingInfo" to pricingInfo,
            "completedJobsCount" to completedJobsCount,
            "avatarUrl" to avatarUrl,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): ServiceProviderProfile {
            return ServiceProviderProfile(
                uid = map["uid"] as? String ?: "",
                fullName = map["fullName"] as? String ?: "",
                email = map["email"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                professionId = map["professionId"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                professionCategoryAr = map["professionCategoryAr"] as? String ?: "",
                wilayaCode = (map["wilayaCode"] as? Number)?.toInt() ?: 16,
                wilayaName = map["wilayaName"] as? String ?: "الجزائر",
                communeName = map["communeName"] as? String ?: "الجزائر الوسطى",
                serviceDescription = map["serviceDescription"] as? String ?: "",
                experienceYears = (map["experienceYears"] as? Number)?.toInt() ?: 1,
                isAvailable = map["isAvailable"] as? Boolean ?: true,
                rating = (map["rating"] as? Number)?.toDouble() ?: 0.0,
                reviewCount = (map["reviewCount"] as? Number)?.toInt() ?: 0,
                isVerified = map["isVerified"] as? Boolean ?: false,
                pricingInfo = map["pricingInfo"] as? String ?: "حسب المعاينة وطبيعة العمل",
                completedJobsCount = (map["completedJobsCount"] as? Number)?.toInt() ?: 0,
                avatarUrl = map["avatarUrl"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
