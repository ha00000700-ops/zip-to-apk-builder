package com.example.data.model

enum class LoveCategory(val displayName: String, val icon: String) {
    ALL("الكل", "✨"),
    ALGERIAN("دارجة جزائرية عسل 🇩🇿", "❤️"),
    ROMANTIC("فصحى رومانسية 🌹", "💌"),
    MORNING("صباحيات دافئة ☕", "☀️"),
    WEATHER_LOVE("طقس وغرام 🌧️", "🌦️")
}

data class LoveQuote(
    val id: String,
    val text: String,
    val translationOrTip: String = "",
    val category: LoveCategory,
    val isAlgerian: Boolean = false,
    val isHumorous: Boolean = false,
    val targetWeather: WeatherConditionType? = null
)

data class UserLoveNote(
    val id: String,
    val content: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

object LoveQuotesRepository {
    val quotes = listOf(
        // Rainy Weather Quotes
        LoveQuote(
            id = "w_rain_1",
            text = "النو تصب والبرد يقرس، بصح صوتك وضحكتك هما لي يدفّيو قلبي يا عمري!",
            translationOrTip = "مهما كان الجو بارداً، دفء صوتك يكفيني",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = true,
            targetWeather = WeatherConditionType.RAINY
        ),
        LoveQuote(
            id = "w_rain_2",
            text = "كل قطرة مطر طايحة اليوم تسلم عليك وتقولك شحال نحبك يا زين البنات!",
            translationOrTip = "رومانسية المطر بالروح الجزائرية",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = false,
            targetWeather = WeatherConditionType.RAINY
        ),
        LoveQuote(
            id = "w_rain_3",
            text = "حين تمطر في مدينتكِ، أشعر أن السماء ترسل لي رسائل حبكِ قطرة قطرة.",
            translationOrTip = "سماء واحدة تجمع قلبيكما",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false,
            targetWeather = WeatherConditionType.RAINY
        ),

        // Cloudy Weather Quotes
        LoveQuote(
            id = "w_cloud_1",
            text = "السما مغيمة بصح وجهك وضحكتك ينورولي أظلم نهار يا روحي!",
            translationOrTip = "أنتِ الشمس التي تبدد الغيوم",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = false,
            targetWeather = WeatherConditionType.CLOUDY
        ),
        LoveQuote(
            id = "w_cloud_2",
            text = "الغيوم تحرس أمنياتنا المشتركة، وتحت هذا السحاب أدعو الله أن يديمكِ لي عمراً.",
            translationOrTip = "دعاء المحبين تحت الغيم",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false,
            targetWeather = WeatherConditionType.CLOUDY
        ),
        LoveQuote(
            id = "w_cloud_3",
            text = "الجو راه مغيم وشباب، يطلب كاس تاي بالنعناع مشحر وهدرة طويلة معاك في التليفون!",
            translationOrTip = "جلسة شاي وكلام من القلب للقلب",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = true,
            targetWeather = WeatherConditionType.PARTLY_CLOUDY
        ),

        // Sunny Weather Quotes
        LoveQuote(
            id = "w_sun_1",
            text = "كي تكون الشمس طالعة نتي شمس حياتي، وكي تغيم ربي يحفظلي عويناتك اللوز المنورين!",
            translationOrTip = "في كل أحوال الجو أنتِ نور عيني",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false,
            targetWeather = WeatherConditionType.CLEAR_DAY
        ),
        LoveQuote(
            id = "w_sun_2",
            text = "شمس اليوم دافية، بصح والله ما تلحق لنص دفء قلبك وحنانتك يا عمري!",
            translationOrTip = "دفء مشاعرك يفوق شمس الصباح",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = true,
            targetWeather = WeatherConditionType.CLEAR_DAY
        ),
        LoveQuote(
            id = "w_sun_3",
            text = "صباح الخير يا نبض الفؤاد، نهارك مشرق كابتسامتكِ وجميل كجمال روحكِ الطاهرة.",
            translationOrTip = "إشراقة حب صباحية",
            category = LoveCategory.MORNING,
            isAlgerian = false,
            targetWeather = WeatherConditionType.CLEAR_DAY
        ),

        // Night & Stars Quotes
        LoveQuote(
            id = "w_night_1",
            text = "القمرة في السما ونتي القمرة تاع قلبي وعالمي كامل.. ليلة سعيدة يا روحي!",
            translationOrTip = "تحية مسائية رومانسية للحبيبة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false,
            targetWeather = WeatherConditionType.CLEAR_NIGHT
        ),
        LoveQuote(
            id = "w_night_2",
            text = "بين مدينتي ومدينتكِ سماء ليلية واحدة نتقاسم فيها نفس النجوم ونفس النبضات.",
            translationOrTip = "تلاقي الأرواح تحت سماء الليل",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false,
            targetWeather = WeatherConditionType.CLEAR_NIGHT
        ),

        // Snowy / Cold Quotes
        LoveQuote(
            id = "w_snow_1",
            text = "بياض الثلج يشبه نقاء قلبكِ الجميل.. برودة الجو تذوب أمام حرارة شوقي إليكِ.",
            translationOrTip = "دفء الشوق في أيام البرد",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false,
            targetWeather = WeatherConditionType.SNOWY
        ),
        LoveQuote(
            id = "w_snow_2",
            text = "البرد راه يقرس بصح نتفكرك نلقى روحي نبتسم وحدي كي المهبول.. ربي يدومك ليا!",
            translationOrTip = "ابتسامة دافئة رغم الصقيع",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true,
            targetWeather = WeatherConditionType.SNOWY
        ),

        // Thunderstorm / Wind Quotes
        LoveQuote(
            id = "w_storm_1",
            text = "الرعود والريح برة، بصح حبك في قلبي راسي ما يزعزعوه جبال جرجرة والونشريس!",
            translationOrTip = "حب راسخ كالجبال الشامخة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true,
            targetWeather = WeatherConditionType.THUNDERSTORM
        ),

        // Witty Algerian General Quotes
        LoveQuote(
            id = "dz_food",
            text = "نحبك قد ما كاين كسكسي نهار الجمعة في قاع الدزاير، وكيما نحب ريحة القهوة العصرونية!",
            translationOrTip = "حب خالص وعميق على الطريقة الجزائرية الأصيلة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true
        ),
        LoveQuote(
            id = "dz_beauty",
            text = "كيما يقولو ناس زمان: الزين يحشم على زينه.. ونتي زينك غلب قاع فصول السنة وباهي كي الورد!",
            translationOrTip = "مدح أصيل في روعة الحبيبة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_weather_dept",
            text = "قلبي راه يدير ميتيو خاصة بيه اليوم: نسبة الحب 100%، وسرعة الشوق تفوق سرعة الرياح!",
            translationOrTip = "نشرة جوية للقلب خصيصاً لك",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = true
        )
    )

    fun getDailyQuote(): LoveQuote {
        val dayOfYear = (System.currentTimeMillis() / (1000 * 60 * 60 * 24)).toInt()
        val index = Math.floorMod(dayOfYear, quotes.size)
        return quotes[index]
    }

    fun getRandomQuote(category: LoveCategory = LoveCategory.ALL): LoveQuote {
        val filtered = if (category == LoveCategory.ALL) quotes else quotes.filter { it.category == category }
        return filtered.randomOrNull() ?: quotes.first()
    }

    /**
     * Automatically retrieves the most contextually relevant love quote based on live weather
     */
    fun getWeatherReactiveQuote(condition: WeatherConditionType): LoveQuote {
        val matches = quotes.filter { it.targetWeather == condition }
        return if (matches.isNotEmpty()) {
            matches.random()
        } else {
            quotes.filter { it.category == LoveCategory.WEATHER_LOVE }.randomOrNull() ?: quotes.first()
        }
    }
}
