package com.example.data.model

enum class LoveCategory(val displayName: String, val icon: String) {
    ALL("الكل", "✨"),
    ALGERIAN("دارجة جزائرية عسل 🇩🇿", "❤️"),
    ROMANTIC("فصحى رومانسية 🌹", "💌"),
    MORNING("صباحيات دافئة ☕", "☀️"),
    WEATHER_LOVE("طقس وغرام 🌧️", "🌦️")
}

data class LoveQuote(
    val id: String,
    val text: String,
    val translationOrTip: String = "",
    val category: LoveCategory,
    val isAlgerian: Boolean = false,
    val isHumorous: Boolean = false
)

data class UserLoveNote(
    val id: String,
    val content: String,
    val dateAdded: Long = System.currentTimeMillis(),
    val isFavorite: Boolean = false
)

object LoveQuotesRepository {
    val quotes = listOf(
        // Algerian Witty & Sweet (فكاهية ولطيفة جزائرية)
        LoveQuote(
            id = "dz_1",
            text = "النو تصب والبرد يقرس، بصح صوتك وضحكتك هما لي يدفّيو قلبي يا عمري!",
            translationOrTip = "مهما كان الجو بارداً، دفء صوتك يكفيني",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true
        ),
        LoveQuote(
            id = "dz_2",
            text = "نحبك قد ما كاين كسكسي نهار الجمعة في قاع الدزاير، وكيما نحب ريحة القهوة الصباح!",
            translationOrTip = "حب خالص وعميق على الطريقة الجزائرية الأصيلة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true
        ),
        LoveQuote(
            id = "dz_3",
            text = "لوكان الطقس قاع يتبدل وتولي الشتا في الصيف، حبك في قلبي جامي يتبدل يا زين الهمة!",
            translationOrTip = "ثبات المشاعر في كل الفصول",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_4",
            text = "قلبي راه يدير ميتيو خاصة بيه اليوم: نسبة الحب 100%، وسرعة الشوق تفوق سرعة الرياح!",
            translationOrTip = "نشرة جوية للقلب خصيصاً لك",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = true
        ),
        LoveQuote(
            id = "dz_5",
            text = "يا سكر معسل، شفت الطقس شحال شباب اليوم؟ بصح والله ما يلحق لنص حلاوتك وعينيك!",
            translationOrTip = "جمالك فاق جمال الطبيعة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_6",
            text = "كيما يقولو ناس زمان: الزين يحشم على زينه.. ونتي زينك غلب قاع فصول السنة وباهي كي الورد!",
            translationOrTip = "مدح أصيل في روعة الحبيبة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_7",
            text = "توحشتك يا الغالية، الجو اليوم يطلب كاس تاي بالنعناع مشحر وهدرة طويلة معاك في التليفون!",
            translationOrTip = "جلسة شاي وكلام من القلب للقلب",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_8",
            text = "الريح راه ينفخ برة، بصح حبك في قلبي راسي ما يزعزعوه جبال جرجرة ولا الونشريس!",
            translationOrTip = "حب راسخ كالجبال الشامخة",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true
        ),
        LoveQuote(
            id = "dz_9",
            text = "كي تكون الشمس طالعة نتي شمس حياتي، وكي تغيم ربي يحفظلي عويناتك اللوز المنورين!",
            translationOrTip = "في كل أحوال الجو أنتِ نور عيني",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = false
        ),
        LoveQuote(
            id = "dz_10",
            text = "السخانة راهي تلحق لـ 40°C، بصح نتي دايما تسخّفي وتسخّني المشاعر يا زينة البنات!",
            translationOrTip = "طرافة جزائرية لمواجهة حرارة الطقس",
            category = LoveCategory.ALGERIAN,
            isAlgerian = true,
            isHumorous = true
        ),

        // Deep Classical Romantic (فصحى رومانسية)
        LoveQuote(
            id = "ro_1",
            text = "بين مدينتي ومدينتكِ سماء واحدة تحتضننا، وتحت كل غيمة أدعو الله أن يحفظكِ لقلبي دائماً.",
            translationOrTip = "السماء تجمعنا مهما بعدت المسافات",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false
        ),
        LoveQuote(
            id = "ro_2",
            text = "أنتِ المطر الذي يسقي روحي بالبهجة، والشمس التي تبدد كل عتمة تسكن أيامي.",
            translationOrTip = "أنتِ سر الفرح والنور",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false
        ),
        LoveQuote(
            id = "ro_3",
            text = "كلما نظرتُ إلى نافذتي ورأيتُ هدوء الجو، تذكرتُ عينيكِ وابتسامتكِ التي تهدئ عواصف قلبي.",
            translationOrTip = "سكينة حبك أروع من أي جو",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false
        ),
        LoveQuote(
            id = "ro_4",
            text = "المسافات لا تقاس بالكيلومترات، بل بنبضات الشوق التي تسافر إليكِ في كل ثانية.",
            translationOrTip = "حب عابر للمدن والمسافات",
            category = LoveCategory.ROMANTIC,
            isAlgerian = false
        ),
        LoveQuote(
            id = "ro_5",
            text = "حين تمطر في مدينتكِ، أشعر أن السماء ترسل لي رسائل حبكِ قطرة قطرة.",
            translationOrTip = "رومانسية المطر بين العاشقين",
            category = LoveCategory.WEATHER_LOVE,
            isAlgerian = false
        ),

        // Morning Quotes (صباحيات دافئة)
        LoveQuote(
            id = "mo_1",
            text = "صباح الخير يا زينة الصباحات.. نهارك مبروك ومورال طالع وابتسامتك ما تغيبش!",
            translationOrTip = "بداية يوم مبهجة ومليئة بالتفاؤل",
            category = LoveCategory.MORNING,
            isAlgerian = true
        ),
        LoveQuote(
            id = "mo_2",
            text = "صباح الورد والياسمين لقلبكِ الرقيق.. جعل الله نهاركِ مشرقاً كشمس بلادي الحبيبة.",
            translationOrTip = "تحية صباحية رقيقة عطرة",
            category = LoveCategory.MORNING,
            isAlgerian = false
        ),
        LoveQuote(
            id = "mo_3",
            text = "صباحك عسل وسكر.. تفقدت الطقس اليوم ولقيت أجمل خبر هو أنكِ في حياتي!",
            translationOrTip = "أجمل طالع صباحي",
            category = LoveCategory.MORNING,
            isAlgerian = true,
            isHumorous = true
        )
    )

    fun getDailyQuote(): LoveQuote {
        val dayOfYear = (System.currentTimeMillis() / (1000 * 60 * 60 * 24)).toInt()
        val index = Math.floorMod(dayOfYear, quotes.size)
        return quotes[index]
    }

    fun getRandomQuote(category: LoveCategory = LoveCategory.ALL): LoveQuote {
        val filtered = if (category == LoveCategory.ALL) quotes else quotes.filter { it.category == category }
        return filtered.randomOrNull() ?: quotes.first()
    }
}
