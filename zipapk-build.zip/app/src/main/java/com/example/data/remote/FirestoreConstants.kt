package com.example.data.remote

object FirestoreConstants {
    const val USERS = "users"
    const val SERVICE_PROVIDERS = "serviceProviders"
    const val PROFESSIONS = "professions"
    const val SERVICE_CATEGORIES = "serviceCategories"
    const val SERVICE_REQUESTS = "serviceRequests"
    const val REVIEWS = "reviews"
    const val CONVERSATIONS = "conversations"
    const val MESSAGES = "messages"
}
