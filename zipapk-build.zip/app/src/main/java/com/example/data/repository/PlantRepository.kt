package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.data.local.ApiKeyManager
import com.example.data.model.ChatMessage
import com.example.data.model.GardenPlant
import com.example.data.model.PlantDiagnosis
import com.example.data.remote.GeminiPlantDoctorService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.InputStream

class PlantRepository(private val context: Context) {

    val apiKeyManager = ApiKeyManager(context)
    private val geminiService = GeminiPlantDoctorService(context)

    private val _scanHistory = MutableStateFlow<List<PlantDiagnosis>>(emptyList())
    val scanHistory: StateFlow<List<PlantDiagnosis>> = _scanHistory.asStateFlow()

    private val _gardenPlants = MutableStateFlow<List<GardenPlant>>(emptyList())
    val gardenPlants: StateFlow<List<GardenPlant>> = _gardenPlants.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _activeDiagnosis = MutableStateFlow<PlantDiagnosis?>(null)
    val activeDiagnosis: StateFlow<PlantDiagnosis?> = _activeDiagnosis.asStateFlow()

    init {
        _chatMessages.value = listOf(
            ChatMessage(
                text = "مرحباً بك في عيادة 'طبيب النباتات الذكي' 🌱\nأنا خبيرك الزراعي المدعوم بالذكاء الاصطناعي لفحص وتشخيص أوراق ونباتات حديقتك الحقيقية، واكتشاف الأمراض الفطرية والحشرية ونقص العناصر الغذائية، وتقديم الأدوية والمبيدات والعلاجات العضوية المناسبة بدقة.\n\nالتقط صورة حية لنبتتك أو اخترها من المعرض لبدء الفحص الحقيقي فوراً!",
                isFromUser = false,
                suggestedReplies = listOf(
                    "ما هي أعراض نقص الحديد في الأوراق؟",
                    "كيف أعالج البياض الدقيقي عضوياً؟",
                    "كيف أحمي أشجار الحمضيات من صانعات الأنفاق؟"
                )
            )
        )
    }

    suspend fun diagnoseImage(bitmap: Bitmap, uriString: String? = null): PlantDiagnosis {
        _isAnalyzing.value = true
        try {
            val diagnosis = geminiService.diagnosePlant(bitmap, uriString)
            _activeDiagnosis.value = diagnosis
            _scanHistory.value = listOf(diagnosis) + _scanHistory.value
            return diagnosis
        } finally {
            _isAnalyzing.value = false
        }
    }

    suspend fun diagnoseFromUri(uri: Uri): PlantDiagnosis {
        val inputStream: InputStream? = try {
            context.contentResolver.openInputStream(uri)
        } catch (e: Exception) {
            null
        }
        val bitmap = inputStream?.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalArgumentException("تعذر فتح ملف الصورة المحددة من المعرض.")
        return diagnoseImage(bitmap, uri.toString())
    }

    fun setDiagnosis(diagnosis: PlantDiagnosis) {
        _activeDiagnosis.value = diagnosis
        if (!_scanHistory.value.any { it.id == diagnosis.id }) {
            _scanHistory.value = listOf(diagnosis) + _scanHistory.value
        }
    }

    fun updateDiagnosisStatus(diagnosisId: String, newStatus: String) {
        _scanHistory.value = _scanHistory.value.map {
            if (it.id == diagnosisId) it.copy(treatmentStatus = newStatus) else it
        }
        if (_activeDiagnosis.value?.id == diagnosisId) {
            _activeDiagnosis.value = _activeDiagnosis.value?.copy(treatmentStatus = newStatus)
        }
    }

    fun addPlantToGarden(name: String, plantType: String, wateringDays: Int, note: String, isUnderTreatment: Boolean) {
        val newPlant = GardenPlant(
            name = name,
            plantType = plantType,
            wateringFrequencyDays = wateringDays,
            lastWateredTimestamp = System.currentTimeMillis(),
            diagnosisNote = note,
            isUnderTreatment = isUnderTreatment
        )
        _gardenPlants.value = listOf(newPlant) + _gardenPlants.value
    }

    fun waterPlant(plantId: String) {
        _gardenPlants.value = _gardenPlants.value.map {
            if (it.id == plantId) it.copy(lastWateredTimestamp = System.currentTimeMillis()) else it
        }
    }

    fun removePlantFromGarden(plantId: String) {
        _gardenPlants.value = _gardenPlants.value.filter { it.id != plantId }
    }

    suspend fun sendChatMessage(userText: String): String {
        val userMsg = ChatMessage(text = userText, isFromUser = true)
        _chatMessages.value = _chatMessages.value + userMsg

        val currentDiag = _activeDiagnosis.value
        val botReplyText = geminiService.askDoctorChat(_chatMessages.value, userText, currentDiag)

        val botMsg = ChatMessage(
            text = botReplyText,
            isFromUser = false,
            suggestedReplies = listOf(
                "ما هي بدائل المبيد الكيميائي؟",
                "كيف أحمي بقية النباتات؟",
                "ما هي أوقات الرش المثالية؟"
            )
        )
        _chatMessages.value = _chatMessages.value + botMsg
        return botReplyText
    }
}
