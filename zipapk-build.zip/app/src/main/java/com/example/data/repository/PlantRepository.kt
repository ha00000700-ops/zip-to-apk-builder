package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.CareTaskEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.DiagnosisEntity
import com.example.data.local.IssueReportEntity
import com.example.data.local.PlantEntity
import com.example.data.local.PlantGrowthEntryEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class PlantRepository(private val database: AppDatabase) {
    private val plantDao = database.plantDao()
    private val diagnosisDao = database.diagnosisDao()
    private val careTaskDao = database.careTaskDao()
    private val chatMessageDao = database.chatMessageDao()
    private val plantGrowthDao = database.plantGrowthDao()
    private val issueReportDao = database.issueReportDao()

    // Plants
    fun getAllPlants(): Flow<List<PlantEntity>> = plantDao.getAllPlants()

    suspend fun getPlantById(id: Long): PlantEntity? = plantDao.getPlantById(id)

    suspend fun insertPlant(plant: PlantEntity): Long {
        val plantId = plantDao.insertPlant(plant)
        // Automatically schedule initial care tasks
        val now = System.currentTimeMillis()
        val oneDayMillis = 24 * 60 * 60 * 1000L

        careTaskDao.insertTask(
            CareTaskEntity(
                plantId = plantId,
                plantName = plant.name,
                taskType = "ري",
                dueDate = now + (plant.wateringIntervalDays * oneDayMillis),
                notes = "سقاية معتدلة وتفقد رطوبة التربة أولاً"
            )
        )
        careTaskDao.insertTask(
            CareTaskEntity(
                plantId = plantId,
                plantName = plant.name,
                taskType = "تسميد",
                dueDate = now + (plant.fertilizingIntervalDays * oneDayMillis),
                notes = "تسميد متوازن NPK مخفف"
            )
        )
        careTaskDao.insertTask(
            CareTaskEntity(
                plantId = plantId,
                plantName = plant.name,
                taskType = "فحص وقائي",
                dueDate = now + (7 * oneDayMillis),
                notes = "فحص أسفل الأوراق للتأكد من خلوها من الحشرات أو البقع الفطرية"
            )
        )
        return plantId
    }

    suspend fun updatePlant(plant: PlantEntity) = plantDao.updatePlant(plant)

    suspend fun deletePlant(plant: PlantEntity) = plantDao.deletePlant(plant)

    // Diagnoses
    fun getAllDiagnoses(): Flow<List<DiagnosisEntity>> = diagnosisDao.getAllDiagnoses()

    fun getRecentDiagnoses(limit: Int = 5): Flow<List<DiagnosisEntity>> = diagnosisDao.getRecentDiagnoses(limit)

    fun getDiagnosesForPlant(plantId: Long): Flow<List<DiagnosisEntity>> = diagnosisDao.getDiagnosesForPlant(plantId)

    fun getDiagnosesByPlantName(plantName: String): Flow<List<DiagnosisEntity>> = diagnosisDao.getDiagnosesByPlantName(plantName)

    suspend fun getDiagnosisById(id: Long): DiagnosisEntity? = diagnosisDao.getDiagnosisById(id)

    suspend fun insertDiagnosis(diagnosis: DiagnosisEntity): Long = diagnosisDao.insertDiagnosis(diagnosis)

    suspend fun updateDiagnosis(diagnosis: DiagnosisEntity) = diagnosisDao.updateDiagnosis(diagnosis)

    suspend fun deleteDiagnosis(diagnosis: DiagnosisEntity) = diagnosisDao.deleteDiagnosis(diagnosis)

    // Care Tasks
    fun getPendingTasks(): Flow<List<CareTaskEntity>> = careTaskDao.getPendingTasks()

    fun getCompletedTasks(): Flow<List<CareTaskEntity>> = careTaskDao.getCompletedTasks()

    fun getTasksForPlant(plantId: Long): Flow<List<CareTaskEntity>> = careTaskDao.getTasksForPlant(plantId)

    suspend fun insertTask(task: CareTaskEntity): Long = careTaskDao.insertTask(task)

    suspend fun markTaskCompleted(taskId: Long) = careTaskDao.markTaskCompleted(taskId, System.currentTimeMillis())

    suspend fun deleteTask(task: CareTaskEntity) = careTaskDao.deleteTask(task)

    // Chat
    fun getAllChatMessages(): Flow<List<ChatMessageEntity>> = chatMessageDao.getAllMessages()

    fun getMessagesForPlant(plantId: Long): Flow<List<ChatMessageEntity>> = chatMessageDao.getMessagesForPlant(plantId)

    suspend fun insertChatMessage(message: ChatMessageEntity): Long = chatMessageDao.insertMessage(message)

    suspend fun clearChat() = chatMessageDao.clearHistory()

    // Plant Growth Journal
    fun getGrowthEntriesForPlant(plantId: Long): Flow<List<PlantGrowthEntryEntity>> = plantGrowthDao.getGrowthEntriesForPlant(plantId)

    suspend fun insertGrowthEntry(entry: PlantGrowthEntryEntity): Long = plantGrowthDao.insertGrowthEntry(entry)

    suspend fun deleteGrowthEntry(entry: PlantGrowthEntryEntity) = plantGrowthDao.deleteGrowthEntry(entry)

    // Issue Reports
    suspend fun insertIssueReport(report: IssueReportEntity): Long = issueReportDao.insertReport(report)

    fun getAllIssueReports(): Flow<List<IssueReportEntity>> = issueReportDao.getAllReports()

    // Keep database clean of fake demo data; only real user records are stored
    suspend fun seedInitialDataIfEmpty() {
        // No-op: Database remains pristine and empty until the user creates real records
    }
}
