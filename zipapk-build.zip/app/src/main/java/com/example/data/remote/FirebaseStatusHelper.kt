package com.example.data.remote

import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseStatusHelper {
    private const val TAG = "KhedmatiFirebase"

    fun isFirebaseInitialized(): Boolean {
        return try {
            FirebaseApp.getApps(FirebaseApp.getInstance().applicationContext).isNotEmpty()
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseApp check: ${e.message}")
            false
        }
    }

    fun getFirebaseAuth(): FirebaseAuth? {
        return try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get FirebaseAuth instance: ${e.message}")
            null
        }
    }

    fun getFirestore(): FirebaseFirestore? {
        return try {
            FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get FirebaseFirestore instance: ${e.message}")
            null
        }
    }

    fun translateFirebaseError(exception: Throwable?): String {
        if (exception == null) return "حدث خطأ غير متوقع، يرجى المحاولة لاحقاً"

        val message = exception.message ?: ""
        val localizedMessage = (exception as? FirebaseAuthException)?.errorCode ?: ""

        return when {
            localizedMessage.contains("ERROR_EMAIL_ALREADY_IN_USE", ignoreCase = true) ||
            message.contains("email address is already in use", ignoreCase = true) ->
                "البريد الإلكتروني مسجل مسبقاً، يرجى تسجيل الدخول أو استخدام بريد آخر"

            localizedMessage.contains("ERROR_WRONG_PASSWORD", ignoreCase = true) ||
            localizedMessage.contains("ERROR_INVALID_CREDENTIAL", ignoreCase = true) ||
            message.contains("invalid-credential", ignoreCase = true) ||
            message.contains("wrong-password", ignoreCase = true) ->
                "البريد الإلكتروني أو كلمة المرور غير صحيحة"

            localizedMessage.contains("ERROR_USER_NOT_FOUND", ignoreCase = true) ||
            message.contains("user-not-found", ignoreCase = true) ->
                "لا يوجد حساب مسجل بهذا البريد الإلكتروني"

            localizedMessage.contains("ERROR_WEAK_PASSWORD", ignoreCase = true) ||
            message.contains("weak-password", ignoreCase = true) ->
                "كلمة المرور ضعيفة جداً، يرجى إدخال 6 أحرف أو أرقام على الأقل"

            localizedMessage.contains("ERROR_INVALID_EMAIL", ignoreCase = true) ||
            message.contains("invalid-email", ignoreCase = true) ->
                "صيغة البريد الإلكتروني غير صحيحة"

            localizedMessage.contains("ERROR_USER_DISABLED", ignoreCase = true) ||
            message.contains("user-disabled", ignoreCase = true) ->
                "هذا الحساب تم تعطيله مؤقتاً، يرجى التواصل مع إدارة خدمتي"

            localizedMessage.contains("ERROR_TOO_MANY_REQUESTS", ignoreCase = true) ||
            message.contains("too-many-requests", ignoreCase = true) ->
                "تم تجاوز عدد المحاولات المسموح بها، يرجى الانتظار دقيقة ثم إعادة المحاولة"

            message.contains("network", ignoreCase = true) ||
            message.contains("timeout", ignoreCase = true) ||
            message.contains("UNAVAILABLE", ignoreCase = true) ->
                "تعذر الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت"

            message.contains("PERMISSION_DENIED", ignoreCase = true) ||
            message.contains("permission-denied", ignoreCase = true) ->
                "لا تملك الصلاحية للقيام بهذه العملية (Firestore Rules)"

            message.contains("FirebaseApp", ignoreCase = true) ||
            message.contains("google-services.json", ignoreCase = true) ||
            message.contains("Default FirebaseApp is not initialized", ignoreCase = true) ->
                "تنبيه: يلزم إضافة ملف إعدادات Firebase (google-services.json) لتفعيل المزامنة المباشرة"

            else ->
                "فشلت العملية: ${exception.localizedMessage ?: "يرجى التحقق من البيانات والمحاولة مجدداً"}"
        }
    }
}
