package com.example.data.model

object ReportStatus {
    const val PENDING = "PENDING"
    const val IN_REVIEW = "IN_REVIEW"
    const val RESOLVED = "RESOLVED"
    const val DISMISSED = "DISMISSED"
}

object ReportType {
    const val USER = "USER"
    const val SERVICE_PROVIDER = "SERVICE_PROVIDER"
    const val SERVICE_REQUEST = "SERVICE_REQUEST"
    const val REVIEW = "REVIEW"
    const val OTHER = "OTHER"
}

data class Report(
    val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val reporterRole: String = "",
    val reportedUserId: String = "",
    val reportedUserName: String = "",
    val reportedUserRole: String = "",
    val type: String = ReportType.USER, // USER, SERVICE_PROVIDER, SERVICE_REQUEST, REVIEW, OTHER
    val targetId: String = "", // requestId or reviewId or userUid
    val reason: String = "",
    val details: String = "",
    val status: String = ReportStatus.PENDING, // PENDING, IN_REVIEW, RESOLVED, DISMISSED
    val adminNotes: String = "",
    val reviewedBy: String = "",
    val reviewedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "reporterId" to reporterId,
            "reporterName" to reporterName,
            "reporterRole" to reporterRole,
            "reportedUserId" to reportedUserId,
            "reportedUserName" to reportedUserName,
            "reportedUserRole" to reportedUserRole,
            "type" to type,
            "targetId" to targetId,
            "reason" to reason,
            "details" to details,
            "status" to status,
            "adminNotes" to adminNotes,
            "reviewedBy" to reviewedBy,
            "reviewedAt" to reviewedAt,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): Report {
            return Report(
                id = map["id"] as? String ?: "",
                reporterId = map["reporterId"] as? String ?: "",
                reporterName = map["reporterName"] as? String ?: "",
                reporterRole = map["reporterRole"] as? String ?: "",
                reportedUserId = map["reportedUserId"] as? String ?: "",
                reportedUserName = map["reportedUserName"] as? String ?: "",
                reportedUserRole = map["reportedUserRole"] as? String ?: "",
                type = map["type"] as? String ?: ReportType.USER,
                targetId = map["targetId"] as? String ?: "",
                reason = map["reason"] as? String ?: "",
                details = map["details"] as? String ?: "",
                status = map["status"] as? String ?: ReportStatus.PENDING,
                adminNotes = map["adminNotes"] as? String ?: "",
                reviewedBy = map["reviewedBy"] as? String ?: "",
                reviewedAt = (map["reviewedAt"] as? Number)?.toLong(),
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
