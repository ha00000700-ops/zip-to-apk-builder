package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val wilayaCode: Int = 16, // Default: 16 - Alger
    val wilayaName: String = "الجزائر",
    val communeName: String = "الجزائر الوسطى",
    val avatarUrl: String = "",
    val fcmToken: String = "",
    val isPhoneVerified: Boolean = false,
    val isRestricted: Boolean = false,
    val restrictionUntil: Long = 0L,
    val isDeleted: Boolean = false,
    val subscription: UserSubscription = UserSubscription(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun resolvedAvatarUrl(): String {
        val resolved = com.example.data.remote.SupabaseConfig.resolveUrl(avatarUrl)
        if (resolved.isBlank()) return ""
        return "$resolved?t=$updatedAt"
    }
    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "uid" to uid,
            "fullName" to fullName,
            "email" to email,
            "phone" to phone,
            "role" to role.code,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "avatarUrl" to avatarUrl,
            "fcmToken" to fcmToken,
            "isPhoneVerified" to isPhoneVerified,
            "isRestricted" to isRestricted,
            "restrictionUntil" to restrictionUntil,
            "isDeleted" to isDeleted,
            "subscription" to subscription.toMap(),
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): UserProfile {
            return UserProfile(
                uid = map["uid"] as? String ?: "",
                fullName = map["fullName"] as? String ?: "",
                email = map["email"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                role = UserRole.fromCode(map["role"] as? String),
                wilayaCode = (map["wilayaCode"] as? Number)?.toInt() ?: 16,
                wilayaName = map["wilayaName"] as? String ?: "الجزائر",
                communeName = map["communeName"] as? String ?: "الجزائر الوسطى",
                avatarUrl = map["avatarUrl"] as? String ?: "",
                fcmToken = map["fcmToken"] as? String ?: "",
                isPhoneVerified = map["isPhoneVerified"] as? Boolean ?: false,
                isRestricted = map["isRestricted"] as? Boolean ?: false,
                restrictionUntil = (map["restrictionUntil"] as? Number)?.toLong() ?: 0L,
                isDeleted = map["isDeleted"] as? Boolean ?: false,
                subscription = UserSubscription.fromMap(map["subscription"] as? Map<String, Any?>),
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
