package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val wilayaCode: Int = 16, // Default: 16 - Alger
    val wilayaName: String = "الجزائر",
    val communeName: String = "الجزائر الوسطى",
    val avatarUrl: String = "",
    val fcmToken: String = "",
    val isPhoneVerified: Boolean = false,
    val isRestricted: Boolean = false,
    val restrictionUntil: Long = 0L,
    val isDeleted: Boolean = false,
    val subscription: UserSubscription = UserSubscription(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun resolvedAvatarUrl(): String {
        val resolved = com.example.data.remote.SupabaseConfig.resolveUrl(avatarUrl)
        if (resolved.isBlank()) return ""
        return "$resolved?t=$updatedAt"
    }
    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "uid" to uid,
            "fullName" to fullName,
            "email" to email,
            "phone" to phone,
            "role" to role.code,
            "wilayaCode" to wilayaCode,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "avatarUrl" to avatarUrl,
            "fcmToken" to fcmToken,
            "isPhoneVerified" to isPhoneVerified,
            "isRestricted" to isRestricted,
            "restrictionUntil" to restrictionUntil,
            "isDeleted" to isDeleted,
            "subscription" to subscription.toMap(),
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        private fun parseLongValue(value: Any?): Long {
            return when (value) {
                is Number -> value.toLong()
                is String -> value.toLongOrNull() ?: 0L
                is com.google.firebase.Timestamp -> value.toDate().time
                is java.util.Date -> value.time
                else -> 0L
            }
        }

        fun fromFirestoreMap(map: Map<String, Any?>): UserProfile {
            val nestedSubMap = map["subscription"] as? Map<String, Any?>
            val parsedNestedSub = if (nestedSubMap != null) UserSubscription.fromMap(nestedSubMap) else null

            val subscription = if (parsedNestedSub != null && parsedNestedSub.isSubscribed) {
                parsedNestedSub
            } else {
                val flatSub = UserSubscription.fromMap(map)
                if (flatSub.isSubscribed) flatSub else (parsedNestedSub ?: flatSub)
            }

            return UserProfile(
                uid = map["uid"] as? String ?: "",
                fullName = map["fullName"] as? String ?: "",
                email = map["email"] as? String ?: "",
                phone = map["phone"] as? String ?: "",
                role = UserRole.fromCode(map["role"] as? String),
                wilayaCode = (map["wilayaCode"] as? Number)?.toInt() ?: 16,
                wilayaName = map["wilayaName"] as? String ?: "الجزائر",
                communeName = map["communeName"] as? String ?: "الجزائر الوسطى",
                avatarUrl = map["avatarUrl"] as? String ?: "",
                fcmToken = map["fcmToken"] as? String ?: "",
                isPhoneVerified = map["isPhoneVerified"] as? Boolean ?: false,
                isRestricted = map["isRestricted"] as? Boolean ?: false,
                restrictionUntil = parseLongValue(map["restrictionUntil"]),
                isDeleted = map["isDeleted"] as? Boolean ?: false,
                subscription = subscription,
                createdAt = parseLongValue(map["createdAt"]).takeIf { it > 0 } ?: System.currentTimeMillis(),
                updatedAt = parseLongValue(map["updatedAt"]).takeIf { it > 0 } ?: System.currentTimeMillis()
            )
        }
    }
}
