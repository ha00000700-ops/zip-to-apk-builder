package com.example.data

import android.content.Context
import com.example.R
import com.example.data.db.AppDatabase
import com.example.data.db.Bookmark
import com.example.data.db.LastRead
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.InputStreamReader

class QuranRepository(private val context: Context) {
    private val quranDao = AppDatabase.getDatabase(context).quranDao()
    
    private var cachedSurahs: List<Surah>? = null

    suspend fun getSurahs(): List<Surah> = withContext(Dispatchers.IO) {
        if (cachedSurahs != null) return@withContext cachedSurahs!!

        try {
            val inputStream = context.resources.openRawResource(R.raw.quran_data)
            val jsonString = InputStreamReader(inputStream, "UTF-8").readText()
            val jsonArray = JSONArray(jsonString)
            
            val surahs = mutableListOf<Surah>()
            for (i in 0 until jsonArray.length()) {
                val surahObj = jsonArray.getJSONObject(i)
                
                val ayahsArray = surahObj.getJSONArray("ayahs")
                val ayahs = mutableListOf<Ayah>()
                for (j in 0 until ayahsArray.length()) {
                    val ayahObj = ayahsArray.getJSONObject(j)
                    ayahs.add(
                        Ayah(
                            numberInSurah = ayahObj.getInt("numberInSurah"),
                            text = ayahObj.getString("text"),
                            page = ayahObj.getInt("page"),
                            juz = ayahObj.getInt("juz")
                        )
                    )
                }
                
                surahs.add(
                    Surah(
                        number = surahObj.getInt("number"),
                        name = surahObj.getString("name"),
                        revelationType = surahObj.getString("revelationType"),
                        numberOfAyahs = surahObj.getInt("numberOfAyahs"),
                        ayahs = ayahs
                    )
                )
            }
            cachedSurahs = surahs
            return@withContext surahs
        } catch (e: Exception) {
            e.printStackTrace()
            return@withContext emptyList()
        }
    }

    suspend fun getSurah(surahNumber: Int): Surah? {
        val surahs = getSurahs()
        return surahs.find { it.number == surahNumber }
    }
    
    suspend fun search(query: String): List<AyahSearchResult> {
        val surahs = getSurahs()
        val results = mutableListOf<AyahSearchResult>()
        for (surah in surahs) {
            // Search in surah name
            if (surah.name.contains(query)) {
                results.add(AyahSearchResult(surah, surah.ayahs.first()))
                continue
            }
            
            // Search in ayahs
            for (ayah in surah.ayahs) {
                // simple exact text search
                val cleanText = ayah.text.replace(Regex("[\\u0617-\\u061A\\u064B-\\u0652]"), "") // very basic diacritics removal
                val cleanQuery = query.replace(Regex("[\\u0617-\\u061A\\u064B-\\u0652]"), "")
                
                if (ayah.text.contains(query) || cleanText.contains(cleanQuery) || ayah.numberInSurah.toString() == query) {
                    results.add(AyahSearchResult(surah, ayah))
                }
            }
        }
        return results
    }

    // Database operations
    fun getAllBookmarks(): Flow<List<Bookmark>> = quranDao.getAllBookmarks()
    
    suspend fun toggleBookmark(surahNumber: Int, surahName: String, ayahNumber: Int, textSnippet: String, isBookmarked: Boolean) {
        if (isBookmarked) {
            quranDao.deleteBookmark(surahNumber, ayahNumber)
        } else {
            quranDao.insertBookmark(Bookmark(surahNumber = surahNumber, surahName = surahName, ayahNumber = ayahNumber, textSnippet = textSnippet))
        }
    }
    
    fun isBookmarked(surahNumber: Int, ayahNumber: Int): Flow<Boolean> = quranDao.isBookmarked(surahNumber, ayahNumber)
    
    fun getLastRead(): Flow<LastRead?> = quranDao.getLastRead()
    
    suspend fun saveLastRead(surahNumber: Int, surahName: String, ayahNumber: Int) {
        quranDao.saveLastRead(LastRead(surahNumber = surahNumber, surahName = surahName, ayahNumber = ayahNumber))
    }
}

data class AyahSearchResult(
    val surah: Surah,
    val ayah: Ayah
)
