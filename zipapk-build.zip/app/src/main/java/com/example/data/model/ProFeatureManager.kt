package com.example.data.model

enum class ProFeature(
    val titleAr: String,
    val descriptionAr: String
) {
    PRIORITY_SEARCH(
        titleAr = "أولوية الظهور في نتائج البحث",
        descriptionAr = "الظهور في صدارة قائمة الحرفيين للزبائن في ولايتك ومدينتك"
    ),
    PROFILE_PROMOTION(
        titleAr = "ترقية وتأطير الملف المهني",
        descriptionAr = "شارات تميز ذهبية وغلاف جذّاب لجذب أكبر عدد من طلبات الخدمة"
    ),
    ADVANCED_STATS(
        titleAr = "إحصائيات وتحليلات متقدمة",
        descriptionAr = "متابعة عدد مشاهدات ملفك والتفاعلات ونسبة قبول العروض ومعدل النمو"
    ),
    LARGER_PORTFOLIO(
        titleAr = "معرض أعمال غير محدود",
        descriptionAr = "إضافة وتوثيق صور وأعمال متعددة لإبراز جودة خبراتك المهنية"
    ),
    ADVANCED_LOCATION_TOOLS(
        titleAr = "أدوات الطلبات الجغرافية المتقدمة",
        descriptionAr = "تصفية ونظام إشعارات دقيق للطلبات حسب المسافة والنطاق الجغرافي"
    ),
    FEATURED_PROVIDERS_SECTION(
        titleAr = "الظهور في قسم الحرفيين المميزين",
        descriptionAr = "عرض ملفك الشخصي في الواجهة الرئيسية للتطبيق لجميع الزبائن"
    )
}

object ProFeatureManager {
    /**
     * CURRENT STATUS: Feature gating is completely DISABLED.
     * All features remain 100% free and accessible for all users and craftsmen.
     */
    const val IS_FEATURE_GATING_ENABLED = false

    /**
     * Checks if a specific feature is available for the given user profile.
     * Currently always returns true to ensure every feature is free.
     */
    fun isFeatureAvailable(userProfile: UserProfile?, feature: ProFeature): Boolean {
        if (!IS_FEATURE_GATING_ENABLED) return true
        return userProfile?.subscription?.isProActive == true
    }
}
