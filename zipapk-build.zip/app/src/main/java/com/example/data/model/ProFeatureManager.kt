package com.example.data.model

enum class ProFeature(
    val titleAr: String,
    val descriptionAr: String,
    val minimumTierLevel: Int = 1 // 1: BASIC+, 2: STANDARD+, 3: PREMIUM
) {
    RECEIVE_REQUESTS(
        titleAr = "استقبال طلبات الخدمة المباشرة",
        descriptionAr = "إمكانية استقبال طلبات الزبائن والرد بالعروض",
        minimumTierLevel = 0
    ),
    STANDARD_SEARCH_VISIBILITY(
        titleAr = "الظهور الأساسي في البحث",
        descriptionAr = "ظهور الملف المهني في قائمة الحرفيين حسب الولاية والمهنة",
        minimumTierLevel = 1
    ),
    HIGHER_SEARCH_RANKING(
        titleAr = "ترتيب متقدم في نتائج البحث",
        descriptionAr = "الظهور قبل الحرفيين بالخطة الأساسية في نتائج البحث",
        minimumTierLevel = 2
    ),
    STANDARD_BADGE(
        titleAr = "شارة الحرفي القياسي المعتمد",
        descriptionAr = "شارة فضية تؤكد اعتماد حسابك وجدارتك",
        minimumTierLevel = 2
    ),
    PRIORITY_SEARCH(
        titleAr = "أولوية الظهور القصوى في نتائج البحث",
        descriptionAr = "الظهور في صدارة قائمة الحرفيين للزبائن في ولايتك ومدينتك",
        minimumTierLevel = 3
    ),
    PREMIUM_BADGE(
        titleAr = "شارة التميز الذهبية",
        descriptionAr = "شارة تميز ذهبية تمنحك أعلى موثوقية وتجذب أكبر عدد من طلبات الخدمة",
        minimumTierLevel = 3
    ),
    PROFILE_PROMOTION(
        titleAr = "ترقية وتأطير الملف المهني",
        descriptionAr = "شارات تميز وغلاف جذّاب لجذب أكبر عدد من طلبات الخدمة",
        minimumTierLevel = 3
    ),
    ADVANCED_STATS(
        titleAr = "إحصائيات وتحليلات متقدمة",
        descriptionAr = "متابعة عدد مشاهدات ملفك والتفاعلات ونسبة قبول العروض ومعدل النمو",
        minimumTierLevel = 3
    ),
    LARGER_PORTFOLIO(
        titleAr = "معرض أعمال غير محدود",
        descriptionAr = "إضافة وتوثيق صور وأعمال متعددة لإبراز جودة خبراتك المهنية",
        minimumTierLevel = 2
    ),
    ADVANCED_LOCATION_TOOLS(
        titleAr = "أدوات الطلبات الجغرافية المتقدمة",
        descriptionAr = "تصفية ونظام إشعارات دقيق للطلبات حسب المسافة والنطاق الجغرافي",
        minimumTierLevel = 2
    ),
    FEATURED_PROVIDERS_SECTION(
        titleAr = "الظهور في قسم الحرفيين المميزين",
        descriptionAr = "عرض ملفك الشخصي في الواجهة الرئيسية للتطبيق لجميع الزبائن",
        minimumTierLevel = 3
    )
}

object ProFeatureManager {
    /**
     * Feature gating status: ENABLED.
     * Tier hierarchy:
     * - FREE: Basic free features (0)
     * - BASIC (500 DZD): Basic marketplace access & standard visibility (1)
     * - STANDARD (1000 DZD): Basic + Standard visibility, higher ranking, and standard badge (2)
     * - PREMIUM (1500 DZD): Basic + Standard + Highest priority ranking, premium badge, advanced stats & featured placement (3)
     */
    // Gating disabled during Free Trial Mode so early users can access all advanced features
    const val IS_FEATURE_GATING_ENABLED = false

    /**
     * Checks if a specific feature is available for the given user profile.
     */
    fun isFeatureAvailable(userProfile: UserProfile?, feature: ProFeature): Boolean {
        if (!IS_FEATURE_GATING_ENABLED) return true
        val tier = userProfile?.subscription?.tierLevel ?: 0
        return tier >= feature.minimumTierLevel
    }

    /**
     * Checks if a user profile has at least a specific subscription tier level.
     */
    fun hasTier(userProfile: UserProfile?, requiredTierLevel: Int): Boolean {
        val tier = userProfile?.subscription?.tierLevel ?: 0
        return tier >= requiredTierLevel
    }
}
