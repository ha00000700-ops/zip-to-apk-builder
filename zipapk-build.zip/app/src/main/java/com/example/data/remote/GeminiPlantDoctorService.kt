package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.data.local.ApiKeyManager
import com.example.data.model.ChatMessage
import com.example.data.model.MedicineItem
import com.example.data.model.OrganicItem
import com.example.data.model.PlantDiagnosis
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiKeyMissingException(message: String) : Exception(message)
class NotAPlantException(message: String) : Exception(message)
class DiagnosisException(message: String) : Exception(message)

class GeminiPlantDoctorService(context: Context) {

    private val apiKeyManager = ApiKeyManager(context)

    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    // Supported modern models to try in priority order
    private val candidateModels = listOf("gemini-2.5-flash", "gemini-3.5-flash", "gemini-flash-latest")

    private fun Bitmap.toBase64(): String {
        val maxDimension = 1024
        val scale = if (width > maxDimension || height > maxDimension) {
            val max = maxOf(width, height)
            maxDimension.toFloat() / max
        } else {
            1.0f
        }
        val scaled = if (scale < 1.0f) {
            Bitmap.createScaledBitmap(this, (width * scale).toInt(), (height * scale).toInt(), true)
        } else {
            this
        }
        val outputStream = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun diagnosePlant(bitmap: Bitmap, imageUriString: String? = null): PlantDiagnosis = withContext(Dispatchers.IO) {
        val apiKey = apiKeyManager.getApiKey()
        if (apiKey.isBlank()) {
            throw ApiKeyMissingException("مفتاح الذكاء الاصطناعي (Gemini API Key) غير مضبوط.\nيرجى إدخال مفتاحك المجاني في الإعدادات لإجراء فحص حقيقي ودقيق لصورتك.")
        }

        val base64Image = bitmap.toBase64()
        val promptText = """
            أنت خبير علم أمراض النباتات الزراعية (Plant Pathologist) وطبيب نباتات محترف.
            افحص الصورة المرفقة فحصاً حقيقياً دقيقاً جداً:
            1. أولاً: تحقق ما إذا كانت الصورة المرفقة تحتوي على نبات، ورقة نباتية، ساق، زهرة، أو ثمرة.
               إذا كانت الصورة لا تحتوي على نبات نهائياً (مثل وجه، سيارة، جماد، أثاث، إلخ)، أرجع JSON فقط بالشكل:
               {"isPlant": false, "errorMessage": "الصورة المرفوعة لا تحتوي على نبات أو ورقة زراعية. يرجى تصوير نبات حقيقي لإجراء الفحص الطبي."}
            2. ثانياً: إذا كانت الصورة لنبات، قم بتشخيص حالته الواقعية بناءً على ما تراه بالضبط في الصورة:
               - هل هو سليم أم مصاب؟
               - ما اسم النبتة العلمي والشائع؟
               - ما هو اسم المرض أو الآفة بدقة (فطري، بكتيري، حشري، نقص عناصر مثل الحديد/النيتروجين، أو تعفن، أو سليم)؟
               - حدد مستوى الخطورة بدقة (سليم، خفيف، متوسط، حرج) ونسبة الثقة في التشخيص.
               - اذكر الأعراض الدقيقة الظاهرة في الصورة، وأسبابها العلمية.
               - اذكر الأدوية والمبيدات الكيميائية المعتمدة المناسبة بالاسم التجاري الشائع، المادة الفعالة، الجرعة وطريقة الرش لكل لتر ماء، ومحاذير الاستخدام وأيام فترة الأمان (PHI).
               - اذكر العلاجات العضوية والطبيعية والمنزلية الفعالة (مثل زيت النيم، بيكربونات الصوديوم، الصابون البوتاسي، الكومبوست، الثوم) مع طريقة التحضير والفوائد.
               - اذكر إرشادات الرعاية الفورية لمنع تفاقم الإصابة، وخطوات الوقاية لحماية بقية المزروعات.
            
            يجب أن يكون الناتج نص JSON حصراً بدون أي مقدمة أو خاتمة أو نص خارج الـ JSON:
            {
              "isPlant": true,
              "plantName": "اسم النبتة العلمي والشائع",
              "commonName": "الاسم الشائع للنبات",
              "isHealthy": false,
              "diseaseName": "Scientific Disease Name in English",
              "diseaseNameArabic": "اسم المرض أو الآفة بالعربية",
              "confidenceScore": 0.95,
              "severity": "متوسط",
              "symptoms": ["عرض 1", "عرض 2"],
              "causes": ["سبب 1", "سبب 2"],
              "chemicalMedicines": [
                {
                  "tradeName": "اسم الدواء أو المبيد التجاري المعتمد",
                  "activeIngredient": "المادة الفعالة وتركيزها",
                  "dosage": "الجرعة الدقيقة لكل لتر ماء وطريقة الاستخدام",
                  "precautions": "محاذير الاستخدام وفترة الأمان قبل الحصاد"
                }
              ],
              "organicTreatments": [
                {
                  "name": "اسم العلاج العضوي أو الطبيعي",
                  "preparation": "طريقة التحضير والنسب الدقيقة",
                  "benefits": "الفائدة والآلية"
                }
              ],
              "careTips": ["نصيحة ري أو إضاءة", "نصيحة تقليم وعزل"],
              "preventionSteps": ["خطوة وقائية 1", "خطوة وقائية 2"]
            }
        """.trimIndent()

        val requestJson = JSONObject().apply {
            val contentsArray = JSONArray().apply {
                val contentObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().put("text", promptText))
                        val inlineData = JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", base64Image)
                        }
                        put(JSONObject().put("inlineData", inlineData))
                    }
                    put("parts", partsArray)
                }
                put(contentObj)
            }
            put("contents", contentsArray)

            val generationConfig = JSONObject().apply {
                put("temperature", 0.1)
                put("responseMimeType", "application/json")
            }
            put("generationConfig", generationConfig)
        }

        var lastErrorMessage = ""

        // Try supported models until one succeeds
        for (model in candidateModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestJson.toString().toRequestBody(jsonMediaType))
                .build()

            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val diagnosis = parseDiagnosisJson(responseBody, imageUriString)
                    if (diagnosis != null) {
                        return@withContext diagnosis
                    }
                } else {
                    val errorDetail = parseErrorMessage(responseBody, response.code)
                    lastErrorMessage = errorDetail
                    Log.e("GeminiPlantDoctor", "Model $model failed: $errorDetail")
                    // If error is 404, try next candidate model; if 400/403 (bad key), break and throw
                    if (response.code == 400 || response.code == 403) {
                        throw DiagnosisException("مفتاح API غير صالح أو غير مفعل:\n$errorDetail")
                    }
                }
            } catch (e: NotAPlantException) {
                throw e
            } catch (e: DiagnosisException) {
                throw e
            } catch (e: Exception) {
                Log.e("GeminiPlantDoctor", "Call failed on $model", e)
                lastErrorMessage = e.localizedMessage ?: "فشل الاتصال بالخادم"
            }
        }

        throw DiagnosisException("فشل إجراء الفحص عبر الذكاء الاصطناعي:\n$lastErrorMessage\nيرجى التأكد من اتصال الإنترنت وصلاحية مفتاح Gemini API.")
    }

    private fun parseDiagnosisJson(responseBody: String, imageUriString: String?): PlantDiagnosis? {
        try {
            val root = JSONObject(responseBody)
            val candidates = root.optJSONArray("candidates") ?: return null
            val firstCandidate = candidates.optJSONObject(0) ?: return null
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val textPart = parts.optJSONObject(0) ?: return null
            var text = textPart.optString("text")

            if (text.startsWith("```json")) {
                text = text.removePrefix("```json").removeSuffix("```").trim()
            } else if (text.startsWith("```")) {
                text = text.removePrefix("```").removeSuffix("```").trim()
            }

            val data = JSONObject(text)

            // Check if AI detected that image is NOT a plant
            if (data.has("isPlant") && !data.optBoolean("isPlant", true)) {
                val errMsg = data.optString("errorMessage", "الصورة المرفوعة ليست لنبات أو ورقة زراعية. يرجى تصوير نبات حقيقي لإجراء الفحص الطبي.")
                throw NotAPlantException(errMsg)
            }

            val isHealthy = data.optBoolean("isHealthy", false)
            val plantName = data.optString("plantName", "نبات تم فحصه بالذكاء الاصطناعي")
            val commonName = data.optString("commonName", "نبات زراعي/منزلي")
            val diseaseName = data.optString("diseaseName", if (isHealthy) "Healthy Plant" else "Plant Pathology Issue")
            val diseaseNameArabic = data.optString("diseaseNameArabic", if (isHealthy) "نبات سليم ومعافى" else "إصابة نباتية مشخصة")
            val confidence = data.optDouble("confidenceScore", 0.94).toFloat()
            val severity = data.optString("severity", if (isHealthy) "سليم" else "متوسط")

            val symptoms = mutableListOf<String>()
            val symptomsArray = data.optJSONArray("symptoms")
            if (symptomsArray != null) {
                for (i in 0 until symptomsArray.length()) {
                    symptoms.add(symptomsArray.getString(i))
                }
            }

            val causes = mutableListOf<String>()
            val causesArray = data.optJSONArray("causes")
            if (causesArray != null) {
                for (i in 0 until causesArray.length()) {
                    causes.add(causesArray.getString(i))
                }
            }

            val chemicalMedicines = mutableListOf<MedicineItem>()
            val chemArray = data.optJSONArray("chemicalMedicines")
            if (chemArray != null) {
                for (i in 0 until chemArray.length()) {
                    val m = chemArray.optJSONObject(i)
                    if (m != null) {
                        chemicalMedicines.add(
                            MedicineItem(
                                tradeName = m.optString("tradeName", "مبيد علاجي مرخص"),
                                activeIngredient = m.optString("activeIngredient", "مادة علاجية فعالة"),
                                dosage = m.optString("dosage", "يخلط بالماء حسب إرشادات النشرة"),
                                precautions = m.optString("precautions", "يرش في الصباح الباكر وتجنب الحرارة العالية")
                            )
                        )
                    }
                }
            }

            val organicTreatments = mutableListOf<OrganicItem>()
            val orgArray = data.optJSONArray("organicTreatments")
            if (orgArray != null) {
                for (i in 0 until orgArray.length()) {
                    val o = orgArray.optJSONObject(i)
                    if (o != null) {
                        organicTreatments.add(
                            OrganicItem(
                                name = o.optString("name", "علاج عضوي طبيعي"),
                                preparation = o.optString("preparation", "تحضير محلول رش مخفف"),
                                benefits = o.optString("benefits", "يقوي مناعة النبات ويوقف تكاثر الممرضات")
                            )
                        )
                    }
                }
            }

            val careTips = mutableListOf<String>()
            val careArray = data.optJSONArray("careTips")
            if (careArray != null) {
                for (i in 0 until careArray.length()) {
                    careTips.add(careArray.getString(i))
                }
            }

            val preventionSteps = mutableListOf<String>()
            val prevArray = data.optJSONArray("preventionSteps")
            if (prevArray != null) {
                for (i in 0 until prevArray.length()) {
                    preventionSteps.add(prevArray.getString(i))
                }
            }

            return PlantDiagnosis(
                plantName = plantName,
                commonName = commonName,
                isHealthy = isHealthy,
                diseaseName = diseaseName,
                diseaseNameArabic = diseaseNameArabic,
                confidenceScore = confidence,
                severity = severity,
                symptoms = symptoms.ifEmpty { listOf("علامات ملحوظة على أنسجة الورقة المشخصة بالذكاء الاصطناعي") },
                causes = causes.ifEmpty { listOf("عوامل بيئية أو رطوبة زائدة أو إصابة ميكروبية") },
                chemicalMedicines = chemicalMedicines,
                organicTreatments = organicTreatments,
                careTips = careTips.ifEmpty { listOf("تعديل معدلات الري وضمان التهوية الجيدة للنبات") },
                preventionSteps = preventionSteps.ifEmpty { listOf("الفحص الدوري للأوراق وتعقيم مقصات التقليم") },
                imageUri = imageUriString,
                treatmentStatus = if (isHealthy) "سليم" else "تحت العلاج"
            )
        } catch (e: NotAPlantException) {
            throw e
        } catch (e: Exception) {
            Log.e("GeminiPlantDoctor", "JSON parse error", e)
            throw DiagnosisException("فشل قراءة استجابة الذكاء الاصطناعي: ${e.localizedMessage}")
        }
    }

    suspend fun askDoctorChat(
        conversationHistory: List<ChatMessage>,
        userPrompt: String,
        currentDiagnosis: PlantDiagnosis?
    ): String = withContext(Dispatchers.IO) {
        val apiKey = apiKeyManager.getApiKey()
        if (apiKey.isBlank()) {
            return@withContext "مفتاح الذكاء الاصطناعي غير مضبوط حالياً. يُرجى النقر على أيقونة المفتاح في الأعلى وإدخال مفتاح Gemini API لتفعيل المحادثة الحية المباشرة مع طبيب النباتات."
        }

        val systemPrompt = buildString {
            append("أنت 'طبيب النباتات الذكي' (Dr. Flora)، خبير متخصص في أمراض ووقاية النباتات، التسميد، والزراعة العضوية والمنزلية.\n")
            append("أجب دوماً بدقة علمية وبشكل مفصل وواضح باللغة العربية.\n")
            if (currentDiagnosis != null) {
                append("المستخدم يناقش معك حالياً نباتاً مفحوصاً حقيقياً:\n")
                append("- اسم النبات: ${currentDiagnosis.plantName} (${currentDiagnosis.commonName})\n")
                append("- التشخيص: ${currentDiagnosis.diseaseNameArabic} (${currentDiagnosis.diseaseName})\n")
                append("- الحالة: ${if (currentDiagnosis.isHealthy) "سليم" else "مصاب"} (مستوى الخطورة: ${currentDiagnosis.severity})\n")
                if (currentDiagnosis.chemicalMedicines.isNotEmpty()) {
                    append("- الأدوية المقترحة: ${currentDiagnosis.chemicalMedicines.joinToString { "${it.tradeName} (${it.dosage})" }}\n")
                }
            }
        }

        val contentsArray = JSONArray()

        val recentMessages = conversationHistory.takeLast(6)
        for (msg in recentMessages) {
            val role = if (msg.isFromUser) "user" else "model"
            contentsArray.put(JSONObject().apply {
                put("role", role)
                put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            })
        }

        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
        })

        val requestJson = JSONObject().apply {
            put("contents", contentsArray)
            val systemInstruction = JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            }
            put("systemInstruction", systemInstruction)
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 1000)
            })
        }

        for (model in candidateModels) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestJson.toString().toRequestBody(jsonMediaType))
                .build()

            try {
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val root = JSONObject(responseBody)
                    val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
                    val content = candidate?.optJSONObject("content")
                    val text = content?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    if (!text.isNullOrBlank()) {
                        return@withContext text.trim()
                    }
                }
            } catch (e: Exception) {
                Log.e("GeminiPlantDoctor", "Chat error on $model", e)
            }
        }

        return@withContext "تعذر الاتصال بخدمة الذكاء الاصطناعي حالياً. يرجى التحقق من اتصالك بالإنترنت وصلاحية مفتاح Gemini API."
    }

    private fun parseErrorMessage(responseBody: String, statusCode: Int): String {
        return try {
            val root = JSONObject(responseBody)
            val error = root.optJSONObject("error")
            val message = error?.optString("message") ?: "HTTP $statusCode"
            message
        } catch (e: Exception) {
            "HTTP $statusCode"
        }
    }
}
