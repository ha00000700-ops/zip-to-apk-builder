package com.example.data.model

data class Review(
    val id: String = "",
    val serviceRequestId: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val providerId: String = "",
    val rating: Int = 5,
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "serviceRequestId" to serviceRequestId,
            "customerId" to customerId,
            "customerName" to customerName,
            "providerId" to providerId,
            "rating" to rating,
            "comment" to comment,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): Review {
            return Review(
                id = map["id"] as? String ?: "",
                serviceRequestId = map["serviceRequestId"] as? String ?: "",
                customerId = map["customerId"] as? String ?: "",
                customerName = map["customerName"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                rating = (map["rating"] as? Number)?.toInt() ?: 5,
                comment = map["comment"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
