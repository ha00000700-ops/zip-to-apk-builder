package com.example.data.model

data class Review(
    val id: String = "",
    val serviceRequestId: String = "",
    val requestId: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val providerId: String = "",
    val rating: Int = 5,
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any> {
        val effectiveReqId = if (requestId.isNotBlank()) requestId else serviceRequestId
        return mapOf(
            "id" to id,
            "serviceRequestId" to effectiveReqId,
            "requestId" to effectiveReqId,
            "customerId" to customerId,
            "customerName" to customerName,
            "providerId" to providerId,
            "rating" to rating,
            "comment" to comment,
            "createdAt" to createdAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): Review {
            val reqId = map["requestId"] as? String ?: map["serviceRequestId"] as? String ?: ""
            return Review(
                id = map["id"] as? String ?: "",
                serviceRequestId = reqId,
                requestId = reqId,
                customerId = map["customerId"] as? String ?: "",
                customerName = map["customerName"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                rating = (map["rating"] as? Number)?.toInt() ?: 5,
                comment = map["comment"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
