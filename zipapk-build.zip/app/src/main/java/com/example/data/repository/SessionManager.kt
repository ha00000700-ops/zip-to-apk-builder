package com.example.data.repository

import com.example.data.local.KhdemliDatabase
import com.example.data.model.ProfessionalEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class SessionManager(private val database: KhdemliDatabase) {
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _currentProfessional = MutableStateFlow<ProfessionalEntity?>(null)
    val currentProfessional: StateFlow<ProfessionalEntity?> = _currentProfessional.asStateFlow()

    init {
        // Automatically initialize with Customer by default (Ahmed) or First User once seeded
        CoroutineScope(Dispatchers.IO).launch {
            try {
                database.userDao().getAllUsers().collect { users ->
                    if (_currentUser.value == null && users.isNotEmpty()) {
                        val defaultClient = users.find { it.id == 2L } ?: users.first()
                        _currentUser.value = defaultClient
                        checkAndLoadProfessionalProfile(defaultClient.id)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun loginWithPhone(phone: String): Boolean {
        val user = database.userDao().getUserByPhone(phone)
        if (user != null && !user.isBlocked) {
            _currentUser.value = user
            checkAndLoadProfessionalProfile(user.id)
            return true
        }
        return false
    }

    suspend fun loginAsUser(user: UserEntity) {
        if (!user.isBlocked) {
            _currentUser.value = user
            checkAndLoadProfessionalProfile(user.id)
        }
    }

    suspend fun registerCustomer(
        fullName: String,
        phone: String,
        email: String,
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String
    ): UserEntity {
        val existing = database.userDao().getUserByPhone(phone)
        if (existing != null) {
            _currentUser.value = existing
            return existing
        }
        val newUser = UserEntity(
            fullName = fullName,
            phone = phone,
            email = email,
            role = UserRole.CUSTOMER,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val id = database.userDao().insertUser(newUser)
        val created = newUser.copy(id = id)
        _currentUser.value = created
        _currentProfessional.value = null
        return created
    }

    suspend fun registerProfessional(
        fullName: String,
        phone: String,
        whatsapp: String,
        serviceCategoryId: Long,
        professionNameAr: String,
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String,
        experienceYears: Int,
        bio: String,
        workingHours: String,
        priceEstimate: String
    ): ProfessionalEntity {
        val user = UserEntity(
            fullName = fullName,
            phone = phone,
            role = UserRole.PROFESSIONAL,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val userId = database.userDao().insertUser(user)
        val fullUser = user.copy(id = userId)
        _currentUser.value = fullUser

        val pro = ProfessionalEntity(
            userId = userId,
            fullName = fullName,
            phone = phone,
            whatsapp = if (whatsapp.isNotBlank()) whatsapp else phone,
            serviceCategoryId = serviceCategoryId,
            professionNameAr = professionNameAr,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr,
            experienceYears = experienceYears,
            bio = bio,
            workingHours = workingHours,
            priceEstimate = priceEstimate,
            isAvailable = true,
            isVerified = false,
            isApprovedByAdmin = true, // By default enabled for smooth local UX
            ratingAverage = 5.0,
            ratingCount = 0,
            completedJobsCount = 0
        )
        val proId = database.professionalDao().insertProfessional(pro)
        val fullPro = pro.copy(id = proId)
        _currentProfessional.value = fullPro
        return fullPro
    }

    fun logout() {
        _currentUser.value = null
        _currentProfessional.value = null
    }

    suspend fun checkAndLoadProfessionalProfile(userId: Long?) {
        if (userId == null) {
            _currentProfessional.value = null
            return
        }
        val pro = database.professionalDao().getProfessionalByUserId(userId).firstOrNull()
        _currentProfessional.value = pro
    }

    fun isAdmin(): Boolean = _currentUser.value?.role == UserRole.ADMIN
    fun isProfessional(): Boolean = _currentUser.value?.role == UserRole.PROFESSIONAL || _currentProfessional.value != null
    fun isCustomer(): Boolean = _currentUser.value?.role == UserRole.CUSTOMER
}
