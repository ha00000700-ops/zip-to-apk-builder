package com.example.data.repository

import com.example.data.local.KhdemliDatabase
import com.example.data.model.ProfessionalEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class SessionManager(
    private val database: KhdemliDatabase,
    private val firebaseManager: com.example.data.remote.FirebaseManager? = null
) {
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _currentProfessional = MutableStateFlow<ProfessionalEntity?>(null)
    val currentProfessional: StateFlow<ProfessionalEntity?> = _currentProfessional.asStateFlow()

    init {
        // Automatically initialize with Customer by default or check active Firebase user / first user
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val activeUid = firebaseManager?.getCurrentFirebaseUid()
                if (activeUid != null) {
                    val remoteUser = firebaseManager.fetchUserByUid(activeUid)
                    if (remoteUser != null) {
                        _currentUser.value = remoteUser
                        database.userDao().insertUser(remoteUser)
                        checkAndLoadProfessionalProfile(remoteUser.id)
                    }
                }
                
                if (_currentUser.value == null) {
                    database.userDao().getAllUsers().collect { users ->
                        if (_currentUser.value == null && users.isNotEmpty()) {
                            val defaultClient = users.find { it.id == 2L } ?: users.first()
                            _currentUser.value = defaultClient
                            checkAndLoadProfessionalProfile(defaultClient.id)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun loginWithEmailPassword(email: String, password: String): Boolean {
        var firebaseUid: String? = null
        if (firebaseManager?.isFirebaseAvailable == true) {
            try {
                firebaseUid = firebaseManager.signInWithEmailPassword(email, password)
            } catch (e: Exception) {
                e.printStackTrace()
                return false
            }
        }

        // Fetch user from Firestore or Local Room
        var user: UserEntity? = null
        if (firebaseUid != null) {
            user = firebaseManager?.fetchUserByUid(firebaseUid)
        }
        if (user == null) {
            user = firebaseManager?.fetchUserByEmail(email)
        }
        if (user == null) {
            user = database.userDao().getAllUsers().firstOrNull()?.find { it.email.equals(email, ignoreCase = true) }
        }

        if (user != null && !user.isBlocked) {
            _currentUser.value = user
            database.userDao().insertUser(user)
            checkAndLoadProfessionalProfile(user.id)
            return true
        } else if (firebaseUid != null) {
            // User authenticated in Firebase Auth but document missing: create fallback document
            val newUser = UserEntity(
                fullName = email.substringBefore("@"),
                phone = "",
                email = email,
                role = UserRole.CUSTOMER
            )
            val id = database.userDao().insertUser(newUser)
            val created = newUser.copy(id = id)
            firebaseManager?.saveUser(created, firebaseUid)
            _currentUser.value = created
            return true
        }
        return false
    }

    suspend fun loginWithPhone(phone: String): Boolean {
        var user = firebaseManager?.fetchUserByPhone(phone)
        if (user == null) {
            user = database.userDao().getUserByPhone(phone)
        }
        if (user != null && !user.isBlocked) {
            _currentUser.value = user
            database.userDao().insertUser(user)
            checkAndLoadProfessionalProfile(user.id)
            return true
        }
        return false
    }

    suspend fun loginAsUser(user: UserEntity) {
        if (!user.isBlocked) {
            _currentUser.value = user
            checkAndLoadProfessionalProfile(user.id)
        }
    }

    suspend fun registerCustomer(
        fullName: String,
        phone: String,
        email: String,
        password: String = "",
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String
    ): UserEntity {
        var firebaseUid: String? = null
        if (email.isNotBlank() && password.length >= 6 && firebaseManager?.isFirebaseAvailable == true) {
            try {
                firebaseUid = firebaseManager.signUpWithEmailPassword(email, password)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val existing = database.userDao().getUserByPhone(phone)
        if (existing != null) {
            _currentUser.value = existing
            firebaseManager?.saveUser(existing, firebaseUid)
            return existing
        }
        val newUser = UserEntity(
            fullName = fullName,
            phone = phone,
            email = email,
            role = UserRole.CUSTOMER,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val id = database.userDao().insertUser(newUser)
        val created = newUser.copy(id = id)
        
        // Save to Firestore securely
        firebaseManager?.saveUser(created, firebaseUid)

        _currentUser.value = created
        _currentProfessional.value = null
        return created
    }

    suspend fun registerProfessional(
        fullName: String,
        phone: String,
        email: String = "",
        password: String = "",
        whatsapp: String,
        serviceCategoryId: Long,
        professionNameAr: String,
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String,
        experienceYears: Int,
        bio: String,
        workingHours: String,
        priceEstimate: String
    ): ProfessionalEntity {
        var firebaseUid: String? = null
        if (email.isNotBlank() && password.length >= 6 && firebaseManager?.isFirebaseAvailable == true) {
            try {
                firebaseUid = firebaseManager.signUpWithEmailPassword(email, password)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val user = UserEntity(
            fullName = fullName,
            phone = phone,
            email = email,
            role = UserRole.PROFESSIONAL,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val userId = database.userDao().insertUser(user)
        val fullUser = user.copy(id = userId)
        
        // Save user to Firestore securely
        firebaseManager?.saveUser(fullUser, firebaseUid)
        
        _currentUser.value = fullUser

        val pro = ProfessionalEntity(
            userId = userId,
            fullName = fullName,
            phone = phone,
            whatsapp = if (whatsapp.isNotBlank()) whatsapp else phone,
            serviceCategoryId = serviceCategoryId,
            professionNameAr = professionNameAr,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr,
            experienceYears = experienceYears,
            bio = bio,
            workingHours = workingHours,
            priceEstimate = priceEstimate,
            isAvailable = true,
            isVerified = false,
            isApprovedByAdmin = true,
            ratingAverage = 5.0,
            ratingCount = 0,
            completedJobsCount = 0
        )
        val proId = database.professionalDao().insertProfessional(pro)
        val fullPro = pro.copy(id = proId)
        
        // Save professional to Firestore
        firebaseManager?.saveProfessional(fullPro)

        _currentProfessional.value = fullPro
        return fullPro
    }

    fun logout() {
        firebaseManager?.signOut()
        _currentUser.value = null
        _currentProfessional.value = null
    }

    suspend fun checkAndLoadProfessionalProfile(userId: Long?) {
        if (userId == null) {
            _currentProfessional.value = null
            return
        }
        val pro = database.professionalDao().getProfessionalByUserId(userId).firstOrNull()
        _currentProfessional.value = pro
    }

    fun isAdmin(): Boolean = _currentUser.value?.role == UserRole.ADMIN
    fun isProfessional(): Boolean = _currentUser.value?.role == UserRole.PROFESSIONAL || _currentProfessional.value != null
    fun isCustomer(): Boolean = _currentUser.value?.role == UserRole.CUSTOMER
}
