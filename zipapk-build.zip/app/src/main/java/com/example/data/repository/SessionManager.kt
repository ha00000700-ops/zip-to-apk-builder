package com.example.data.repository

import android.util.Log
import com.example.data.local.KhdemliDatabase
import com.example.data.model.ProfessionalEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class SessionManager(
    private val database: KhdemliDatabase,
    private val firebaseManager: com.example.data.remote.FirebaseManager? = null
) {
    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _currentProfessional = MutableStateFlow<ProfessionalEntity?>(null)
    val currentProfessional: StateFlow<ProfessionalEntity?> = _currentProfessional.asStateFlow()

    init {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val activeUid = firebaseManager?.getCurrentFirebaseUid()
                if (activeUid != null) {
                    // 1. Restore session instantly from local Room DB strictly by firebaseUid
                    val localUser = database.userDao().getUserByFirebaseUid(activeUid)
                    if (localUser != null) {
                        _currentUser.value = localUser
                        val localPro = database.professionalDao().getProfessionalByFirebaseUid(activeUid)
                        if (localPro != null) {
                            _currentProfessional.value = localPro
                        }
                        Log.d("SessionManager", "Restored session locally for UID=$activeUid (${localUser.fullName})")
                    }

                    // 2. Fetch latest user from Firestore to keep synced
                    val remoteUser = firebaseManager.fetchUserByUid(activeUid)
                    if (remoteUser != null) {
                        val existingLocal = database.userDao().getUserByFirebaseUid(activeUid)
                        val userToSave = remoteUser.copy(
                            id = existingLocal?.id ?: 0,
                            firebaseUid = activeUid
                        )
                        _currentUser.value = userToSave
                        val localId = database.userDao().insertUser(userToSave)
                        val userWithId = if (userToSave.id == 0L) userToSave.copy(id = localId) else userToSave
                        _currentUser.value = userWithId
                        checkAndLoadProfessionalProfile(userWithId, activeUid)
                        registerCurrentFcmToken()
                    } else if (localUser != null) {
                        checkAndLoadProfessionalProfile(localUser, activeUid)
                    }
                } else {
                    _currentUser.value = null
                    _currentProfessional.value = null
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    suspend fun loginWithEmailPassword(email: String, password: String): Boolean {
        val fm = firebaseManager ?: run {
            Log.e("SessionManager", "FirebaseManager is null")
            return false
        }
        val trimmedEmail = email.trim()
        val trimmedPass = password.trim()
        if (trimmedEmail.isBlank() || trimmedPass.isBlank()) {
            return false
        }

        val firebaseUid = try {
            fm.signInWithEmailPassword(trimmedEmail, trimmedPass)
        } catch (e: Exception) {
            Log.e("SessionManager", "Firebase signIn failed: ${e.message}")
            return false
        } ?: return false

        // Fetch user from Firestore by Firebase UID
        var user: UserEntity? = fm.fetchUserByUid(firebaseUid)
        if (user == null) {
            user = fm.fetchUserByEmail(trimmedEmail)
        }

        if (user == null) {
            // User exists in Firebase Auth but document was not yet created in Firestore
            val newUser = UserEntity(
                firebaseUid = firebaseUid,
                fullName = trimmedEmail.substringBefore("@"),
                phone = "",
                email = trimmedEmail,
                role = UserRole.CUSTOMER
            )
            val id = database.userDao().insertUser(newUser)
            val created = newUser.copy(id = id)
            fm.saveUser(created, firebaseUid)
            user = created
        } else {
            user = user.copy(firebaseUid = firebaseUid)
        }

        if (user.isBlocked) {
            fm.signOut()
            return false
        }

        database.userDao().insertUser(user)
        _currentUser.value = user
        checkAndLoadProfessionalProfile(user, firebaseUid)
        registerCurrentFcmToken()
        return true
    }

    suspend fun loginAsUser(user: UserEntity) {
        if (!user.isBlocked) {
            _currentUser.value = user
            val uid = firebaseManager?.getCurrentFirebaseUid()
            checkAndLoadProfessionalProfile(user, uid)
        }
    }

    suspend fun registerCustomer(
        fullName: String,
        phone: String,
        email: String,
        password: String,
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String
    ): Result<UserEntity> {
        val fm = firebaseManager ?: return Result.failure(IllegalStateException("Firebase service not available"))
        val trimmedEmail = email.trim()
        val trimmedPass = password.trim()
        val trimmedName = fullName.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank() || trimmedPhone.isBlank()) {
            return Result.failure(IllegalArgumentException("الرجاء إدخال الاسم ورقم الهاتف"))
        }
        if (!trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
            return Result.failure(IllegalArgumentException("الرجاء إدخال بريد إلكتروني صالح"))
        }
        if (trimmedPass.length < 6) {
            return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 6 أحرف أو أرقام على الأقل"))
        }

        val firebaseUid = try {
            fm.signUpWithEmailPassword(trimmedEmail, trimmedPass)
        } catch (e: Exception) {
            Log.e("SessionManager", "Firebase signUp failed: ${e.message}")
            return Result.failure(e)
        } ?: return Result.failure(IllegalStateException("تعذر إنشاء حساب Firebase"))

        val newUser = UserEntity(
            firebaseUid = firebaseUid,
            fullName = trimmedName,
            phone = trimmedPhone,
            email = trimmedEmail,
            role = UserRole.CUSTOMER,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val id = database.userDao().insertUser(newUser)
        val created = newUser.copy(id = id)

        // Save to Firestore with real Firebase UID
        fm.saveUser(created, firebaseUid)

        _currentUser.value = created
        _currentProfessional.value = null
        registerCurrentFcmToken()
        return Result.success(created)
    }

    suspend fun registerProfessional(
        fullName: String,
        phone: String,
        email: String,
        password: String,
        whatsapp: String,
        serviceCategoryId: Long,
        professionNameAr: String,
        wilayaCode: Int,
        wilayaNameAr: String,
        communeNameAr: String,
        experienceYears: Int,
        bio: String,
        workingHours: String,
        priceEstimate: String
    ): Result<ProfessionalEntity> {
        val fm = firebaseManager ?: return Result.failure(IllegalStateException("Firebase service not available"))
        val trimmedEmail = email.trim()
        val trimmedPass = password.trim()
        val trimmedName = fullName.trim()
        val trimmedPhone = phone.trim()

        if (trimmedName.isBlank() || trimmedPhone.isBlank()) {
            return Result.failure(IllegalArgumentException("الرجاء إدخال الاسم ورقم الهاتف"))
        }
        if (!trimmedEmail.contains("@") || !trimmedEmail.contains(".")) {
            return Result.failure(IllegalArgumentException("الرجاء إدخال بريد إلكتروني صالح"))
        }
        if (trimmedPass.length < 6) {
            return Result.failure(IllegalArgumentException("كلمة المرور يجب أن تكون 6 أحرف على الأقل"))
        }

        val firebaseUid = try {
            fm.signUpWithEmailPassword(trimmedEmail, trimmedPass)
        } catch (e: Exception) {
            Log.e("SessionManager", "Firebase pro signUp failed: ${e.message}")
            return Result.failure(e)
        } ?: return Result.failure(IllegalStateException("تعذر إنشاء حساب Firebase للحرفي"))

        val user = UserEntity(
            firebaseUid = firebaseUid,
            fullName = trimmedName,
            phone = trimmedPhone,
            email = trimmedEmail,
            role = UserRole.PROFESSIONAL,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr
        )
        val userId = database.userDao().insertUser(user)
        val fullUser = user.copy(id = userId)

        // Save user to Firestore
        fm.saveUser(fullUser, firebaseUid)
        _currentUser.value = fullUser

        val pro = ProfessionalEntity(
            firebaseUid = firebaseUid,
            userId = userId,
            fullName = trimmedName,
            phone = trimmedPhone,
            whatsapp = if (whatsapp.isNotBlank()) whatsapp.trim() else trimmedPhone,
            serviceCategoryId = serviceCategoryId,
            professionNameAr = professionNameAr,
            wilayaCode = wilayaCode,
            wilayaNameAr = wilayaNameAr,
            communeNameAr = communeNameAr,
            experienceYears = experienceYears,
            bio = bio,
            workingHours = workingHours,
            priceEstimate = priceEstimate,
            isAvailable = true,
            isVerified = false,
            isApprovedByAdmin = true,
            ratingAverage = 5.0,
            ratingCount = 0,
            completedJobsCount = 0
        )
        val proId = database.professionalDao().insertProfessional(pro)
        val fullPro = pro.copy(id = proId)

        // Save professional to Firestore
        fm.saveProfessional(fullPro, firebaseUid)

        _currentProfessional.value = fullPro
        registerCurrentFcmToken()
        return Result.success(fullPro)
    }

    suspend fun registerCurrentFcmToken() {
        try {
            val user = _currentUser.value ?: return
            val token = firebaseManager?.getFcmToken()
            if (token != null && token.isNotBlank() && user.fcmToken != token) {
                val uid = firebaseManager?.getCurrentFirebaseUid() ?: user.id.toString()
                firebaseManager?.updateUserFcmToken(uid, token)
                val updatedUser = user.copy(fcmToken = token)
                _currentUser.value = updatedUser
                database.userDao().insertUser(updatedUser)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun logout() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                firebaseManager?.clearUserFcmTokenOnLogout()
            } catch (e: Exception) {
                e.printStackTrace()
            }
            firebaseManager?.signOut()
            _currentUser.value = null
            _currentProfessional.value = null
        }
    }

    suspend fun checkAndLoadProfessionalProfile(user: UserEntity?, firebaseUid: String? = null) {
        if (user == null) {
            _currentProfessional.value = null
            return
        }
        val uid = firebaseUid?.ifBlank { null }
            ?: user.firebaseUid.ifBlank { null }
            ?: firebaseManager?.getCurrentFirebaseUid()

        if (uid.isNullOrBlank()) {
            _currentProfessional.value = null
            return
        }

        var pro: ProfessionalEntity? = null

        // 1. Primary source of truth: fetch from Firestore by Firebase UID (professionals/{uid})
        if (firebaseManager != null) {
            try {
                pro = firebaseManager.fetchProfessionalByUid(uid)
            } catch (e: Exception) {
                Log.e("SessionManager", "Error fetching pro by UID=$uid from Firestore", e)
            }
        }

        // 2. Local cache fallback: check Room cache strictly WHERE firebaseUid = :uid
        if (pro == null) {
            pro = database.professionalDao().getProfessionalByFirebaseUid(uid)
        }

        // Strictly NO fallbacks by user.id (Long) or phone number!
        if (pro != null) {
            val existingLocalPro = database.professionalDao().getProfessionalByFirebaseUid(uid)
            val fullPro = pro.copy(
                id = existingLocalPro?.id ?: (if (pro.id > 0) pro.id else 0),
                firebaseUid = uid
            )
            if (user.role != UserRole.PROFESSIONAL) {
                val updatedUser = user.copy(role = UserRole.PROFESSIONAL)
                _currentUser.value = updatedUser
                database.userDao().insertUser(updatedUser)
                firebaseManager?.saveUser(updatedUser, uid)
            }
            val localProId = database.professionalDao().insertProfessional(fullPro)
            val savedPro = if (fullPro.id == 0L) fullPro.copy(id = localProId) else fullPro
            _currentProfessional.value = savedPro
            Log.d("SessionManager", "Loaded professional profile for UID=$uid: ${savedPro.professionNameAr}")
        } else {
            _currentProfessional.value = null
            Log.d("SessionManager", "No professional profile found for UID=$uid. Setting _currentProfessional = null")
        }
    }

    fun isAdmin(): Boolean = _currentUser.value?.role == UserRole.ADMIN
    fun isProfessional(): Boolean = _currentUser.value?.role == UserRole.PROFESSIONAL || _currentProfessional.value != null
    fun isCustomer(): Boolean = _currentUser.value?.role == UserRole.CUSTOMER
}
