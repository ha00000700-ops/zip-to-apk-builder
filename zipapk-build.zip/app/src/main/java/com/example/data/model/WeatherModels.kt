package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

data class CityInfo(
    val name: String,
    val country: String = "الجزائر",
    val latitude: Double,
    val longitude: Double,
    val adminName: String = ""
)

data class CurrentWeather(
    val temperature: Double,
    val apparentTemperature: Double,
    val relativeHumidity: Int,
    val windSpeed: Double,
    val weatherCode: Int,
    val isDay: Boolean,
    val precipitation: Double
)

data class HourlyForecast(
    val timeLabel: String,
    val temperature: Double,
    val weatherCode: Int,
    val isDay: Boolean
)

data class DailyForecast(
    val dateLabel: String,
    val weatherCode: Int,
    val maxTemp: Double,
    val minTemp: Double
)

data class CityWeatherData(
    val city: CityInfo,
    val current: CurrentWeather,
    val hourly: List<HourlyForecast>,
    val daily: List<DailyForecast>,
    val lastUpdated: Long = System.currentTimeMillis()
)

enum class WeatherConditionType(
    val titleArabic: String,
    val romanticSubtitle: String,
    val algerianQuote: String,
    val iconName: String,
    val gradientColors: List<Color>
) {
    CLEAR_DAY(
        titleArabic = "مشمس ودافئ",
        romanticSubtitle = "شمس مشرقة كابتسامتكِ الدافئة",
        algerianQuote = "كي تكون الشمس طالعة نتي شمس حياتي وضوّ عيني!",
        iconName = "wb_sunny",
        gradientColors = listOf(Color(0xFFFF9A8B), Color(0xFFFF6A88), Color(0xFFFF99AC))
    ),
    CLEAR_NIGHT(
        titleArabic = "سماء صافية ونجوم",
        romanticSubtitle = "سماء مقمرة تشهد على حبي لك",
        algerianQuote = "القمرة في السما ونتي القمرة تاع قلبي يا عمري",
        iconName = "nights_stay",
        gradientColors = listOf(Color(0xFF2C1654), Color(0xFF1E1035), Color(0xFF120B20))
    ),
    CLOUDY(
        titleArabic = "غائم ورومانسي",
        romanticSubtitle = "غيوم لطيفة تحرس أمنياتنا المشتركة",
        algerianQuote = "السما مغيمة بصح وجهك ينورلي أظلم نهار!",
        iconName = "cloud",
        gradientColors = listOf(Color(0xFF6B7280), Color(0xFFA78BFA), Color(0xFFE9D5FF))
    ),
    PARTLY_CLOUDY(
        titleArabic = "غائم جزئياً",
        romanticSubtitle = "نسيم عليل يبعث إليكِ أشواقي",
        algerianQuote = "جو شباب يطلب قعدة تاي معاك وهدرة ما تخلاصش!",
        iconName = "partly_cloudy_day",
        gradientColors = listOf(Color(0xFFFB7185), Color(0xFFF472B6), Color(0xFFFDA4AF))
    ),
    RAINY(
        titleArabic = "ماطر وشتوي",
        romanticSubtitle = "قطرات مطر تسقي زهور حبنا",
        algerianQuote = "النو تصب والبرد يقرس، وصوتك برك لي يدفي قلبي!",
        iconName = "water_drop",
        gradientColors = listOf(Color(0xFF3B82F6), Color(0xFF6366F1), Color(0xFF4C1D95))
    ),
    THUNDERSTORM(
        titleArabic = "عاصف ورعدي",
        romanticSubtitle = "مهما عصفت الأجواء، قلبي ملاذكِ الآمن",
        algerianQuote = "الرعود تضرب برة بصح حبك في قلبي راسي ما يتبدل!",
        iconName = "thunderstorm",
        gradientColors = listOf(Color(0xFF312E81), Color(0xFF4C1D95), Color(0xFF1E1B4B))
    ),
    SNOWY(
        titleArabic = "ثلجي نقي",
        romanticSubtitle = "بياض نقي يشبه نقاء قلبكِ الجميل",
        algerianQuote = "الثلج شباب بصح حنانتك أدفى من الدنيا وما فيها",
        iconName = "ac_unit",
        gradientColors = listOf(Color(0xFF93C5FD), Color(0xFFBFDBFE), Color(0xFFE0E7FF))
    ),
    FOGGY(
        titleArabic = "ضبابي ساحر",
        romanticSubtitle = "حتى عبر الضباب والمسافات، أراكِ بقلبي",
        algerianQuote = "الضباب مغطي الطريق بصح طريق قلبي ليك واضحة وضوح الشمس",
        iconName = "foggy",
        gradientColors = listOf(Color(0xFF64748B), Color(0xFF94A3B8), Color(0xFFCBD5E1))
    );

    companion object {
        fun fromWmoCode(code: Int, isDay: Boolean): WeatherConditionType {
            return when (code) {
                0 -> if (isDay) CLEAR_DAY else CLEAR_NIGHT
                1, 2 -> if (isDay) PARTLY_CLOUDY else CLEAR_NIGHT
                3 -> CLOUDY
                45, 48 -> FOGGY
                51, 53, 55, 61, 63, 65, 80, 81, 82 -> RAINY
                71, 73, 75, 77, 85, 86 -> SNOWY
                95, 96, 99 -> THUNDERSTORM
                else -> if (isDay) CLEAR_DAY else CLEAR_NIGHT
            }
        }
    }
}
