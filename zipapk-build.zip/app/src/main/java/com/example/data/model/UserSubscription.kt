package com.example.data.model

enum class SubscriptionPlan(val code: String, val displayNameAr: String) {
    FREE("FREE", "المجانية"),
    PRO("PRO", "خدمتي Pro ⭐");

    companion object {
        fun fromCode(code: String?): SubscriptionPlan {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: FREE
        }
    }
}

enum class SubscriptionStatus(val code: String, val displayNameAr: String) {
    ACTIVE("ACTIVE", "نشط"),
    EXPIRED("EXPIRED", "منتهي"),
    CANCELLED("CANCELLED", "ملغى");

    companion object {
        fun fromCode(code: String?): SubscriptionStatus {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: ACTIVE
        }
    }
}

data class UserSubscription(
    val plan: SubscriptionPlan = SubscriptionPlan.FREE,
    val status: SubscriptionStatus = SubscriptionStatus.ACTIVE,
    val startDate: Long = 0L,
    val endDate: Long = 0L
) {
    val isProActive: Boolean
        get() = plan == SubscriptionPlan.PRO &&
                status == SubscriptionStatus.ACTIVE &&
                (endDate == 0L || System.currentTimeMillis() < endDate)

    fun toMap(): Map<String, Any> {
        return mapOf(
            "plan" to plan.code,
            "status" to status.code,
            "startDate" to startDate,
            "endDate" to endDate
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>?): UserSubscription {
            if (map == null) return UserSubscription()
            return UserSubscription(
                plan = SubscriptionPlan.fromCode(map["plan"] as? String),
                status = SubscriptionStatus.fromCode(map["status"] as? String),
                startDate = (map["startDate"] as? Number)?.toLong() ?: 0L,
                endDate = (map["endDate"] as? Number)?.toLong() ?: 0L
            )
        }
    }
}
