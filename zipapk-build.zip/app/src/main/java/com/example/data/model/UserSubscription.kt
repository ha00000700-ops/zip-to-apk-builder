package com.example.data.model

enum class SubscriptionPlan(
    val code: String,
    val displayNameAr: String,
    val priceDzd: Long,
    val tierLevel: Int,
    val badgeLabelAr: String? = null
) {
    FREE("FREE", "الحساب المجاني", 0L, 0, null),
    BASIC("BASIC", "الخطة الأساسية", 500L, 1, "أساسي"),
    STANDARD("STANDARD", "الخطة القياسية", 1000L, 2, "قياسي ⭐"),
    PREMIUM("PREMIUM", "الخطة المميزة", 1500L, 3, "مميز ⭐⭐⭐");

    companion object {
        fun fromCode(code: String?): SubscriptionPlan {
            if (code.isNullOrBlank()) return FREE
            val upper = code.uppercase().trim()
            return when {
                upper.contains("PREMIUM") || upper.contains("PRO") -> PREMIUM
                upper.contains("STANDARD") -> STANDARD
                upper.contains("BASIC") -> BASIC
                upper == "FREE" -> FREE
                else -> values().firstOrNull { it.code.equals(upper, ignoreCase = true) } ?: FREE
            }
        }
    }
}

enum class SubscriptionStatus(val code: String, val displayNameAr: String) {
    FREE("FREE", "الحساب المجاني"),
    PENDING("PENDING", "قيد انتظار تأكيد الدفع"),
    ACTIVE("ACTIVE", "نشط ومفعل"),
    EXPIRED("EXPIRED", "منتهي"),
    CANCELLED("CANCELLED", "ملغى"),
    PAYMENT_FAILED("PAYMENT_FAILED", "فشلت عملية الدفع");

    companion object {
        fun fromCode(code: String?): SubscriptionStatus {
            if (code.isNullOrBlank()) return FREE
            val upper = code.uppercase().trim()
            return when (upper) {
                "ACTIVE", "SUCCESSFUL", "SUCCESS", "PAID", "ACTIVE_SUBSCRIPTION" -> ACTIVE
                "PENDING" -> PENDING
                "EXPIRED" -> EXPIRED
                "CANCELLED", "CANCELED" -> CANCELLED
                "PAYMENT_FAILED", "FAILED" -> PAYMENT_FAILED
                else -> values().firstOrNull { it.code.equals(upper, ignoreCase = true) } ?: FREE
            }
        }
    }
}

data class UserSubscription(
    val plan: SubscriptionPlan = SubscriptionPlan.FREE,
    val status: SubscriptionStatus = SubscriptionStatus.FREE,
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    val paymentId: String? = null,
    val checkoutId: String? = null,
    val amount: Long = 0L,
    val currency: String = "DZD",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    val isSubscribed: Boolean
        get() = (plan == SubscriptionPlan.BASIC || plan == SubscriptionPlan.STANDARD || plan == SubscriptionPlan.PREMIUM) &&
                status == SubscriptionStatus.ACTIVE &&
                (endDate == 0L || System.currentTimeMillis() < endDate)

    val isProActive: Boolean
        get() = isSubscribed

    val tierLevel: Int
        get() = if (isSubscribed) plan.tierLevel else 0

    fun toMap(): Map<String, Any?> {
        return mapOf(
            "plan" to plan.code,
            "status" to status.code,
            "startDate" to startDate,
            "endDate" to endDate,
            "paymentId" to paymentId,
            "checkoutId" to checkoutId,
            "amount" to amount,
            "currency" to currency,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        private fun parseLongValue(value: Any?): Long {
            return when (value) {
                is Number -> value.toLong()
                is String -> value.toLongOrNull() ?: 0L
                is com.google.firebase.Timestamp -> value.toDate().time
                is java.util.Date -> value.time
                else -> 0L
            }
        }

        fun fromMap(map: Map<String, Any?>?): UserSubscription {
            if (map == null) return UserSubscription()

            val planStr = (map["plan"] as? String)
                ?: (map["subscriptionPlan"] as? String)
                ?: (map["planId"] as? String)

            val statusStr = (map["status"] as? String)
                ?: (map["subscriptionStatus"] as? String)

            val paymentIdVal = (map["paymentId"] as? String)
                ?: (map["checkoutId"] as? String)

            val checkoutIdVal = (map["checkoutId"] as? String)
                ?: (map["paymentId"] as? String)

            val amountVal = parseLongValue(map["amount"])
            val startDateVal = parseLongValue(map["startDate"])
            val endDateVal = parseLongValue(map["endDate"])
            val createdAtVal = parseLongValue(map["createdAt"])
            val updatedAtVal = parseLongValue(map["updatedAt"])

            return UserSubscription(
                plan = SubscriptionPlan.fromCode(planStr),
                status = SubscriptionStatus.fromCode(statusStr),
                startDate = startDateVal,
                endDate = endDateVal,
                paymentId = paymentIdVal,
                checkoutId = checkoutIdVal,
                amount = amountVal,
                currency = map["currency"] as? String ?: "DZD",
                createdAt = createdAtVal,
                updatedAt = updatedAtVal
            )
        }
    }
}
