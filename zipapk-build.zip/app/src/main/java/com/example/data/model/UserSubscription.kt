package com.example.data.model

enum class SubscriptionPlan(
    val code: String,
    val displayNameAr: String,
    val priceDzd: Long,
    val tierLevel: Int,
    val badgeLabelAr: String? = null
) {
    FREE("FREE", "الحساب المجاني", 0L, 0, null),
    BASIC("BASIC", "الخطة الأساسية", 500L, 1, "أساسي"),
    STANDARD("STANDARD", "الخطة القياسية", 1000L, 2, "قياسي ⭐"),
    PREMIUM("PREMIUM", "الخطة المميزة", 1500L, 3, "مميز ⭐⭐⭐");

    companion object {
        fun fromCode(code: String?): SubscriptionPlan {
            if (code.isNullOrBlank()) return FREE
            return when (code.uppercase()) {
                "BASIC" -> BASIC
                "STANDARD" -> STANDARD
                "PREMIUM", "PRO" -> PREMIUM
                else -> values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: FREE
            }
        }
    }
}

enum class SubscriptionStatus(val code: String, val displayNameAr: String) {
    FREE("FREE", "الحساب المجاني"),
    PENDING("PENDING", "قيد انتظار تأكيد الدفع"),
    ACTIVE("ACTIVE", "نشط ومفعل"),
    EXPIRED("EXPIRED", "منتهي"),
    CANCELLED("CANCELLED", "ملغى"),
    PAYMENT_FAILED("PAYMENT_FAILED", "فشلت عملية الدفع");

    companion object {
        fun fromCode(code: String?): SubscriptionStatus {
            return values().firstOrNull { it.code.equals(code, ignoreCase = true) } ?: FREE
        }
    }
}

data class UserSubscription(
    val plan: SubscriptionPlan = SubscriptionPlan.FREE,
    val status: SubscriptionStatus = SubscriptionStatus.FREE,
    val startDate: Long = 0L,
    val endDate: Long = 0L,
    val paymentId: String? = null,
    val checkoutId: String? = null,
    val amount: Long = 0L,
    val currency: String = "DZD",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    val isSubscribed: Boolean
        get() = (plan == SubscriptionPlan.BASIC || plan == SubscriptionPlan.STANDARD || plan == SubscriptionPlan.PREMIUM) &&
                status == SubscriptionStatus.ACTIVE &&
                (endDate == 0L || System.currentTimeMillis() < endDate)

    val isProActive: Boolean
        get() = isSubscribed

    val tierLevel: Int
        get() = if (isSubscribed) plan.tierLevel else 0

    fun toMap(): Map<String, Any?> {
        return mapOf(
            "plan" to plan.code,
            "status" to status.code,
            "startDate" to startDate,
            "endDate" to endDate,
            "paymentId" to paymentId,
            "checkoutId" to checkoutId,
            "amount" to amount,
            "currency" to currency,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromMap(map: Map<String, Any?>?): UserSubscription {
            if (map == null) return UserSubscription()
            return UserSubscription(
                plan = SubscriptionPlan.fromCode(map["plan"] as? String),
                status = SubscriptionStatus.fromCode(map["status"] as? String),
                startDate = (map["startDate"] as? Number)?.toLong() ?: 0L,
                endDate = (map["endDate"] as? Number)?.toLong() ?: 0L,
                paymentId = map["paymentId"] as? String,
                checkoutId = map["checkoutId"] as? String,
                amount = (map["amount"] as? Number)?.toLong() ?: 0L,
                currency = map["currency"] as? String ?: "DZD",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: 0L,
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: 0L
            )
        }
    }
}
