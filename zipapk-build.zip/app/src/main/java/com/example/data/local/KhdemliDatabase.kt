package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ProfessionalEntity::class,
        ServiceCategoryEntity::class,
        WilayaEntity::class,
        CommuneEntity::class,
        ServiceRequestEntity::class,
        ReviewEntity::class,
        MessageEntity::class,
        ReportEntity::class,
        AdminSettingsEntity::class,
        VerificationRequestEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KhdemliDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun professionalDao(): ProfessionalDao
    abstract fun serviceCategoryDao(): ServiceCategoryDao
    abstract fun wilayaDao(): WilayaDao
    abstract fun serviceRequestDao(): ServiceRequestDao
    abstract fun reviewDao(): ReviewDao
    abstract fun messageDao(): MessageDao
    abstract fun reportDao(): ReportDao
    abstract fun adminSettingsDao(): AdminSettingsDao
    abstract fun verificationRequestDao(): VerificationRequestDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: KhdemliDatabase? = null

        fun getDatabase(context: Context): KhdemliDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KhdemliDatabase::class.java,
                    "khdemli_dz_database.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

suspend fun seedDatabase(database: KhdemliDatabase) {
    try {
        // 1. Seed All 58 Wilayas and Communes
        val wilayasList = AlgeriaWilayasData.allWilayas.map {
            WilayaEntity(code = it.code, nameAr = it.nameAr, nameFr = it.nameFr, isCovered = true)
        }
        database.wilayaDao().insertWilayas(wilayasList)

        val communesList = mutableListOf<CommuneEntity>()
        AlgeriaWilayasData.allWilayas.forEach { w ->
            w.communes.forEach { c ->
                communesList.add(CommuneEntity(wilayaCode = w.code, nameAr = c, nameFr = c))
            }
        }
        communesList.chunked(100).forEach { chunk ->
            database.wilayaDao().insertCommunes(chunk)
        }

    // 2. Seed Initial Services
    val initialServices = listOf(
        ServiceCategoryEntity(1, "plumbing", "سباكة وترصيص", "Plomberie", "خدمات تسليك المجاري، تصليح التسريبات، تركيب السخانات وشبكات المياه", "plumbing", true, 1),
        ServiceCategoryEntity(2, "electricity", "كهرباء منازل وصناعي", "Électricité", "صيانة الأعطال الكهربائية، تركيب القواطع، الإضاءة والمآخذ", "electric_bolt", true, 2),
        ServiceCategoryEntity(3, "hvac", "تكييف وتبريد", "Climatisation & Froid", "شحن الغاز، تنظيف وتركيب المكيفات، صيانة غرف التبريد", "ac_unit", true, 3),
        ServiceCategoryEntity(4, "mechanic", "ميكانيكي سيارات", "Mécanique auto", "ميكانيك عام، كهرباء السيارات، الفحص بالسكانير والتدخل السريع", "car_repair", true, 4),
        ServiceCategoryEntity(5, "carpentry", "نجارة وأثاث", "Menuiserie", "صناعة وتصليح الأبواب والمطابخ، تركيب وتعديل الأثاث", "carpenter", true, 5),
        ServiceCategoryEntity(6, "painting", "دهان وديكور", "Peinture", "طلاء الجدران، معالجة الرطوبة، ورق الجدران والديكورات العصرية", "format_paint", true, 6),
        ServiceCategoryEntity(7, "blacksmith", "حدادة وألمنيوم", "Ferronnerie", "أبواب وشبابيك حديدية، ستائر معدنية، هياكل حديدية", "hardware", true, 7),
        ServiceCategoryEntity(8, "masonry", "بناء وترميم", "Maçonnerie", "أشغال البناء، السيراميك والماصو، تلييس وتهيئة الواجهات", "foundation", true, 8),
        ServiceCategoryEntity(9, "appliances", "تصليح أجهزة كهرومنزلية", "Électroménager", "تصليح الثلاجات، الغسالات، الأفران، والميكروويف", "kitchen", true, 9),
        ServiceCategoryEntity(10, "phone_repair", "تصليح هواتف وشاشات", "Réparation Téléphones", "تغيير الشاشات، صيانة البطاريات، الفورمات وإصلاح البورد", "smartphone", true, 10),
        ServiceCategoryEntity(11, "computer_it", "صيانة كمبيوتر وشبكات", "Informatique", "تصليح الحواسيب، تنصيب الويندوز، تركيب شبكات الإنترنت", "computer", true, 11),
        ServiceCategoryEntity(12, "cleaning", "تنظيف منازل ومكاتب", "Nettoyage", "تنظيف شامل بعد الأشغال، غسيل السجاد والواجهات الزجاجية", "cleaning_services", true, 12),
        ServiceCategoryEntity(13, "moving", "نقل البضائع والعفش", "Transport & Déménagement", "شاحنات نقل العفش مع عمال التحميل والتفريغ عبر 58 ولاية", "local_shipping", true, 13),
        ServiceCategoryEntity(14, "cctv_security", "كاميرات مراقبة وإنذار", "Caméras & Sécurité", "تركيب وضبط كاميرات المراقبة، أجهزة الإنذار والمنازل الذكية", "videocam", true, 14),
        ServiceCategoryEntity(15, "locksmith", "أقفال ومفاتيح", "Serrurerie", "فتح الأبواب المغلقة، تغيير الكوالين ونسخ المفاتيح الذكية", "key", true, 15),
        ServiceCategoryEntity(16, "gardening", "بستنة وتنسيق حدائق", "Jardinage", "تقليم الأشجار، زرع العشب، تركيب شبكات السقي بالتقطير", "yard", true, 16)
    )
    database.serviceCategoryDao().insertAllServices(initialServices)

    // 3. Seed Users (Admin, Customer, and Craftsmen)
    val adminUser = UserEntity(
        id = 1,
        fullName = "مدير منصة خدملي DZ",
        phone = "0550000000",
        email = "admin@khdemli-dz.com",
        role = UserRole.ADMIN,
        wilayaCode = 16,
        wilayaNameAr = "الجزائر",
        communeNameAr = "حيدرة"
    )
    database.userDao().insertUser(adminUser)

    val clientUser = UserEntity(
        id = 2,
        fullName = "أحمد بلقاسم",
        phone = "0661122334",
        email = "ahmed.dz@gmail.com",
        role = UserRole.CUSTOMER,
        wilayaCode = 16,
        wilayaNameAr = "الجزائر",
        communeNameAr = "الجزائر الوسطى"
    )
    database.userDao().insertUser(clientUser)

    // Seed Professionals Users & Pro profiles
    val proUsers = listOf(
        UserEntity(3, "ياسين بن علي (السباك)", "0770112233", "yacine@khdemli.dz", UserRole.PROFESSIONAL, 16, "الجزائر", "حيدرة"),
        UserEntity(4, "كريم مهدوي (الكهربائي)", "0555223344", "karim@khdemli.dz", UserRole.PROFESSIONAL, 31, "وهران", "بئر الجير"),
        UserEntity(5, "محمد الشريف (تكييف وتبريد)", "0666334455", "mohamed@khdemli.dz", UserRole.PROFESSIONAL, 25, "قسنطينة", "علي منجلي"),
        UserEntity(6, "سفيان العمراوي (ميكانيكي متنقل)", "0777445566", "sofiane@khdemli.dz", UserRole.PROFESSIONAL, 19, "سطيف", "العلمة"),
        UserEntity(7, "طارق زياني (أثاث ونجارة)", "0551556677", "tarek@khdemli.dz", UserRole.PROFESSIONAL, 9, "البليدة", "بوفاريك"),
        UserEntity(8, "عبد القادر بلحاج (دهان وديكور)", "0662667788", "abdelkader@khdemli.dz", UserRole.PROFESSIONAL, 23, "عنابة", "عنابة")
    )
    proUsers.forEach { database.userDao().insertUser(it) }

    val professionals = listOf(
        ProfessionalEntity(
            id = 1,
            userId = 3,
            fullName = "ياسين بن علي",
            phone = "0770112233",
            whatsapp = "0770112233",
            serviceCategoryId = 1,
            professionNameAr = "سباك وترصيص صحي",
            professionNameFr = "Plombier",
            wilayaCode = 16,
            wilayaNameAr = "الجزائر",
            communeNameAr = "حيدرة",
            experienceYears = 8,
            bio = "حرفي سباك معتمد ذو خبرة 8 سنوات في تركيب شبكات المياه الحديثة، تسليك المجاري بأحدث الآلات، وتصليح السخانات والمضخات بدقة وضمان.",
            workingHours = "07:30 - 19:30 (متاح للحالات الطارئة)",
            isAvailable = true,
            isVerified = true,
            isApprovedByAdmin = true,
            ratingAverage = 4.9,
            ratingCount = 38,
            completedJobsCount = 54,
            priceEstimate = "تبدأ من 1500 دج",
            portfolioImages = "تركيب سخان غازي, شبكة مياه PEX متعددة الطبقات, تسليك بالضغط العالي",
            isProSubscriber = true
        ),
        ProfessionalEntity(
            id = 2,
            userId = 4,
            fullName = "كريم مهدوي",
            phone = "0555223344",
            whatsapp = "0555223344",
            serviceCategoryId = 2,
            professionNameAr = "كهربائي منازل وصناعي",
            professionNameFr = "Électricien",
            wilayaCode = 31,
            wilayaNameAr = "وهران",
            communeNameAr = "بئر الجير",
            experienceYears = 6,
            bio = "أقوم بجميع التمديدات الكهربائية للمنازل والمحلات، كشف الشورت الكهربائي، لوحات التحكم وتوزيع الأحمال بأعلى معايير السلامة.",
            workingHours = "08:00 - 18:00 (السبت - الخميس)",
            isAvailable = true,
            isVerified = true,
            isApprovedByAdmin = true,
            ratingAverage = 4.8,
            ratingCount = 29,
            completedJobsCount = 41,
            priceEstimate = "تبدأ من 2000 دج",
            portfolioImages = "لوحة كهربائية ذكية, إضاءة مخفية LED, كشف أعطال",
            isProSubscriber = true
        ),
        ProfessionalEntity(
            id = 3,
            userId = 5,
            fullName = "محمد الشريف",
            phone = "0666334455",
            whatsapp = "0666334455",
            serviceCategoryId = 3,
            professionNameAr = "تكييف وتبريد وتصليح كهرومنزل",
            professionNameFr = "Technicien Froid & Climatisation",
            wilayaCode = 25,
            wilayaNameAr = "قسنطينة",
            communeNameAr = "علي منجلي",
            experienceYears = 10,
            bio = "فني تبريد وتكييف معتمد. تركيب مكيفات Split، شحن الغاز الأصلي R410/R32، وصيانة غسالات وثلاجات.",
            workingHours = "08:00 - 20:00 (يومياً)",
            isAvailable = true,
            isVerified = true,
            isApprovedByAdmin = true,
            ratingAverage = 4.95,
            ratingCount = 62,
            completedJobsCount = 89,
            priceEstimate = "2500 دج للمعاينة والشحن",
            portfolioImages = "تركيب مكيف Inverter, تنظيف وتعقيم المبخر, صيانة ثلاجة No-Frost",
            isProSubscriber = true
        ),
        ProfessionalEntity(
            id = 4,
            userId = 6,
            fullName = "سفيان العمراوي",
            phone = "0777445566",
            whatsapp = "0777445566",
            serviceCategoryId = 4,
            professionNameAr = "ميكانيكي سيارات متنقل وفحص سكانير",
            professionNameFr = "Mécanique auto mobile",
            wilayaCode = 19,
            wilayaNameAr = "سطيف",
            communeNameAr = "العلمة",
            experienceYears = 7,
            bio = "خدمة الميكانيك السريع وفحص السيارات بالسكانير أينما كنت في ولاية سطيف وضواحيها. تبديل الفرامل، السيور، وحل مشاكل الانطلاق.",
            workingHours = "24/24 للنجدة على الطريق",
            isAvailable = true,
            isVerified = false,
            isApprovedByAdmin = true,
            ratingAverage = 4.7,
            ratingCount = 19,
            completedJobsCount = 28,
            priceEstimate = "حسب التدخل والموقع",
            portfolioImages = "فحص OBD2, تغيير قشاط التايمنغ, تدخل طارئ على الطريق",
            isProSubscriber = false
        ),
        ProfessionalEntity(
            id = 5,
            userId = 7,
            fullName = "طارق زياني",
            phone = "0551556677",
            whatsapp = "0551556677",
            serviceCategoryId = 5,
            professionNameAr = "نجار وصانع مطابخ عصرية",
            professionNameFr = "Menuisier",
            wilayaCode = 9,
            wilayaNameAr = "البليدة",
            communeNameAr = "بوفاريك",
            experienceYears = 12,
            bio = "تفصيل وتصميم غرف النوم والمطابخ MDF و High Gloss، تلبيس الأبواب، تعديل الأثاث المستورد بدقة عالية.",
            workingHours = "08:00 - 17:00 (السبت - الخميس)",
            isAvailable = true,
            isVerified = true,
            isApprovedByAdmin = true,
            ratingAverage = 4.85,
            ratingCount = 33,
            completedJobsCount = 47,
            priceEstimate = "حسب المتر والتصميم",
            portfolioImages = "مطبخ ألماني مجهز, خزانة Dressing مدمجة, باب خشب صلب",
            isProSubscriber = false
        ),
        ProfessionalEntity(
            id = 6,
            userId = 8,
            fullName = "عبد القادر بلحاج",
            phone = "0662667788",
            whatsapp = "0662667788",
            serviceCategoryId = 6,
            professionNameAr = "دهان محترف وديكورات بلكوبلاتر",
            professionNameFr = "Peintre & Décorateur",
            wilayaCode = 23,
            wilayaNameAr = "عنابة",
            communeNameAr = "عنابة",
            experienceYears = 9,
            bio = "أحدث الدهانات الديكورية (ستيكو، سابلي، أوتوشنتو)، طلاء الفلل والشقق بأجود أنواع الصباغة المقاومة للرطوبة.",
            workingHours = "07:00 - 17:00",
            isAvailable = true,
            isVerified = true,
            isApprovedByAdmin = true,
            ratingAverage = 4.9,
            ratingCount = 25,
            completedJobsCount = 34,
            priceEstimate = "حسب المساحة ونوع الطلاء",
            portfolioImages = "دهان ديكوري سابلي, صالون عصري بجبس بورد, طلاء واجهة",
            isProSubscriber = false
        )
    )
    professionals.forEach { database.professionalDao().insertProfessional(it) }

    // 4. Seed Sample Requests
    val sampleRequest1 = ServiceRequestEntity(
        id = 1,
        customerId = 2,
        customerName = "أحمد بلقاسم",
        customerPhone = "0661122334",
        professionalId = 1,
        professionalName = "ياسين بن علي",
        professionalPhone = "0770112233",
        serviceCategoryId = 1,
        serviceNameAr = "سباكة وترصيص",
        description = "يوجد تسريب مياه قوي تحت حوض المطبخ وانسداد في مجرى التصريف الرئيسي للشقة، نحتاج تدخل سريع.",
        urgency = RequestUrgency.URGENT,
        wilayaCode = 16,
        wilayaNameAr = "الجزائر",
        communeNameAr = "الجزائر الوسطى",
        addressDetails = "نهج ديدوش مراد، الطابق الثاني",
        status = RequestStatus.IN_PROGRESS,
        agreedPriceDzd = 2500.0,
        customerNotes = "الرجاء إحضار جوان كوتشوك وقطع تبديل 3/4",
        professionalNotes = "في طريقي إلى العنوان ومعدات التسليك جاهزة",
        isRated = false,
        createdAt = System.currentTimeMillis() - 3600000 * 3,
        updatedAt = System.currentTimeMillis() - 1800000
    )
    database.serviceRequestDao().insertRequest(sampleRequest1)

    val sampleRequest2 = ServiceRequestEntity(
        id = 2,
        customerId = 2,
        customerName = "أحمد بلقاسم",
        customerPhone = "0661122334",
        professionalId = 2,
        professionalName = "كريم مهدوي",
        professionalPhone = "0555223344",
        serviceCategoryId = 2,
        serviceNameAr = "كهرباء منازل وصناعي",
        description = "تركيب ثريات صالون وتغيير قواطع لوحة الكهرباء الرئيسية القديمة لقواطع حديثة آمنة.",
        urgency = RequestUrgency.NORMAL,
        wilayaCode = 16,
        wilayaNameAr = "الجزائر",
        communeNameAr = "الجزائر الوسطى",
        status = RequestStatus.COMPLETED,
        agreedPriceDzd = 3500.0,
        isRated = true,
        createdAt = System.currentTimeMillis() - 86400000 * 4,
        updatedAt = System.currentTimeMillis() - 86400000 * 3
    )
    database.serviceRequestDao().insertRequest(sampleRequest2)

    // 5. Seed Reviews
    val review1 = ReviewEntity(
        id = 1,
        requestId = 2,
        customerId = 2,
        customerName = "أحمد بلقاسم",
        professionalId = 2,
        rating = 5,
        comment = "خدمة ممتازة، كريم إنسان خلوق ومحترف في عمله، جاء في الموعد تماماً وأنهى العمل بإتقان ونظافة.",
        createdAt = System.currentTimeMillis() - 86400000 * 3
    )
    database.reviewDao().insertReview(review1)

    val review2 = ReviewEntity(
        id = 2,
        requestId = 0,
        customerId = 0,
        customerName = "فاروق بن عيسى",
        professionalId = 1,
        rating = 5,
        comment = "ياسين سباك ممتاز جداً، أصلح مشكلة التسريب التي عانيت منها لأشهر في نصف ساعة فقط. أنصح بالتعامل معه بشدة.",
        createdAt = System.currentTimeMillis() - 86400000 * 7
    )
    database.reviewDao().insertReview(review2)

    // 6. Seed Sample Messages
    val msg1 = MessageEntity(
        id = 1,
        requestId = 1,
        senderId = 2,
        senderName = "أحمد بلقاسم",
        recipientId = 3,
        content = "السلام عليكم أخ ياسين، هل أنت متوجه للمكان؟",
        timestamp = System.currentTimeMillis() - 2400000,
        isRead = true
    )
    val msg2 = MessageEntity(
        id = 2,
        requestId = 1,
        senderId = 3,
        senderName = "ياسين بن علي",
        recipientId = 2,
        content = "وعليكم السلام خويا أحمد، نعم راني في الطريق 10 دقائق ونكون عندك بحول الله.",
        timestamp = System.currentTimeMillis() - 1800000,
        isRead = true
    )
    database.messageDao().insertMessage(msg1)
    database.messageDao().insertMessage(msg2)

    // 7. Seed Admin Settings
    database.adminSettingsDao().insertOrUpdateSettings(
        AdminSettingsEntity(
            id = 1,
            appName = "خدملي DZ",
            appSlogan = "لقى لي يخدمها",
            commissionRatePercent = 5.0,
            proSubscriptionPriceDzd = 1500.0,
            supportPhone = "0550000000",
            supportEmail = "support@khdemli-dz.com",
            isMaintenanceMode = false,
            isAutoApproveCraftsmen = false,
            ePaymentGatewayEnabled = true
        )
    )

    // 8. Seed Verification Requests
    val verif1 = VerificationRequestEntity(
        id = 1,
        professionalId = 4,
        userId = 6,
        professionalName = "سفيان العمراوي",
        professionNameAr = "ميكانيكي سيارات متنقل",
        phone = "0777445566",
        wilayaCode = 19,
        wilayaNameAr = "سطيف",
        communeNameAr = "العلمة",
        idCardNumber = "19911910023456",
        qualificationOrTradeRegister = "دبلوم تقني سامي في إلكترونيك وميكانيك السيارات + سجل حرفي رقم 19/0423",
        documentNotes = "تم إرفاق نسخة من بطاقة التعريف البيومترية وشهادة الكفاءة المهنية من مركز التكوين المهني سطيف.",
        status = VerificationStatus.PENDING,
        createdAt = System.currentTimeMillis() - 86400000 * 2
    )
    database.verificationRequestDao().insertVerificationRequest(verif1)

    // 9. Seed Sample Reports
    val report1 = ReportEntity(
        id = 1,
        reporterId = 2,
        reporterName = "أحمد بلقاسم",
        targetType = "PROFESSIONAL",
        targetId = 6,
        targetName = "عبد القادر بلحاج",
        reason = "عدم الالتزام بالموعد المحدد",
        details = "تم الاتفاق على الحضور صباح يوم الخميس ولم يحضر دون إبلاغ مسبق.",
        status = ReportStatus.NEW,
        createdAt = System.currentTimeMillis() - 86400000
    )
    database.reportDao().insertReport(report1)

    // 10. Seed Sample Notifications
    val notif1 = NotificationEntity(
        id = 1,
        recipientUserId = 2,
        title = "مرحباً بك في خدملي DZ 🇩🇿",
        body = "منصتك الأولى للعثور على أمهر الحرفيين في كافة الـ 58 ولاية جزائرية بكل أمان وثقة.",
        type = NotificationType.SYSTEM,
        createdAt = System.currentTimeMillis() - 86400000 * 5,
        isRead = true
    )
    val notif2 = NotificationEntity(
        id = 2,
        recipientUserId = 2,
        title = "تحديث حالة الطلب #1",
        body = "الحرفي ياسين بن علي في طريقه إليك لتنفيذ خدمة السباكة والترصيص.",
        type = NotificationType.STATUS_UPDATE,
        targetId = 1,
        createdAt = System.currentTimeMillis() - 1800000,
        isRead = false
    )
    val notif3 = NotificationEntity(
        id = 3,
        recipientUserId = 0, // For admin
        title = "طلب توثيق حرفي جديد 🛡️",
        body = "قام الحرفي سفيان العمراوي بتقديم ملف التوثيق للحصول على شارة حرفي موثوق.",
        type = NotificationType.VERIFICATION_UPDATE,
        targetId = 1,
        createdAt = System.currentTimeMillis() - 86400000 * 2,
        isRead = false
    )
    database.notificationDao().insertNotification(notif1)
    database.notificationDao().insertNotification(notif2)
    database.notificationDao().insertNotification(notif3)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
