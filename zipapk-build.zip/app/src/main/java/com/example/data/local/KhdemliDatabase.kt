package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ProfessionalEntity::class,
        ServiceCategoryEntity::class,
        WilayaEntity::class,
        CommuneEntity::class,
        ServiceRequestEntity::class,
        RequestOfferEntity::class,
        ReviewEntity::class,
        MessageEntity::class,
        ReportEntity::class,
        AdminSettingsEntity::class,
        VerificationRequestEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class KhdemliDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun professionalDao(): ProfessionalDao
    abstract fun serviceCategoryDao(): ServiceCategoryDao
    abstract fun wilayaDao(): WilayaDao
    abstract fun serviceRequestDao(): ServiceRequestDao
    abstract fun requestOfferDao(): RequestOfferDao
    abstract fun reviewDao(): ReviewDao
    abstract fun messageDao(): MessageDao
    abstract fun reportDao(): ReportDao
    abstract fun adminSettingsDao(): AdminSettingsDao
    abstract fun verificationRequestDao(): VerificationRequestDao
    abstract fun notificationDao(): NotificationDao


    companion object {
        @Volatile
        private var INSTANCE: KhdemliDatabase? = null

        fun getDatabase(context: Context): KhdemliDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KhdemliDatabase::class.java,
                    "khdemli_dz_database.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

suspend fun seedDatabase(database: KhdemliDatabase) {
    try {
        // 1. Seed All 58 Wilayas and Communes
        val wilayasList = AlgeriaWilayasData.allWilayas.map {
            WilayaEntity(code = it.code, nameAr = it.nameAr, nameFr = it.nameFr, isCovered = true)
        }
        database.wilayaDao().insertWilayas(wilayasList)

        val communesList = mutableListOf<CommuneEntity>()
        AlgeriaWilayasData.allWilayas.forEach { w ->
            w.communes.forEach { c ->
                communesList.add(CommuneEntity(wilayaCode = w.code, nameAr = c, nameFr = c))
            }
        }
        communesList.chunked(100).forEach { chunk ->
            database.wilayaDao().insertCommunes(chunk)
        }

    // 2. Seed Initial Services
    val initialServices = listOf(
        ServiceCategoryEntity(1, "plumbing", "سباكة وترصيص", "Plomberie", "خدمات تسليك المجاري، تصليح التسريبات، تركيب السخانات وشبكات المياه", "plumbing", true, 1),
        ServiceCategoryEntity(2, "electricity", "كهرباء منازل وصناعي", "Électricité", "صيانة الأعطال الكهربائية، تركيب القواطع، الإضاءة والمآخذ", "electric_bolt", true, 2),
        ServiceCategoryEntity(3, "hvac", "تكييف وتبريد", "Climatisation & Froid", "شحن الغاز، تنظيف وتركيب المكيفات، صيانة غرف التبريد", "ac_unit", true, 3),
        ServiceCategoryEntity(4, "mechanic", "ميكانيكي سيارات", "Mécanique auto", "ميكانيك عام، كهرباء السيارات، الفحص بالسكانير والتدخل السريع", "car_repair", true, 4),
        ServiceCategoryEntity(5, "carpentry", "نجارة وأثاث", "Menuiserie", "صناعة وتصليح الأبواب والمطابخ، تركيب وتعديل الأثاث", "carpenter", true, 5),
        ServiceCategoryEntity(6, "painting", "دهان وديكور", "Peinture", "طلاء الجدران، معالجة الرطوبة، ورق الجدران والديكورات العصرية", "format_paint", true, 6),
        ServiceCategoryEntity(7, "blacksmith", "حدادة وألمنيوم", "Ferronnerie", "أبواب وشبابيك حديدية، ستائر معدنية، هياكل حديدية", "hardware", true, 7),
        ServiceCategoryEntity(8, "masonry", "بناء وترميم", "Maçonnerie", "أشغال البناء، السيراميك والماصو، تلييس وتهيئة الواجهات", "foundation", true, 8),
        ServiceCategoryEntity(9, "appliances", "تصليح أجهزة كهرومنزلية", "Électroménager", "تصليح الثلاجات، الغسالات، الأفران، والميكروويف", "kitchen", true, 9),
        ServiceCategoryEntity(10, "phone_repair", "تصليح هواتف وشاشات", "Réparation Téléphones", "تغيير الشاشات، صيانة البطاريات، الفورمات وإصلاح البورد", "smartphone", true, 10),
        ServiceCategoryEntity(11, "computer_it", "صيانة كمبيوتر وشبكات", "Informatique", "تصليح الحواسيب، تنصيب الويندوز، تركيب شبكات الإنترنت", "computer", true, 11),
        ServiceCategoryEntity(12, "cleaning", "تنظيف منازل ومكاتب", "Nettoyage", "تنظيف شامل بعد الأشغال، غسيل السجاد والواجهات الزجاجية", "cleaning_services", true, 12),
        ServiceCategoryEntity(13, "moving", "نقل البضائع والعفش", "Transport & Déménagement", "شاحنات نقل العفش مع عمال التحميل والتفريغ عبر 58 ولاية", "local_shipping", true, 13),
        ServiceCategoryEntity(14, "cctv_security", "كاميرات مراقبة وإنذار", "Caméras & Sécurité", "تركيب وضبط كاميرات المراقبة، أجهزة الإنذار والمنازل الذكية", "videocam", true, 14),
        ServiceCategoryEntity(15, "locksmith", "أقفال ومفاتيح", "Serrurerie", "فتح الأبواب المغلقة، تغيير الكوالين ونسخ المفاتيح الذكية", "key", true, 15),
        ServiceCategoryEntity(16, "gardening", "بستنة وتنسيق حدائق", "Jardinage", "تقليم الأشجار، زرع العشب، تركيب شبكات السقي بالتقطير", "yard", true, 16)
    )
    database.serviceCategoryDao().insertAllServices(initialServices)

    // 3. Seed Default Platform Admin Settings
    database.adminSettingsDao().insertOrUpdateSettings(
        AdminSettingsEntity(
            id = 1,
            appName = "خدملي DZ",
            appSlogan = "لقى لي يخدمها",
            commissionRatePercent = 5.0,
            proSubscriptionPriceDzd = 1500.0,
            supportPhone = "0550123456",
            supportEmail = "contact@khdemli-dz.com",
            isMaintenanceMode = false,
            isAutoApproveCraftsmen = false,
            ePaymentGatewayEnabled = true
        )
    )
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
