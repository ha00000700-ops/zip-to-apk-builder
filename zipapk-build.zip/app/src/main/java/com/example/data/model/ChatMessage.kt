package com.example.data.model

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val text: String = "",
    val type: String = "text", // text, voice, image, video
    val audioUrl: String = "",
    val mediaUrl: String = "",
    val thumbnailUrl: String = "",
    val duration: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val read: Boolean = false
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "conversationId" to conversationId,
            "senderId" to senderId,
            "receiverId" to receiverId,
            "text" to text,
            "type" to type,
            "audioUrl" to audioUrl,
            "mediaUrl" to mediaUrl,
            "thumbnailUrl" to thumbnailUrl,
            "duration" to duration,
            "createdAt" to createdAt,
            "read" to read
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): ChatMessage {
            return ChatMessage(
                id = id,
                conversationId = map["conversationId"] as? String ?: "",
                senderId = map["senderId"] as? String ?: "",
                receiverId = map["receiverId"] as? String ?: "",
                text = map["text"] as? String ?: "",
                type = map["type"] as? String ?: "text",
                audioUrl = map["audioUrl"] as? String ?: "",
                mediaUrl = map["mediaUrl"] as? String ?: "",
                thumbnailUrl = map["thumbnailUrl"] as? String ?: "",
                duration = (map["duration"] as? Number)?.toLong() ?: 0L,
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                read = map["read"] as? Boolean ?: false
            )
        }
    }
}
