package com.example.data.model

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val text: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val read: Boolean = false
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "conversationId" to conversationId,
            "senderId" to senderId,
            "receiverId" to receiverId,
            "text" to text,
            "createdAt" to createdAt,
            "read" to read
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): ChatMessage {
            return ChatMessage(
                id = id,
                conversationId = map["conversationId"] as? String ?: "",
                senderId = map["senderId"] as? String ?: "",
                receiverId = map["receiverId"] as? String ?: "",
                text = map["text"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                read = map["read"] as? Boolean ?: false
            )
        }
    }
}
