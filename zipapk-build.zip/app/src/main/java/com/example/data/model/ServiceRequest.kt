package com.example.data.model

enum class RequestStatus(val titleAr: String) {
    PENDING("قيد الانتظار"),
    ACCEPTED("تم القبول"),
    IN_PROGRESS("قيد الإنجاز"),
    COMPLETED("مكتمل"),
    REJECTED("مرفوض"),
    CANCELLED("ملغى")
}

data class ServiceRequest(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val providerId: String = "",
    val providerName: String = "",
    val professionId: String = "",
    val professionNameAr: String = "",
    val wilayaName: String = "",
    val communeName: String = "",
    val addressDetails: String = "",
    val description: String = "",
    val status: RequestStatus = RequestStatus.PENDING,
    val proposedPriceDzd: Long? = null,
    val paymentInfo: PaymentInfo = PaymentInfo(),
    val customServiceId: String? = null,
    val scheduledDate: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "customerId" to customerId,
            "customerName" to customerName,
            "customerPhone" to customerPhone,
            "providerId" to providerId,
            "providerName" to providerName,
            "professionId" to professionId,
            "professionNameAr" to professionNameAr,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "addressDetails" to addressDetails,
            "description" to description,
            "status" to status.name,
            "proposedPriceDzd" to proposedPriceDzd,
            "paymentInfo" to paymentInfo.toFirestoreMap(),
            "customServiceId" to customServiceId,
            "scheduledDate" to scheduledDate,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): ServiceRequest {
            return ServiceRequest(
                id = map["id"] as? String ?: "",
                customerId = map["customerId"] as? String ?: "",
                customerName = map["customerName"] as? String ?: "",
                customerPhone = map["customerPhone"] as? String ?: "",
                providerId = map["providerId"] as? String ?: "",
                providerName = map["providerName"] as? String ?: "",
                professionId = map["professionId"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                wilayaName = map["wilayaName"] as? String ?: "",
                communeName = map["communeName"] as? String ?: "",
                addressDetails = map["addressDetails"] as? String ?: "",
                description = map["description"] as? String ?: "",
                status = try {
                    RequestStatus.valueOf(map["status"] as? String ?: RequestStatus.PENDING.name)
                } catch (e: Exception) {
                    RequestStatus.PENDING
                },
                proposedPriceDzd = (map["proposedPriceDzd"] as? Number)?.toLong(),
                paymentInfo = PaymentInfo.fromFirestoreMap(map["paymentInfo"] as? Map<String, Any?>),
                customServiceId = map["customServiceId"] as? String,
                scheduledDate = (map["scheduledDate"] as? Number)?.toLong(),
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
            )
        }
    }
}
