package com.example.data

data class Surah(
    val number: Int,
    val name: String,
    val revelationType: String,
    val numberOfAyahs: Int,
    val ayahs: List<Ayah>
)

data class Ayah(
    val numberInSurah: Int,
    val text: String,
    val page: Int,
    val juz: Int
)
