package com.example.data.model

import java.util.Calendar
import java.util.concurrent.TimeUnit

enum class EventType(val titleAr: String, val iconEmoji: String) {
    FIRST_MET("أول لقاء بيننا", "✨"),
    ANNIVERSARY("ذكرى الخطوبة / الزواج", "💍"),
    HER_BIRTHDAY("عيد ميلاد حبيبتي", "🎂"),
    HIM_BIRTHDAY("عيد ميلاد حبيبي", "🎉"),
    FIRST_LOVE("أول اعتراف بالحب", "💌"),
    CUSTOM("مناسبة خاصة بنا", "💖")
}

data class SpecialEvent(
    val id: String,
    val title: String,
    val year: Int,
    val month: Int, // 1 - 12
    val day: Int,
    val eventType: EventType,
    val note: String = ""
) {
    /**
     * Calculates days until next occurrence of this event
     */
    fun daysUntilNext(): Int {
        val today = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val nextOccurrence = Calendar.getInstance().apply {
            set(Calendar.YEAR, today.get(Calendar.YEAR))
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (nextOccurrence.before(today)) {
            nextOccurrence.add(Calendar.YEAR, 1)
        }

        val diffMillis = nextOccurrence.timeInMillis - today.timeInMillis
        return TimeUnit.MILLISECONDS.toDays(diffMillis).toInt()
    }

    /**
     * Total days passed since original date (e.g. for anniversaries or first met)
     */
    fun totalDaysPassed(): Long {
        val today = Calendar.getInstance()
        val original = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val diff = today.timeInMillis - original.timeInMillis
        return if (diff > 0) TimeUnit.MILLISECONDS.toDays(diff) else 0L
    }
}
