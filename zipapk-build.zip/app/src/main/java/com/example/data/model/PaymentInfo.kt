package com.example.data.model

data class PaymentInfo(
    val status: PaymentStatus = PaymentStatus.UNPAID,
    val method: PaymentMethod = PaymentMethod.CASH,
    val amountDzd: Long = 0L,
    val checkoutId: String? = null,
    val checkoutUrl: String? = null,
    val chargilyPaymentId: String? = null,
    val receiptUrl: String? = null,
    val failureReason: String? = null,
    val createdAt: Long? = null,
    val paidAt: Long? = null
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "status" to status.code,
            "method" to method.code,
            "amountDzd" to amountDzd,
            "checkoutId" to checkoutId,
            "checkoutUrl" to checkoutUrl,
            "chargilyPaymentId" to chargilyPaymentId,
            "receiptUrl" to receiptUrl,
            "failureReason" to failureReason,
            "createdAt" to createdAt,
            "paidAt" to paidAt
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>?): PaymentInfo {
            if (map == null) return PaymentInfo()
            return PaymentInfo(
                status = PaymentStatus.fromCode(map["status"] as? String),
                method = PaymentMethod.fromCode(map["method"] as? String),
                amountDzd = (map["amountDzd"] as? Number)?.toLong() ?: 0L,
                checkoutId = map["checkoutId"] as? String,
                checkoutUrl = map["checkoutUrl"] as? String,
                chargilyPaymentId = map["chargilyPaymentId"] as? String,
                receiptUrl = map["receiptUrl"] as? String,
                failureReason = map["failureReason"] as? String,
                createdAt = (map["createdAt"] as? Number)?.toLong(),
                paidAt = (map["paidAt"] as? Number)?.toLong()
            )
        }
    }
}
