package com.example.data.model

object VerificationStatus {
    const val PENDING = "PENDING"
    const val APPROVED = "APPROVED"
    const val REJECTED = "REJECTED"
}

data class VerificationRequest(
    val id: String = "", // Same as providerUid
    val providerUid: String = "",
    val providerName: String = "",
    val providerPhone: String = "",
    val professionNameAr: String = "",
    val wilayaName: String = "",
    val communeName: String = "",
    val experienceYears: Int = 0,
    val notes: String = "",
    val status: String = VerificationStatus.PENDING,
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val reviewedAt: Long? = null,
    val reviewedBy: String? = null
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "providerUid" to providerUid,
            "providerName" to providerName,
            "providerPhone" to providerPhone,
            "professionNameAr" to professionNameAr,
            "wilayaName" to wilayaName,
            "communeName" to communeName,
            "experienceYears" to experienceYears,
            "notes" to notes,
            "status" to status,
            "rejectionReason" to rejectionReason,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt,
            "reviewedAt" to reviewedAt,
            "reviewedBy" to reviewedBy
        )
    }

    companion object {
        fun fromFirestoreMap(id: String, map: Map<String, Any?>): VerificationRequest {
            return VerificationRequest(
                id = id,
                providerUid = map["providerUid"] as? String ?: id,
                providerName = map["providerName"] as? String ?: "",
                providerPhone = map["providerPhone"] as? String ?: "",
                professionNameAr = map["professionNameAr"] as? String ?: "",
                wilayaName = map["wilayaName"] as? String ?: "",
                communeName = map["communeName"] as? String ?: "",
                experienceYears = (map["experienceYears"] as? Number)?.toInt() ?: 0,
                notes = map["notes"] as? String ?: "",
                status = map["status"] as? String ?: VerificationStatus.PENDING,
                rejectionReason = map["rejectionReason"] as? String ?: "",
                createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                reviewedAt = (map["reviewedAt"] as? Number)?.toLong(),
                reviewedBy = map["reviewedBy"] as? String
            )
        }
    }
}
