package com.example.data.remote

import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object SupabaseConfig {
    /**
     * Supabase Project URL.
     * Configure this value with your Supabase project URL.
     */
    var SUPABASE_URL: String = com.example.BuildConfig.SUPABASE_URL.let {
        if (it.isBlank() || it.contains("your-project")) "https://mgpzpdbvfrbwousswphg.supabase.co" else it
    }

    /**
     * Supabase Anon Key.
     * Configure this value with your Supabase anon/public key.
     */
    var SUPABASE_KEY: String = com.example.BuildConfig.SUPABASE_KEY.ifBlank { "your-anon-key" }

    /**
     * Supabase Storage Bucket name.
     */
    const val BUCKET_NAME: String = "khedmati"

    private val signedUrlCache = ConcurrentHashMap<String, Pair<String, Long>>()

    fun isConfigured(): Boolean {
        return SUPABASE_URL.isNotBlank() &&
                !SUPABASE_URL.contains("your-project") &&
                SUPABASE_KEY.isNotBlank() &&
                !SUPABASE_KEY.contains("your-anon-key")
    }

    /**
     * Extracts the relative object path inside the storage bucket from any Supabase Storage URL.
     */
    fun extractObjectPath(urlString: String): String? {
        if (urlString.isBlank()) return null
        // If already a signed URL with active token, don't re-extract
        if (urlString.contains("/storage/v1/object/sign/") && urlString.contains("token=")) {
            return null
        }
        val marker = "/$BUCKET_NAME/"
        val idx = urlString.indexOf(marker)
        if (idx != -1) {
            val pathWithQuery = urlString.substring(idx + marker.length)
            val clean = pathWithQuery.substringBefore("?").removePrefix("/")
            return clean.ifBlank { null }
        }
        return null
    }

    /**
     * Generates or retrieves a cached time-limited signed URL for a private bucket object
     * using the Supabase Storage signing endpoint.
     */
    fun getSignedUrl(objectPath: String, okHttpClient: OkHttpClient? = null): String? {
        val cleanPath = objectPath.removePrefix("/")
        if (cleanPath.isBlank()) return null
        val now = System.currentTimeMillis()

        // Check in-memory cache with 5-minute safety margin
        signedUrlCache[cleanPath]?.let { (cachedUrl, expiryTime) ->
            if (now < expiryTime - 300_000) {
                return cachedUrl
            }
        }

        if (!isConfigured()) {
            return null
        }

        val client = okHttpClient ?: OkHttpClient()
        val signEndpoint = "$SUPABASE_URL/storage/v1/object/sign/$BUCKET_NAME/$cleanPath"
        val jsonBody = """{"expiresIn": 7200}""".toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url(signEndpoint)
            .addHeader("apikey", SUPABASE_KEY)
            .addHeader("Authorization", "Bearer $SUPABASE_KEY")
            .post(jsonBody)
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.w("SupabaseConfig", "Supabase sign request returned code ${response.code} for path: $cleanPath")
                    null
                } else {
                    val bodyString = response.body?.string() ?: return null
                    val json = JSONObject(bodyString)
                    val signedPath = json.optString("signedURL").ifBlank { json.optString("signedUrl") }
                    if (signedPath.isNotBlank()) {
                        val fullSignedUrl = if (signedPath.startsWith("http")) signedPath else "$SUPABASE_URL$signedPath"
                        val expiryTime = now + (7200 * 1000L)
                        signedUrlCache[cleanPath] = Pair(fullSignedUrl, expiryTime)
                        fullSignedUrl
                    } else {
                        null
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("SupabaseConfig", "Exception retrieving signed URL for $cleanPath", e)
            null
        }
    }

    fun resolveUrl(urlOrPath: String): String {
        if (urlOrPath.isBlank()) return ""
        if (urlOrPath.startsWith("content://") || urlOrPath.startsWith("file://")) {
            return urlOrPath
        }
        if (urlOrPath.startsWith("http://") || urlOrPath.startsWith("https://")) {
            // Ensure any existing public Supabase URLs are converted back to private ones dynamically
            // so they are processed by the custom Coil interceptor for secure signing.
            val publicMarker = "/storage/v1/object/public/$BUCKET_NAME/"
            val privateMarker = "/storage/v1/object/$BUCKET_NAME/"
            if (urlOrPath.contains(publicMarker)) {
                return urlOrPath.replace(publicMarker, privateMarker)
            }
            return urlOrPath
        }
        val cleanPath = urlOrPath.removePrefix("/")
        return "$SUPABASE_URL/storage/v1/object/$BUCKET_NAME/$cleanPath"
    }
}


