package com.example.data.remote

object SupabaseConfig {
    /**
     * Supabase Project URL.
     * Configure this value with your Supabase project URL.
     */
    var SUPABASE_URL: String = "https://your-project.supabase.co"

    /**
     * Supabase Anon Key.
     * Configure this value with your Supabase anon/public key.
     */
    var SUPABASE_KEY: String = "your-anon-key"

    /**
     * Supabase Storage Bucket name.
     */
    const val BUCKET_NAME: String = "khedmati"
}
