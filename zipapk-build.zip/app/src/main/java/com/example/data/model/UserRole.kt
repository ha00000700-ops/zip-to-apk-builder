package com.example.data.model

enum class UserRole(val code: String, val titleAr: String, val descriptionAr: String) {
    CUSTOMER(
        code = "CUSTOMER",
        titleAr = "زبون / باحث عن خدمة",
        descriptionAr = "أبحث عن حرفيين ومهنيين موثوقين لإنجاز أشغال وخدمات في منطقتي"
    ),
    SERVICE_PROVIDER(
        code = "SERVICE_PROVIDER",
        titleAr = "حرفي / مقدم خدمة",
        descriptionAr = "أقدم خدمات مهنية وحرفية وأستقبل طلبات العمل من الزبائن"
    ),
    ADMIN(
        code = "ADMIN",
        titleAr = "مدير النظام",
        descriptionAr = "إدارة وتسيير منصة خدمتي ومتابعة المستخدمين والطلبات"
    );

    companion object {
        fun fromCode(code: String?): UserRole {
            return when (code?.uppercase()) {
                "ADMIN" -> ADMIN
                "SERVICE_PROVIDER", "PROVIDER", "CRAFTSMAN" -> SERVICE_PROVIDER
                else -> CUSTOMER
            }
        }
    }
}
