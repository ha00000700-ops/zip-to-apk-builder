package com.example.data.model

enum class UserRole(val code: String, val titleAr: String, val descriptionAr: String) {
    CUSTOMER(
        code = "CUSTOMER",
        titleAr = "زبون / باحث عن خدمة",
        descriptionAr = "أبحث عن حرفيين ومهنيين موثوقين لإنجاز أشغال وخدمات في منطقتي"
    ),
    SERVICE_PROVIDER(
        code = "SERVICE_PROVIDER",
        titleAr = "حرفي / مقدم خدمة",
        descriptionAr = "أقدم خدمات مهنية وحرفية وأستقبل طلبات العمل من الزبائن"
    );

    companion object {
        fun fromCode(code: String?): UserRole {
            return when (code?.uppercase()) {
                "SERVICE_PROVIDER", "PROVIDER", "CRAFTSMAN" -> SERVICE_PROVIDER
                else -> CUSTOMER
            }
        }
    }
}
