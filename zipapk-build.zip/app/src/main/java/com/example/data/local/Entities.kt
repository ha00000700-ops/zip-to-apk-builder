package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plants")
data class PlantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val scientificName: String = "",
    val plantType: String, // خضروات، أشجار مثمرة، نباتات زينة، نباتات عطرية، نخيل، محاصيل
    val location: String, // حديقة، حقل، داخل المنزل، شرفة، دفيئة، أصيص
    val imagePath: String = "",
    val plantedDate: String = "",
    val wateringIntervalDays: Int = 3,
    val fertilizingIntervalDays: Int = 14,
    val lastWateredDate: Long = 0L,
    val lastFertilizedDate: Long = 0L,
    val healthStatus: String = "سليم", // سليم، يحتاج رعاية، مصاب، في طور العلاج
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "diagnoses")
data class DiagnosisEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantId: Long? = null,
    val plantCommonName: String,
    val plantScientificName: String = "",
    val generalHealth: String = "",
    val diseaseName: String,
    val scientificDiseaseName: String = "",
    val confidenceLevel: String, // أدلة بصرية واضحة، احتمال متوسط، اشتباه أولي يتطلب فحصاً مخبرياً
    val severity: String, // منخفض، متوسط، مرتفع، حرج
    val urgency: String, // تدخل فوري، خلال 24-48 ساعة، متابعة دورية
    val affectedPart: String, // الأوراق، الساق، الثمار، الجذور
    val symptomsSummary: String,
    val possibleCauses: String,
    val alternativeDiagnoses: String = "",
    val environmentalFactors: String = "", // ري، حرارة، ضوء، نقص عناصر
    val immediateActions: String,
    val preventiveCare: String,
    val chemicalTreatments: String, // المواد الفعالة والتحذيرات
    val imagePath: String = "",
    val secondImagePath: String = "", // للمقارنة ومتابعة التحسن
    val additionalImages: String = "", // مسارات صور إضافية مفصولة بفواصل (ورقة، ساق، ثمرة)
    val pathogenType: String = "غير محدد", // فطري، بكتيري، فيروسي، حشري / آفة، نقص عناصر غذائية، إجهاد ري، إجهاد حراري
    val clarifyingQuestions: String = "", // أسئلة متابعة ذكية عندما تكون الصورة غير واضحة
    val scientificSources: String = "", // مراجع علمية معتمدة (INRAA, FAO)
    val followUpNotes: String = "",
    val improvementRating: Int = 0, // 0 = لم يُقيّم، 1 إلى 5
    val advisoryNote: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "care_tasks")
data class CareTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantId: Long,
    val plantName: String,
    val taskType: String, // ري، تسميد، تقليم، فحص، وقاية
    val dueDate: Long,
    val isCompleted: Boolean = false,
    val completedAt: Long? = null,
    val notes: String = ""
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "assistant"
    val text: String,
    val imagePath: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val followUpQuestions: String = "", // أسئلة متابعة مفصولة بفواصل
    val linkedPlantId: Long? = null // لربط السؤال بنبات معين
)

@Entity(tableName = "plant_growth_entries")
data class PlantGrowthEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val plantId: Long,
    val imagePath: String,
    val stageTitle: String, // تشتيل، نمو خضري، إزهار، عقد ثمار، نضج
    val heightCm: Double? = null,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "issue_reports")
data class IssueReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val diagnosisId: Long? = null,
    val plantName: String = "",
    val issueType: String = "تشخيص غير دقيق",
    val userComment: String,
    val contactEmail: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isReviewed: Boolean = false
)
