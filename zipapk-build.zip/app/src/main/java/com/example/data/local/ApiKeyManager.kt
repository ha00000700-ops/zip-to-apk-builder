package com.example.data.local

import android.content.Context
import com.example.BuildConfig

/**
 * Manages access to the hidden Gemini API key securely injected via BuildConfig
 * without exposing it in the UI or plain text files.
 */
class ApiKeyManager(context: Context) {

    fun getApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY?.trim() ?: ""
            if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") {
                key
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun hasValidKey(): Boolean = getApiKey().isNotBlank()
}
