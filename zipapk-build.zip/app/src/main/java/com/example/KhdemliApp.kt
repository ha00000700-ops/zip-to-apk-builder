package com.example

import android.app.Application
import com.example.data.local.KhdemliDatabase
import com.example.data.local.seedDatabase
import com.example.data.remote.FirebaseManager
import com.example.data.repository.KhdemliRepository
import com.example.data.repository.SessionManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class KhdemliApp : Application() {

    lateinit var database: KhdemliDatabase
        private set

    lateinit var firebaseManager: FirebaseManager
        private set

    lateinit var repository: KhdemliRepository
        private set

    lateinit var sessionManager: SessionManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = KhdemliDatabase.getDatabase(this)
        firebaseManager = FirebaseManager.getInstance(this)
        repository = KhdemliRepository(database, firebaseManager, this)
        sessionManager = SessionManager(database, firebaseManager)

        com.example.util.NotificationHelper.createNotificationChannel(this)

        // Ensure database is seeded asynchronously on first run
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // If users table is empty, trigger seed
                val initialUsers = database.userDao().getUserByPhone("0550000000")
                if (initialUsers == null) {
                    seedDatabase(database)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
