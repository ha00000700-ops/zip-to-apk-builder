package com.example.receiver

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.model.ReceiverStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class TvReceiverEngine {

    private val tag = "TvReceiverEngine"
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var connectionJob: Job? = null
    private val shouldAutoReconnect = AtomicBoolean(true)

    private val _status = MutableStateFlow(ReceiverStatus.DISCONNECTED)
    val status = _status.asStateFlow()

    private val _latestFrame = MutableStateFlow<Bitmap?>(null)
    val latestFrame = _latestFrame.asStateFlow()

    private val _receiverFps = MutableStateFlow(0)
    val receiverFps = _receiverFps.asStateFlow()

    private val _measuredLatencyMs = MutableStateFlow(0L)
    val measuredLatencyMs = _measuredLatencyMs.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage = _errorMessage.asStateFlow()

    private val frameCounter = AtomicInteger(0)
    private var lastFpsCalcTime = System.currentTimeMillis()

    fun connect(targetUrl: String, pin: String = "") {
        disconnect()
        shouldAutoReconnect.set(true)

        val fullUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            "http://$targetUrl"
        } else {
            targetUrl
        }

        val baseStreamUrl = if (fullUrl.endsWith("/stream")) fullUrl else "$fullUrl/stream"
        val streamUrl = if (pin.isNotBlank() && !baseStreamUrl.contains("pin=")) {
            if (baseStreamUrl.contains("?")) "$baseStreamUrl&pin=$pin" else "$baseStreamUrl?pin=$pin"
        } else {
            baseStreamUrl
        }

        _status.value = ReceiverStatus.CONNECTING
        _errorMessage.value = null

        connectionJob = scope.launch {
            var retryCount = 0

            while (isActive && shouldAutoReconnect.get()) {
                var connection: HttpURLConnection? = null
                var inputStream: BufferedInputStream? = null

                try {
                    Log.d(tag, "Connecting to stream URL: $streamUrl (attempt ${retryCount + 1})")
                    val url = URL(streamUrl)
                    connection = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 6000
                        readTimeout = 15000
                        useCaches = false
                        if (pin.isNotBlank()) {
                            setRequestProperty("X-Pin", pin)
                            setRequestProperty("Authorization", "Bearer $pin")
                        }
                        setRequestProperty("User-Agent", "CastDirect-TV-Receiver/1.0")
                    }
                    connection.connect()

                    if (connection.responseCode == 401) {
                        _status.value = ReceiverStatus.ERROR
                        _errorMessage.value = "رمز PIN غير صحيح أو مفقود. تحقق من رمز الأمان على الهاتف."
                        shouldAutoReconnect.set(false)
                        return@launch
                    }

                    if (connection.responseCode != 200) {
                        _status.value = ReceiverStatus.ERROR
                        _errorMessage.value = "استجابة الخادم: كود ${connection.responseCode}"
                        delay(2000)
                        retryCount++
                        continue
                    }

                    _status.value = ReceiverStatus.STREAMING
                    _errorMessage.value = null
                    retryCount = 0
                    inputStream = BufferedInputStream(connection.inputStream, 64 * 1024)

                    // Start FPS calculation loop
                    val fpsJob = launch {
                        while (isActive) {
                            delay(1000)
                            val elapsed = System.currentTimeMillis() - lastFpsCalcTime
                            if (elapsed >= 1000) {
                                _receiverFps.value = (frameCounter.getAndSet(0) * 1000.0 / elapsed).toInt()
                                lastFpsCalcTime = System.currentTimeMillis()
                            }
                        }
                    }

                    // Parser for multipart/x-mixed-replace JPEG stream
                    readMjpegStream(inputStream)

                    fpsJob.cancel()

                } catch (e: Exception) {
                    if (isActive && shouldAutoReconnect.get()) {
                        Log.w(tag, "Connection drop: ${e.message}, retrying in 2s...")
                        _status.value = ReceiverStatus.CONNECTING
                        _errorMessage.value = "انقطع الاتصال، جاري إعادة المحاولة تلقائياً..."
                        delay(2000)
                        retryCount++
                    }
                } finally {
                    try { inputStream?.close() } catch (_: Exception) {}
                    try { connection?.disconnect() } catch (_: Exception) {}
                }
            }

            if (!shouldAutoReconnect.get()) {
                _status.value = ReceiverStatus.DISCONNECTED
            }
        }
    }

    private fun readMjpegStream(stream: BufferedInputStream) {
        val frameBuffer = ByteArrayOutputStream(128 * 1024)
        var prevByte = -1

        while (scope.isActive && shouldAutoReconnect.get()) {
            val b = stream.read()
            if (b == -1) break

            // Detect Start of Image: 0xFF 0xD8
            if (prevByte == 0xFF && b == 0xD8) {
                frameBuffer.reset()
                frameBuffer.write(0xFF)
                frameBuffer.write(0xD8)

                var framePrev = 0xD8
                while (scope.isActive && shouldAutoReconnect.get()) {
                    val frameByte = stream.read()
                    if (frameByte == -1) return
                    frameBuffer.write(frameByte)

                    // Detect End of Image: 0xFF 0xD9
                    if (framePrev == 0xFF && frameByte == 0xD9) {
                        val jpegBytes = frameBuffer.toByteArray()
                        val bitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                        if (bitmap != null) {
                            val old = _latestFrame.value
                            _latestFrame.value = bitmap
                            old?.recycle()
                            frameCounter.incrementAndGet()
                        }
                        break
                    }
                    framePrev = frameByte
                }
            }
            prevByte = b
        }
    }

    fun disconnect() {
        shouldAutoReconnect.set(false)
        connectionJob?.cancel()
        connectionJob = null
        _status.value = ReceiverStatus.DISCONNECTED
        _receiverFps.value = 0
        _latestFrame.value?.recycle()
        _latestFrame.value = null
    }
}
