package com.example.receiver

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.example.model.ReceiverStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class TvReceiverEngine {

    private val tag = "TvReceiverEngine"
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var connectionJob: Job? = null
    private var audioJob: Job? = null
    private var audioTrack: AudioTrack? = null
    private val shouldAutoReconnect = AtomicBoolean(true)

    private val _status = MutableStateFlow(ReceiverStatus.DISCONNECTED)
    val status = _status.asStateFlow()

    private val _isAudioMuted = MutableStateFlow(false)
    val isAudioMuted = _isAudioMuted.asStateFlow()

    private val _latestFrame = MutableStateFlow<Bitmap?>(null)
    val latestFrame = _latestFrame.asStateFlow()

    private val _receiverFps = MutableStateFlow(0)
    val receiverFps = _receiverFps.asStateFlow()

    private val _measuredLatencyMs = MutableStateFlow(0L)
    val measuredLatencyMs = _measuredLatencyMs.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage = _errorMessage.asStateFlow()

    private val frameCounter = AtomicInteger(0)
    private var lastFpsCalcTime = System.currentTimeMillis()

    fun connect(targetUrl: String, pin: String = "") {
        disconnect()
        shouldAutoReconnect.set(true)

        val fullUrl = if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            "http://$targetUrl"
        } else {
            targetUrl
        }

        val baseStreamUrl = if (fullUrl.endsWith("/stream")) fullUrl else "$fullUrl/stream"
        val streamUrl = if (pin.isNotBlank() && !baseStreamUrl.contains("pin=")) {
            if (baseStreamUrl.contains("?")) "$baseStreamUrl&pin=$pin" else "$baseStreamUrl?pin=$pin"
        } else {
            baseStreamUrl
        }

        _status.value = ReceiverStatus.CONNECTING
        _errorMessage.value = null

        startAudioPlayback(fullUrl, pin)

        connectionJob = scope.launch {
            var retryCount = 0

            while (isActive && shouldAutoReconnect.get()) {
                var connection: HttpURLConnection? = null
                var inputStream: BufferedInputStream? = null

                try {
                    Log.d(tag, "Connecting to stream URL: $streamUrl (attempt ${retryCount + 1})")
                    val url = URL(streamUrl)
                    connection = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 6000
                        readTimeout = 15000
                        useCaches = false
                        if (pin.isNotBlank()) {
                            setRequestProperty("X-Pin", pin)
                            setRequestProperty("Authorization", "Bearer $pin")
                        }
                        setRequestProperty("User-Agent", "CastDirect-TV-Receiver/1.0")
                    }
                    connection.connect()

                    if (connection.responseCode == 401) {
                        _status.value = ReceiverStatus.ERROR
                        _errorMessage.value = "رمز PIN غير صحيح أو مفقود. تحقق من رمز الأمان على الهاتف."
                        shouldAutoReconnect.set(false)
                        return@launch
                    }

                    if (connection.responseCode != 200) {
                        _status.value = ReceiverStatus.ERROR
                        _errorMessage.value = "استجابة الخادم: كود ${connection.responseCode}"
                        delay(2000)
                        retryCount++
                        continue
                    }

                    _status.value = ReceiverStatus.STREAMING
                    _errorMessage.value = null
                    retryCount = 0
                    inputStream = BufferedInputStream(connection.inputStream, 64 * 1024)

                    // Start FPS calculation loop
                    val fpsJob = launch {
                        while (isActive) {
                            delay(1000)
                            val elapsed = System.currentTimeMillis() - lastFpsCalcTime
                            if (elapsed >= 1000) {
                                _receiverFps.value = (frameCounter.getAndSet(0) * 1000.0 / elapsed).toInt()
                                lastFpsCalcTime = System.currentTimeMillis()
                            }
                        }
                    }

                    // Parser for multipart/x-mixed-replace JPEG stream
                    readMjpegStream(inputStream)

                    fpsJob.cancel()

                } catch (e: Exception) {
                    if (isActive && shouldAutoReconnect.get()) {
                        Log.w(tag, "Connection drop: ${e.message}, retrying in 2s...")
                        _status.value = ReceiverStatus.CONNECTING
                        _errorMessage.value = "انقطع الاتصال، جاري إعادة المحاولة تلقائياً..."
                        delay(2000)
                        retryCount++
                    }
                } finally {
                    try { inputStream?.close() } catch (_: Exception) {}
                    try { connection?.disconnect() } catch (_: Exception) {}
                }
            }

            if (!shouldAutoReconnect.get()) {
                _status.value = ReceiverStatus.DISCONNECTED
            }
        }
    }

    private fun readMjpegStream(stream: BufferedInputStream) {
        val frameBuffer = ByteArrayOutputStream(128 * 1024)
        var prevByte = -1

        while (scope.isActive && shouldAutoReconnect.get()) {
            val b = stream.read()
            if (b == -1) break

            // Detect Start of Image: 0xFF 0xD8
            if (prevByte == 0xFF && b == 0xD8) {
                frameBuffer.reset()
                frameBuffer.write(0xFF)
                frameBuffer.write(0xD8)

                var framePrev = 0xD8
                while (scope.isActive && shouldAutoReconnect.get()) {
                    val frameByte = stream.read()
                    if (frameByte == -1) return
                    frameBuffer.write(frameByte)

                    // Detect End of Image: 0xFF 0xD9
                    if (framePrev == 0xFF && frameByte == 0xD9) {
                        val jpegBytes = frameBuffer.toByteArray()
                        val bitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                        if (bitmap != null) {
                            val old = _latestFrame.value
                            _latestFrame.value = bitmap
                            old?.recycle()
                            frameCounter.incrementAndGet()
                        }
                        break
                    }
                    framePrev = frameByte
                }
            }
            prevByte = b
        }
    }

    fun toggleMute() {
        val newMuted = !_isAudioMuted.value
        _isAudioMuted.value = newMuted
        if (newMuted) {
            audioTrack?.setVolume(0f)
        } else {
            audioTrack?.setVolume(1f)
        }
    }

    private fun startAudioPlayback(baseUrl: String, pin: String) {
        val baseAudioUrl = if (baseUrl.endsWith("/audio")) baseUrl else "$baseUrl/audio"
        val audioUrl = if (pin.isNotBlank() && !baseAudioUrl.contains("pin=")) {
            if (baseAudioUrl.contains("?")) "$baseAudioUrl&pin=$pin" else "$baseAudioUrl?pin=$pin"
        } else {
            baseAudioUrl
        }

        audioJob?.cancel()
        audioJob = scope.launch {
            var stream: BufferedInputStream? = null
            var conn: HttpURLConnection? = null
            try {
                val bufferSize = AudioTrack.getMinBufferSize(
                    48000,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(8192)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(48000)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                track.play()
                audioTrack = track

                val url = URL(audioUrl)
                conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 15000
                    useCaches = false
                    if (pin.isNotBlank()) {
                        setRequestProperty("X-Pin", pin)
                        setRequestProperty("Authorization", "Bearer $pin")
                    }
                }
                conn.connect()

                if (conn.responseCode == 200) {
                    stream = BufferedInputStream(conn.inputStream, 8192)
                    // Skip 44-byte WAV header
                    val headerBytes = ByteArray(44)
                    var readHeader = 0
                    while (readHeader < 44) {
                        val r = stream.read(headerBytes, readHeader, 44 - readHeader)
                        if (r <= 0) break
                        readHeader += r
                    }

                    val buffer = ByteArray(3840)
                    while (isActive && shouldAutoReconnect.get()) {
                        val bytesRead = stream.read(buffer, 0, buffer.size)
                        if (bytesRead > 0) {
                            if (!_isAudioMuted.value) {
                                track.write(buffer, 0, bytesRead)
                            }
                        } else if (bytesRead == -1) {
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(tag, "Audio playback notice: ${e.message}")
            } finally {
                try { stream?.close() } catch (_: Exception) {}
                try { conn?.disconnect() } catch (_: Exception) {}
                try { audioTrack?.stop() } catch (_: Exception) {}
                try { audioTrack?.release() } catch (_: Exception) {}
                audioTrack = null
            }
        }
    }

    fun disconnect() {
        shouldAutoReconnect.set(false)
        connectionJob?.cancel()
        connectionJob = null
        audioJob?.cancel()
        audioJob = null
        try { audioTrack?.stop() } catch (_: Exception) {}
        try { audioTrack?.release() } catch (_: Exception) {}
        audioTrack = null
        _status.value = ReceiverStatus.DISCONNECTED
        _receiverFps.value = 0
        _latestFrame.value?.recycle()
        _latestFrame.value = null
    }
}
