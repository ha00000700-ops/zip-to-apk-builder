package com.example.server

import android.graphics.Bitmap
import android.util.Log
import com.example.model.StreamStats
import com.example.util.StandbyFrameGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class LocalStreamServer(
    private val port: Int = 8080,
    var pinSecurityEnabled: Boolean = true,
    var pairingPin: String = "4829"
) {
    val actualPort: Int
        get() = serverSocket?.localPort ?: port
    val activeClientsCount: Int
        get() = activeClients.size
    val totalBytesTransferred: Long
        get() = totalBytesSent.get()
    private val tag = "LocalStreamServer"
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val activeClients = ConcurrentHashMap<Socket, OutputStream>()
    private val activeAudioClients = ConcurrentHashMap<Socket, OutputStream>()
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val frameCount = AtomicInteger(0)
    private val totalBytesSent = AtomicLong(0L)
    private val totalAudioBytesSent = AtomicLong(0L)
    private var lastFpsCalculationTime = System.currentTimeMillis()
    private var currentFps = 0
    private var currentBitrateKbps = 0
    private var bytesInCurrentSecond = 0L

    private val _streamStats = MutableStateFlow(StreamStats())
    val streamStats = _streamStats.asStateFlow()

    @Volatile
    private var latestFrameJpeg: ByteArray? = null

    @Volatile
    var isPausedBySystem: Boolean = false
        set(value) {
            field = value
            if (value) {
                // Broadcast pause frame immediately to all connected TV clients
                val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                broadcastFrame(pauseFrame)
            }
        }

    private fun log(msg: String, isError: Boolean = false) {
        try {
            if (isError) Log.e(tag, msg) else Log.d(tag, msg)
        } catch (_: Throwable) {
            println("[$tag] $msg")
        }
    }

    fun start() {
        if (isRunning.getAndSet(true)) return

        try {
            serverSocket = ServerSocket(port).apply {
                reuseAddress = true
            }
            log("Local stream server listening on port $port")
        } catch (e: Exception) {
            log("Failed to bind server socket: ${e.message}", true)
            isRunning.set(false)
            return
        }

        scope.launch {
            try {
                while (isActive && isRunning.get()) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: Exception) {
                        break
                    }
                    handleClient(socket)
                }
            } catch (e: Exception) {
                log("Server error: ${e.message}", true)
            } finally {
                stop()
            }
        }

        // Stats & Standby heartbeat loop
        scope.launch {
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(1000)
                val now = System.currentTimeMillis()
                val elapsed = now - lastFpsCalculationTime
                if (elapsed >= 1000) {
                    currentFps = (frameCount.getAndSet(0) * 1000.0 / elapsed).toInt()
                    currentBitrateKbps = ((bytesInCurrentSecond * 8) / 1024).toInt()
                    bytesInCurrentSecond = 0L
                    lastFpsCalculationTime = now

                    _streamStats.value = _streamStats.value.copy(
                        fps = currentFps,
                        activeClients = activeClients.size,
                        bytesSent = totalBytesSent.get(),
                        currentBitrateKbps = currentBitrateKbps,
                        uptimeSeconds = _streamStats.value.uptimeSeconds + 1
                    )
                }

                // If paused by Messenger or external app, send heartbeat paused frame every 1.5 seconds
                // to maintain connection alive without disconnects!
                if (isPausedBySystem && activeClients.isNotEmpty()) {
                    val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                    broadcastFrame(pauseFrame)
                }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        scope.launch {
            try {
                socket.tcpNoDelay = true
                socket.soTimeout = 15000
                val inputStream = socket.getInputStream()
                val outputStream = socket.getOutputStream()

                val buffer = ByteArray(2048)
                val bytesRead = inputStream.read(buffer)
                if (bytesRead <= 0) {
                    socket.close()
                    return@launch
                }

                val requestHeader = String(buffer, 0, bytesRead)
                val firstLine = requestHeader.lines().firstOrNull() ?: ""

                // Check PIN Authorization
                val isAuthorized = !pinSecurityEnabled || isRequestAuthorized(requestHeader)

                when {
                    firstLine.contains("GET /stream") -> {
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            return@launch
                        }

                        // MJPEG low-latency stream for TV
                        sendMjpegHeaders(outputStream)
                        activeClients[socket] = outputStream
                        _streamStats.value = _streamStats.value.copy(activeClients = activeClients.size)

                        val initialFrame = if (isPausedBySystem) {
                            StandbyFrameGenerator.generatePausedFrame()
                        } else {
                            latestFrameJpeg
                        }

                        initialFrame?.let { frame ->
                            writeFrame(outputStream, frame)
                        }
                    }
                    firstLine.contains("GET /audio") -> {
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            return@launch
                        }

                        val header = "HTTP/1.1 200 OK\r\n" +
                                "Content-Type: audio/wav\r\n" +
                                "Access-Control-Allow-Origin: *\r\n" +
                                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                                "Pragma: no-cache\r\n" +
                                "Connection: close\r\n\r\n"
                        outputStream.write(header.toByteArray())
                        outputStream.write(buildStreamingWavHeader())
                        outputStream.flush()
                        activeAudioClients[socket] = outputStream
                    }
                    firstLine.contains("GET /status") -> {
                        val json = """{"status":"${if (isPausedBySystem) "paused" else "streaming"}","fps":$currentFps,"clients":${activeClients.size},"audioClients":${activeAudioClients.size},"bitrateKbps":$currentBitrateKbps,"pinRequired":$pinSecurityEnabled}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    else -> {
                        // Serve TV Web Receiver HTML interface (with PIN prompt if enabled)
                        val html = getTvViewerHtml(pinSecurityEnabled, isAuthorized)
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ${html.toByteArray().size}\r\nConnection: close\r\n\r\n$html"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                }
            } catch (e: Exception) {
                activeClients.remove(socket)
                activeAudioClients.remove(socket)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    private fun isRequestAuthorized(headers: String): Boolean {
        // Check query param e.g. /stream?pin=XXXX
        val queryPin = Regex("[?&]pin=([0-9]{4})").find(headers)?.groupValues?.get(1)
        if (queryPin == pairingPin) return true

        // Check header e.g. X-Pin: XXXX or Authorization: Bearer XXXX
        if (headers.contains("X-Pin: $pairingPin", ignoreCase = true)) return true
        if (headers.contains("Authorization: Bearer $pairingPin", ignoreCase = true)) return true

        // Check Cookie e.g. Cookie: cast_pin=XXXX
        if (headers.contains("cast_pin=$pairingPin", ignoreCase = true)) return true

        return false
    }

    private fun sendMjpegHeaders(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Connection: close\r\n" +
                "Server: CastDirect/1.0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=--frame\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()
    }

    private fun writeFrame(output: OutputStream, jpegData: ByteArray) {
        val timestamp = System.currentTimeMillis()
        val frameHeader = "--frame\r\n" +
                "Content-Type: image/jpeg\r\n" +
                "Content-Length: ${jpegData.size}\r\n" +
                "X-Timestamp: $timestamp\r\n\r\n"
        output.write(frameHeader.toByteArray())
        output.write(jpegData)
        output.write("\r\n".toByteArray())
        output.flush()
    }

    fun broadcastFrame(jpegData: ByteArray) {
        if (!isRunning.get() || activeClients.isEmpty()) {
            latestFrameJpeg = jpegData
            return
        }

        latestFrameJpeg = jpegData
        frameCount.incrementAndGet()
        val dataSize = jpegData.size.toLong()
        val updatedTotal = totalBytesSent.addAndGet(dataSize)
        bytesInCurrentSecond += dataSize
        _streamStats.value = _streamStats.value.copy(bytesSent = updatedTotal)

        val deadSockets = mutableListOf<Socket>()

        for ((socket, outStream) in activeClients) {
            try {
                writeFrame(outStream, jpegData)
            } catch (e: Exception) {
                deadSockets.add(socket)
            }
        }

        for (socket in deadSockets) {
            activeClients.remove(socket)
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun broadcastAudioChunk(pcmData: ByteArray, timestamp: Long = System.currentTimeMillis()) {
        if (!isRunning.get() || activeAudioClients.isEmpty()) return

        totalAudioBytesSent.addAndGet(pcmData.size.toLong())
        val deadSockets = mutableListOf<Socket>()

        for ((socket, outStream) in activeAudioClients) {
            try {
                outStream.write(pcmData)
                outStream.flush()
            } catch (e: Exception) {
                deadSockets.add(socket)
            }
        }

        for (socket in deadSockets) {
            activeAudioClients.remove(socket)
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun buildStreamingWavHeader(sampleRate: Int = 48000, channels: Int = 2, bitsPerSample: Int = 16): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)
        val totalDataLen = 0x7FFFFFFF // Streaming / indefinite length flag
        val totalAudioLen = totalDataLen + 36

        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalAudioLen and 0xff).toByte()
        header[5] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[6] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[7] = ((totalAudioLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 4 bytes: size of 'fmt ' chunk
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // format = 1 (PCM)
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = blockAlign.toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalDataLen and 0xff).toByte()
        header[41] = ((totalDataLen shr 8) and 0xff).toByte()
        header[42] = ((totalDataLen shr 16) and 0xff).toByte()
        header[43] = ((totalDataLen shr 24) and 0xff).toByte()
        return header
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        for ((socket, _) in activeClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeClients.clear()

        for ((socket, _) in activeAudioClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeAudioClients.clear()

        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        log("Local stream server stopped")
    }

    private fun getTvViewerHtml(pinRequired: Boolean, isAuthorized: Boolean): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CastDirect TV Receiver</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body {
            background-color: #000;
            color: #F0F4F8;
            font-family: system-ui, -apple-system, sans-serif;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #stage {
            position: relative;
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
        }
        #stream-img {
            max-width: 100vw;
            max-height: 100vh;
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .top-hud {
            position: absolute;
            top: 24px;
            right: 24px;
            background: rgba(11, 19, 32, 0.9);
            backdrop-filter: blur(14px);
            padding: 10px 18px;
            border-radius: 12px;
            border: 1px solid rgba(0, 229, 255, 0.35);
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 14px;
            z-index: 10;
            transition: opacity 0.5s ease;
        }
        .bottom-hud {
            position: absolute;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(11, 19, 32, 0.92);
            backdrop-filter: blur(16px);
            padding: 12px 24px;
            border-radius: 16px;
            border: 1px solid rgba(0, 229, 255, 0.4);
            display: flex;
            align-items: center;
            gap: 18px;
            font-size: 14px;
            z-index: 15;
            transition: opacity 0.5s ease;
            box-shadow: 0 8px 30px rgba(0,0,0,0.7);
        }
        .badge {
            background: #00E5FF;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
        }
        .audio-badge {
            background: #00E676;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00E676;
            box-shadow: 0 0 10px #00E676;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.9); opacity: 0.7; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(0.9); opacity: 0.7; }
        }
        .ctrl-btn {
            background: rgba(0, 229, 255, 0.15);
            color: #00E5FF;
            border: 1px solid #00E5FF;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .ctrl-btn:hover, .ctrl-btn:focus {
            background: #00E5FF;
            color: #001E2B;
            outline: none;
        }
        .vol-container {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .vol-slider {
            -webkit-appearance: none;
            width: 110px;
            height: 6px;
            border-radius: 3px;
            background: rgba(255,255,255,0.25);
            outline: none;
        }
        .vol-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #00E5FF;
            cursor: pointer;
        }
        /* Unmute Banner Overlay for TV Browsers */
        #unmute-banner {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(17, 26, 41, 0.95);
            border: 2px solid #00E5FF;
            padding: 24px 36px;
            border-radius: 18px;
            text-align: center;
            z-index: 25;
            cursor: pointer;
            box-shadow: 0 12px 50px rgba(0, 229, 255, 0.35);
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translate(-50%, -50%) scale(1); }
            50% { transform: translate(-50%, -50%) scale(1.03); }
        }
        /* PIN Dialog Modal */
        #pin-modal {
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(9, 14, 23, 0.95);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        .pin-card {
            background: #111A29;
            border: 1px solid #00E5FF;
            border-radius: 20px;
            padding: 36px 48px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.8);
            max-width: 480px;
        }
        .pin-input {
            width: 200px;
            font-size: 32px;
            letter-spacing: 12px;
            text-align: center;
            padding: 12px;
            background: #090E17;
            border: 2px solid #00E5FF;
            color: #00E5FF;
            border-radius: 12px;
            margin: 20px 0;
            outline: none;
        }
        .pin-btn {
            background: #00E5FF;
            color: #001E2B;
            border: none;
            padding: 12px 32px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }
        .remote-tip {
            font-size: 11px;
            color: #94A3B8;
            margin-top: 14px;
        }
        .privacy-pill {
            font-size: 11px;
            color: #94A3B8;
            background: rgba(255,255,255,0.08);
            padding: 4px 8px;
            border-radius: 6px;
        }
        .hidden { display: none !important; }
    </style>
</head>
<body>
    <!-- Hidden HTML5 Audio Element for low-latency playback -->
    <audio id="stream-audio" preload="none" playsinline></audio>

    <!-- PIN Dialog for unauthorized TV browsers -->
    <div id="pin-modal" class="${if (pinRequired && !isAuthorized) "" else "hidden"}">
        <div class="pin-card">
            <h2 style="margin-bottom: 8px;">🔒 إذن الاتصال بالتلفزيون</h2>
            <p style="color: #94A3B8; font-size: 13px;">أدخل رمز PIN المكون من 4 أرقام المعروض على شاشة الهاتف</p>
            <input type="password" id="pin-field" maxlength="4" class="pin-input" placeholder="••••" autofocus />
            <br>
            <button id="pin-submit" class="pin-btn" onclick="submitPin()">تأكيد الاتصال (OK)</button>
            <p class="remote-tip">اضغط زر الوسط (OK) في ريموت التلفزيون بعد الإدخال</p>
        </div>
    </div>

    <!-- Unmute prompt banner for TV Autoplay policy -->
    <div id="unmute-banner" class="hidden" onclick="enableAudioAndPlay()">
        <h2 style="font-size: 22px; margin-bottom: 8px; color: #00E5FF;">🔊 تفعيل صوت التلفزيون</h2>
        <p style="font-size: 14px; color: #CBD5E1; margin-bottom: 12px;">انقر هنا أو اضغط زر (OK) في ريموت التلفزيون لبدء سماع الصوت المباشر</p>
        <span class="privacy-pill">🛡️ صوت التطبيقات والوسائط فقط | مكالمات Messenger معزولة</span>
    </div>

    <div id="stage" onclick="toggleFullscreen()">
        <!-- Top HUD -->
        <div class="top-hud" id="top-hud">
            <div class="status-dot"></div>
            <span>CastDirect TV - بث مباشر</span>
            <span class="badge" id="stats-badge">H.264 Low-Latency</span>
            <span class="audio-badge" id="audio-badge">🎵 صوت الوسائط 48kHz</span>
        </div>

        <!-- Bottom Audio & Playback Controls HUD -->
        <div class="bottom-hud" id="bottom-hud">
            <button id="audio-toggle-btn" class="ctrl-btn" onclick="toggleMute(event)">
                <span id="mute-icon">🔊</span>
                <span id="mute-text">كتم الصوت</span>
            </button>
            <div class="vol-container">
                <span style="font-size: 12px; color: #94A3B8;">مستوى الصوت:</span>
                <input type="range" id="vol-slider" class="vol-slider" min="0" max="100" value="100" oninput="changeVolume(this.value, event)" onclick="event.stopPropagation()">
                <span id="vol-text" style="font-size: 12px; font-weight: bold; width: 36px;">100%</span>
            </div>
            <span class="privacy-pill">🛡️ المكالمات معزولة</span>
            <button class="ctrl-btn" onclick="toggleFullscreen(event)">⛶ ملء الشاشة (F)</button>
        </div>

        <img id="stream-img" src="" alt="Phone Screen Stream">
    </div>

    <script>
        const img = document.getElementById('stream-img');
        const audio = document.getElementById('stream-audio');
        const topHud = document.getElementById('top-hud');
        const bottomHud = document.getElementById('bottom-hud');
        const unmuteBanner = document.getElementById('unmute-banner');
        let hideTimeout;

        function autoHideHuds() {
            clearTimeout(hideTimeout);
            topHud.style.opacity = '1';
            bottomHud.style.opacity = '1';
            hideTimeout = setTimeout(() => {
                topHud.style.opacity = '0';
                bottomHud.style.opacity = '0';
            }, 4000);
        }

        function getStoredPin() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('pin') || localStorage.getItem('cast_pin') || '';
        }

        function loadStream() {
            const pin = getStoredPin();
            const pinModal = document.getElementById('pin-modal');
            
            if ($pinRequired && !pin) {
                pinModal.classList.remove('hidden');
                document.getElementById('pin-field').focus();
                return;
            }

            pinModal.classList.add('hidden');
            img.src = '/stream?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            
            // Connect and stream audio
            loadAudio(pin);
            autoHideHuds();
        }

        function loadAudio(pin) {
            audio.src = '/audio?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            audio.volume = 1.0;
            const playPromise = audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    unmuteBanner.classList.add('hidden');
                }).catch(() => {
                    // Browser requires user interaction to play audio (TV remote OK or mouse click)
                    unmuteBanner.classList.remove('hidden');
                });
            }
        }

        function enableAudioAndPlay() {
            audio.play().then(() => {
                unmuteBanner.classList.add('hidden');
            }).catch(() => {});
        }

        function toggleMute(e) {
            if (e) e.stopPropagation();
            audio.muted = !audio.muted;
            const icon = document.getElementById('mute-icon');
            const text = document.getElementById('mute-text');
            if (audio.muted) {
                icon.innerText = '🔇';
                text.innerText = 'تشغيل الصوت';
                document.getElementById('audio-badge').innerText = '🔇 الصوت مكتوم';
            } else {
                icon.innerText = '🔊';
                text.innerText = 'كتم الصوت';
                document.getElementById('audio-badge').innerText = '🎵 صوت الوسائط 48kHz';
                enableAudioAndPlay();
            }
            autoHideHuds();
        }

        function changeVolume(val, e) {
            if (e) e.stopPropagation();
            audio.volume = val / 100.0;
            document.getElementById('vol-text').innerText = val + '%';
            if (audio.muted && val > 0) {
                audio.muted = false;
                document.getElementById('mute-icon').innerText = '🔊';
                document.getElementById('mute-text').innerText = 'كتم الصوت';
            }
            autoHideHuds();
        }

        function submitPin() {
            const pinVal = document.getElementById('pin-field').value.trim();
            if (pinVal.length === 4) {
                localStorage.setItem('cast_pin', pinVal);
                document.cookie = "cast_pin=" + pinVal + "; path=/; max-age=86400";
                loadStream();
            } else {
                alert('الرجاء إدخال 4 أرقام');
            }
        }

        document.getElementById('pin-field')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitPin();
        });

        // Fullscreen Toggle for Android TV Remote Control
        function toggleFullscreen(e) {
            if (e) e.stopPropagation();
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
            } else {
                document.exitFullscreen().catch(() => {});
            }
        }

        // Android TV Remote Key Handling (DPad OK = 23, Enter = 13, Key F = 70, Key M = 77)
        window.addEventListener('keydown', function(e) {
            if (e.keyCode === 13 || e.keyCode === 23) {
                if (!document.getElementById('pin-modal').classList.contains('hidden')) {
                    submitPin();
                } else if (!unmuteBanner.classList.contains('hidden')) {
                    enableAudioAndPlay();
                } else {
                    toggleFullscreen();
                }
            } else if (e.key === 'm' || e.key === 'M') {
                toggleMute();
            } else if (e.key === 'f' || e.key === 'F') {
                toggleFullscreen();
            } else if (e.key === 'ArrowUp' || e.key === '+') {
                const slider = document.getElementById('vol-slider');
                const newVal = Math.min(100, parseInt(slider.value) + 10);
                slider.value = newVal;
                changeVolume(newVal);
            } else if (e.key === 'ArrowDown' || e.key === '-') {
                const slider = document.getElementById('vol-slider');
                const newVal = Math.max(0, parseInt(slider.value) - 10);
                slider.value = newVal;
                changeVolume(newVal);
            }
            autoHideHuds();
        });

        img.onerror = () => {
            setTimeout(loadStream, 1500);
        };

        audio.onerror = () => {
            setTimeout(() => {
                loadAudio(getStoredPin());
            }, 2000);
        };

        loadStream();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
