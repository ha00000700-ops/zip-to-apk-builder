package com.example.server

import android.graphics.Bitmap
import android.util.Log
import com.example.model.StreamStats
import com.example.util.StandbyFrameGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class LocalStreamServer(
    private val port: Int = 8080,
    var pinSecurityEnabled: Boolean = true,
    var pairingPin: String = "4829"
) {
    val actualPort: Int
        get() = serverSocket?.localPort ?: port
    val activeClientsCount: Int
        get() = activeClients.size
    val totalBytesTransferred: Long
        get() = totalBytesSent.get()
    private val tag = "LocalStreamServer"
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val activeClients = ConcurrentHashMap<Socket, OutputStream>()
    private val clientVideoQueues = ConcurrentHashMap<Socket, java.util.concurrent.ArrayBlockingQueue<ByteArray>>()
    private val activeAudioClients = ConcurrentHashMap<Socket, OutputStream>()
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val frameCount = AtomicInteger(0)
    private val totalBytesSent = AtomicLong(0L)
    private val totalAudioBytesSent = AtomicLong(0L)
    private var lastFpsCalculationTime = System.currentTimeMillis()
    private var currentFps = 0
    private var currentBitrateKbps = 0
    private var bytesInCurrentSecond = 0L

    private val _streamStats = MutableStateFlow(StreamStats())
    val streamStats = _streamStats.asStateFlow()

    @Volatile
    private var latestFrameJpeg: ByteArray? = null

    @Volatile
    var isPausedBySystem: Boolean = false
        set(value) {
            field = value
            if (value) {
                // Broadcast pause frame immediately to all connected TV clients
                val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                broadcastFrame(pauseFrame)
            }
        }

    private fun log(msg: String, isError: Boolean = false) {
        try {
            if (isError) Log.e(tag, msg) else Log.d(tag, msg)
        } catch (_: Throwable) {
            println("[$tag] $msg")
        }
    }

    fun start() {
        if (isRunning.getAndSet(true)) return

        try {
            serverSocket = ServerSocket(port).apply {
                reuseAddress = true
            }
            log("Local stream server listening on port $port")
        } catch (e: Exception) {
            log("Failed to bind server socket: ${e.message}", true)
            isRunning.set(false)
            return
        }

        scope.launch {
            try {
                while (isActive && isRunning.get()) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: Exception) {
                        break
                    }
                    handleClient(socket)
                }
            } catch (e: Exception) {
                log("Server error: ${e.message}", true)
            } finally {
                stop()
            }
        }

        // Stats & Standby heartbeat loop
        scope.launch {
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(1000)
                val now = System.currentTimeMillis()
                val elapsed = now - lastFpsCalculationTime
                if (elapsed >= 1000) {
                    currentFps = (frameCount.getAndSet(0) * 1000.0 / elapsed).toInt()
                    currentBitrateKbps = ((bytesInCurrentSecond * 8) / 1024).toInt()
                    bytesInCurrentSecond = 0L
                    lastFpsCalculationTime = now

                    _streamStats.value = _streamStats.value.copy(
                        fps = currentFps,
                        activeClients = activeClients.size,
                        bytesSent = totalBytesSent.get(),
                        currentBitrateKbps = currentBitrateKbps,
                        uptimeSeconds = _streamStats.value.uptimeSeconds + 1
                    )
                }

                // If paused by Messenger or external app, send heartbeat paused frame every 1.5 seconds
                // to maintain connection alive without disconnects!
                if (isPausedBySystem && activeClients.isNotEmpty()) {
                    val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                    broadcastFrame(pauseFrame)
                }
            }
        }

        // Audio Stream Keep-Alive Loop: keeps audio stream flowing continuously at 50 chunks/sec only when stalled (>100ms)
        scope.launch {
            val silentChunk = ByteArray(3840) // 20ms of stereo PCM 16-bit silence
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(20)
                if (activeAudioClients.isNotEmpty()) {
                    val now = System.currentTimeMillis()
                    if (lastAudioChunkBroadcastTime > 0L && (now - lastAudioChunkBroadcastTime) > 100) { // If no chunk emitted for 100ms, send silent heartbeat chunk
                        lastAudioChunkBroadcastTime = now
                        broadcastAudioChunk(silentChunk)
                    }
                }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        scope.launch {
            try {
                socket.tcpNoDelay = true
                socket.soTimeout = 0 // Infinite timeout for long-lived streaming connections
                socket.sendBufferSize = 128 * 1024 // 128KB OS socket buffer for seamless, non-blocking frame transmission
                val inputStream = socket.getInputStream()
                val outputStream = socket.getOutputStream()

                val buffer = ByteArray(2048)
                val bytesRead = inputStream.read(buffer)
                if (bytesRead <= 0) {
                    socket.close()
                    return@launch
                }

                val requestHeader = String(buffer, 0, bytesRead)
                val firstLine = requestHeader.lines().firstOrNull() ?: ""

                // Check PIN Authorization
                val isAuthorized = !pinSecurityEnabled || isRequestAuthorized(requestHeader)

                when {
                    firstLine.contains("GET /stream") -> {
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            return@launch
                        }

                        // MJPEG low-latency stream for TV with buffered output
                        val bufferedOutput = java.io.BufferedOutputStream(outputStream, 64 * 1024)
                        sendMjpegHeaders(bufferedOutput)
                        val clientVideoQueue = java.util.concurrent.ArrayBlockingQueue<ByteArray>(2)
                        clientVideoQueues[socket] = clientVideoQueue
                        activeClients[socket] = bufferedOutput
                        _streamStats.value = _streamStats.value.copy(activeClients = activeClients.size)

                        val initialFrame = if (isPausedBySystem) {
                            StandbyFrameGenerator.generatePausedFrame()
                        } else {
                            latestFrameJpeg
                        }

                        initialFrame?.let { frame ->
                            writeFrame(bufferedOutput, frame)
                        }

                        try {
                            while (isActive && isRunning.get() && !socket.isClosed) {
                                val frame = clientVideoQueue.poll(50, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                                writeFrame(bufferedOutput, frame)
                            }
                        } catch (e: Exception) {
                        } finally {
                            clientVideoQueues.remove(socket)
                            activeClients.remove(socket)
                            try { socket.close() } catch (_: Exception) {}
                            _streamStats.value = _streamStats.value.copy(activeClients = activeClients.size)
                        }
                    }
                    firstLine.contains("GET /audio") -> {
                        log("HTTP GET /audio request received from ${socket.remoteSocketAddress}. User-Agent: ${requestHeader.lines().find { it.startsWith("User-Agent:", ignoreCase = true) } ?: "Unknown"}")
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            log("Rejected /audio request: Unauthorized PIN")
                            return@launch
                        }

                        val header = "HTTP/1.1 200 OK\r\n" +
                                "Content-Type: audio/wav\r\n" +
                                "Transfer-Encoding: chunked\r\n" +
                                "Access-Control-Allow-Origin: *\r\n" +
                                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                                "Pragma: no-cache\r\n\r\n"
                        outputStream.write(header.toByteArray())

                        val wavHeader = buildStreamingWavHeader()
                        writeChunkedData(outputStream, wavHeader)
                        wavHeaderBytesSent.addAndGet(wavHeader.size.toLong())
                        outputStream.flush()

                        val clientQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(6) // Max 6 chunks (120ms buffer: absorbs micro-jitter without stutter or lag buildup)
                        clientAudioQueues[socket] = clientQueue
                        activeAudioClients[socket] = outputStream
                        log("[DIAGNOSTIC SERVER] TV Audio client connected (${socket.remoteSocketAddress}). Chunk #1 (44-byte WAV header) sent. Active audio clients: ${activeAudioClients.size}")

                        var clientChunkCount = 0L

                        try {
                            while (isActive && isRunning.get() && !socket.isClosed) {
                                val pcmChunk = when {
                                    testToneCountdown.get() > 0 -> {
                                        testToneCountdown.decrementAndGet()
                                        kotlinx.coroutines.delay(20)
                                        generateTestSineWaveChunk()
                                    }
                                    else -> {
                                        val chunk = clientQueue.poll(20, java.util.concurrent.TimeUnit.MILLISECONDS)
                                        if (chunk == null) {
                                            continue
                                        }
                                        chunk
                                    }
                                }

                                writeChunkedData(outputStream, pcmChunk)
                                clientChunkCount++
                                pcmChunksWritten.incrementAndGet()
                                pcmBytesSent.addAndGet(pcmChunk.size.toLong())
                                lastPcmSentTimestamp = System.currentTimeMillis()

                                if (clientChunkCount == 1L) {
                                    log("[DIAGNOSTIC STREAMING LOOP] FIRST PCM chunk (#2 overall) sent to ${socket.remoteSocketAddress}: ${pcmChunk.size} bytes")
                                }
                                if (clientChunkCount % 150 == 0L) { // Log every ~3 seconds
                                    log("[DIAGNOSTIC STREAMING LOOP] Socket ${socket.remoteSocketAddress} | PCM Chunks: $clientChunkCount | Total PCM Sent: ${pcmBytesSent.get() / 1024} KB")
                                }
                            }
                        } catch (e: Exception) {
                            log("[DIAGNOSTIC SERVER ERROR] Audio streaming loop ended for ${socket.remoteSocketAddress}: ${e.message}")
                        } finally {
                            clientAudioQueues.remove(socket)
                            activeAudioClients.remove(socket)
                            try { socket.close() } catch (_: Exception) {}
                            log("[DIAGNOSTIC SERVER DISCONNECT] TV Audio client disconnected (${socket.remoteSocketAddress}). Remaining active audio clients: ${activeAudioClients.size}")
                        }
                    }
                    firstLine.contains("GET /audio-test") -> {
                        log("[DIAGNOSTIC SERVER] GET /audio-test request received from ${socket.remoteSocketAddress}. Activating 5-second 440Hz test audio tone.")
                        triggerTestAudioBroadcast()
                        val json = """{"status":"ok","message":"Test audio broadcast activated (250 chunks / 5s 440Hz sine wave)"}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    firstLine.contains("GET /status") -> {
                        val json = """{"status":"${if (isPausedBySystem) "paused" else "streaming"}","fps":$currentFps,"clients":${activeClients.size},"audioClients":${activeAudioClients.size},"bitrateKbps":$currentBitrateKbps,"audioBytesSent":${totalAudioBytesSent.get()},"pinRequired":$pinSecurityEnabled,"pcmChunksPassed":${pcmChunksPassed.get()},"pcmChunksWritten":${pcmChunksWritten.get()}}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    else -> {
                        // Serve TV Web Receiver HTML interface (with PIN prompt and strict anti-caching headers)
                        val html = getTvViewerHtml(pinSecurityEnabled, isAuthorized)
                        val response = "HTTP/1.1 200 OK\r\n" +
                                "Content-Type: text/html; charset=UTF-8\r\n" +
                                "Content-Length: ${html.toByteArray().size}\r\n" +
                                "Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n" +
                                "Pragma: no-cache\r\n" +
                                "Expires: 0\r\n" +
                                "Connection: close\r\n\r\n$html"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                }
            } catch (e: Exception) {
                activeClients.remove(socket)
                activeAudioClients.remove(socket)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    private fun isRequestAuthorized(headers: String): Boolean {
        // Check query param e.g. /stream?pin=XXXX
        val queryPin = Regex("[?&]pin=([0-9]{4})").find(headers)?.groupValues?.get(1)
        if (queryPin == pairingPin) return true

        // Check header e.g. X-Pin: XXXX or Authorization: Bearer XXXX
        if (headers.contains("X-Pin: $pairingPin", ignoreCase = true)) return true
        if (headers.contains("Authorization: Bearer $pairingPin", ignoreCase = true)) return true

        // Check Cookie e.g. Cookie: cast_pin=XXXX
        if (headers.contains("cast_pin=$pairingPin", ignoreCase = true)) return true

        return false
    }

    private fun sendMjpegHeaders(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Connection: close\r\n" +
                "Server: CastDirect/1.0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()
    }

    private val frameBoundaryBytes = "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ".toByteArray(Charsets.US_ASCII)
    private val frameHeaderEndBytes = "\r\n\r\n".toByteArray(Charsets.US_ASCII)
    private val pcmChunkHexHeader = "${Integer.toHexString(3840)}\r\n".toByteArray(Charsets.US_ASCII)
    private val wavHeaderHexHeader = "${Integer.toHexString(44)}\r\n".toByteArray(Charsets.US_ASCII)

    private fun writeFrame(output: OutputStream, jpegData: ByteArray) {
        val sizeBytes = jpegData.size.toString().toByteArray(Charsets.US_ASCII)
        synchronized(output) {
            output.write(frameBoundaryBytes)
            output.write(sizeBytes)
            output.write(frameHeaderEndBytes)
            output.write(jpegData)
            output.write(crlfBytes)
            output.flush()
        }
    }

    fun broadcastFrame(jpegData: ByteArray) {
        latestFrameJpeg = jpegData
        if (!isRunning.get() || activeClients.isEmpty()) {
            return
        }

        frameCount.incrementAndGet()
        val dataSize = jpegData.size.toLong()
        val updatedTotal = totalBytesSent.addAndGet(dataSize)
        bytesInCurrentSecond += dataSize
        _streamStats.value = _streamStats.value.copy(bytesSent = updatedTotal)

        // Non-blocking distribution to client queues (never blocks ScreenCaptureThread!)
        for (queue in clientVideoQueues.values) {
            if (!queue.offer(jpegData)) {
                queue.poll() // Drop older frame to guarantee zero lag and real-time freshness
                queue.offer(jpegData)
            }
        }
    }

    fun onOrientationChanged() {
        // Purge old pre-rotation frames so client immediately renders the new rotated frame
        for (queue in clientVideoQueues.values) {
            queue.clear()
        }
        // Trim audio queue down to at most 2 chunks (40ms) so accumulated audio doesn't burst
        for (queue in clientAudioQueues.values) {
            while (queue.size > 2) {
                queue.poll()
            }
        }
    }

    val pcmChunksGenerated = AtomicLong(0L)
    val pcmChunksPassed = AtomicLong(0L)
    val pcmChunksWritten = AtomicLong(0L)
    val wavHeaderBytesSent = AtomicLong(0L)
    val pcmBytesGenerated = AtomicLong(0L)
    val pcmBytesSent = AtomicLong(0L)
    @Volatile var lastPcmSentTimestamp = 0L
    val testToneCountdown = AtomicInteger(0)
    private val clientAudioQueues = java.util.concurrent.ConcurrentHashMap<Socket, java.util.concurrent.LinkedBlockingQueue<ByteArray>>()
    private val silentPcmChunk = ByteArray(3840)
    private val crlfBytes = "\r\n".toByteArray()

    private fun writeChunkedData(outputStream: OutputStream, data: ByteArray) {
        val hexHeader = when (data.size) {
            3840 -> pcmChunkHexHeader
            44 -> wavHeaderHexHeader
            else -> "${Integer.toHexString(data.size)}\r\n".toByteArray(Charsets.US_ASCII)
        }
        synchronized(outputStream) {
            outputStream.write(hexHeader)
            outputStream.write(data)
            outputStream.write(crlfBytes)
            outputStream.flush()
        }
    }

    private var testSinePhase = 0.0

    fun generateTestSineWaveChunk(frequencyHz: Double = 440.0, sampleRate: Int = 48000, numFrames: Int = 960): ByteArray {
        val bytes = ByteArray(numFrames * 4) // 16-bit stereo = 4 bytes per frame
        val amplitude = 16000.0 // Audible test tone
        val phaseIncrement = 2.0 * Math.PI * frequencyHz / sampleRate

        var offset = 0
        for (i in 0 until numFrames) {
            val sampleVal = (Math.sin(testSinePhase) * amplitude).toInt().coerceIn(-32768, 32767).toShort()
            testSinePhase += phaseIncrement
            if (testSinePhase > 2.0 * Math.PI) testSinePhase -= 2.0 * Math.PI

            bytes[offset] = (sampleVal.toInt() and 0xFF).toByte()
            bytes[offset + 1] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
            bytes[offset + 2] = (sampleVal.toInt() and 0xFF).toByte()
            bytes[offset + 3] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
            offset += 4
        }
        pcmChunksGenerated.incrementAndGet()
        pcmBytesGenerated.addAndGet(bytes.size.toLong())
        return bytes
    }

    fun triggerTestAudioBroadcast() {
        for (queue in clientAudioQueues.values) {
            queue.clear()
        }
        testToneCountdown.set(250) // Set 250 chunks (5 seconds)
        log("[DIAGNOSTIC TEST AUDIO] Activated 5-second 440Hz test tone flag (250 chunks). Active audio clients: ${activeAudioClients.size}")
    }

    @Volatile
    private var lastAudioChunkBroadcastTime = 0L
    private var lastAudioLogTime = 0L
    private var totalAudioChunksBroadcast = 0L

    fun broadcastAudioChunk(pcmData: ByteArray, timestamp: Long = System.currentTimeMillis()) {
        if (!isRunning.get() || activeAudioClients.isEmpty()) return
        lastAudioChunkBroadcastTime = System.currentTimeMillis()
        pcmChunksPassed.incrementAndGet()
        for (queue in clientAudioQueues.values) {
            if (!queue.offer(pcmData)) {
                // Queue full (>400ms lag): drop oldest chunk so TV client receives real-time current audio
                queue.poll()
                queue.offer(pcmData)
            }
        }
    }

    private fun buildStreamingWavHeader(sampleRate: Int = 48000, channels: Int = 2, bitsPerSample: Int = 16): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)
        val totalDataLen = 0x7FFFFFFF // Streaming / indefinite length flag
        val totalAudioLen = totalDataLen + 36

        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalAudioLen and 0xff).toByte()
        header[5] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[6] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[7] = ((totalAudioLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 4 bytes: size of 'fmt ' chunk
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // format = 1 (PCM)
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = blockAlign.toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalDataLen and 0xff).toByte()
        header[41] = ((totalDataLen shr 8) and 0xff).toByte()
        header[42] = ((totalDataLen shr 16) and 0xff).toByte()
        header[43] = ((totalDataLen shr 24) and 0xff).toByte()
        return header
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        for ((socket, _) in activeClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeClients.clear()
        clientVideoQueues.clear()

        for ((socket, _) in activeAudioClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeAudioClients.clear()
        clientAudioQueues.clear()

        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        log("Local stream server stopped")
    }

    private fun getTvViewerHtml(pinRequired: Boolean, isAuthorized: Boolean): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CastDirect TV Receiver</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body {
            background-color: #000;
            color: #F0F4F8;
            font-family: system-ui, -apple-system, sans-serif;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #stage {
            position: relative;
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
        }
        #stream-img {
            max-width: 100vw;
            max-height: 100vh;
            width: 100%;
            height: 100%;
            object-fit: contain;
            image-rendering: high-quality;
            image-rendering: -webkit-optimize-contrast;
            transform: translateZ(0);
            backface-visibility: hidden;
        }
        .top-hud {
            position: absolute;
            top: 24px;
            right: 28px;
            background: rgba(15, 23, 42, 0.82);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            padding: 8px 18px;
            border-radius: 9999px;
            border: 1px solid rgba(255, 255, 255, 0.14);
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 13px;
            font-weight: 500;
            color: #E2E8F0;
            z-index: 10;
            transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
            pointer-events: none;
            opacity: 1;
        }
        .top-hud.hidden-hud {
            opacity: 0;
            transform: translateY(-20px);
        }
        .bottom-hud {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(15, 23, 42, 0.88);
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            padding: 10px 22px;
            border-radius: 9999px;
            border: 1px solid rgba(255, 255, 255, 0.16);
            display: flex;
            align-items: center;
            gap: 16px;
            font-size: 14px;
            z-index: 20;
            transition: opacity 0.4s cubic-bezier(0.4, 0, 0.2, 1), transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.6);
            user-select: none;
            opacity: 1;
        }
        .bottom-hud.hidden-hud {
            opacity: 0;
            transform: translateX(-50%) translateY(24px);
            pointer-events: none;
        }
        .badge {
            background: #00E5FF;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 9999px;
            font-weight: bold;
            font-size: 12px;
        }
        .audio-badge {
            background: rgba(0, 230, 118, 0.2);
            color: #00E676;
            border: 1px solid rgba(0, 230, 118, 0.4);
            padding: 4px 10px;
            border-radius: 9999px;
            font-weight: 600;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00E676;
            box-shadow: 0 0 10px #00E676;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.9); opacity: 0.7; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(0.9); opacity: 0.7; }
        }
        .ctrl-btn {
            background: rgba(255, 255, 255, 0.08);
            color: #F8FAFC;
            border: 1px solid rgba(255, 255, 255, 0.18);
            padding: 9px 18px;
            border-radius: 9999px;
            font-size: 13.5px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            outline: none;
        }
        .ctrl-btn:hover, .ctrl-btn:focus-visible {
            background: #00E5FF;
            color: #001E2B;
            border-color: #00E5FF;
            transform: scale(1.05);
            box-shadow: 0 0 16px rgba(0, 229, 255, 0.45);
        }
        .ctrl-btn:active {
            transform: scale(0.96);
        }
        .vol-container {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(255, 255, 255, 0.06);
            padding: 4px 14px;
            border-radius: 9999px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .vol-btn {
            background: rgba(255, 255, 255, 0.1);
            color: #F8FAFC;
            border: 1px solid rgba(255, 255, 255, 0.15);
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s ease;
            outline: none;
        }
        .vol-btn:hover, .vol-btn:focus-visible {
            background: #00E5FF;
            color: #001E2B;
            border-color: #00E5FF;
            transform: scale(1.12);
        }
        .vol-btn:active {
            transform: scale(0.92);
        }
        .vol-slider {
            -webkit-appearance: none;
            appearance: none;
            width: 120px;
            height: 6px;
            border-radius: 9999px;
            background: rgba(255, 255, 255, 0.22);
            outline: none;
            cursor: pointer;
            transition: background 0.2s;
        }
        .vol-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #00E5FF;
            cursor: pointer;
            box-shadow: 0 0 8px rgba(0, 229, 255, 0.6);
            transition: transform 0.15s ease;
        }
        .vol-slider:hover::-webkit-slider-thumb, .vol-slider:focus::-webkit-slider-thumb {
            transform: scale(1.25);
        }
        .vol-label {
            font-size: 13px;
            font-weight: 700;
            width: 44px;
            text-align: center;
            color: #00E5FF;
            font-variant-numeric: tabular-nums;
        }
        /* Unmute Banner Overlay for TV Browsers */
        #unmute-banner {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(17, 26, 41, 0.95);
            border: 2px solid #00E5FF;
            padding: 24px 36px;
            border-radius: 18px;
            text-align: center;
            z-index: 25;
            cursor: pointer;
            box-shadow: 0 12px 50px rgba(0, 229, 255, 0.35);
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translate(-50%, -50%) scale(1); }
            50% { transform: translate(-50%, -50%) scale(1.03); }
        }
        /* PIN Dialog Modal */
        #pin-modal {
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(9, 14, 23, 0.95);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        .pin-card {
            background: #111A29;
            border: 1px solid #00E5FF;
            border-radius: 20px;
            padding: 36px 48px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.8);
            max-width: 480px;
        }
        .pin-input {
            width: 200px;
            font-size: 32px;
            letter-spacing: 12px;
            text-align: center;
            padding: 12px;
            background: #090E17;
            border: 2px solid #00E5FF;
            color: #00E5FF;
            border-radius: 12px;
            margin: 20px 0;
            outline: none;
        }
        .pin-btn {
            background: #00E5FF;
            color: #001E2B;
            border: none;
            padding: 12px 32px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }
        .remote-tip {
            font-size: 11px;
            color: #94A3B8;
            margin-top: 14px;
        }
        .hidden { display: none !important; }
    </style>
</head>
<body>
    <!-- Hidden HTML5 Audio Element for low-latency playback -->
    <audio id="stream-audio" preload="none" playsinline></audio>

    <!-- PIN Dialog for unauthorized TV browsers -->
    <div id="pin-modal" class="${if (pinRequired && !isAuthorized) "" else "hidden"}">
        <div class="pin-card">
            <h2 style="margin-bottom: 8px;">🔒 إذن الاتصال بالتلفزيون</h2>
            <p style="color: #94A3B8; font-size: 13px;">أدخل رمز PIN المكون من 4 أرقام المعروض على شاشة الهاتف</p>
            <input type="password" id="pin-field" maxlength="4" class="pin-input" placeholder="••••" autofocus />
            <br>
            <button id="pin-submit" class="pin-btn" onclick="submitPin()">تأكيد الاتصال (OK)</button>
            <p class="remote-tip">اضغط زر الوسط (OK) في ريموت التلفزيون بعد الإدخال</p>
        </div>
    </div>

    <!-- Unmute prompt banner for TV Autoplay policy -->
    <div id="unmute-banner" class="hidden" onclick="enableAudioAndPlay()">
        <h2 style="font-size: 22px; margin-bottom: 8px; color: #00E5FF;">🔊 انقر لتشغيل الصوت</h2>
        <p style="font-size: 14px; color: #CBD5E1;">انقر هنا أو اضغط زر (OK) في ريموت التلفزيون لبدء سماع الصوت المباشر</p>
    </div>

    <div id="stage" onclick="handleStageClick(event)" ondblclick="toggleFullscreen(event)">
        <!-- Top HUD -->
        <div class="top-hud" id="top-hud">
            <div class="status-dot"></div>
            <span style="font-weight: 700; letter-spacing: 0.5px;">CastDirect TV</span>
            <span class="badge">مباشر</span>
            <span class="audio-badge" id="audio-badge">🎵 صوت نقي 48kHz</span>
        </div>

        <!-- Bottom Audio & Playback Controls HUD -->
        <div class="bottom-hud" id="bottom-hud" onclick="event.stopPropagation()">
            <!-- Mute / Unmute Button -->
            <button id="audio-toggle-btn" class="ctrl-btn" onclick="toggleMute(event)" title="كتم / تشغيل الصوت">
                <span id="mute-icon">🔊</span>
                <span id="mute-text">كتم الصوت</span>
            </button>

            <!-- Volume Controls: Minus, Slider, Plus, Value -->
            <div class="vol-container" onclick="event.stopPropagation()">
                <button class="vol-btn" onclick="adjustVolume(-5, event)" title="خفض الصوت (-5%)">−</button>
                <input type="range" id="vol-slider" class="vol-slider" min="0" max="100" value="100" oninput="changeVolume(this.value, event)" title="مستوى الصوت">
                <button class="vol-btn" onclick="adjustVolume(5, event)" title="رفع الصوت (+5%)">+</button>
                <span id="vol-text" class="vol-label">100%</span>
            </div>

            <!-- Fullscreen Button -->
            <button id="fullscreen-btn" class="ctrl-btn" onclick="toggleFullscreen(event)" title="ملء الشاشة">
                <span id="fs-icon">⛶</span>
                <span id="fs-text">ملء الشاشة</span>
            </button>
        </div>

        <img id="stream-img" src="" alt="Phone Screen Stream">
    </div>

    <script>
        const img = document.getElementById('stream-img');
        const audio = document.getElementById('stream-audio');
        const topHud = document.getElementById('top-hud');
        const bottomHud = document.getElementById('bottom-hud');
        const unmuteBanner = document.getElementById('unmute-banner');
        let hideTimeout;

        let audioCtx = null;
        let audioGainNode = null;
        let nextStartTime = 0;
        let audioReader = null;
        let isWebAudioActive = false;
        let savedVolume = 100;

        window.onerror = function(msg, url, line) {
            console.error('[CastDirect TV Error]', msg, line);
        };

        window.addEventListener('unhandledrejection', function(event) {
            console.error('[CastDirect TV Promise Error]', event.reason);
        });

        function showHuds() {
            clearTimeout(hideTimeout);
            topHud.classList.remove('hidden-hud');
            bottomHud.classList.remove('hidden-hud');
            hideTimeout = setTimeout(() => {
                topHud.classList.add('hidden-hud');
                bottomHud.classList.add('hidden-hud');
            }, 3500);
        }

        function autoHideHuds() {
            showHuds();
        }

        // Keep HUD visible while interacting with the control bar
        bottomHud.addEventListener('mouseenter', () => clearTimeout(hideTimeout));
        bottomHud.addEventListener('mouseleave', autoHideHuds);

        // Wake controls on user activity (mouse movement, touch, pointer)
        window.addEventListener('mousemove', autoHideHuds, { passive: true });
        window.addEventListener('pointermove', autoHideHuds, { passive: true });
        window.addEventListener('touchstart', autoHideHuds, { passive: true });

        function handleStageClick(e) {
            if (e.target.closest('#bottom-hud') || e.target.closest('#unmute-banner') || e.target.closest('#pin-modal')) {
                return;
            }
            if (bottomHud.classList.contains('hidden-hud')) {
                showHuds();
            } else {
                bottomHud.classList.add('hidden-hud');
                topHud.classList.add('hidden-hud');
            }
        }

        function getStoredPin() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('pin') || localStorage.getItem('cast_pin') || '';
        }

        function loadStream() {
            const pin = getStoredPin();
            const pinModal = document.getElementById('pin-modal');
            
            if ($pinRequired && !pin) {
                pinModal.classList.remove('hidden');
                document.getElementById('pin-field').focus();
                return;
            }

            pinModal.classList.add('hidden');
            img.src = '/stream?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            
            // Connect and stream audio via Web Audio API low latency pipeline
            loadAudioStream(pin);
            autoHideHuds();
        }

        function initAudioContext() {
            if (!audioCtx) {
                const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
                if (AudioCtxClass) {
                    audioCtx = new AudioCtxClass({ sampleRate: 48000 });
                    audioGainNode = audioCtx.createGain();
                    audioGainNode.gain.value = 1.0;
                    audioGainNode.connect(audioCtx.destination);
                    console.log('[CastDirect TV Audio] AudioContext initialized at', audioCtx.sampleRate, 'Hz');
                }
            }
        }

        async function loadAudioStream(pin) {
            initAudioContext();
            const audioBadge = document.getElementById('audio-badge');

            if (!window.fetch || !audioCtx) {
                loadAudioFallback(pin);
                return;
            }

            const url = '/audio?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            console.log('[CastDirect TV Audio] Requesting PCM stream:', url);

            try {
                if (audioReader) {
                    try { audioReader.cancel(); } catch(e) {}
                }

                const response = await fetch(url);
                if (!response.ok) {
                    throw new Error('HTTP status ' + response.status + ' ' + (response.statusText || ''));
                }

                if (!response.body) {
                    throw new Error('response.body is null or undefined!');
                }

                if (audioCtx.state === 'suspended') {
                    unmuteBanner.classList.remove('hidden');
                } else {
                    unmuteBanner.classList.add('hidden');
                }

                audioReader = response.body.getReader();
                isWebAudioActive = true;
                if (audioBadge) audioBadge.innerText = '🎵 صوت نقي 48kHz';

                let leftover = new Uint8Array(0);
                let headerSkipped = false;

                while (true) {
                    const { done, value } = await audioReader.read();
                    if (done) break;
                    if (!value || value.length === 0) continue;

                    let combined = new Uint8Array(leftover.length + value.length);
                    combined.set(leftover);
                    combined.set(value, leftover.length);

                    let pcmOffset = 0;
                    if (!headerSkipped) {
                        if (combined.length >= 44 && combined[0] === 82 && combined[1] === 73 && combined[2] === 70) { // 'RIFF'
                            pcmOffset = 44; // Skip 44-byte WAV header
                            headerSkipped = true;
                        } else if (combined.length >= 44) {
                            headerSkipped = true;
                        } else {
                            leftover = combined;
                            continue;
                        }
                    }

                    let pcmData = combined.subarray(pcmOffset);
                    let usableLength = Math.floor(pcmData.length / 4) * 4; // 16-bit stereo frame = 4 bytes
                    leftover = pcmData.subarray(usableLength);

                    if (usableLength > 0 && audioCtx) {
                        playPcmChunk(pcmData.subarray(0, usableLength));
                    }
                }
            } catch (err) {
                console.warn('[CastDirect TV Audio] Stream error, retrying in 2s:', err);
                setTimeout(() => loadAudioStream(pin), 2000);
            }
        }

        function playPcmChunk(chunkBytes) {
            if (!audioCtx || !audioGainNode) return;

            const numFrames = chunkBytes.length / 4;
            if (numFrames <= 0) return;

            const audioBuffer = audioCtx.createBuffer(2, numFrames, 48000);
            const channelLeft = audioBuffer.getChannelData(0);
            const channelRight = audioBuffer.getChannelData(1);

            if (chunkBytes.byteOffset % 2 === 0) {
                const int16 = new Int16Array(chunkBytes.buffer, chunkBytes.byteOffset, numFrames * 2);
                for (let i = 0; i < numFrames; i++) {
                    channelLeft[i] = int16[i * 2] / 32768.0;
                    channelRight[i] = int16[i * 2 + 1] / 32768.0;
                }
            } else {
                const dataView = new DataView(chunkBytes.buffer, chunkBytes.byteOffset, chunkBytes.byteLength);
                for (let i = 0; i < numFrames; i++) {
                    channelLeft[i] = dataView.getInt16(i * 4, true) / 32768.0;
                    channelRight[i] = dataView.getInt16(i * 4 + 2, true) / 32768.0;
                }
            }

            const source = audioCtx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioGainNode);

            const currentTime = audioCtx.currentTime;
            
            if (nextStartTime === 0) {
                // Initial pre-roll: 30ms buffer to start playback cleanly with minimal latency
                nextStartTime = currentTime + 0.03;
            } else if (nextStartTime < currentTime) {
                // Seamless underrun recovery with tiny 10ms safety margin to prevent clipping/stutter (avoiding old 40ms gaps)
                nextStartTime = currentTime + 0.01;
            } else if (nextStartTime > currentTime + 0.12) {
                // Tight forward drift cap: keep audio tightly synchronized within 30-120ms of real-time
                nextStartTime = currentTime + 0.03;
            }

            source.start(nextStartTime);
            nextStartTime += audioBuffer.duration;
        }

        function loadAudioFallback(pin) {
            audio.src = '/audio?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            audio.volume = 1.0;
            const playPromise = audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    unmuteBanner.classList.add('hidden');
                }).catch(() => {
                    unmuteBanner.classList.remove('hidden');
                });
            }
        }

        function enableAudioAndPlay() {
            initAudioContext();
            if (audioCtx) {
                audioCtx.resume().then(() => {
                    unmuteBanner.classList.add('hidden');
                    const badge = document.getElementById('audio-badge');
                    if (badge) badge.innerText = '🎵 صوت نقي 48kHz';
                }).catch(err => {
                    console.error('[CastDirect TV Audio] Failed to resume AudioContext:', err);
                });
            }
            if (audio.src) {
                audio.play().then(() => {
                    unmuteBanner.classList.add('hidden');
                }).catch(() => {});
            }
        }

        function toggleMute(e) {
            if (e) e.stopPropagation();
            initAudioContext();
            const icon = document.getElementById('mute-icon');
            const text = document.getElementById('mute-text');
            const slider = document.getElementById('vol-slider');
            const volText = document.getElementById('vol-text');
            const badge = document.getElementById('audio-badge');

            if (isWebAudioActive && audioGainNode) {
                const isCurrentlyMuted = audioGainNode.gain.value === 0;
                if (isCurrentlyMuted) {
                    const targetVol = savedVolume > 0 ? savedVolume : 100;
                    audioGainNode.gain.value = targetVol / 100.0;
                    if (slider) slider.value = targetVol;
                    if (volText) volText.innerText = targetVol + '%';
                    if (icon) icon.innerText = '🔊';
                    if (text) text.innerText = 'كتم الصوت';
                    if (badge) badge.innerText = '🎵 صوت نقي 48kHz';
                    enableAudioAndPlay();
                } else {
                    savedVolume = parseInt(slider.value) || 100;
                    audioGainNode.gain.value = 0;
                    if (icon) icon.innerText = '🔇';
                    if (text) text.innerText = 'تشغيل الصوت';
                    if (badge) badge.innerText = '🔇 مكتوم';
                }
            } else {
                audio.muted = !audio.muted;
                if (audio.muted) {
                    if (icon) icon.innerText = '🔇';
                    if (text) text.innerText = 'تشغيل الصوت';
                    if (badge) badge.innerText = '🔇 مكتوم';
                } else {
                    if (icon) icon.innerText = '🔊';
                    if (text) text.innerText = 'كتم الصوت';
                    if (badge) badge.innerText = '🎵 صوت نقي 48kHz';
                    enableAudioAndPlay();
                }
            }
            autoHideHuds();
        }

        function changeVolume(val, e) {
            if (e) e.stopPropagation();
            initAudioContext();
            const num = Math.min(100, Math.max(0, parseInt(val) || 0));
            const volFrac = num / 100.0;
            if (audioGainNode) audioGainNode.gain.value = volFrac;
            audio.volume = volFrac;

            const slider = document.getElementById('vol-slider');
            if (slider && parseInt(slider.value) !== num) slider.value = num;

            const volText = document.getElementById('vol-text');
            if (volText) volText.innerText = num + '%';

            const icon = document.getElementById('mute-icon');
            const text = document.getElementById('mute-text');
            const badge = document.getElementById('audio-badge');

            if (num > 0) {
                savedVolume = num;
                if (icon) icon.innerText = '🔊';
                if (text) text.innerText = 'كتم الصوت';
                if (badge) badge.innerText = '🎵 صوت نقي 48kHz';
                enableAudioAndPlay();
            } else {
                if (icon) icon.innerText = '🔇';
                if (text) text.innerText = 'تشغيل الصوت';
                if (badge) badge.innerText = '🔇 مكتوم';
            }
            autoHideHuds();
        }

        function adjustVolume(delta, e) {
            if (e) e.stopPropagation();
            const slider = document.getElementById('vol-slider');
            const current = parseInt(slider.value) || 0;
            changeVolume(current + delta, e);
        }

        function isFullscreen() {
            return !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement);
        }

        function toggleFullscreen(e) {
            if (e) e.stopPropagation();
            if (!isFullscreen()) {
                const el = document.documentElement;
                if (el.requestFullscreen) {
                    el.requestFullscreen().catch(() => {});
                } else if (el.webkitRequestFullscreen) {
                    el.webkitRequestFullscreen().catch(() => {});
                } else if (el.mozRequestFullScreen) {
                    el.mozRequestFullScreen().catch(() => {});
                } else if (el.msRequestFullscreen) {
                    el.msRequestFullscreen().catch(() => {});
                }
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen().catch(() => {});
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen().catch(() => {});
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen().catch(() => {});
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen().catch(() => {});
                }
            }
            autoHideHuds();
        }

        function updateFullscreenBtn() {
            const icon = document.getElementById('fs-icon');
            const text = document.getElementById('fs-text');
            if (isFullscreen()) {
                if (icon) icon.innerText = '🗗';
                if (text) text.innerText = 'خروج من ملء الشاشة';
            } else {
                if (icon) icon.innerText = '⛶';
                if (text) text.innerText = 'ملء الشاشة';
            }
        }

        document.addEventListener('fullscreenchange', updateFullscreenBtn);
        document.addEventListener('webkitfullscreenchange', updateFullscreenBtn);
        document.addEventListener('mozfullscreenchange', updateFullscreenBtn);
        document.addEventListener('MSFullscreenChange', updateFullscreenBtn);

        function submitPin() {
            const pinVal = document.getElementById('pin-field').value.trim();
            if (pinVal.length === 4) {
                localStorage.setItem('cast_pin', pinVal);
                document.cookie = "cast_pin=" + pinVal + "; path=/; max-age=86400";
                loadStream();
            } else {
                alert('الرجاء إدخال 4 أرقام');
            }
        }

        document.getElementById('pin-field')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitPin();
        });

        // Android TV Remote Key Handling (DPad OK = 23, Enter = 13, Key F = 70, Key M = 77)
        window.addEventListener('keydown', function(e) {
            autoHideHuds();
            if (e.keyCode === 13 || e.keyCode === 23) {
                if (!document.getElementById('pin-modal').classList.contains('hidden')) {
                    submitPin();
                } else if (!unmuteBanner.classList.contains('hidden')) {
                    enableAudioAndPlay();
                } else {
                    toggleFullscreen();
                }
            } else if (e.key === 'm' || e.key === 'M') {
                toggleMute();
            } else if (e.key === 'f' || e.key === 'F') {
                toggleFullscreen();
            } else if (e.key === 'ArrowUp' || e.key === '+') {
                adjustVolume(5);
            } else if (e.key === 'ArrowDown' || e.key === '-') {
                adjustVolume(-5);
            }
        });

        img.onerror = () => {
            setTimeout(loadStream, 1500);
        };

        audio.onerror = () => {
            setTimeout(() => {
                loadAudioStream(getStoredPin());
            }, 2000);
        };

        loadStream();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
