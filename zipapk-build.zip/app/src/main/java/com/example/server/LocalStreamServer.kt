package com.example.server

import android.graphics.Bitmap
import android.util.Log
import com.example.model.StreamStats
import com.example.util.StandbyFrameGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class LocalStreamServer(
    private val port: Int = 8080,
    var pinSecurityEnabled: Boolean = true,
    var pairingPin: String = "4829"
) {
    val actualPort: Int
        get() = serverSocket?.localPort ?: port
    val activeClientsCount: Int
        get() = activeClients.size
    val totalBytesTransferred: Long
        get() = totalBytesSent.get()
    private val tag = "LocalStreamServer"
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val activeClients = ConcurrentHashMap<Socket, OutputStream>()
    private val activeAudioClients = ConcurrentHashMap<Socket, OutputStream>()
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val frameCount = AtomicInteger(0)
    private val totalBytesSent = AtomicLong(0L)
    private val totalAudioBytesSent = AtomicLong(0L)
    private var lastFpsCalculationTime = System.currentTimeMillis()
    private var currentFps = 0
    private var currentBitrateKbps = 0
    private var bytesInCurrentSecond = 0L

    private val _streamStats = MutableStateFlow(StreamStats())
    val streamStats = _streamStats.asStateFlow()

    @Volatile
    private var latestFrameJpeg: ByteArray? = null

    @Volatile
    var isPausedBySystem: Boolean = false
        set(value) {
            field = value
            if (value) {
                // Broadcast pause frame immediately to all connected TV clients
                val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                broadcastFrame(pauseFrame)
            }
        }

    private fun log(msg: String, isError: Boolean = false) {
        try {
            if (isError) Log.e(tag, msg) else Log.d(tag, msg)
        } catch (_: Throwable) {
            println("[$tag] $msg")
        }
    }

    fun start() {
        if (isRunning.getAndSet(true)) return

        try {
            serverSocket = ServerSocket(port).apply {
                reuseAddress = true
            }
            log("Local stream server listening on port $port")
        } catch (e: Exception) {
            log("Failed to bind server socket: ${e.message}", true)
            isRunning.set(false)
            return
        }

        scope.launch {
            try {
                while (isActive && isRunning.get()) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: Exception) {
                        break
                    }
                    handleClient(socket)
                }
            } catch (e: Exception) {
                log("Server error: ${e.message}", true)
            } finally {
                stop()
            }
        }

        // Stats & Standby heartbeat loop
        scope.launch {
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(1000)
                val now = System.currentTimeMillis()
                val elapsed = now - lastFpsCalculationTime
                if (elapsed >= 1000) {
                    currentFps = (frameCount.getAndSet(0) * 1000.0 / elapsed).toInt()
                    currentBitrateKbps = ((bytesInCurrentSecond * 8) / 1024).toInt()
                    bytesInCurrentSecond = 0L
                    lastFpsCalculationTime = now

                    _streamStats.value = _streamStats.value.copy(
                        fps = currentFps,
                        activeClients = activeClients.size,
                        bytesSent = totalBytesSent.get(),
                        currentBitrateKbps = currentBitrateKbps,
                        uptimeSeconds = _streamStats.value.uptimeSeconds + 1
                    )
                }

                // If paused by Messenger or external app, send heartbeat paused frame every 1.5 seconds
                // to maintain connection alive without disconnects!
                if (isPausedBySystem && activeClients.isNotEmpty()) {
                    val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                    broadcastFrame(pauseFrame)
                }
            }
        }

        // Audio Stream Keep-Alive Loop: keeps audio stream flowing continuously at 50 chunks/sec
        scope.launch {
            val silentChunk = ByteArray(3840) // 20ms of stereo PCM 16-bit silence
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(20)
                if (activeAudioClients.isNotEmpty()) {
                    val now = System.currentTimeMillis()
                    if (now - lastAudioChunkBroadcastTime > 45) { // If no chunk emitted for 45ms, send silent heartbeat chunk
                        broadcastAudioChunk(silentChunk)
                    }
                }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        scope.launch {
            try {
                socket.tcpNoDelay = true
                socket.soTimeout = 0 // Infinite timeout for long-lived streaming connections
                val inputStream = socket.getInputStream()
                val outputStream = socket.getOutputStream()

                val buffer = ByteArray(2048)
                val bytesRead = inputStream.read(buffer)
                if (bytesRead <= 0) {
                    socket.close()
                    return@launch
                }

                val requestHeader = String(buffer, 0, bytesRead)
                val firstLine = requestHeader.lines().firstOrNull() ?: ""

                // Check PIN Authorization
                val isAuthorized = !pinSecurityEnabled || isRequestAuthorized(requestHeader)

                when {
                    firstLine.contains("GET /stream") -> {
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            return@launch
                        }

                        // MJPEG low-latency stream for TV
                        sendMjpegHeaders(outputStream)
                        activeClients[socket] = outputStream
                        _streamStats.value = _streamStats.value.copy(activeClients = activeClients.size)

                        val initialFrame = if (isPausedBySystem) {
                            StandbyFrameGenerator.generatePausedFrame()
                        } else {
                            latestFrameJpeg
                        }

                        initialFrame?.let { frame ->
                            writeFrame(outputStream, frame)
                        }
                    }
                    firstLine.contains("GET /audio") -> {
                        log("HTTP GET /audio request received from ${socket.remoteSocketAddress}. User-Agent: ${requestHeader.lines().find { it.startsWith("User-Agent:", ignoreCase = true) } ?: "Unknown"}")
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            log("Rejected /audio request: Unauthorized PIN")
                            return@launch
                        }

                        val header = "HTTP/1.1 200 OK\r\n" +
                                "Content-Type: audio/wav\r\n" +
                                "Transfer-Encoding: chunked\r\n" +
                                "Access-Control-Allow-Origin: *\r\n" +
                                "Cache-Control: no-cache, no-store, must-revalidate\r\n" +
                                "Pragma: no-cache\r\n\r\n"
                        outputStream.write(header.toByteArray())

                        val wavHeader = buildStreamingWavHeader()
                        writeChunkedData(outputStream, wavHeader)
                        wavHeaderBytesSent.addAndGet(wavHeader.size.toLong())
                        outputStream.flush()

                        val clientQueue = java.util.concurrent.LinkedBlockingQueue<ByteArray>(20) // Max 20 chunks (400ms max latency window to absorb Wi-Fi jitter)
                        clientAudioQueues[socket] = clientQueue
                        activeAudioClients[socket] = outputStream
                        log("[DIAGNOSTIC SERVER] TV Audio client connected (${socket.remoteSocketAddress}). Chunk #1 (44-byte WAV header) sent. Active audio clients: ${activeAudioClients.size}")

                        var clientChunkCount = 0L

                        try {
                            while (isActive && isRunning.get() && !socket.isClosed) {
                                val pcmChunk = when {
                                    testToneCountdown.get() > 0 -> {
                                        testToneCountdown.decrementAndGet()
                                        kotlinx.coroutines.delay(20)
                                        generateTestSineWaveChunk()
                                    }
                                    else -> {
                                        val chunk = clientQueue.poll(20, java.util.concurrent.TimeUnit.MILLISECONDS)
                                        if (chunk == null) {
                                            continue
                                        }
                                        chunk
                                    }
                                }

                                writeChunkedData(outputStream, pcmChunk)
                                clientChunkCount++
                                pcmChunksWritten.incrementAndGet()
                                pcmBytesSent.addAndGet(pcmChunk.size.toLong())
                                lastPcmSentTimestamp = System.currentTimeMillis()

                                if (clientChunkCount == 1L) {
                                    log("[DIAGNOSTIC STREAMING LOOP] FIRST PCM chunk (#2 overall) sent to ${socket.remoteSocketAddress}: ${pcmChunk.size} bytes")
                                }
                                if (clientChunkCount % 150 == 0L) { // Log every ~3 seconds
                                    log("[DIAGNOSTIC STREAMING LOOP] Socket ${socket.remoteSocketAddress} | PCM Chunks: $clientChunkCount | Total PCM Sent: ${pcmBytesSent.get() / 1024} KB")
                                }
                            }
                        } catch (e: Exception) {
                            log("[DIAGNOSTIC SERVER ERROR] Audio streaming loop ended for ${socket.remoteSocketAddress}: ${e.message}")
                        } finally {
                            clientAudioQueues.remove(socket)
                            activeAudioClients.remove(socket)
                            try { socket.close() } catch (_: Exception) {}
                            log("[DIAGNOSTIC SERVER DISCONNECT] TV Audio client disconnected (${socket.remoteSocketAddress}). Remaining active audio clients: ${activeAudioClients.size}")
                        }
                    }
                    firstLine.contains("GET /audio-test") -> {
                        log("[DIAGNOSTIC SERVER] GET /audio-test request received from ${socket.remoteSocketAddress}. Activating 5-second 440Hz test audio tone.")
                        triggerTestAudioBroadcast()
                        val json = """{"status":"ok","message":"Test audio broadcast activated (250 chunks / 5s 440Hz sine wave)"}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    firstLine.contains("GET /status") -> {
                        val json = """{"status":"${if (isPausedBySystem) "paused" else "streaming"}","fps":$currentFps,"clients":${activeClients.size},"audioClients":${activeAudioClients.size},"bitrateKbps":$currentBitrateKbps,"audioBytesSent":${totalAudioBytesSent.get()},"pinRequired":$pinSecurityEnabled}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    else -> {
                        // Serve TV Web Receiver HTML interface (with PIN prompt and strict anti-caching headers)
                        val html = getTvViewerHtml(pinSecurityEnabled, isAuthorized)
                        val response = "HTTP/1.1 200 OK\r\n" +
                                "Content-Type: text/html; charset=UTF-8\r\n" +
                                "Content-Length: ${html.toByteArray().size}\r\n" +
                                "Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n" +
                                "Pragma: no-cache\r\n" +
                                "Expires: 0\r\n" +
                                "Connection: close\r\n\r\n$html"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                }
            } catch (e: Exception) {
                activeClients.remove(socket)
                activeAudioClients.remove(socket)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    private fun isRequestAuthorized(headers: String): Boolean {
        // Check query param e.g. /stream?pin=XXXX
        val queryPin = Regex("[?&]pin=([0-9]{4})").find(headers)?.groupValues?.get(1)
        if (queryPin == pairingPin) return true

        // Check header e.g. X-Pin: XXXX or Authorization: Bearer XXXX
        if (headers.contains("X-Pin: $pairingPin", ignoreCase = true)) return true
        if (headers.contains("Authorization: Bearer $pairingPin", ignoreCase = true)) return true

        // Check Cookie e.g. Cookie: cast_pin=XXXX
        if (headers.contains("cast_pin=$pairingPin", ignoreCase = true)) return true

        return false
    }

    private fun sendMjpegHeaders(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Connection: close\r\n" +
                "Server: CastDirect/1.0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=--frame\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()
    }

    private fun writeFrame(output: OutputStream, jpegData: ByteArray) {
        val timestamp = System.currentTimeMillis()
        val frameHeader = "--frame\r\n" +
                "Content-Type: image/jpeg\r\n" +
                "Content-Length: ${jpegData.size}\r\n" +
                "X-Timestamp: $timestamp\r\n\r\n"
        output.write(frameHeader.toByteArray())
        output.write(jpegData)
        output.write("\r\n".toByteArray())
        output.flush()
    }

    fun broadcastFrame(jpegData: ByteArray) {
        if (!isRunning.get() || activeClients.isEmpty()) {
            latestFrameJpeg = jpegData
            return
        }

        latestFrameJpeg = jpegData
        frameCount.incrementAndGet()
        val dataSize = jpegData.size.toLong()
        val updatedTotal = totalBytesSent.addAndGet(dataSize)
        bytesInCurrentSecond += dataSize
        _streamStats.value = _streamStats.value.copy(bytesSent = updatedTotal)

        val deadSockets = mutableListOf<Socket>()

        for ((socket, outStream) in activeClients) {
            try {
                writeFrame(outStream, jpegData)
            } catch (e: Exception) {
                deadSockets.add(socket)
            }
        }

        for (socket in deadSockets) {
            activeClients.remove(socket)
            try { socket.close() } catch (_: Exception) {}
        }
    }

    val pcmChunksGenerated = AtomicLong(0L)
    val pcmChunksPassed = AtomicLong(0L)
    val pcmChunksWritten = AtomicLong(0L)
    val wavHeaderBytesSent = AtomicLong(0L)
    val pcmBytesGenerated = AtomicLong(0L)
    val pcmBytesSent = AtomicLong(0L)
    @Volatile var lastPcmSentTimestamp = 0L
    val testToneCountdown = AtomicInteger(0)
    private val clientAudioQueues = java.util.concurrent.ConcurrentHashMap<Socket, java.util.concurrent.LinkedBlockingQueue<ByteArray>>()

    private fun writeChunkedData(outputStream: OutputStream, data: ByteArray) {
        synchronized(outputStream) {
            val hexSize = Integer.toHexString(data.size)
            val headerBytes = "$hexSize\r\n".toByteArray()
            val trailerBytes = "\r\n".toByteArray()
            val fullChunk = ByteArray(headerBytes.size + data.size + trailerBytes.size)

            System.arraycopy(headerBytes, 0, fullChunk, 0, headerBytes.size)
            System.arraycopy(data, 0, fullChunk, headerBytes.size, data.size)
            System.arraycopy(trailerBytes, 0, fullChunk, headerBytes.size + data.size, trailerBytes.size)

            outputStream.write(fullChunk)
            outputStream.flush()
        }
    }

    private var testSinePhase = 0.0

    fun generateTestSineWaveChunk(frequencyHz: Double = 440.0, sampleRate: Int = 48000, numFrames: Int = 960): ByteArray {
        val bytes = ByteArray(numFrames * 4) // 16-bit stereo = 4 bytes per frame
        val amplitude = 16000.0 // Audible test tone
        val phaseIncrement = 2.0 * Math.PI * frequencyHz / sampleRate

        var offset = 0
        for (i in 0 until numFrames) {
            val sampleVal = (Math.sin(testSinePhase) * amplitude).toInt().coerceIn(-32768, 32767).toShort()
            testSinePhase += phaseIncrement
            if (testSinePhase > 2.0 * Math.PI) testSinePhase -= 2.0 * Math.PI

            bytes[offset] = (sampleVal.toInt() and 0xFF).toByte()
            bytes[offset + 1] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
            bytes[offset + 2] = (sampleVal.toInt() and 0xFF).toByte()
            bytes[offset + 3] = ((sampleVal.toInt() shr 8) and 0xFF).toByte()
            offset += 4
        }
        pcmChunksGenerated.incrementAndGet()
        pcmBytesGenerated.addAndGet(bytes.size.toLong())
        return bytes
    }

    fun triggerTestAudioBroadcast() {
        for (queue in clientAudioQueues.values) {
            queue.clear()
        }
        testToneCountdown.set(250) // Set 250 chunks (5 seconds)
        log("[DIAGNOSTIC TEST AUDIO] Activated 5-second 440Hz test tone flag (250 chunks). Active audio clients: ${activeAudioClients.size}")
    }

    @Volatile
    private var lastAudioChunkBroadcastTime = 0L
    private var lastAudioLogTime = 0L
    private var totalAudioChunksBroadcast = 0L

    fun broadcastAudioChunk(pcmData: ByteArray, timestamp: Long = System.currentTimeMillis()) {
        if (!isRunning.get() || activeAudioClients.isEmpty()) return
        pcmChunksPassed.incrementAndGet()
        for (queue in clientAudioQueues.values) {
            if (!queue.offer(pcmData)) {
                // Queue full (>100ms lag): drop oldest chunk so TV client receives real-time current audio
                queue.poll()
                queue.offer(pcmData)
            }
        }
    }

    private fun buildStreamingWavHeader(sampleRate: Int = 48000, channels: Int = 2, bitsPerSample: Int = 16): ByteArray {
        val byteRate = sampleRate * channels * (bitsPerSample / 8)
        val blockAlign = channels * (bitsPerSample / 8)
        val totalDataLen = 0x7FFFFFFF // Streaming / indefinite length flag
        val totalAudioLen = totalDataLen + 36

        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalAudioLen and 0xff).toByte()
        header[5] = ((totalAudioLen shr 8) and 0xff).toByte()
        header[6] = ((totalAudioLen shr 16) and 0xff).toByte()
        header[7] = ((totalAudioLen shr 24) and 0xff).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 4 bytes: size of 'fmt ' chunk
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // format = 1 (PCM)
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (sampleRate and 0xff).toByte()
        header[25] = ((sampleRate shr 8) and 0xff).toByte()
        header[26] = ((sampleRate shr 16) and 0xff).toByte()
        header[27] = ((sampleRate shr 24) and 0xff).toByte()
        header[28] = (byteRate and 0xff).toByte()
        header[29] = ((byteRate shr 8) and 0xff).toByte()
        header[30] = ((byteRate shr 16) and 0xff).toByte()
        header[31] = ((byteRate shr 24) and 0xff).toByte()
        header[32] = blockAlign.toByte()
        header[33] = 0
        header[34] = bitsPerSample.toByte()
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalDataLen and 0xff).toByte()
        header[41] = ((totalDataLen shr 8) and 0xff).toByte()
        header[42] = ((totalDataLen shr 16) and 0xff).toByte()
        header[43] = ((totalDataLen shr 24) and 0xff).toByte()
        return header
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        for ((socket, _) in activeClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeClients.clear()

        for ((socket, _) in activeAudioClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeAudioClients.clear()

        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        log("Local stream server stopped")
    }

    private fun getTvViewerHtml(pinRequired: Boolean, isAuthorized: Boolean): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CastDirect TV Receiver</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body {
            background-color: #000;
            color: #F0F4F8;
            font-family: system-ui, -apple-system, sans-serif;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #stage {
            position: relative;
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
        }
        #stream-img {
            max-width: 100vw;
            max-height: 100vh;
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .top-hud {
            position: absolute;
            top: 24px;
            right: 24px;
            background: rgba(11, 19, 32, 0.9);
            backdrop-filter: blur(14px);
            padding: 10px 18px;
            border-radius: 12px;
            border: 1px solid rgba(0, 229, 255, 0.35);
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 14px;
            z-index: 10;
            transition: opacity 0.5s ease;
        }
        .bottom-hud {
            position: absolute;
            bottom: 24px;
            left: 50%;
            transform: translateX(-50%);
            background: rgba(11, 19, 32, 0.92);
            backdrop-filter: blur(16px);
            padding: 12px 24px;
            border-radius: 16px;
            border: 1px solid rgba(0, 229, 255, 0.4);
            display: flex;
            align-items: center;
            gap: 18px;
            font-size: 14px;
            z-index: 15;
            transition: opacity 0.5s ease;
            box-shadow: 0 8px 30px rgba(0,0,0,0.7);
        }
        .badge {
            background: #00E5FF;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
        }
        .audio-badge {
            background: #00E676;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00E676;
            box-shadow: 0 0 10px #00E676;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.9); opacity: 0.7; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(0.9); opacity: 0.7; }
        }
        .ctrl-btn {
            background: rgba(0, 229, 255, 0.15);
            color: #00E5FF;
            border: 1px solid #00E5FF;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .ctrl-btn:hover, .ctrl-btn:focus {
            background: #00E5FF;
            color: #001E2B;
            outline: none;
        }
        .vol-container {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .vol-slider {
            -webkit-appearance: none;
            width: 110px;
            height: 6px;
            border-radius: 3px;
            background: rgba(255,255,255,0.25);
            outline: none;
        }
        .vol-slider::-webkit-slider-thumb {
            -webkit-appearance: none;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            background: #00E5FF;
            cursor: pointer;
        }
        /* Unmute Banner Overlay for TV Browsers */
        #unmute-banner {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(17, 26, 41, 0.95);
            border: 2px solid #00E5FF;
            padding: 24px 36px;
            border-radius: 18px;
            text-align: center;
            z-index: 25;
            cursor: pointer;
            box-shadow: 0 12px 50px rgba(0, 229, 255, 0.35);
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translate(-50%, -50%) scale(1); }
            50% { transform: translate(-50%, -50%) scale(1.03); }
        }
        /* PIN Dialog Modal */
        #pin-modal {
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(9, 14, 23, 0.95);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        .pin-card {
            background: #111A29;
            border: 1px solid #00E5FF;
            border-radius: 20px;
            padding: 36px 48px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.8);
            max-width: 480px;
        }
        .pin-input {
            width: 200px;
            font-size: 32px;
            letter-spacing: 12px;
            text-align: center;
            padding: 12px;
            background: #090E17;
            border: 2px solid #00E5FF;
            color: #00E5FF;
            border-radius: 12px;
            margin: 20px 0;
            outline: none;
        }
        .pin-btn {
            background: #00E5FF;
            color: #001E2B;
            border: none;
            padding: 12px 32px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }
        .remote-tip {
            font-size: 11px;
            color: #94A3B8;
            margin-top: 14px;
        }
        .privacy-pill {
            font-size: 11px;
            color: #94A3B8;
            background: rgba(255,255,255,0.08);
            padding: 4px 8px;
            border-radius: 6px;
        }
        /* Diagnostic Overlay HUD */
        .diag-hud {
            position: absolute;
            top: 24px;
            left: 24px;
            background: rgba(10, 15, 26, 0.94);
            backdrop-filter: blur(14px);
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid rgba(255, 171, 0, 0.5);
            font-family: monospace, monospace;
            font-size: 11px;
            color: #FFC107;
            z-index: 30;
            line-height: 1.6;
            max-width: 340px;
            box-shadow: 0 6px 24px rgba(0,0,0,0.7);
            direction: ltr;
            text-align: left;
        }
        .diag-title { font-weight: bold; color: #FFF; margin-bottom: 6px; font-size: 12px; border-bottom: 1px solid rgba(255,255,255,0.2); padding-bottom: 4px; }
        .diag-val { color: #00E5FF; font-weight: bold; }
        .diag-err { color: #FF5252; font-weight: bold; word-break: break-all; }
        .hidden { display: none !important; }
    </style>
</head>
<body>
    <!-- Hidden HTML5 Audio Element for low-latency playback -->
    <audio id="stream-audio" preload="none" playsinline></audio>

    <!-- Diagnostic Overlay HUD for TV Audio -->
    <div class="diag-hud" id="diag-hud">
        <div class="diag-title">🔍 TV Audio Diagnostic HUD</div>
        <div>Pipeline: <span class="diag-val" id="diag-pipeline">Initializing...</span></div>
        <div>HTTP Status: <span class="diag-val" id="diag-http-status">Pending</span></div>
        <div>Fetch OK: <span class="diag-val" id="diag-fetch-ok">Pending</span></div>
        <div>Reader State: <span class="diag-val" id="diag-reader-state">Pending</span></div>
        <div>AudioContext: <span class="diag-val" id="diag-ctx-state">Uninitialized</span></div>
        <div>Chunks Recv: <span class="diag-val" id="diag-chunks">0</span> (<span class="diag-val" id="diag-bytes">0 KB</span>)</div>
        <div>PCM Recv: <span class="diag-val" id="diag-pcm-recv">0 KB</span></div>
        <div>Signal Peak: <span class="diag-val" id="diag-peak">0.000</span> | RMS: <span class="diag-val" id="diag-rms">0.000</span></div>
        <div>Jitter: <span class="diag-val" id="diag-jitter">20ms</span> | Resets: <span class="diag-val" id="diag-resets">0</span> | Underruns: <span class="diag-val" id="diag-underruns">0</span></div>
        <div style="border-top:1px dashed rgba(255,255,255,0.2); margin-top:6px; padding-top:4px; font-size:10px; color:#00E5FF;">
          <b>[1] Engine:</b> Produced=<span id="diag-eng-prod">0</span> | ReadErr=<span id="diag-eng-err">0</span><br>
          <b>[2] Server:</b> Recv=<span id="diag-srv-recv">0</span> | Sent=<span id="diag-srv-sent">0</span> | Drop=<span id="diag-srv-drop">0</span><br>
          <b>[3] Client (JS):</b> Recv=<span id="diag-js-recv">0</span> | Sched=<span id="diag-js-sched">0</span> | Lost=<span id="diag-js-lost">0</span><br>
          <b>[4] Delta (Loss):</b> Loss=<span id="diag-delta-loss" style="color:#FF5252;">0</span>
        </div>
        <div>First 32 B (Hex):</div>
        <div id="diag-hex-bytes" style="color:#00E5FF; word-break:break-all; font-size:10px; margin-top:2px;">None</div>
        <div>JS Errors: <span class="diag-val" id="diag-errors">0</span></div>
        <div id="diag-err-detail" class="diag-err" style="display:none; margin-top:4px; font-size:10px;"></div>
    </div>

    <!-- PIN Dialog for unauthorized TV browsers -->
    <div id="pin-modal" class="${if (pinRequired && !isAuthorized) "" else "hidden"}">
        <div class="pin-card">
            <h2 style="margin-bottom: 8px;">🔒 إذن الاتصال بالتلفزيون</h2>
            <p style="color: #94A3B8; font-size: 13px;">أدخل رمز PIN المكون من 4 أرقام المعروض على شاشة الهاتف</p>
            <input type="password" id="pin-field" maxlength="4" class="pin-input" placeholder="••••" autofocus />
            <br>
            <button id="pin-submit" class="pin-btn" onclick="submitPin()">تأكيد الاتصال (OK)</button>
            <p class="remote-tip">اضغط زر الوسط (OK) في ريموت التلفزيون بعد الإدخال</p>
        </div>
    </div>

    <!-- Unmute prompt banner for TV Autoplay policy -->
    <div id="unmute-banner" class="hidden" onclick="enableAudioAndPlay()">
        <h2 style="font-size: 22px; margin-bottom: 8px; color: #00E5FF;">🔊 تفعيل صوت التلفزيون</h2>
        <p style="font-size: 14px; color: #CBD5E1; margin-bottom: 12px;">انقر هنا أو اضغط زر (OK) في ريموت التلفزيون لبدء سماع الصوت المباشر</p>
        <span class="privacy-pill">🛡️ صوت التطبيقات والوسائط فقط | مكالمات Messenger معزولة</span>
    </div>

    <!-- Dedicated Test Audio Action Bar for Android TV -->
    <div id="test-audio-bar" style="position: fixed; bottom: 85px; left: 50%; transform: translateX(-50%); background: rgba(17, 26, 41, 0.95); border: 2px solid #FFC107; padding: 10px 20px; border-radius: 14px; z-index: 90; display: flex; align-items: center; gap: 14px; box-shadow: 0 8px 32px rgba(0,0,0,0.85);">
        <button id="test-audio-btn" class="ctrl-btn" onclick="triggerTestAudio(event)" style="background: #FFC107; color: #001E2B; border: none; padding: 8px 18px; font-size: 14px; font-weight: bold; border-radius: 8px; cursor: pointer; display: flex; align-items: center; gap: 6px;">
            🔊 اختبار الصوت 🔊
        </button>
        <span id="test-audio-status" style="font-size: 13px; color: #00E5FF; font-weight: bold;">جاهز للتشغيل</span>
    </div>

    <div id="stage" onclick="toggleFullscreen()">
        <!-- Top HUD -->
        <div class="top-hud" id="top-hud">
            <div class="status-dot"></div>
            <span>CastDirect TV - بث مباشر</span>
            <span class="badge" id="stats-badge">H.264 Low-Latency</span>
            <span class="audio-badge" id="audio-badge">🎵 صوت الوسائط 48kHz</span>
        </div>

        <!-- Bottom Audio & Playback Controls HUD -->
        <div class="bottom-hud" id="bottom-hud">
            <button id="audio-toggle-btn" class="ctrl-btn" onclick="toggleMute(event)">
                <span id="mute-icon">🔊</span>
                <span id="mute-text">كتم الصوت</span>
            </button>
            <div class="vol-container">
                <span style="font-size: 12px; color: #94A3B8;">مستوى الصوت:</span>
                <input type="range" id="vol-slider" class="vol-slider" min="0" max="100" value="100" oninput="changeVolume(this.value, event)" onclick="event.stopPropagation()">
                <span id="vol-text" style="font-size: 12px; font-weight: bold; width: 36px;">100%</span>
            </div>
            <span class="privacy-pill">🛡️ المكالمات معزولة</span>
            <button class="ctrl-btn" onclick="triggerTestAudio(event)" style="border-color: #FFC107; color: #FFC107;">🧪 صوت تجريبي (5ث)</button>
            <button class="ctrl-btn" onclick="toggleFullscreen(event)">⛶ ملء الشاشة (F)</button>
        </div>

        <img id="stream-img" src="" alt="Phone Screen Stream">
    </div>

    <script>
        const img = document.getElementById('stream-img');
        const audio = document.getElementById('stream-audio');
        const topHud = document.getElementById('top-hud');
        const bottomHud = document.getElementById('bottom-hud');
        const unmuteBanner = document.getElementById('unmute-banner');
        let hideTimeout;

        let audioCtx = null;
        let audioGainNode = null;
        let nextStartTime = 0;
        let audioReader = null;
        let isWebAudioActive = false;

        let totalChunksCount = 0;
        let totalBytesRecv = 0;
        let jsErrorCount = 0;

        window.onerror = function(msg, url, line) {
            jsErrorCount++;
            document.getElementById('diag-errors').innerText = jsErrorCount;
            const errDiv = document.getElementById('diag-err-detail');
            errDiv.style.display = 'block';
            errDiv.innerText = 'Err: ' + msg + ' (L' + line + ')';
            console.error('[TV Audio HUD Error]', msg, line);
        };

        window.addEventListener('unhandledrejection', function(event) {
            jsErrorCount++;
            document.getElementById('diag-errors').innerText = jsErrorCount;
            const errDiv = document.getElementById('diag-err-detail');
            errDiv.style.display = 'block';
            errDiv.innerText = 'Promise Err: ' + (event.reason ? (event.reason.message || event.reason) : 'Unknown');
            console.error('[TV Audio HUD Promise Error]', event.reason);
        });

        function updateDiagStats() {
            if (audioCtx) {
                document.getElementById('diag-ctx-state').innerText = audioCtx.state + ' (' + audioCtx.sampleRate + 'Hz)';
            }
        }
        setInterval(updateDiagStats, 1000);

        function autoHideHuds() {
            clearTimeout(hideTimeout);
            topHud.style.opacity = '1';
            bottomHud.style.opacity = '1';
            hideTimeout = setTimeout(() => {
                topHud.style.opacity = '0';
                bottomHud.style.opacity = '0';
            }, 4000);
        }

        function getStoredPin() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('pin') || localStorage.getItem('cast_pin') || '';
        }

        function loadStream() {
            const pin = getStoredPin();
            const pinModal = document.getElementById('pin-modal');
            
            if ($pinRequired && !pin) {
                pinModal.classList.remove('hidden');
                document.getElementById('pin-field').focus();
                return;
            }

            pinModal.classList.add('hidden');
            img.src = '/stream?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            
            // Connect and stream audio via Web Audio API low latency pipeline
            loadAudioStream(pin);
            autoHideHuds();
        }

        function initAudioContext() {
            if (!audioCtx) {
                const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
                if (AudioCtxClass) {
                    audioCtx = new AudioCtxClass({ sampleRate: 48000 });
                    audioGainNode = audioCtx.createGain();
                    audioGainNode.gain.value = 1.0;
                    audioGainNode.connect(audioCtx.destination);
                    console.log('[CastDirect TV Audio] AudioContext initialized, sampleRate:', audioCtx.sampleRate, 'state:', audioCtx.state);
                    updateDiagStats();
                }
            }
        }

        async function triggerTestAudio(e) {
            if (e) e.stopPropagation();
            const statusEl = document.getElementById('test-audio-status');
            const btnEl = document.getElementById('test-audio-btn');
            console.log('[CastDirect TV] Requesting /audio-test from server...');
            if (statusEl) statusEl.innerText = '⏳ جاري بدء النغمة...';
            if (btnEl) btnEl.disabled = true;

            try {
                const res = await fetch('/audio-test');
                if (res.ok) {
                    if (statusEl) statusEl.innerText = '🔊 يعمل النغم التجريبي (440Hz)...';
                    let countdown = 5;
                    const timer = setInterval(() => {
                        countdown--;
                        if (countdown > 0) {
                            if (statusEl) statusEl.innerText = '🔊 يعمل (' + countdown + 'ث)...';
                        } else {
                            clearInterval(timer);
                            if (statusEl) statusEl.innerText = '✅ اكتمل النغم بنجاح!';
                            if (btnEl) btnEl.disabled = false;
                        }
                    }, 1000);
                } else {
                    if (statusEl) statusEl.innerText = '❌ فشل الطلب (HTTP ' + res.status + ')';
                    if (btnEl) btnEl.disabled = false;
                }
            } catch(err) {
                console.error('[CastDirect TV] /audio-test error:', err);
                if (statusEl) statusEl.innerText = '❌ خطأ شبكة: ' + (err.message || err);
                if (btnEl) btnEl.disabled = false;
            }
        }

        async function loadAudioStream(pin) {
            initAudioContext();
            const audioBadge = document.getElementById('audio-badge');
            document.getElementById('diag-pipeline').innerText = 'WebAudio (Fetch ReadableStream)';
            document.getElementById('diag-http-status').innerText = 'Requesting...';
            document.getElementById('diag-fetch-ok').innerText = 'Pending';
            document.getElementById('diag-reader-state').innerText = 'Pending';

            if (!window.fetch || !audioCtx) {
                document.getElementById('diag-pipeline').innerText = 'Fallback (<audio> Tag)';
                loadAudioFallback(pin);
                return;
            }

            const url = '/audio?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            console.log('[CastDirect TV Audio] Requesting PCM stream:', url);

            try {
                if (audioReader) {
                    try { audioReader.cancel(); } catch(e) {}
                }

                const response = await fetch(url);
                document.getElementById('diag-http-status').innerText = response.status + ' ' + (response.statusText || 'OK');
                document.getElementById('diag-fetch-ok').innerText = 'ok=' + response.ok + ' (body=' + (!!response.body) + ')';
                console.log('[CastDirect TV Audio DIAGNOSTIC] HTTP Response Status:', response.status, 'OK:', response.ok, 'Headers:', Array.from(response.headers.entries()));

                if (!response.ok) {
                    throw new Error('HTTP status ' + response.status + ' ' + (response.statusText || ''));
                }

                if (!response.body) {
                    throw new Error('response.body is null or undefined!');
                }

                if (audioCtx.state === 'suspended') {
                    console.log('[CastDirect TV Audio] AudioContext suspended due to TV autoplay policy. Showing unmute banner.');
                    unmuteBanner.classList.remove('hidden');
                } else {
                    unmuteBanner.classList.add('hidden');
                }

                audioReader = response.body.getReader();
                document.getElementById('diag-reader-state').innerText = 'Active (Reading...)';
                isWebAudioActive = true;
                audioBadge.innerText = '🎵 صوت الوسائط 48kHz (مباشر)';

                let leftover = new Uint8Array(0);
                let headerSkipped = false;
                let firstChunkLogged = false;

                while (true) {
                    const { done, value } = await audioReader.read();
                    if (done) {
                        document.getElementById('diag-reader-state').innerText = 'Done (EOF)';
                        break;
                    }
                    if (!value || value.length === 0) continue;

                    if (!firstChunkLogged) {
                        firstChunkLogged = true;
                        let hexSlice = Array.from(value.subarray(0, Math.min(32, value.length)))
                            .map(b => b.toString(16).padStart(2, '0').toUpperCase())
                            .join(' ');
                        document.getElementById('diag-hex-bytes').innerText = hexSlice;
                        document.getElementById('diag-reader-state').innerText = 'Receiving Data (Active)';
                        console.log('[CastDirect TV Audio DIAGNOSTIC] FIRST audio chunk received in JS! Size:', value.length, 'bytes. First Hex:', hexSlice);
                    }

                    totalChunksCount++;
                    totalBytesRecv += value.length;
                    document.getElementById('diag-chunks').innerText = totalChunksCount;
                    document.getElementById('diag-bytes').innerText = Math.round(totalBytesRecv / 1024) + ' KB';

                    let combined = new Uint8Array(leftover.length + value.length);
                    combined.set(leftover);
                    combined.set(value, leftover.length);

                    let pcmOffset = 0;
                    if (!headerSkipped) {
                        if (combined.length >= 44 && combined[0] === 82 && combined[1] === 73 && combined[2] === 70) { // 'RIFF'
                            pcmOffset = 44; // Skip 44-byte WAV header
                            headerSkipped = true;
                            console.log('[CastDirect TV Audio] Skipping 44-byte WAV header.');
                        } else if (combined.length >= 44) {
                            headerSkipped = true;
                        } else {
                            leftover = combined;
                            continue;
                        }
                    }

                    let pcmData = combined.subarray(pcmOffset);
                    let usableLength = Math.floor(pcmData.length / 4) * 4; // 16-bit stereo frame = 4 bytes
                    leftover = pcmData.subarray(usableLength);

                    if (usableLength > 0 && audioCtx) {
                        playPcmChunk(pcmData.subarray(0, usableLength));
                    }
                }
            } catch (err) {
                console.warn('[CastDirect TV Audio] Fetch stream error:', err);
                document.getElementById('diag-pipeline').innerText = 'Err: ' + (err.message || err) + ' (Retrying in 2s...)';
                const errDiv = document.getElementById('diag-err-detail');
                if (errDiv) {
                    errDiv.style.display = 'block';
                    errDiv.innerText = 'Net Err: ' + (err.message || err);
                }
                setTimeout(() => loadAudioStream(pin), 2000);
            }
        }

        let totalPcmBytesRecv = 0;

        let chunkArrivalTimes = [];
        let resetCount = 0;
        let underrunCount = 0;

        function playPcmChunk(chunkBytes) {
            if (!audioCtx || !audioGainNode) return;

            const nowMs = performance.now();
            chunkArrivalTimes.push(nowMs);
            if (chunkArrivalTimes.length > 50) chunkArrivalTimes.shift();

            let avgIntervalMs = 20;
            if (chunkArrivalTimes.length >= 2) {
                let sumIntervals = 0;
                for (let k = 1; k < chunkArrivalTimes.length; k++) {
                    sumIntervals += (chunkArrivalTimes[k] - chunkArrivalTimes[k-1]);
                }
                avgIntervalMs = sumIntervals / (chunkArrivalTimes.length - 1);
            }

            const numFrames = chunkBytes.length / 4;
            if (numFrames <= 0) return;

            totalPcmBytesRecv += chunkBytes.length;
            const pcmElem = document.getElementById('diag-pcm-recv');
            if (pcmElem) pcmElem.innerText = Math.round(totalPcmBytesRecv / 1024) + ' KB';

            const audioBuffer = audioCtx.createBuffer(2, numFrames, 48000);
            const channelLeft = audioBuffer.getChannelData(0);
            const channelRight = audioBuffer.getChannelData(1);

            const dataView = new DataView(chunkBytes.buffer, chunkBytes.byteOffset, chunkBytes.byteLength);

            let jsPeak = 0;
            let sumSquare = 0;
            for (let i = 0; i < numFrames; i++) {
                const sampleL = dataView.getInt16(i * 4, true) / 32768.0;
                const sampleR = dataView.getInt16(i * 4 + 2, true) / 32768.0;
                const absL = Math.abs(sampleL);
                if (absL > jsPeak) jsPeak = absL;
                sumSquare += sampleL * sampleL;
                const absR = Math.abs(sampleR);
                if (absR > jsPeak) jsPeak = absR;
                sumSquare += sampleR * sampleR;
                channelLeft[i] = sampleL;
                channelRight[i] = sampleR;
            }

            // Fixed RMS calculation across both stereo channels (2 * numFrames total samples)
            const totalSamples = numFrames * 2;
            const jsRms = totalSamples > 0 ? Math.sqrt(sumSquare / totalSamples) : 0;

            const peakElem = document.getElementById('diag-peak');
            if (peakElem) peakElem.innerText = jsPeak.toFixed(3);
            const rmsElem = document.getElementById('diag-rms');
            if (rmsElem) rmsElem.innerText = jsRms.toFixed(4);

            const source = audioCtx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioGainNode);

            const currentTime = audioCtx.currentTime;
            
            // Initialize nextStartTime if uninitialized or too far behind/ahead
            if (nextStartTime === 0 || nextStartTime < currentTime) {
                underrunCount++;
                const underrunEl = document.getElementById('diag-underruns');
                if (underrunEl) underrunEl.innerText = underrunCount;
                nextStartTime = currentTime + 0.04; // 40ms initial pre-roll buffer
            } else if (nextStartTime > currentTime + 0.25) {
                // Only reset if drift exceeds 250ms to prevent runaway latency
                resetCount++;
                const resetEl = document.getElementById('diag-resets');
                if (resetEl) resetEl.innerText = resetCount;
                nextStartTime = currentTime + 0.04;
            }

            source.start(nextStartTime);
            nextStartTime += audioBuffer.duration;

            const jitterEl = document.getElementById('diag-jitter');
            if (jitterEl) jitterEl.innerText = Math.round(Math.abs(avgIntervalMs - 20)) + 'ms';
        }

        function loadAudioFallback(pin) {
            audio.src = '/audio?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            audio.volume = 1.0;
            const playPromise = audio.play();
            if (playPromise !== undefined) {
                playPromise.then(() => {
                    unmuteBanner.classList.add('hidden');
                }).catch(() => {
                    unmuteBanner.classList.remove('hidden');
                });
            }
        }

        function enableAudioAndPlay() {
            initAudioContext();
            if (audioCtx) {
                audioCtx.resume().then(() => {
                    console.log('[CastDirect TV Audio] AudioContext resumed successfully!');
                    unmuteBanner.classList.add('hidden');
                    document.getElementById('audio-badge').innerText = '🎵 صوت الوسائط 48kHz (نشط)';
                }).catch(err => {
                    console.error('[CastDirect TV Audio] Failed to resume AudioContext:', err);
                });
            }
            if (audio.src) {
                audio.play().then(() => {
                    unmuteBanner.classList.add('hidden');
                }).catch(() => {});
            }
        }

        function toggleMute(e) {
            if (e) e.stopPropagation();
            initAudioContext();
            const icon = document.getElementById('mute-icon');
            const text = document.getElementById('mute-text');

            if (isWebAudioActive && audioGainNode) {
                const isCurrentlyMuted = audioGainNode.gain.value === 0;
                if (isCurrentlyMuted) {
                    const sliderVal = parseInt(document.getElementById('vol-slider').value) || 100;
                    audioGainNode.gain.value = sliderVal / 100.0;
                    icon.innerText = '🔊';
                    text.innerText = 'كتم الصوت';
                    document.getElementById('audio-badge').innerText = '🎵 صوت الوسائط 48kHz';
                    enableAudioAndPlay();
                } else {
                    audioGainNode.gain.value = 0;
                    icon.innerText = '🔇';
                    text.innerText = 'تشغيل الصوت';
                    document.getElementById('audio-badge').innerText = '🔇 الصوت مكتوم';
                }
            } else {
                audio.muted = !audio.muted;
                if (audio.muted) {
                    icon.innerText = '🔇';
                    text.innerText = 'تشغيل الصوت';
                    document.getElementById('audio-badge').innerText = '🔇 الصوت مكتوم';
                } else {
                    icon.innerText = '🔊';
                    text.innerText = 'كتم الصوت';
                    document.getElementById('audio-badge').innerText = '🎵 صوت الوسائط 48kHz';
                    enableAudioAndPlay();
                }
            }
            autoHideHuds();
        }

        function changeVolume(val, e) {
            if (e) e.stopPropagation();
            initAudioContext();
            const volFrac = val / 100.0;
            if (audioGainNode) audioGainNode.gain.value = volFrac;
            audio.volume = volFrac;
            document.getElementById('vol-text').innerText = val + '%';

            if (val > 0) {
                document.getElementById('mute-icon').innerText = '🔊';
                document.getElementById('mute-text').innerText = 'كتم الصوت';
                enableAudioAndPlay();
            }
            autoHideHuds();
        }

        function submitPin() {
            const pinVal = document.getElementById('pin-field').value.trim();
            if (pinVal.length === 4) {
                localStorage.setItem('cast_pin', pinVal);
                document.cookie = "cast_pin=" + pinVal + "; path=/; max-age=86400";
                loadStream();
            } else {
                alert('الرجاء إدخال 4 أرقام');
            }
        }

        document.getElementById('pin-field')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitPin();
        });

        // Fullscreen Toggle for Android TV Remote Control
        function toggleFullscreen(e) {
            if (e) e.stopPropagation();
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
            } else {
                document.exitFullscreen().catch(() => {});
            }
        }

        // Android TV Remote Key Handling (DPad OK = 23, Enter = 13, Key F = 70, Key M = 77)
        window.addEventListener('keydown', function(e) {
            if (e.keyCode === 13 || e.keyCode === 23) {
                if (!document.getElementById('pin-modal').classList.contains('hidden')) {
                    submitPin();
                } else if (!unmuteBanner.classList.contains('hidden')) {
                    enableAudioAndPlay();
                } else {
                    toggleFullscreen();
                }
            } else if (e.key === 'm' || e.key === 'M') {
                toggleMute();
            } else if (e.key === 'f' || e.key === 'F') {
                toggleFullscreen();
            } else if (e.key === 'ArrowUp' || e.key === '+') {
                const slider = document.getElementById('vol-slider');
                const newVal = Math.min(100, parseInt(slider.value) + 10);
                slider.value = newVal;
                changeVolume(newVal);
            } else if (e.key === 'ArrowDown' || e.key === '-') {
                const slider = document.getElementById('vol-slider');
                const newVal = Math.max(0, parseInt(slider.value) - 10);
                slider.value = newVal;
                changeVolume(newVal);
            }
            autoHideHuds();
        });

        img.onerror = () => {
            setTimeout(loadStream, 1500);
        };

        audio.onerror = () => {
            setTimeout(() => {
                loadAudioStream(getStoredPin());
            }, 2000);
        };

        loadStream();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
