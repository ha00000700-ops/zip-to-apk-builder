package com.example.server

import android.graphics.Bitmap
import android.util.Log
import com.example.model.StreamStats
import com.example.util.StandbyFrameGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

class LocalStreamServer(
    private val port: Int = 8080,
    var pinSecurityEnabled: Boolean = true,
    var pairingPin: String = "4829"
) {
    private val tag = "LocalStreamServer"
    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val activeClients = ConcurrentHashMap<Socket, OutputStream>()
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val frameCount = AtomicInteger(0)
    private val totalBytesSent = AtomicLong(0L)
    private var lastFpsCalculationTime = System.currentTimeMillis()
    private var currentFps = 0
    private var currentBitrateKbps = 0
    private var bytesInCurrentSecond = 0L

    private val _streamStats = MutableStateFlow(StreamStats())
    val streamStats = _streamStats.asStateFlow()

    @Volatile
    private var latestFrameJpeg: ByteArray? = null

    @Volatile
    var isPausedBySystem: Boolean = false
        set(value) {
            field = value
            if (value) {
                // Broadcast pause frame immediately to all connected TV clients
                val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                broadcastFrame(pauseFrame)
            }
        }

    fun start() {
        if (isRunning.getAndSet(true)) return

        scope.launch {
            try {
                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                Log.d(tag, "Local stream server listening on port $port")

                while (isActive && isRunning.get()) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: Exception) {
                        break
                    }
                    handleClient(socket)
                }
            } catch (e: Exception) {
                Log.e(tag, "Server error: ${e.message}", e)
            } finally {
                stop()
            }
        }

        // Stats & Standby heartbeat loop
        scope.launch {
            while (isActive && isRunning.get()) {
                kotlinx.coroutines.delay(1000)
                val now = System.currentTimeMillis()
                val elapsed = now - lastFpsCalculationTime
                if (elapsed >= 1000) {
                    currentFps = (frameCount.getAndSet(0) * 1000.0 / elapsed).toInt()
                    currentBitrateKbps = ((bytesInCurrentSecond * 8) / 1024).toInt()
                    bytesInCurrentSecond = 0L
                    lastFpsCalculationTime = now

                    _streamStats.value = _streamStats.value.copy(
                        fps = currentFps,
                        activeClients = activeClients.size,
                        bytesSent = totalBytesSent.get(),
                        currentBitrateKbps = currentBitrateKbps,
                        uptimeSeconds = _streamStats.value.uptimeSeconds + 1
                    )
                }

                // If paused by Messenger or external app, send heartbeat paused frame every 1.5 seconds
                // to maintain connection alive without disconnects!
                if (isPausedBySystem && activeClients.isNotEmpty()) {
                    val pauseFrame = StandbyFrameGenerator.generatePausedFrame()
                    broadcastFrame(pauseFrame)
                }
            }
        }
    }

    private fun handleClient(socket: Socket) {
        scope.launch {
            try {
                socket.tcpNoDelay = true
                socket.soTimeout = 15000
                val inputStream = socket.getInputStream()
                val outputStream = socket.getOutputStream()

                val buffer = ByteArray(2048)
                val bytesRead = inputStream.read(buffer)
                if (bytesRead <= 0) {
                    socket.close()
                    return@launch
                }

                val requestHeader = String(buffer, 0, bytesRead)
                val firstLine = requestHeader.lines().firstOrNull() ?: ""

                // Check PIN Authorization
                val isAuthorized = !pinSecurityEnabled || isRequestAuthorized(requestHeader)

                when {
                    firstLine.contains("GET /stream") -> {
                        if (!isAuthorized) {
                            val unauthorized = "HTTP/1.1 401 Unauthorized\r\n" +
                                    "Content-Type: text/plain; charset=UTF-8\r\n" +
                                    "Access-Control-Allow-Origin: *\r\n" +
                                    "Connection: close\r\n\r\n" +
                                    "Unauthorized: Invalid or missing Security PIN"
                            outputStream.write(unauthorized.toByteArray())
                            outputStream.flush()
                            socket.close()
                            return@launch
                        }

                        // MJPEG low-latency stream for TV
                        sendMjpegHeaders(outputStream)
                        activeClients[socket] = outputStream

                        val initialFrame = if (isPausedBySystem) {
                            StandbyFrameGenerator.generatePausedFrame()
                        } else {
                            latestFrameJpeg
                        }

                        initialFrame?.let { frame ->
                            writeFrame(outputStream, frame)
                        }
                    }
                    firstLine.contains("GET /status") -> {
                        val json = """{"status":"${if (isPausedBySystem) "paused" else "streaming"}","fps":$currentFps,"clients":${activeClients.size},"bitrateKbps":$currentBitrateKbps,"pinRequired":$pinSecurityEnabled}"""
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: ${json.length}\r\nAccess-Control-Allow-Origin: *\r\n\r\n$json"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                    else -> {
                        // Serve TV Web Receiver HTML interface (with PIN prompt if enabled)
                        val html = getTvViewerHtml(pinSecurityEnabled, isAuthorized)
                        val response = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ${html.toByteArray().size}\r\nConnection: close\r\n\r\n$html"
                        outputStream.write(response.toByteArray())
                        outputStream.flush()
                        socket.close()
                    }
                }
            } catch (e: Exception) {
                activeClients.remove(socket)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    private fun isRequestAuthorized(headers: String): Boolean {
        // Check query param e.g. /stream?pin=XXXX
        val queryPin = Regex("[?&]pin=([0-9]{4})").find(headers)?.groupValues?.get(1)
        if (queryPin == pairingPin) return true

        // Check header e.g. X-Pin: XXXX or Authorization: Bearer XXXX
        if (headers.contains("X-Pin: $pairingPin", ignoreCase = true)) return true
        if (headers.contains("Authorization: Bearer $pairingPin", ignoreCase = true)) return true

        // Check Cookie e.g. Cookie: cast_pin=XXXX
        if (headers.contains("cast_pin=$pairingPin", ignoreCase = true)) return true

        return false
    }

    private fun sendMjpegHeaders(output: OutputStream) {
        val header = "HTTP/1.1 200 OK\r\n" +
                "Connection: close\r\n" +
                "Server: CastDirect/1.0\r\n" +
                "Cache-Control: no-store, no-cache, must-revalidate, pre-check=0, post-check=0, max-age=0\r\n" +
                "Pragma: no-cache\r\n" +
                "Access-Control-Allow-Origin: *\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=--frame\r\n\r\n"
        output.write(header.toByteArray())
        output.flush()
    }

    private fun writeFrame(output: OutputStream, jpegData: ByteArray) {
        val timestamp = System.currentTimeMillis()
        val frameHeader = "--frame\r\n" +
                "Content-Type: image/jpeg\r\n" +
                "Content-Length: ${jpegData.size}\r\n" +
                "X-Timestamp: $timestamp\r\n\r\n"
        output.write(frameHeader.toByteArray())
        output.write(jpegData)
        output.write("\r\n".toByteArray())
        output.flush()
    }

    fun broadcastFrame(jpegData: ByteArray) {
        if (!isRunning.get() || activeClients.isEmpty()) {
            latestFrameJpeg = jpegData
            return
        }

        latestFrameJpeg = jpegData
        frameCount.incrementAndGet()
        val dataSize = jpegData.size.toLong()
        totalBytesSent.addAndGet(dataSize)
        bytesInCurrentSecond += dataSize

        val deadSockets = mutableListOf<Socket>()

        for ((socket, outStream) in activeClients) {
            try {
                writeFrame(outStream, jpegData)
            } catch (e: Exception) {
                deadSockets.add(socket)
            }
        }

        for (socket in deadSockets) {
            activeClients.remove(socket)
            try { socket.close() } catch (_: Exception) {}
        }
    }

    fun stop() {
        if (!isRunning.getAndSet(false)) return

        for ((socket, _) in activeClients) {
            try { socket.close() } catch (_: Exception) {}
        }
        activeClients.clear()

        try {
            serverSocket?.close()
        } catch (_: Exception) {}
        serverSocket = null
        Log.d(tag, "Local stream server stopped")
    }

    private fun getTvViewerHtml(pinRequired: Boolean, isAuthorized: Boolean): String {
        return """
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CastDirect TV Receiver</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body {
            background-color: #000;
            color: #F0F4F8;
            font-family: system-ui, -apple-system, sans-serif;
            width: 100vw;
            height: 100vh;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #stage {
            position: relative;
            width: 100vw;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #000;
        }
        #stream-img {
            max-width: 100vw;
            max-height: 100vh;
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .hud-overlay {
            position: absolute;
            top: 24px;
            right: 24px;
            background: rgba(11, 19, 32, 0.88);
            backdrop-filter: blur(14px);
            padding: 10px 18px;
            border-radius: 12px;
            border: 1px solid rgba(0, 229, 255, 0.35);
            display: flex;
            align-items: center;
            gap: 14px;
            font-size: 14px;
            z-index: 10;
            transition: opacity 0.5s ease;
        }
        .badge {
            background: #00E5FF;
            color: #001E2B;
            padding: 4px 10px;
            border-radius: 6px;
            font-weight: bold;
            font-size: 12px;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00E676;
            box-shadow: 0 0 10px #00E676;
            animation: pulse 1.5s infinite;
        }
        @keyframes pulse {
            0% { transform: scale(0.9); opacity: 0.7; }
            50% { transform: scale(1.2); opacity: 1; }
            100% { transform: scale(0.9); opacity: 0.7; }
        }
        /* PIN Dialog Modal */
        #pin-modal {
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(9, 14, 23, 0.95);
            backdrop-filter: blur(20px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 100;
        }
        .pin-card {
            background: #111A29;
            border: 1px solid #00E5FF;
            border-radius: 20px;
            padding: 36px 48px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.8);
            max-width: 480px;
        }
        .pin-input {
            width: 200px;
            font-size: 32px;
            letter-spacing: 12px;
            text-align: center;
            padding: 12px;
            background: #090E17;
            border: 2px solid #00E5FF;
            color: #00E5FF;
            border-radius: 12px;
            margin: 20px 0;
            outline: none;
        }
        .pin-btn {
            background: #00E5FF;
            color: #001E2B;
            border: none;
            padding: 12px 32px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 10px;
            cursor: pointer;
            width: 100%;
        }
        .remote-tip {
            font-size: 11px;
            color: #94A3B8;
            margin-top: 14px;
        }
        .hidden { display: none !important; }
    </style>
</head>
<body>
    <!-- PIN Dialog for unauthorized TV browsers -->
    <div id="pin-modal" class="${if (pinRequired && !isAuthorized) "" else "hidden"}">
        <div class="pin-card">
            <h2 style="margin-bottom: 8px;">🔒 إذن الاتصال بالتلفزيون</h2>
            <p style="color: #94A3B8; font-size: 13px;">أدخل رمز PIN المكون من 4 أرقام المعروض على شاشة الهاتف</p>
            <input type="password" id="pin-field" maxlength="4" class="pin-input" placeholder="••••" autofocus />
            <br>
            <button id="pin-submit" class="pin-btn" onclick="submitPin()">تأكيد الاتصال (OK)</button>
            <p class="remote-tip">اضغط زر الوسط (OK) في ريموت التلفزيون بعد الإدخال</p>
        </div>
    </div>

    <div id="stage" onclick="toggleFullscreen()">
        <div class="hud-overlay" id="hud">
            <div class="status-dot"></div>
            <span>CastDirect TV - شاشة كاملة</span>
            <span class="badge" id="stats-badge">H.264 Low-Latency</span>
        </div>
        <img id="stream-img" src="" alt="Phone Screen Stream">
    </div>

    <script>
        const img = document.getElementById('stream-img');
        const hud = document.getElementById('hud');
        let hideTimeout;

        function autoHideHud() {
            clearTimeout(hideTimeout);
            hud.style.opacity = '1';
            hideTimeout = setTimeout(() => { hud.style.opacity = '0'; }, 3500);
        }

        function getStoredPin() {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get('pin') || localStorage.getItem('cast_pin') || '';
        }

        function loadStream() {
            const pin = getStoredPin();
            const pinModal = document.getElementById('pin-modal');
            
            // Check if PIN is required
            if ($pinRequired && !pin) {
                pinModal.classList.remove('hidden');
                document.getElementById('pin-field').focus();
                return;
            }

            pinModal.classList.add('hidden');
            img.src = '/stream?pin=' + encodeURIComponent(pin) + '&t=' + Date.now();
            autoHideHud();
        }

        function submitPin() {
            const pinVal = document.getElementById('pin-field').value.trim();
            if (pinVal.length === 4) {
                localStorage.setItem('cast_pin', pinVal);
                document.cookie = "cast_pin=" + pinVal + "; path=/; max-age=86400";
                loadStream();
            } else {
                alert('الرجاء إدخال 4 أرقام');
            }
        }

        document.getElementById('pin-field')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitPin();
        });

        // Fullscreen Toggle for Android TV Remote Control
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(() => {});
            } else {
                document.exitFullscreen().catch(() => {});
            }
        }

        // Android TV Remote Key Handling (DPad OK = KeyCode 23, Enter = 13, Key F = 70)
        window.addEventListener('keydown', function(e) {
            if (e.keyCode === 13 || e.keyCode === 23 || e.key === 'f' || e.key === 'F') {
                if (document.getElementById('pin-modal').classList.contains('hidden')) {
                    toggleFullscreen();
                }
            }
            autoHideHud();
        });

        img.onerror = () => {
            setTimeout(loadStream, 1500);
        };

        loadStream();
    </script>
</body>
</html>
        """.trimIndent()
    }
}
