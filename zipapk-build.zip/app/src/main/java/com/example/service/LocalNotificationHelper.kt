package com.example.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import java.util.Collections

object LocalNotificationHelper {

    private const val TAG = "LocalNotificationHelper"

    const val CHANNEL_ID_GENERAL = "khedmati_general_channel_v2"
    const val CHANNEL_NAME_GENERAL = "إشعارات عامة وتحديثات الطلبات"

    const val CHANNEL_ID_CHAT = "khedmati_chat_channel_v2"
    const val CHANNEL_NAME_CHAT = "رسائل المحادثات الفورية"

    fun getNotificationSoundUri(context: Context): Uri {
        return Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.khedmati_notification}")
    }

    private val seenNotificationIds: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    private val sessionBaselineIds: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    @Volatile
    private var emissionsHandledInSession = 0
    @Volatile
    private var sessionStartTime = System.currentTimeMillis()

    private var currentSessionUid: String? = null

    fun resetSession() {
        currentSessionUid = null
        seenNotificationIds.clear()
        sessionBaselineIds.clear()
        emissionsHandledInSession = 0
        sessionStartTime = System.currentTimeMillis()
        val caller = Throwable().stackTrace.take(5).joinToString(" <- ") { it.methodName }
        Log.d(TAG, "DIAGNOSTIC: resetSession called at timestamp $sessionStartTime from caller: $caller")
    }

    /**
     * Start a new user notification session explicitly when logging in or observing.
     * Guarantees that any pre-existing notifications cannot trigger system notifications.
     */
    fun startSession(uid: String = "default_user") {
        if (currentSessionUid == uid && sessionBaselineIds.isNotEmpty()) {
            Log.d(TAG, "DIAGNOSTIC: startSession skipped for existing active session uid=$uid (baseline size=${sessionBaselineIds.size}). Prevents screen navigation from wiping baseline.")
            return
        }
        currentSessionUid = uid
        seenNotificationIds.clear()
        sessionBaselineIds.clear()
        emissionsHandledInSession = 0
        sessionStartTime = System.currentTimeMillis()
        val caller = Throwable().stackTrace.take(6).joinToString(" <- ") { "${it.className}.${it.methodName}:${it.lineNumber}" }
        Log.d(TAG, "DIAGNOSTIC: startSession initialized for uid=$uid at timestamp $sessionStartTime | Caller stack: $caller")
    }

    fun getSessionStartTime(): Long = sessionStartTime

    fun isSeen(notificationId: String): Boolean = seenNotificationIds.contains(notificationId) || sessionBaselineIds.contains(notificationId)

    fun markSeen(notificationId: String) {
        if (notificationId.isNotBlank()) {
            seenNotificationIds.add(notificationId)
            sessionBaselineIds.add(notificationId)
        }
    }

    fun handleNewNotifications(context: Context, notifications: List<AppNotification>) {
        ensureChannels(context)
        emissionsHandledInSession++

        val currentTime = System.currentTimeMillis()
        val isInitialSyncPhase = emissionsHandledInSession <= 2 || (currentTime - sessionStartTime < 2000L)

        val allIds = notifications.map { it.id }
        Log.d(TAG, "DIAGNOSTIC: handleNewNotifications emission #$emissionsHandledInSession | sessionStartTime=$sessionStartTime | currentTime=$currentTime | isInitialSyncPhase=$isInitialSyncPhase | receivedCount=${notifications.size} | IDs: $allIds")

        if (isInitialSyncPhase) {
            for (notif in notifications) {
                if (notif.id.isNotBlank()) {
                    sessionBaselineIds.add(notif.id)
                    seenNotificationIds.add(notif.id)
                    Log.d(TAG, "DIAGNOSTIC: [Initial Sync] Added to baseline & seen -> ID: ${notif.id}, title: ${notif.title}, isRead: ${notif.isRead}, createdAt: ${notif.createdAt}")
                }
            }
            Log.d(TAG, "DIAGNOSTIC: Initial sync phase complete. Baseline size: ${sessionBaselineIds.size}, Seen size: ${seenNotificationIds.size}")
            return
        }

        // Subsequent emissions analysis
        for (notif in notifications) {
            val id = notif.id
            val inBaseline = sessionBaselineIds.contains(id)
            val inSeen = seenNotificationIds.contains(id)
            val isUnread = !notif.isRead
            val notBlank = id.isNotBlank()

            val willNotify = isUnread && notBlank && !inBaseline && !inSeen
            val reason = buildString {
                if (!isUnread) append("READ; ")
                if (!notBlank) append("BLANK_ID; ")
                if (inBaseline) append("ALREADY_IN_BASELINE; ")
                if (inSeen) append("ALREADY_SEEN; ")
                if (willNotify) append("GENUINELY_NEW; ")
            }

            Log.d(TAG, "DIAGNOSTIC: [Subsequent Emission] ID=$id | title=${notif.title} | isRead=${notif.isRead} | createdAt=${notif.createdAt} | inBaseline=$inBaseline | inSeen=$inSeen | willNotify=$willNotify | reason=[$reason]")
        }

        // Subsequent emissions: only notify for genuinely new unread notifications that were not in baseline or seen
        val newlyArrived = notifications.filter { notif ->
            !notif.isRead &&
            notif.id.isNotBlank() &&
            !sessionBaselineIds.contains(notif.id) &&
            !seenNotificationIds.contains(notif.id)
        }

        // Add all notifications to seen / baseline sets so they won't trigger alerts again
        for (notif in notifications) {
            if (notif.id.isNotBlank()) {
                seenNotificationIds.add(notif.id)
            }
        }

        for (notif in newlyArrived) {
            sessionBaselineIds.add(notif.id)
            Log.d(TAG, "DIAGNOSTIC: TRIGGERING SYSTEM NOTIFICATION for newly arrived ID: ${notif.id}, title: ${notif.title}")
            showSystemNotification(context, notif)
        }
    }

    fun showSystemNotification(context: Context, notification: AppNotification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            if (permissionStatus != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted, skipping system notification")
                return
            }
        }

        ensureChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("extra_target_type", notification.targetType)
            putExtra("extra_target_id", notification.targetId)
            putExtra("notification_id", notification.id)
            putExtra("notification_type", notification.type)

            if (notification.targetType == AppNotificationTargetType.CONVERSATION || notification.type == AppNotificationType.NEW_MESSAGE) {
                putExtra("conversationId", notification.targetId)
            } else if (notification.targetType == AppNotificationTargetType.PUBLIC_REQUEST) {
                putExtra("publicRequestId", notification.targetId)
                putExtra("requestId", notification.targetId)
            } else if (notification.targetType == AppNotificationTargetType.SERVICE_REQUEST) {
                putExtra("serviceRequestId", notification.targetId)
                putExtra("requestId", notification.targetId)
            }
        }

        val notificationId = if (notification.id.isNotBlank()) notification.id.hashCode() else (System.currentTimeMillis() % 100000).toInt()

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isChat = (notification.type == AppNotificationType.NEW_MESSAGE || notification.targetType == AppNotificationTargetType.CONVERSATION)
        val channelId = if (isChat) CHANNEL_ID_CHAT else CHANNEL_ID_GENERAL
        val soundUri = getNotificationSoundUri(context)

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(notification.title.ifBlank { "خدمتي DZ" })
            .setContentText(notification.body.ifBlank { "إشعار جديد" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(notification.body.ifBlank { "إشعار جديد" }))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (isChat) NotificationCompat.CATEGORY_MESSAGE else NotificationCompat.CATEGORY_EVENT)
            .setSound(soundUri)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS or NotificationCompat.DEFAULT_VIBRATE)
            .setContentIntent(pendingIntent)

        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(notificationId, builder.build())
            Log.d(TAG, "Posted system notification: ${notification.title} (ID: $notificationId)")
        } catch (e: Exception) {
            Log.e(TAG, "Error posting notification: ${e.message}", e)
        }
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val soundUri = getNotificationSoundUri(context)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            // Remove legacy channels to force Android 8+ to apply the custom sound channel configuration
            try {
                notificationManager.deleteNotificationChannel("khedmati_general_channel")
                notificationManager.deleteNotificationChannel("khedmati_chat_channel")
            } catch (e: Exception) {
                Log.w(TAG, "Could not delete legacy channels: ${e.message}")
            }

            val generalChannel = NotificationChannel(
                CHANNEL_ID_GENERAL,
                CHANNEL_NAME_GENERAL,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات العروض الجديدة، قبول العروض وتحديثات الطلبات"
                enableVibration(true)
                enableLights(true)
                setSound(soundUri, audioAttributes)
            }

            val chatChannel = NotificationChannel(
                CHANNEL_ID_CHAT,
                CHANNEL_NAME_CHAT,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات الرسائل والمحادثات المباشرة"
                enableVibration(true)
                enableLights(true)
                setSound(soundUri, audioAttributes)
            }

            notificationManager.createNotificationChannel(generalChannel)
            notificationManager.createNotificationChannel(chatChannel)
        }
    }
}
