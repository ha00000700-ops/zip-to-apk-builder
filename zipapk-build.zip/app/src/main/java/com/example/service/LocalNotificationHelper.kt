package com.example.service

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AppNotification
import com.example.data.model.AppNotificationTargetType
import com.example.data.model.AppNotificationType
import java.util.Collections

object LocalNotificationHelper {

    private const val TAG = "LocalNotificationHelper"

    const val CHANNEL_ID_GENERAL = "khedmati_general_channel"
    const val CHANNEL_NAME_GENERAL = "إشعارات عامة وتحديثات الطلبات"

    const val CHANNEL_ID_CHAT = "khedmati_chat_channel"
    const val CHANNEL_NAME_CHAT = "رسائل المحادثات الفورية"

    private val seenNotificationIds: MutableSet<String> = Collections.synchronizedSet(HashSet<String>())
    private var isFirstSync = true
    private var sessionStartTime = System.currentTimeMillis()

    fun resetSession() {
        seenNotificationIds.clear()
        isFirstSync = true
        sessionStartTime = System.currentTimeMillis()
        Log.d(TAG, "Notification session reset")
    }

    fun handleNewNotifications(context: Context, notifications: List<AppNotification>) {
        ensureChannels(context)

        // Initial sync: populate seen set so existing notifications are not blasted as system notifications
        if (isFirstSync) {
            for (notif in notifications) {
                if (notif.id.isNotBlank()) {
                    seenNotificationIds.add(notif.id)
                }
            }
            isFirstSync = false
            sessionStartTime = System.currentTimeMillis()
            Log.d(TAG, "Initial sync complete: cached ${seenNotificationIds.size} notification IDs")
            return
        }

        // Subsequent emissions: only notify for genuinely new unread notifications
        val newlyArrived = notifications.filter { notif ->
            !notif.isRead &&
            notif.id.isNotBlank() &&
            !seenNotificationIds.contains(notif.id) &&
            notif.createdAt >= (sessionStartTime - 15_000L)
        }

        for (notif in newlyArrived) {
            seenNotificationIds.add(notif.id)
            showSystemNotification(context, notif)
        }
    }

    fun showSystemNotification(context: Context, notification: AppNotification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permissionStatus = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            if (permissionStatus != PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "POST_NOTIFICATIONS permission not granted, skipping system notification")
                return
            }
        }

        ensureChannels(context)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("extra_target_type", notification.targetType)
            putExtra("extra_target_id", notification.targetId)
            putExtra("notification_id", notification.id)
            putExtra("notification_type", notification.type)

            if (notification.targetType == AppNotificationTargetType.CONVERSATION || notification.type == AppNotificationType.NEW_MESSAGE) {
                putExtra("conversationId", notification.targetId)
            } else if (notification.targetType == AppNotificationTargetType.PUBLIC_REQUEST) {
                putExtra("publicRequestId", notification.targetId)
                putExtra("requestId", notification.targetId)
            } else if (notification.targetType == AppNotificationTargetType.SERVICE_REQUEST) {
                putExtra("serviceRequestId", notification.targetId)
                putExtra("requestId", notification.targetId)
            }
        }

        val notificationId = if (notification.id.isNotBlank()) notification.id.hashCode() else (System.currentTimeMillis() % 100000).toInt()

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isChat = (notification.type == AppNotificationType.NEW_MESSAGE || notification.targetType == AppNotificationTargetType.CONVERSATION)
        val channelId = if (isChat) CHANNEL_ID_CHAT else CHANNEL_ID_GENERAL

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(notification.title.ifBlank { "خدمتي DZ" })
            .setContentText(notification.body.ifBlank { "إشعار جديد" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(notification.body.ifBlank { "إشعار جديد" }))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (isChat) NotificationCompat.CATEGORY_MESSAGE else NotificationCompat.CATEGORY_EVENT)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pendingIntent)

        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(notificationId, builder.build())
            Log.d(TAG, "Posted system notification: ${notification.title} (ID: $notificationId)")
        } catch (e: Exception) {
            Log.e(TAG, "Error posting notification: ${e.message}", e)
        }
    }

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val generalChannel = NotificationChannel(
                CHANNEL_ID_GENERAL,
                CHANNEL_NAME_GENERAL,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات العروض الجديدة، قبول العروض وتحديثات الطلبات"
                enableVibration(true)
                enableLights(true)
            }

            val chatChannel = NotificationChannel(
                CHANNEL_ID_CHAT,
                CHANNEL_NAME_CHAT,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات الرسائل والمحادثات المباشرة"
                enableVibration(true)
                enableLights(true)
            }

            notificationManager.createNotificationChannel(generalChannel)
            notificationManager.createNotificationChannel(chatChannel)
        }
    }
}
