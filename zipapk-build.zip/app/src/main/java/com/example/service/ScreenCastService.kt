package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.ScreenCaptureEngine
import com.example.model.CastStatus
import com.example.model.DiagnosticLogEntry
import com.example.model.LogLevel
import com.example.model.StreamConfig
import com.example.model.StreamStats
import com.example.server.LocalStreamServer
import com.example.util.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ScreenCastService : Service() {

    private val tag = "ScreenCastService"
    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var mediaProjection: MediaProjection? = null
    private var captureEngine: ScreenCaptureEngine? = null
    private var streamServer: LocalStreamServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    companion object {
        const val CHANNEL_ID = "cast_direct_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.action.START_CAST"
        const val ACTION_RESUME = "com.example.action.RESUME_CAST"
        const val ACTION_STOP = "com.example.action.STOP_CAST"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        // Global state observable across the application
        val castStatus = MutableStateFlow(CastStatus.IDLE)
        val streamStats = MutableStateFlow(StreamStats())
        val diagnosticLogs = MutableStateFlow<List<DiagnosticLogEntry>>(emptyList())
        val activeStreamUrl = MutableStateFlow("")
        val systemInterruptionReason = MutableStateFlow<String?>(null)
        val currentPairingPin = MutableStateFlow("4829")
        val isPinSecurityEnabled = MutableStateFlow(true)
        val isAdaptiveQualityEnabled = MutableStateFlow(true)

        fun addLog(source: String, message: String, details: String = "", level: LogLevel = LogLevel.INFO) {
            val entry = DiagnosticLogEntry(source = source, message = message, details = details, level = level)
            val current = diagnosticLogs.value.toMutableList()
            current.add(0, entry)
            if (current.size > 100) current.removeAt(current.size - 1)
            diagnosticLogs.value = current
        }

        fun regeneratePin() {
            val newPin = String.format("%04d", (1000..9999).random())
            currentPairingPin.value = newPin
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): ScreenCastService = this@ScreenCastService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        registerNetworkMonitor()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CastDirect::StreamingWakeLock").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L) // 12 hours timeout
            }
        } catch (e: Exception) {
            Log.w(tag, "WakeLock error: ${e.message}")
        }
    }

    private fun registerNetworkMonitor() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val ip = NetworkUtils.getLocalIpAddress(this@ScreenCastService)
                    val url = NetworkUtils.getStreamUrl(ip, 8080)
                    activeStreamUrl.value = url
                    addLog("NetworkMonitor", "تم تحديث اتصال الشبكة بنجاح", "العنوان المحلي الجديد: $url", LogLevel.INFO)
                }

                override fun onLost(network: Network) {
                    addLog("NetworkMonitor", "انقطع اتصال Wi-Fi", "جاري انتظار استعادة الاتصال دون إيقاف الخادم", LogLevel.WARNING)
                }
            }
            connectivityManager?.registerNetworkCallback(request, networkCallback!!)
        } catch (e: Exception) {
            Log.w(tag, "Network callback registration failed: ${e.message}")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START, ACTION_RESUME -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                @Suppress("DEPRECATION")
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != -1 && resultData != null) {
                    handleStartOrResume(resultCode, resultData)
                } else {
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopStreaming()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun handleStartOrResume(resultCode: Int, resultData: Intent) {
        val ip = NetworkUtils.getLocalIpAddress(this)
        val config = StreamConfig(
            pinSecurityEnabled = isPinSecurityEnabled.value,
            pairingPin = currentPairingPin.value,
            adaptiveQuality = isAdaptiveQualityEnabled.value
        )
        val url = NetworkUtils.getStreamUrl(ip, config.port)
        activeStreamUrl.value = url

        val notification = buildNotification("جاري تشغيل البث...", url)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        castStatus.value = CastStatus.STARTING
        systemInterruptionReason.value = null

        try {
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = projectionManager.getMediaProjection(resultCode, resultData)
            mediaProjection = projection

            if (projection == null) {
                addLog("ScreenCastService", "فشل استلام تفويض MediaProjection", "أعاد النظام قيمة null", LogLevel.ERROR)
                castStatus.value = CastStatus.ERROR
                stopSelf()
                return
            }

            // If server is not running, start it
            if (streamServer == null) {
                val server = LocalStreamServer(
                    port = config.port,
                    pinSecurityEnabled = config.pinSecurityEnabled,
                    pairingPin = config.pairingPin
                )
                streamServer = server
                server.start()

                serviceScope.launch {
                    server.streamStats.collect { stats ->
                        streamStats.value = stats
                    }
                }
            } else {
                // Resume existing server session: update PIN and unpause
                streamServer?.pairingPin = config.pairingPin
                streamServer?.pinSecurityEnabled = config.pinSecurityEnabled
                streamServer?.isPausedBySystem = false
            }

            // Stop any previous capture engine instance cleanly
            captureEngine?.stop()

            // Start fresh capture engine
            val engine = ScreenCaptureEngine(
                context = this,
                mediaProjection = projection,
                config = config,
                onFrameEncoded = { frameBytes, encodeMs ->
                    streamServer?.broadcastFrame(frameBytes)

                    // Adaptive Quality Adjustment
                    if (isAdaptiveQualityEnabled.value && encodeMs > 65) {
                        // High load: lower quality slightly to maintain sub-50ms latency
                        captureEngine?.currentJpegQuality = 65
                    } else if (isAdaptiveQualityEnabled.value && encodeMs < 25) {
                        captureEngine?.currentJpegQuality = 80
                    }

                    streamStats.value = streamStats.value.copy(
                        encodeDurationMs = encodeMs,
                        currentQualityLevel = captureEngine?.currentJpegQuality ?: 75
                    )
                },
                onSessionInterrupted = { reason ->
                    // CRITICAL REQUIREMENT 2: Keep LocalStreamServer alive and connected!
                    // Do NOT stop streamServer. Set paused mode so server sends standby frame to TV!
                    castStatus.value = CastStatus.PAUSED_BY_SYSTEM
                    systemInterruptionReason.value = reason
                    streamServer?.isPausedBySystem = true

                    addLog(
                        "ScreenCastService",
                        "تم تعليق التقاط الشاشة مع إبقاء اتصال التلفزيون نشطاً",
                        "الخادم والعملاء متصلون وجاهزون للاستئناف فور انتهاء مكالمة Messenger",
                        LogLevel.WARNING
                    )

                    updateNotification("توقف البث: $reason", url)
                },
                onLogEvent = { source, msg, details, level ->
                    addLog(source, msg, details, level)
                }
            )
            captureEngine = engine
            engine.start()

            castStatus.value = CastStatus.STREAMING
            updateNotification("البث نشط على التلفزيون", url)
            addLog("ScreenCastService", "تم تشغيل البث بنجاح", "يتم إرسال الشاشة مباشرة للـ TV", LogLevel.INFO)

        } catch (e: Exception) {
            Log.e(tag, "Error during startStreaming: ${e.message}", e)
            addLog("ScreenCastService", "خطأ أثناء تشغيل البث", e.localizedMessage ?: "Unknown", LogLevel.ERROR)
            castStatus.value = CastStatus.ERROR
            stopStreaming()
        }
    }

    private fun stopStreaming() {
        castStatus.value = CastStatus.STOPPED
        try {
            captureEngine?.stop()
            captureEngine = null
        } catch (_: Exception) {}

        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}

        try {
            streamServer?.stop()
            streamServer = null
        } catch (_: Exception) {}

        addLog("ScreenCastService", "تم إنهاء خدمة البث وإغلاق السيرفر ومسح الذاكرة", level = LogLevel.INFO)
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, urlText: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenCastService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.cast_direct_icon)
            .setContentTitle("CastDirect TV - $statusText")
            .setContentText("عنوان التلفزيون: $urlText")
            .setSubText("بث محلي Wi-Fi")
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف البث", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(statusText: String, urlText: String) {
        val notification = buildNotification(statusText, urlText)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        stopStreaming()
        try {
            if (networkCallback != null && connectivityManager != null) {
                connectivityManager?.unregisterNetworkCallback(networkCallback!!)
            }
        } catch (_: Exception) {}
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
