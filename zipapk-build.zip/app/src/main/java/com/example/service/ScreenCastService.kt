package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.view.Display
import android.view.Surface
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.engine.AudioCaptureEngine
import com.example.engine.ScreenCaptureEngine
import com.example.model.AudioStats
import com.example.model.AudioStatus
import com.example.model.CastStatus
import com.example.model.DiagnosticLogEntry
import com.example.model.LogLevel
import com.example.model.StreamConfig
import com.example.model.StreamStats
import com.example.server.LocalStreamServer
import com.example.util.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ScreenCastService : Service() {

    private val tag = "ScreenCastService"
    private val binder = LocalBinder()
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var mediaProjection: MediaProjection? = null
    private var captureEngine: ScreenCaptureEngine? = null
    private var audioEngine: AudioCaptureEngine? = null
    private var streamServer: LocalStreamServer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var displayManager: DisplayManager? = null
    private var displayListener: DisplayManager.DisplayListener? = null
    private var lastKnownRotation = -1

    companion object {
        const val CHANNEL_ID = "cast_direct_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.action.START_CAST"
        const val ACTION_RESUME = "com.example.action.RESUME_CAST"
        const val ACTION_STOP = "com.example.action.STOP_CAST"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        // Global state observable across the application
        val castStatus = MutableStateFlow(CastStatus.IDLE)
        val streamStats = MutableStateFlow(StreamStats())
        val diagnosticLogs = MutableStateFlow<List<DiagnosticLogEntry>>(emptyList())
        val activeStreamUrl = MutableStateFlow("")
        val systemInterruptionReason = MutableStateFlow<String?>(null)
        val currentPairingPin = MutableStateFlow("4829")
        val isPinSecurityEnabled = MutableStateFlow(true)
        val isAdaptiveQualityEnabled = MutableStateFlow(true)
        val audioStats = MutableStateFlow(AudioStats())
        val isAudioMuted = MutableStateFlow(false)

        fun addLog(source: String, message: String, details: String = "", level: LogLevel = LogLevel.INFO) {
            val entry = DiagnosticLogEntry(source = source, message = message, details = details, level = level)
            val current = diagnosticLogs.value.toMutableList()
            current.add(0, entry)
            if (current.size > 100) current.removeAt(current.size - 1)
            diagnosticLogs.value = current
        }

        fun regeneratePin() {
            val newPin = String.format("%04d", (1000..9999).random())
            currentPairingPin.value = newPin
        }

        fun toggleAudioMute(serviceInstance: ScreenCastService? = null) {
            val newState = !isAudioMuted.value
            isAudioMuted.value = newState
            serviceInstance?.audioEngine?.isMuted = newState
            audioStats.value = audioStats.value.copy(
                isMuted = newState,
                status = if (newState) AudioStatus.MUTED else AudioStatus.STREAMING,
                statusMessage = if (newState) "الصوت مكتوم من التطبيق" else "بث صوت الوسائط نشط"
            )
        }
    }

    inner class LocalBinder : Binder() {
        fun getService(): ScreenCastService = this@ScreenCastService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        registerNetworkMonitor()
        registerDisplayOrientationListener()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CastDirect::StreamingWakeLock").apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L) // 12 hours timeout
            }
        } catch (e: Exception) {
            Log.w(tag, "WakeLock error: ${e.message}")
        }
    }

    private fun registerNetworkMonitor() {
        try {
            connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            networkCallback = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    val ip = NetworkUtils.getLocalIpAddress(this@ScreenCastService)
                    val url = NetworkUtils.getStreamUrl(ip, 8080)
                    activeStreamUrl.value = url
                    addLog("NetworkMonitor", "تم تحديث اتصال الشبكة بنجاح", "العنوان المحلي الجديد: $url", LogLevel.INFO)
                }

                override fun onLost(network: Network) {
                    addLog("NetworkMonitor", "انقطع اتصال Wi-Fi", "جاري انتظار استعادة الاتصال دون إيقاف الخادم", LogLevel.WARNING)
                }
            }
            connectivityManager?.registerNetworkCallback(request, networkCallback!!)
        } catch (e: Exception) {
            Log.w(tag, "Network callback registration failed: ${e.message}")
        }
    }

    private fun registerDisplayOrientationListener() {
        try {
            displayManager = getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
            lastKnownRotation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                display?.rotation ?: Surface.ROTATION_0
            } else {
                @Suppress("DEPRECATION")
                windowManager?.defaultDisplay?.rotation ?: Surface.ROTATION_0
            }

            displayListener = object : DisplayManager.DisplayListener {
                override fun onDisplayAdded(displayId: Int) {}
                override fun onDisplayRemoved(displayId: Int) {}
                override fun onDisplayChanged(displayId: Int) {
                    if (displayId == Display.DEFAULT_DISPLAY) {
                        val currentRotation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            display?.rotation ?: Surface.ROTATION_0
                        } else {
                            @Suppress("DEPRECATION")
                            windowManager?.defaultDisplay?.rotation ?: Surface.ROTATION_0
                        }
                        if (currentRotation != lastKnownRotation) {
                            lastKnownRotation = currentRotation
                            handleOrientationChanged()
                        }
                    }
                }
            }
            displayManager?.registerDisplayListener(displayListener, null)
        } catch (e: Exception) {
            Log.w(tag, "DisplayListener registration failed: ${e.message}")
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handleOrientationChanged()
    }

    private fun handleOrientationChanged() {
        Log.d(tag, "Screen orientation change detected: resetting frame pacing and clearing stale buffers")
        captureEngine?.resetFramePacing()
        streamServer?.onOrientationChanged()
        addLog(
            "ScreenCastService",
            "تم رصد تدوير الشاشة",
            "تم تفريغ طابور الإطارات القديمة وإعادة ضبط التوقيت لضمان سلاسة انتقال الفيديو والصوت",
            LogLevel.INFO
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START, ACTION_RESUME -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, android.app.Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                // In Android, Activity.RESULT_OK is -1
                if (resultCode == android.app.Activity.RESULT_OK && resultData != null) {
                    handleStartOrResume(resultCode, resultData)
                } else {
                    // Call startForeground with a temporary notification before stopSelf to prevent ForegroundServiceDidNotStartInTimeException
                    val ip = NetworkUtils.getLocalIpAddress(this)
                    val tempNotification = buildNotification("تم إلغاء البث", "http://$ip:8080")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(NOTIFICATION_ID, tempNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                    } else {
                        startForeground(NOTIFICATION_ID, tempNotification)
                    }
                    addLog("ScreenCastService", "تم إلغاء تفويض التقاط الشاشة", "كود الاستجابة: $resultCode", LogLevel.WARNING)
                    castStatus.value = CastStatus.IDLE
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopStreaming()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun handleStartOrResume(resultCode: Int, resultData: Intent) {
        val ip = NetworkUtils.getLocalIpAddress(this)
        val config = StreamConfig(
            pinSecurityEnabled = isPinSecurityEnabled.value,
            pairingPin = currentPairingPin.value,
            adaptiveQuality = isAdaptiveQualityEnabled.value
        )
        val url = NetworkUtils.getStreamUrl(ip, config.port)
        activeStreamUrl.value = url

        val notification = buildNotification("جاري تشغيل البث...", url)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        castStatus.value = CastStatus.STARTING
        systemInterruptionReason.value = null

        try {
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = projectionManager.getMediaProjection(resultCode, resultData)
            mediaProjection = projection

            if (projection == null) {
                addLog("ScreenCastService", "فشل استلام تفويض MediaProjection", "أعاد النظام قيمة null", LogLevel.ERROR)
                castStatus.value = CastStatus.ERROR
                stopSelf()
                return
            }

            // If server is not running, start it
            if (streamServer == null) {
                val server = LocalStreamServer(
                    port = config.port,
                    pinSecurityEnabled = config.pinSecurityEnabled,
                    pairingPin = config.pairingPin
                )
                streamServer = server
                server.start()

                serviceScope.launch {
                    server.streamStats.collect { stats ->
                        streamStats.value = stats
                    }
                }
            } else {
                // Resume existing server session: update PIN and unpause
                streamServer?.pairingPin = config.pairingPin
                streamServer?.pinSecurityEnabled = config.pinSecurityEnabled
                streamServer?.isPausedBySystem = false
            }

            // Stop any previous capture engine instance cleanly
            captureEngine?.stop()

            // Start fresh capture engine
            val engine = ScreenCaptureEngine(
                context = this,
                mediaProjection = projection,
                config = config,
                onFrameEncoded = { frameBytes, encodeMs ->
                    streamServer?.broadcastFrame(frameBytes)

                    // Adaptive Quality Adjustment
                    if (isAdaptiveQualityEnabled.value && encodeMs > 65) {
                        // High load: lower quality slightly to maintain sub-50ms latency
                        captureEngine?.currentJpegQuality = 65
                    } else if (isAdaptiveQualityEnabled.value && encodeMs < 25) {
                        captureEngine?.currentJpegQuality = 80
                    }

                    streamStats.value = streamStats.value.copy(
                        encodeDurationMs = encodeMs,
                        currentQualityLevel = captureEngine?.currentJpegQuality ?: 75
                    )
                },
                onSessionInterrupted = { reason ->
                    // CRITICAL REQUIREMENT 2: Keep LocalStreamServer alive and connected!
                    // Do NOT stop streamServer. Set paused mode so server sends standby frame to TV!
                    castStatus.value = CastStatus.PAUSED_BY_SYSTEM
                    systemInterruptionReason.value = reason
                    streamServer?.isPausedBySystem = true

                    addLog(
                        "ScreenCastService",
                        "تم تعليق التقاط الشاشة مع إبقاء اتصال التلفزيون نشطاً",
                        "الخادم والعملاء متصلون وجاهزون للاستئناف فور انتهاء مكالمة Messenger",
                        LogLevel.WARNING
                    )

                    updateNotification("توقف البث: $reason", url)
                },
                onLogEvent = { source, msg, details, level ->
                    addLog(source, msg, details, level)
                }
            )
            captureEngine = engine
            engine.start()

            // Start AudioCaptureEngine independently (failures in audio NEVER impact video)
            try {
                audioEngine?.stop()
                val aEngine = AudioCaptureEngine(
                    context = this,
                    mediaProjection = projection,
                    onAudioChunkEncoded = { pcmBytes, timestamp ->
                        streamServer?.broadcastAudioChunk(pcmBytes, timestamp)
                        audioStats.value = audioStats.value.copy(
                            bytesSent = audioStats.value.bytesSent + pcmBytes.size
                        )
                    },
                    onStatusChanged = { status, msg ->
                        audioStats.value = audioStats.value.copy(
                            isCapturing = status == AudioStatus.STREAMING || status == AudioStatus.SILENT || status == AudioStatus.CALL_EXCLUDED,
                            status = status,
                            statusMessage = msg,
                            isMuted = isAudioMuted.value
                        )
                    },
                    onLogEvent = { source, msg, details, level ->
                        addLog(source, msg, details, level)
                    }
                )
                aEngine.isMuted = isAudioMuted.value
                audioEngine = aEngine
                aEngine.start()
            } catch (e: Exception) {
                Log.w(tag, "Audio engine start warning: ${e.message}")
                addLog("AudioCaptureEngine", "تنبيه في مسار الصوت (الفيديو مستمر)", e.localizedMessage ?: "Audio engine failed to start", LogLevel.WARNING)
            }

            castStatus.value = CastStatus.STREAMING
            updateNotification("البث نشط على التلفزيون", url)
            addLog("ScreenCastService", "تم تشغيل البث بنجاح", "يتم إرسال الشاشة والصوت مباشرة للـ TV", LogLevel.INFO)

        } catch (e: Exception) {
            Log.e(tag, "Error during startStreaming: ${e.message}", e)
            val errorMsg = e.localizedMessage ?: "فشل بدء التقاط الشاشة"
            addLog("ScreenCastService", "خطأ أثناء تشغيل البث", errorMsg, LogLevel.ERROR)
            cleanupResources()
            castStatus.value = CastStatus.ERROR
        }
    }

    private fun cleanupResources() {
        try {
            audioEngine?.stop()
            audioEngine = null
        } catch (_: Exception) {}
        audioStats.value = AudioStats()

        try {
            captureEngine?.stop()
            captureEngine = null
        } catch (_: Exception) {}

        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}

        try {
            streamServer?.stop()
            streamServer = null
        } catch (_: Exception) {}

        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {}
    }

    private fun stopStreaming() {
        castStatus.value = CastStatus.STOPPED
        cleanupResources()
        addLog("ScreenCastService", "تم إنهاء خدمة البث وإغلاق السيرفر ومسح الذاكرة", level = LogLevel.INFO)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, urlText: String): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, ScreenCastService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.cast_direct_icon)
            .setContentTitle("CastDirect TV - $statusText")
            .setContentText("عنوان التلفزيون: $urlText")
            .setSubText("بث محلي Wi-Fi")
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف البث", stopIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(statusText: String, urlText: String) {
        val notification = buildNotification(statusText, urlText)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onDestroy() {
        stopStreaming()
        try {
            if (networkCallback != null && connectivityManager != null) {
                connectivityManager?.unregisterNetworkCallback(networkCallback!!)
            }
        } catch (_: Exception) {}
        try {
            if (displayListener != null && displayManager != null) {
                displayManager?.unregisterDisplayListener(displayListener)
            }
        } catch (_: Exception) {}
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
