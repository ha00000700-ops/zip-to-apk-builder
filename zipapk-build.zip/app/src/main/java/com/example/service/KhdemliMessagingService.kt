package com.example.service

import android.util.Log
import com.example.data.remote.FirebaseManager
import com.example.util.NotificationHelper
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class KhdemliMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM Registration Token: $token")
        val firebaseManager = FirebaseManager.getInstance(applicationContext)
        val activeUid = firebaseManager.getCurrentFirebaseUid()
        if (activeUid != null) {
            CoroutineScope(Dispatchers.IO).launch {
                firebaseManager.updateUserFcmToken(activeUid, token)
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message Received from: ${remoteMessage.from}")

        val title = remoteMessage.notification?.title 
            ?: remoteMessage.data["title"] 
            ?: "خدملي DZ"
        val body = remoteMessage.notification?.body 
            ?: remoteMessage.data["body"] 
            ?: "لديك إشعار جديد"
        val targetId = remoteMessage.data["targetId"]?.toLongOrNull() ?: 0L
        val type = remoteMessage.data["type"] ?: ""

        NotificationHelper.showNotification(
            context = applicationContext,
            title = title,
            body = body,
            targetId = targetId,
            notificationType = type
        )
    }

    companion object {
        private const val TAG = "KhdemliFCM"
    }
}
