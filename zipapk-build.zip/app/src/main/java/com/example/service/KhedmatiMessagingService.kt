package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.repository.AuthRepository
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class KhedmatiMessagingService : FirebaseMessagingService() {

    private val tag = "KhedmatiFCM"
    private val scope = CoroutineScope(Dispatchers.IO)

    companion object {
        const val CHANNEL_ID_GENERAL = LocalNotificationHelper.CHANNEL_ID_GENERAL
        const val CHANNEL_NAME_GENERAL = LocalNotificationHelper.CHANNEL_NAME_GENERAL

        const val CHANNEL_ID_CHAT = LocalNotificationHelper.CHANNEL_ID_CHAT
        const val CHANNEL_NAME_CHAT = LocalNotificationHelper.CHANNEL_NAME_CHAT
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(tag, "FCM onNewToken: $token")
        val repo = AuthRepository()
        val uid = repo.currentUserId
        if (!uid.isNullOrBlank()) {
            scope.launch {
                repo.registerFcmToken(token)
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(tag, "FCM Message received from: ${remoteMessage.from}")

        var title: String? = null
        var body: String? = null
        var targetType: String? = null
        var targetId: String? = null

        // 1. Parse Data Payload
        if (remoteMessage.data.isNotEmpty()) {
            Log.d(tag, "FCM Data payload: ${remoteMessage.data}")
            title = remoteMessage.data["title"]
            body = remoteMessage.data["body"]
            targetType = remoteMessage.data["targetType"] ?: remoteMessage.data["type"]
            targetId = remoteMessage.data["targetId"] ?: remoteMessage.data["conversationId"] ?: remoteMessage.data["requestId"]
        }

        // 2. Parse Notification Payload (if present, fallback/override)
        remoteMessage.notification?.let { notif ->
            if (title.isNullOrBlank()) title = notif.title
            if (body.isNullOrBlank()) body = notif.body
        }

        val displayTitle = if (!title.isNullOrBlank()) title!! else "خدمتي DZ"
        val displayBody = if (!body.isNullOrBlank()) body!! else "لديك إشعار جديد في تطبيق خدمتي"

        sendSystemNotification(
            title = displayTitle,
            body = displayBody,
            targetType = targetType,
            targetId = targetId
        )
    }

    private fun sendSystemNotification(
        title: String,
        body: String,
        targetType: String?,
        targetId: String?
    ) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            if (!targetType.isNullOrBlank()) {
                putExtra("extra_target_type", targetType)
            }
            if (!targetId.isNullOrBlank()) {
                putExtra("extra_target_id", targetId)
            }
        }

        val notificationId = (System.currentTimeMillis() % 100000).toInt()

        val pendingIntent = PendingIntent.getActivity(
            this,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isChat = (targetType == "chat" || targetType == "conversation" || targetType == "NEW_MESSAGE")
        val channelId = if (isChat) CHANNEL_ID_CHAT else CHANNEL_ID_GENERAL
        val soundUri = LocalNotificationHelper.getNotificationSoundUri(this)

        LocalNotificationHelper.ensureChannels(this)

        val notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setDefaults(NotificationCompat.DEFAULT_LIGHTS or NotificationCompat.DEFAULT_VIBRATE)
            .setContentIntent(pendingIntent)

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(notificationId, notificationBuilder.build())
    }
}
