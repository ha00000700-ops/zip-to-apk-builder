package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CitySelectionDialog
import com.example.ui.components.EditProfileDialog
import com.example.ui.screens.AnniversariesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoveMessagesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RoseLight
import com.example.ui.theme.RosePrimary
import com.example.ui.viewmodel.CoupleWeatherViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: CoupleWeatherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val uiState by viewModel.uiState.collectAsState()
            MyApplicationTheme(romanticTheme = uiState.romanticTheme) {
                // Ensure RTL layout for Arabic
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    CoupleWeatherApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun CoupleWeatherApp(viewModel: CoupleWeatherViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    // Dialog state controllers
    var showEditUserDialog by remember { mutableStateOf(false) }
    var showEditPartnerDialog by remember { mutableStateOf(false) }
    var showSelectUserCityDialog by remember { mutableStateOf(false) }
    var showSelectPartnerCityDialog by remember { mutableStateOf(false) }

    // Hardware/Predictive back handler: return to Home tab if on another tab
    if (uiState.currentTab != 0) {
        BackHandler {
            viewModel.selectTab(0)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar"),
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                tonalElevation = 8.dp
            ) {
                // Tab 0: طقسنا
                NavigationBarItem(
                    selected = uiState.currentTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == 0) Icons.Filled.WbSunny else Icons.Outlined.WbSunny,
                            contentDescription = "طقسنا"
                        )
                    },
                    label = { Text("طقسنا", fontWeight = if (uiState.currentTab == 0) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = RoseLight.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("nav_tab_weather")
                )

                // Tab 1: رسائل الغرام
                NavigationBarItem(
                    selected = uiState.currentTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == 1) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = "رسائل الغرام"
                        )
                    },
                    label = { Text("رسائل الغرام", fontWeight = if (uiState.currentTab == 1) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = RoseLight.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("nav_tab_messages")
                )

                // Tab 2: مناسباتنا
                NavigationBarItem(
                    selected = uiState.currentTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == 2) Icons.Filled.CalendarMonth else Icons.Outlined.CalendarMonth,
                            contentDescription = "مناسباتنا"
                        )
                    },
                    label = { Text("مناسباتنا", fontWeight = if (uiState.currentTab == 2) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = RoseLight.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("nav_tab_anniversaries")
                )

                // Tab 3: الإعدادات
                NavigationBarItem(
                    selected = uiState.currentTab == 3,
                    onClick = { viewModel.selectTab(3) },
                    icon = {
                        Icon(
                            imageVector = if (uiState.currentTab == 3) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "الإعدادات"
                        )
                    },
                    label = { Text("الإعدادات", fontWeight = if (uiState.currentTab == 3) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = RosePrimary,
                        selectedTextColor = RosePrimary,
                        indicatorColor = RoseLight.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier.testTag("nav_tab_settings")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentTab) {
                0 -> HomeScreen(
                    uiState = uiState,
                    viewModel = viewModel,
                    onOpenEditUser = { showEditUserDialog = true },
                    onOpenEditPartner = { showEditPartnerDialog = true },
                    onOpenSelectUserCity = { showSelectUserCityDialog = true },
                    onOpenSelectPartnerCity = { showSelectPartnerCityDialog = true },
                    onNavigateToAnniversaries = { viewModel.selectTab(2) }
                )
                1 -> LoveMessagesScreen(
                    partnerName = uiState.partnerName,
                    loveNotes = uiState.loveNotes,
                    onAddNote = { viewModel.addLoveNote(it) },
                    onDeleteNote = { viewModel.deleteLoveNote(it) },
                    onToggleFavoriteNote = { viewModel.toggleFavoriteNote(it) }
                )
                2 -> AnniversariesScreen(
                    partnerName = uiState.partnerName,
                    anniversaries = uiState.anniversaries,
                    onAddEvent = { title, y, m, d, type, note ->
                        viewModel.addAnniversary(title, y, m, d, type, note)
                    },
                    onDeleteEvent = { viewModel.deleteAnniversary(it) }
                )
                3 -> SettingsScreen(
                    uiState = uiState,
                    onEditUser = { showEditUserDialog = true },
                    onEditPartner = { showEditPartnerDialog = true },
                    onSelectUserCity = { showSelectUserCityDialog = true },
                    onSelectPartnerCity = { showSelectPartnerCityDialog = true },
                    onRefreshWeather = { viewModel.loadWeatherData() },
                    onSelectTheme = { viewModel.setRomanticTheme(it) },
                    onSelectCardStyle = { viewModel.setCardStyle(it) },
                    onToggleParticles = { viewModel.toggleParticlesEnabled(it) },
                    onSetWeatherOverride = { viewModel.setWeatherEffectOverride(it) }
                )
            }
        }
    }

    // Edit User Profile Dialog
    if (showEditUserDialog) {
        EditProfileDialog(
            initialName = uiState.userName,
            initialAvatarUri = uiState.userAvatarUri,
            defaultDrawableRes = R.drawable.img_avatar_him,
            isPartner = false,
            onDismiss = { showEditUserDialog = false },
            onSave = { newName, newUri ->
                viewModel.updateUserName(newName)
                viewModel.updateUserAvatar(newUri)
            }
        )
    }

    // Edit Partner Profile Dialog
    if (showEditPartnerDialog) {
        EditProfileDialog(
            initialName = uiState.partnerName,
            initialAvatarUri = uiState.partnerAvatarUri,
            defaultDrawableRes = R.drawable.img_avatar_her,
            isPartner = true,
            onDismiss = { showEditPartnerDialog = false },
            onSave = { newName, newUri ->
                viewModel.updatePartnerName(newName)
                viewModel.updatePartnerAvatar(newUri)
            }
        )
    }

    // Select User City Dialog
    if (showSelectUserCityDialog) {
        CitySelectionDialog(
            targetRoleLabel = uiState.userName,
            onDismiss = { showSelectUserCityDialog = false },
            onSelectCity = {
                viewModel.updateUserCity(it)
                showSelectUserCityDialog = false
            },
            onSearch = { viewModel.searchCities(it) },
            searchResults = uiState.searchResults,
            isSearching = uiState.isSearching
        )
    }

    // Select Partner City Dialog
    if (showSelectPartnerCityDialog) {
        CitySelectionDialog(
            targetRoleLabel = uiState.partnerName,
            onDismiss = { showSelectPartnerCityDialog = false },
            onSelectCity = {
                viewModel.updatePartnerCity(it)
                showSelectPartnerCityDialog = false
            },
            onSearch = { viewModel.searchCities(it) },
            searchResults = uiState.searchResults,
            isSearching = uiState.isSearching
        )
    }
}
