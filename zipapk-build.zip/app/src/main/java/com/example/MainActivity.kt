package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.*
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MintSecondary
import com.example.ui.theme.MintSoft
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.PlantDoctorViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: PlantDoctorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: PlantDoctorViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeDiagnosis by viewModel.activeDiagnosis.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentScreen != Screen.DiagnosisResult) {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MintSoft,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Spa,
                                        contentDescription = null,
                                        tint = EmeraldPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "طبيب النباتات الذكي",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldPrimary
                                )
                                Text(
                                    text = when (currentScreen) {
                                        Screen.Scan -> "الفحص والتشخيص بالكمرا"
                                        Screen.DiagnosisResult -> "تقرير الفحص والدواء"
                                        Screen.Chat -> "استشارة خبير زراعي ذكي"
                                        Screen.MyGarden -> "حديقتي وجداول السقاية"
                                        Screen.Encyclopedia -> "موسوعة ودليل الأمراض"
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                // 1. Scan tab
                NavigationBarItem(
                    selected = currentScreen == Screen.Scan,
                    onClick = { viewModel.navigateTo(Screen.Scan) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == Screen.Scan) Icons.Filled.CameraAlt else Icons.Outlined.CameraAlt,
                            contentDescription = "فحص"
                        )
                    },
                    label = { Text("فحص", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = MintSoft
                    ),
                    modifier = Modifier.testTag("nav_scan_tab")
                )

                // 2. Diagnosis result tab (if any active)
                if (activeDiagnosis != null) {
                    NavigationBarItem(
                        selected = currentScreen == Screen.DiagnosisResult,
                        onClick = { viewModel.navigateTo(Screen.DiagnosisResult) },
                        icon = {
                            Icon(
                                imageVector = if (currentScreen == Screen.DiagnosisResult) Icons.Filled.MedicalServices else Icons.Outlined.MedicalServices,
                                contentDescription = "الدواء"
                            )
                        },
                        label = { Text("الدواء", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = MintSoft
                        ),
                        modifier = Modifier.testTag("nav_diagnosis_tab")
                    )
                }

                // 3. AI Chat tab
                NavigationBarItem(
                    selected = currentScreen == Screen.Chat,
                    onClick = { viewModel.navigateTo(Screen.Chat) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == Screen.Chat) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Outlined.Chat,
                            contentDescription = "محادثة"
                        )
                    },
                    label = { Text("المحادثة", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = MintSoft
                    ),
                    modifier = Modifier.testTag("nav_chat_tab")
                )

                // 4. Garden tab
                NavigationBarItem(
                    selected = currentScreen == Screen.MyGarden,
                    onClick = { viewModel.navigateTo(Screen.MyGarden) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == Screen.MyGarden) Icons.Filled.Yard else Icons.Outlined.Yard,
                            contentDescription = "حديقتي"
                        )
                    },
                    label = { Text("حديقتي", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = MintSoft
                    ),
                    modifier = Modifier.testTag("nav_garden_tab")
                )

                // 5. Encyclopedia tab
                NavigationBarItem(
                    selected = currentScreen == Screen.Encyclopedia,
                    onClick = { viewModel.navigateTo(Screen.Encyclopedia) },
                    icon = {
                        Icon(
                            imageVector = if (currentScreen == Screen.Encyclopedia) Icons.AutoMirrored.Filled.MenuBook else Icons.AutoMirrored.Outlined.MenuBook,
                            contentDescription = "الموسوعة"
                        )
                    },
                    label = { Text("الموسوعة", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = EmeraldPrimary,
                        selectedTextColor = EmeraldPrimary,
                        indicatorColor = MintSoft
                    ),
                    modifier = Modifier.testTag("nav_encyclopedia_tab")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    Screen.Scan -> ScanScreen(viewModel = viewModel)
                    Screen.DiagnosisResult -> DiagnosisResultScreen(viewModel = viewModel)
                    Screen.Chat -> ChatScreen(viewModel = viewModel)
                    Screen.MyGarden -> GardenScreen(viewModel = viewModel)
                    Screen.Encyclopedia -> EncyclopediaScreen(viewModel = viewModel)
                }
            }
        }
    }
}
