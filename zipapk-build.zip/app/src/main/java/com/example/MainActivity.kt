package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LocalFlorist
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.PlantDoctorViewModel
import com.example.ui.Screen
import com.example.ui.screens.AddEditPlantScreen
import com.example.ui.screens.AdminGuidanceScreen
import com.example.ui.screens.CareScheduleScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CompareHistoryScreen
import com.example.ui.screens.DiagnoseScreen
import com.example.ui.screens.DiagnosisDetailScreen
import com.example.ui.screens.EncyclopediaDetailScreen
import com.example.ui.screens.EncyclopediaScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PlantDetailScreen
import com.example.ui.screens.MyPlantsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.WeatherScreen
import com.example.ui.theme.AgriGreenDark
import com.example.ui.theme.AgriGreenMint
import com.example.ui.theme.MyApplicationTheme

data class NavItem(
    val title: String,
    val screen: Screen,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    private val viewModel: PlantDoctorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val userProfile by viewModel.userProfile.collectAsState()
            val isFrench = userProfile.preferredLanguage.contains("Fran", ignoreCase = true)
            val layoutDirection = if (isFrench) LayoutDirection.Ltr else LayoutDirection.Rtl

            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        PlantDoctorApp(viewModel = viewModel, isFrench = isFrench)
                    }
                }
            }
        }
    }
}

@Composable
fun PlantDoctorApp(viewModel: PlantDoctorViewModel, isFrench: Boolean = false) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Mandatory BackHandler for custom state navigation
    BackHandler(enabled = currentScreen != Screen.Home) {
        if (!viewModel.navigateBack()) {
            viewModel.navigateTo(Screen.Home)
        }
    }

    val navItems = listOf(
        NavItem(
            title = if (isFrench) "Accueil" else "الرئيسية",
            screen = Screen.Home,
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_home"
        ),
        NavItem(
            title = if (isFrench) "Diagnostic" else "التشخيص",
            screen = Screen.Diagnose,
            selectedIcon = Icons.Filled.AutoAwesome,
            unselectedIcon = Icons.Outlined.AutoAwesome,
            testTag = "nav_diagnose"
        ),
        NavItem(
            title = if (isFrench) "Conseils IA" else "المحادثة",
            screen = Screen.Chat,
            selectedIcon = Icons.Filled.Chat,
            unselectedIcon = Icons.Outlined.Chat,
            testTag = "nav_chat"
        ),
        NavItem(
            title = if (isFrench) "Mes Plantes" else "نباتاتي",
            screen = Screen.MyPlants,
            selectedIcon = Icons.Filled.LocalFlorist,
            unselectedIcon = Icons.Outlined.LocalFlorist,
            testTag = "nav_plants"
        ),
        NavItem(
            title = if (isFrench) "Profil" else "حسابي",
            screen = Screen.Profile,
            selectedIcon = Icons.Filled.Person,
            unselectedIcon = Icons.Outlined.Person,
            testTag = "nav_profile"
        )
    )

    val isTopLevelScreen = currentScreen in listOf(
        Screen.Home,
        Screen.Diagnose,
        Screen.Chat,
        Screen.MyPlants,
        Screen.Profile
    )

    Scaffold(
        bottomBar = {
            if (isTopLevelScreen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier
                        .windowInsetsPadding(WindowInsets.navigationBars)
                        .testTag("main_bottom_nav_bar")
                ) {
                    navItems.forEach { item ->
                        val isSelected = when (item.screen) {
                            Screen.Home -> currentScreen == Screen.Home
                            Screen.Diagnose -> currentScreen == Screen.Diagnose
                            Screen.Chat -> currentScreen == Screen.Chat
                            Screen.MyPlants -> currentScreen == Screen.MyPlants
                            Screen.Profile -> currentScreen == Screen.Profile
                            else -> false
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentScreen != item.screen) {
                                    viewModel.navigateTo(item.screen)
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AgriGreenDark,
                                indicatorColor = AgriGreenMint,
                                selectedTextColor = AgriGreenDark,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                is Screen.Home -> HomeScreen(viewModel = viewModel)
                is Screen.Diagnose -> DiagnoseScreen(viewModel = viewModel)
                is Screen.DiagnosisDetail -> DiagnosisDetailScreen(viewModel = viewModel)
                is Screen.Chat -> ChatScreen(viewModel = viewModel)
                is Screen.MyPlants -> MyPlantsScreen(viewModel = viewModel)
                is Screen.PlantDetail -> PlantDetailScreen(viewModel = viewModel)
                is Screen.AddEditPlant -> AddEditPlantScreen(viewModel = viewModel)
                is Screen.CareSchedule -> CareScheduleScreen(viewModel = viewModel)
                is Screen.Encyclopedia -> EncyclopediaScreen(viewModel = viewModel)
                is Screen.EncyclopediaDetail -> EncyclopediaDetailScreen(viewModel = viewModel)
                is Screen.Weather -> WeatherScreen(viewModel = viewModel)
                is Screen.CompareHistory -> CompareHistoryScreen(viewModel = viewModel)
                is Screen.Profile -> ProfileScreen(viewModel = viewModel)
                is Screen.AdminGuidance -> AdminGuidanceScreen(viewModel = viewModel)
            }
        }
    }
}
