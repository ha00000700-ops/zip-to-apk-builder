package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.MainViewModel
import com.example.ui.MainViewModelFactory
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.craftsman.CraftsmanDetailScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.requests.CreateRequestScreen
import com.example.ui.screens.requests.RequestDetailScreen
import com.example.ui.screens.requests.RequestsListScreen
import com.example.ui.screens.search.SearchScreen
import com.example.ui.theme.KhdemliTheme

sealed class Screen {
    object Home : Screen()
    object Search : Screen()
    object Requests : Screen()
    object Profile : Screen()
    object Auth : Screen()
    object Admin : Screen()
    data class CraftsmanDetail(val craftsman: ProfessionalEntity) : Screen()
    data class CreateRequest(val targetCraftsman: ProfessionalEntity? = null) : Screen()
    data class RequestDetail(val request: ServiceRequestEntity) : Screen()
    data class Chat(val request: ServiceRequestEntity) : Screen()
}

enum class BottomNavItem(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    HOME("الرئيسية", Icons.Filled.Home, Icons.Outlined.Home),
    SEARCH("البحث", Icons.Filled.Search, Icons.Outlined.Search),
    REQUESTS("طلباتي", Icons.Filled.Assignment, Icons.Outlined.Assignment),
    PROFILE("حسابي", Icons.Filled.Person, Icons.Outlined.Person)
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels {
        val app = application as KhdemliApp
        MainViewModelFactory(app.repository, app.sessionManager)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

            KhdemliTheme(darkTheme = isDarkMode) {
                // Ensure Arabic RTL direction across the entire application
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    KhdemliMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun KhdemliMainApp(viewModel: MainViewModel) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Home) }
    var currentBottomNav by remember { mutableStateOf(BottomNavItem.HOME) }

    // Collect States
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentPro by viewModel.currentProfessional.collectAsStateWithLifecycle()
    val services by viewModel.services.collectAsStateWithLifecycle()
    val topCraftsmen by viewModel.topCraftsmen.collectAsStateWithLifecycle()
    val filteredCraftsmen by viewModel.filteredCraftsmen.collectAsStateWithLifecycle()
    val userRequests by viewModel.userRequests.collectAsStateWithLifecycle()
    val userNotifications by viewModel.userNotifications.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()
    val selectedWilayaCode by viewModel.selectedWilayaCode.collectAsStateWithLifecycle()
    val selectedCommuneName by viewModel.selectedCommuneName.collectAsStateWithLifecycle()
    val selectedServiceId by viewModel.selectedServiceId.collectAsStateWithLifecycle()
    val onlyAvailable by viewModel.onlyAvailable.collectAsStateWithLifecycle()
    val sortByRating by viewModel.sortByRating.collectAsStateWithLifecycle()

    // Admin & Moderation States
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allProfessionalsAdmin by viewModel.allProfessionalsAdmin.collectAsStateWithLifecycle()
    val allRequestsAdmin by viewModel.allRequestsAdmin.collectAsStateWithLifecycle()
    val allReportsAdmin by viewModel.allReportsAdmin.collectAsStateWithLifecycle()
    val pendingVerifications by viewModel.pendingVerificationRequests.collectAsStateWithLifecycle()
    val allReviewsAdmin by viewModel.allReviewsAdmin.collectAsStateWithLifecycle()
    val flaggedReviewsAdmin by viewModel.flaggedReviewsAdmin.collectAsStateWithLifecycle()

    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current

    // Handle back button smoothly to dismiss keyboards and return to home tabs
    BackHandler(enabled = currentScreen !is Screen.Home) {
        keyboardController?.hide()
        focusManager.clearFocus()
        when (currentScreen) {
            is Screen.CraftsmanDetail -> currentScreen = Screen.Home
            is Screen.CreateRequest -> currentScreen = Screen.Home
            is Screen.Chat -> currentScreen = Screen.Requests
            is Screen.RequestDetail -> {
                currentScreen = Screen.Requests
                currentBottomNav = BottomNavItem.REQUESTS
            }
            is Screen.Admin -> {
                currentScreen = Screen.Profile
                currentBottomNav = BottomNavItem.PROFILE
            }
            is Screen.Auth -> {
                currentScreen = Screen.Home
                currentBottomNav = BottomNavItem.HOME
            }
            is Screen.Search, is Screen.Requests, is Screen.Profile -> {
                currentScreen = Screen.Home
                currentBottomNav = BottomNavItem.HOME
            }
            is Screen.Home -> {}
        }
    }

    val showBottomBar = currentScreen is Screen.Home ||
            currentScreen is Screen.Search ||
            currentScreen is Screen.Requests ||
            currentScreen is Screen.Profile

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.testTag("main_bottom_nav"),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    BottomNavItem.values().forEach { item ->
                        val isSelected = currentBottomNav == item
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                currentBottomNav = item
                                currentScreen = when (item) {
                                    BottomNavItem.HOME -> Screen.Home
                                    BottomNavItem.SEARCH -> Screen.Search
                                    BottomNavItem.REQUESTS -> Screen.Requests
                                    BottomNavItem.PROFILE -> Screen.Profile
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title
                                )
                            },
                            label = { Text(item.title, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            ),
                            modifier = Modifier.testTag("nav_item_${item.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        currentUser = currentUser,
                        services = services,
                        topCraftsmen = topCraftsmen,
                        selectedWilayaCode = selectedWilayaCode,
                        selectedCommuneName = selectedCommuneName,
                        onLocationChanged = { code, wName, cName ->
                            viewModel.setLocation(code, wName, cName)
                        },
                        onCategoryClick = { service ->
                            viewModel.setServiceFilter(service.id)
                            currentBottomNav = BottomNavItem.SEARCH
                            currentScreen = Screen.Search
                        },
                        onCraftsmanClick = { craftsman ->
                            currentScreen = Screen.CraftsmanDetail(craftsman)
                        },
                        onRequestServiceClick = { craftsman ->
                            currentScreen = Screen.CreateRequest(craftsman)
                        },
                        onNavigateToSearch = { query ->
                            viewModel.setSearchQuery(query)
                            currentBottomNav = BottomNavItem.SEARCH
                            currentScreen = Screen.Search
                        }
                    )
                }

                is Screen.Search -> {
                    SearchScreen(
                        services = services,
                        craftsmenList = filteredCraftsmen,
                        selectedWilayaCode = selectedWilayaCode,
                        selectedServiceId = selectedServiceId,
                        onlyAvailable = onlyAvailable,
                        sortByRating = sortByRating,
                        onQueryChanged = { viewModel.setSearchQuery(it) },
                        onWilayaSelected = { viewModel.setWilayaFilter(it) },
                        onServiceSelected = { viewModel.setServiceFilter(it) },
                        onToggleOnlyAvailable = { viewModel.toggleOnlyAvailable(it) },
                        onToggleSortByRating = { viewModel.toggleSortByRating(it) },
                        onCraftsmanClick = { craftsman ->
                            currentScreen = Screen.CraftsmanDetail(craftsman)
                        },
                        onRequestServiceClick = { craftsman ->
                            currentScreen = Screen.CreateRequest(craftsman)
                        }
                    )
                }

                is Screen.Requests -> {
                    RequestsListScreen(
                        currentUser = currentUser,
                        currentPro = currentPro,
                        requestsList = userRequests,
                        onSelectRequest = { req ->
                            currentScreen = Screen.RequestDetail(req)
                        },
                        onCreateNewRequest = {
                            currentScreen = Screen.CreateRequest(null)
                        },
                        onAcceptRequest = { req ->
                            viewModel.acceptRequestAsPro(req)
                        }
                    )
                }

                is Screen.Profile -> {
                    ProfileScreen(
                        currentUser = currentUser,
                        currentPro = currentPro,
                        notifications = userNotifications,
                        isDarkMode = isDarkMode,
                        onToggleDarkMode = { viewModel.toggleDarkMode(it) },
                        onToggleProAvailability = { viewModel.toggleProAvailability(it) },
                        onSubmitVerification = { idCard, qual, notes ->
                            viewModel.submitCraftsmanVerification(idCard, qual, notes)
                        },
                        onMarkNotificationRead = { notifId ->
                            viewModel.markNotificationAsRead(notifId)
                        },
                        onNavigateToAdmin = { currentScreen = Screen.Admin },
                        onSwitchAccount = { currentScreen = Screen.Auth },
                        onLogout = {
                            viewModel.logout()
                            currentScreen = Screen.Auth
                        }
                    )
                }

                is Screen.Auth -> {
                    AuthScreen(
                        services = services,
                        allDemoUsers = allUsers,
                        onLoginSuccess = { user ->
                            viewModel.login(user)
                            currentScreen = Screen.Home
                            currentBottomNav = BottomNavItem.HOME
                        },
                        onRegisterCustomer = { name, phone, email, wCode, wName, cName ->
                            viewModel.registerCustomer(name, phone, email, wCode, wName, cName)
                            currentScreen = Screen.Home
                            currentBottomNav = BottomNavItem.HOME
                        },
                        onRegisterProfessional = { name, phone, wa, sId, sName, wCode, wName, cName, exp, bio, hours, price ->
                            viewModel.registerProfessional(name, phone, wa, sId, sName, wCode, wName, cName, exp, bio, hours, price)
                            currentScreen = Screen.Home
                            currentBottomNav = BottomNavItem.HOME
                        }
                    )
                }

                is Screen.CraftsmanDetail -> {
                    val reviews by viewModel.getReviewsForPro(screen.craftsman.id)
                        .collectAsStateWithLifecycle(initialValue = emptyList())

                    CraftsmanDetailScreen(
                        craftsman = screen.craftsman,
                        reviews = reviews,
                        currentUser = currentUser,
                        onBack = { currentScreen = Screen.Home },
                        onRequestService = {
                            currentScreen = Screen.CreateRequest(screen.craftsman)
                        },
                        onStartDirectChat = {
                            val directReq = ServiceRequestEntity(
                                customerId = currentUser?.id ?: 2L,
                                customerName = currentUser?.fullName ?: "زبون خدملي",
                                customerPhone = currentUser?.phone ?: "0550000000",
                                professionalId = screen.craftsman.id,
                                professionalName = screen.craftsman.fullName,
                                professionalPhone = screen.craftsman.phone,
                                serviceCategoryId = screen.craftsman.serviceCategoryId,
                                serviceNameAr = screen.craftsman.professionNameAr,
                                description = "محادثة استفسار مباشر حول الخدمة",
                                urgency = RequestUrgency.NORMAL,
                                wilayaCode = screen.craftsman.wilayaCode,
                                wilayaNameAr = screen.craftsman.wilayaNameAr,
                                communeNameAr = screen.craftsman.communeNameAr,
                                status = RequestStatus.NEW
                            )
                            viewModel.createServiceRequest(directReq) { newId ->
                                currentScreen = Screen.Chat(directReq.copy(id = newId))
                            }
                        },
                        onSubmitReport = { report ->
                            viewModel.submitReport(report)
                        },
                        onFlagReview = { reviewId, reason ->
                            viewModel.flagReview(reviewId, reason)
                        }
                    )
                }

                is Screen.CreateRequest -> {
                    CreateRequestScreen(
                        currentUser = currentUser,
                        targetCraftsman = screen.targetCraftsman,
                        services = services,
                        onBack = { currentScreen = Screen.Home },
                        onSubmitRequest = { req ->
                            viewModel.createServiceRequest(req) { newId ->
                                currentScreen = Screen.RequestDetail(req.copy(id = newId))
                                currentBottomNav = BottomNavItem.REQUESTS
                            }
                        }
                    )
                }

                is Screen.RequestDetail -> {
                    val liveReq = userRequests.find { it.id == screen.request.id } ?: screen.request

                    RequestDetailScreen(
                        request = liveReq,
                        currentUser = currentUser,
                        currentPro = currentPro,
                        onBack = {
                            currentScreen = Screen.Requests
                            currentBottomNav = BottomNavItem.REQUESTS
                        },
                        onStatusChange = { newStatus ->
                            viewModel.updateRequestStatus(liveReq.id, newStatus)
                        },
                        onAcceptByPro = {
                            viewModel.acceptRequestAsPro(liveReq)
                        },
                        onOpenChat = {
                            currentScreen = Screen.Chat(liveReq)
                        },
                        onSubmitReview = { rating, comment ->
                            if (liveReq.professionalId != null) {
                                viewModel.submitReview(
                                    requestId = liveReq.id,
                                    professionalId = liveReq.professionalId,
                                    rating = rating,
                                    comment = comment
                                )
                            }
                        },
                        onSubmitReport = { report ->
                            viewModel.submitReport(report)
                        }
                    )
                }

                is Screen.Chat -> {
                    val messages by viewModel.getMessagesForRequest(screen.request.id)
                        .collectAsStateWithLifecycle(initialValue = emptyList())

                    ChatScreen(
                        request = screen.request,
                        messages = messages,
                        currentUser = currentUser,
                        onBack = {
                            currentScreen = Screen.RequestDetail(screen.request)
                        },
                        onSendMessage = { content ->
                            viewModel.sendMessage(screen.request.id, content)
                        }
                    )
                }

                is Screen.Admin -> {
                    AdminDashboardScreen(
                        users = allUsers,
                        professionals = allProfessionalsAdmin,
                        requests = allRequestsAdmin,
                        reports = allReportsAdmin,
                        verificationRequests = pendingVerifications,
                        reviews = allReviewsAdmin,
                        flaggedReviews = flaggedReviewsAdmin,
                        services = services,
                        onBack = {
                            currentScreen = Screen.Profile
                            currentBottomNav = BottomNavItem.PROFILE
                        },
                        onApproveVerification = { reqId, proId ->
                            viewModel.adminApproveVerification(reqId, proId)
                        },
                        onRejectVerification = { reqId, proId, reason ->
                            viewModel.adminRejectVerification(reqId, proId, reason)
                        },
                        onRevokeVerification = { proId, reason ->
                            viewModel.adminRevokeVerification(proId, reason)
                        },
                        onDeleteReview = { reviewId ->
                            viewModel.adminDeleteReview(reviewId)
                        },
                        onToggleBlockUser = { user ->
                            viewModel.adminToggleBlockUser(user)
                        },
                        onDeleteUser = { user ->
                            viewModel.adminDeleteUser(user)
                        },
                        onUpdateReport = { reportId, status, action ->
                            viewModel.adminUpdateReport(reportId, status, action)
                        },
                        onAddServiceCategory = { nameAr, nameFr, icon ->
                            viewModel.adminAddServiceCategory(nameAr, nameFr, icon)
                        }
                    )
                }
            }
        }
    }
}
