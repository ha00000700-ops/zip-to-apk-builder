package com.example

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.navigation.KhedmatiNavGraph
import com.example.ui.theme.KhedmatiTheme

class MainActivity : ComponentActivity() {
    private var initialTargetType by mutableStateOf<String?>(null)
    private var initialTargetId by mutableStateOf<String?>(null)
    private var initialConversationId by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        extractNotificationExtras(intent)
        enableEdgeToEdge()
        setContent {
            KhedmatiTheme {
                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    // Notification permission result handled by system
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    KhedmatiNavGraph(
                        initialTargetType = initialTargetType,
                        initialTargetId = initialTargetId,
                        initialConversationId = initialConversationId
                    )
                    // Reset after navigation
                    LaunchedEffect(initialTargetType, initialTargetId, initialConversationId) {
                        if (initialTargetType != null || initialTargetId != null || initialConversationId != null) {
                            initialTargetType = null
                            initialTargetId = null
                            initialConversationId = null
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractNotificationExtras(intent)
    }

    private fun extractNotificationExtras(intent: Intent?) {
        if (intent == null) return
        val targetType = intent.getStringExtra("extra_target_type")
        val targetId = intent.getStringExtra("extra_target_id")
        val convId = intent.getStringExtra("conversationId")
        val reqId = intent.getStringExtra("requestId")
            ?: intent.getStringExtra("publicRequestId")
            ?: intent.getStringExtra("serviceRequestId")

        initialTargetType = targetType
        initialTargetId = targetId ?: convId ?: reqId
        initialConversationId = convId ?: if (targetType?.uppercase() in listOf("CONVERSATION", "CHAT", "NEW_MESSAGE")) targetId else null
    }
}

