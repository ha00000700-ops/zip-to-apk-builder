package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.navigation.KhedmatiNavGraph
import com.example.ui.theme.KhedmatiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KhedmatiTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    KhedmatiNavGraph()
                }
            }
        }
    }
}

