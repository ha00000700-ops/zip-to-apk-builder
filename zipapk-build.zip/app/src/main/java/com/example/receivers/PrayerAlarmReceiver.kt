package com.example.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.notifications.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val isUpdate = intent.getBooleanExtra(EXTRA_IS_UPDATE, false)
        if (isUpdate) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val settingsRepository = com.example.data.SettingsRepository(context)
                    val lat = settingsRepository.latitudeFlow.first()
                    val lng = settingsRepository.longitudeFlow.first()
                    
                    if (lat != null && lng != null) {
                        val calcMethod = settingsRepository.calculationMethodFlow.first()
                        val asrMethod = settingsRepository.asrMethodFlow.first()
                        val timeZoneId = settingsRepository.timeZoneIdFlow.first()
                        val notifsEnabled = settingsRepository.notificationsEnabledFlow.first()
                        val preAlertEnabled = settingsRepository.preAlertEnabledFlow.first()
                        val preAlertDuration = settingsRepository.preAlertDurationFlow.first()
                        val adhanEnabled = settingsRepository.adhanEnabledFlow.first()
                        val vibrationEnabled = settingsRepository.vibrationEnabledFlow.first()
                        
                        val scheduler = com.example.notifications.AlarmScheduler(context)
                        scheduler.scheduleAlarms(
                            lat = lat,
                            lng = lng,
                            calcMethod = calcMethod,
                            asrMethod = asrMethod,
                            timeZoneId = timeZoneId,
                            notificationsEnabled = notifsEnabled,
                            preAlertEnabled = preAlertEnabled,
                            preAlertDuration = preAlertDuration,
                            adhanEnabled = adhanEnabled,
                            vibrationEnabled = vibrationEnabled
                        )
                    }
                } finally {
                    pendingResult.finish()
                }
            }
            return
        }

        val prayerName = intent.getStringExtra(EXTRA_PRAYER_NAME) ?: return
        val isPreAlert = intent.getBooleanExtra(EXTRA_IS_PRE_ALERT, false)
        val adhanEnabled = intent.getBooleanExtra(EXTRA_ADHAN_ENABLED, false)
        val vibrationEnabled = intent.getBooleanExtra(EXTRA_VIBRATION_ENABLED, true)

        val arabicName = getArabicPrayerName(prayerName)
        
        val title: String
        val message: String

        if (isPreAlert) {
            title = "اقترب موعد الصلاة"
            message = "صلاة $arabicName بعد قليل"
            val notificationHelper = NotificationHelper(context)
            notificationHelper.showPrayerNotification(title, message, playAdhan = false, vibrate = vibrationEnabled)
        } else {
            title = "حان الآن وقت الصلاة"
            message = "حان الآن وقت صلاة $arabicName"
            
            val notificationHelper = NotificationHelper(context)
            notificationHelper.showPrayerNotification(title, message, playAdhan = adhanEnabled, vibrate = vibrationEnabled)
            
            // If adhan is enabled and we want to play it via a foreground service for longer playback
            if (adhanEnabled) {
                // For a simple solution, playing custom sound via NotificationChannel (as done in NotificationHelper)
                // is often enough and less intrusive than a full foreground service, but we can also trigger a service here.
            }
        }
    }

    private fun getArabicPrayerName(prayerName: String): String {
        return when (prayerName) {
            "FAJR" -> "الفجر"
            "SUNRISE" -> "الشروق"
            "DHUHR" -> "الظهر"
            "ASR" -> "العصر"
            "MAGHRIB" -> "المغرب"
            "ISHA" -> "العشاء"
            else -> ""
        }
    }

    companion object {
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_IS_PRE_ALERT = "extra_is_pre_alert"
        const val EXTRA_ADHAN_ENABLED = "extra_adhan_enabled"
        const val EXTRA_VIBRATION_ENABLED = "extra_vibration_enabled"
        const val EXTRA_IS_UPDATE = "extra_is_update"
    }
}
