package com.example.receivers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.SettingsRepository
import com.example.notifications.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || 
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED ||
            intent.action == Intent.ACTION_TIME_CHANGED) {
            
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val settingsRepository = SettingsRepository(context)
                    val lat = settingsRepository.latitudeFlow.first()
                    val lng = settingsRepository.longitudeFlow.first()
                    
                    if (lat != null && lng != null) {
                        val calcMethod = settingsRepository.calculationMethodFlow.first()
                        val asrMethod = settingsRepository.asrMethodFlow.first()
                        val timeZoneId = settingsRepository.timeZoneIdFlow.first()
                        val notifsEnabled = settingsRepository.notificationsEnabledFlow.first()
                        val preAlertEnabled = settingsRepository.preAlertEnabledFlow.first()
                        val preAlertDuration = settingsRepository.preAlertDurationFlow.first()
                        val adhanEnabled = settingsRepository.adhanEnabledFlow.first()
                        val vibrationEnabled = settingsRepository.vibrationEnabledFlow.first()
                        
                        val scheduler = AlarmScheduler(context)
                        scheduler.scheduleAlarms(
                            lat = lat,
                            lng = lng,
                            calcMethod = calcMethod,
                            asrMethod = asrMethod,
                            timeZoneId = timeZoneId,
                            notificationsEnabled = notifsEnabled,
                            preAlertEnabled = preAlertEnabled,
                            preAlertDuration = preAlertDuration,
                            adhanEnabled = adhanEnabled,
                            vibrationEnabled = vibrationEnabled
                        )
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
