package com.example.architecture

/**
 * Technical Whitepaper & Architectural Analysis of Android MediaProjection API
 * and Multi-App Concurrency Restrictions (e.g. Simultaneous Messenger Call Screen Sharing).
 */
object MediaProjectionAnalysis {

    const val TITLE_AR = "التحليل المعماري لقيود Android MediaProjection والبث المتزامن مع Messenger"

    const val EXECUTIVE_SUMMARY_AR = """
في نظام Android الرسمي (AOSP)، تم تصميم MediaProjection كـ "مورد أحادي الإشغال" (Single-Tenant Exclusive Resource).
عندما يبدأ تطبيقنا بث شاشة الهاتف إلى التلفزيون، ويقوم المستخدم في نفس الوقت بتفعيل "مشاركة الشاشة" في Facebook Messenger، يقوم نظام Android باستدعاء دالة Callback.onStop() فوراً على جلستنا وإلغاء صلاحية الوصول إلى VirtualDisplay، مما يوقف بث التلفزيون إجبارياً على مستوى نواة النظام (Android Framework).
لا يمكن لأي تطبيق غير مروّت (Non-Root) تجاوز هذا القيد لأن الحظر مفروض بواسطة MediaProjectionManagerService داخل كود النظام.
    """

    val ARCHITECTURAL_FACTS = listOf(
        ArchitecturalFact(
            title = "1. آلية التنافي الحصري في AOSP (Mutual Exclusivity)",
            codeReference = "frameworks/base/services/core/java/com/android/server/media/projection/MediaProjectionManagerService.java",
            explanation = """
داخل خدمة النظام MediaProjectionManagerService، يحتفظ النظام بحقل واحد فقط للجلسة النشطة:
`private MediaProjection mProjectionGrant;`
عندما يطلب Messenger جلسة التقاط جديدة عبر createScreenCaptureIntent() ويوافق المستخدم، ينفذ النظام الدالة:
```java
if (mProjectionGrant != null) {
    mProjectionGrant.stop(); // إيقاف الجلسة السابقة إجبارياً
}
```
هذا يستدعي فوراً `MediaProjection.Callback.onStop()` في تطبيقنا.
            """.trimIndent()
        ),
        ArchitecturalFact(
            title = "2. سلوك VirtualDisplay و SurfaceFlinger",
            codeReference = "android.hardware.display.VirtualDisplay",
            explanation = """
بمجرد استدعاء onStop()، يقوم SurfaceFlinger بفصل شاشة العرض الافتراضية (VirtualDisplay).
حتى لو أبقى تطبيقنا الـ Foreground Service والـ Socket نشطين، تتوقف تدفقات الـ Buffers من نظام العرض إلى MediaCodec، مما يسبب تجمد الصورة أو ظهور شاشة سوداء على التلفزيون.
            """.trimIndent()
        ),
        ArchitecturalFact(
            title = "3. خرافة حل المشكلة عبر WebRTC",
            codeReference = "WebRTC vs OS Capture Layer",
            explanation = """
WebRTC هو بروتوكول نقل للوسائط (Transport Protocol) يعمل فوق طبقة الشبكة (RTP/SRTP/ICE).
الالتقاط (Capture) يسبق النقل؛ WebRTC يحتاج إلى Surface أو VideoCapturer يأتي من MediaProjection.
إذا أوقف النظام الـ MediaProjection المصدر، فلن يجد WebRTC أي إطارات فيديو لنقلها. لذا WebRTC لا يحل ولن يحل قيد تعدد جلسات الالتقاط.
            """.trimIndent()
        ),
        ArchitecturalFact(
            title = "4. تحديثات Android 14 و Android 15 (Partial Screen Sharing)",
            codeReference = "android.media.projection.MediaProjectionConfig (API 34+)",
            explanation = """
في Android 14، أضافت Google إمكانية مشاركة تطبيق واحد فقط (App-Specific Capture).
مع ذلك، ما زالت سياسة النظام تمنع امتلاك رمزين (Tokens) متزامنين من نوع MediaProjection لتطبيقات مختلفة من الطرف الثالث من دون صلاحيات النظام الفائقة (SignatureOrSystem).
            """.trimIndent()
        )
    )

    val SUPPORTED_SOLUTIONS = listOf(
        SupportedSolution(
            id = "auto_resume",
            title = "الحل 1: بروتوكول الاستئناف الذاتي الذكي (Smart Auto-Resume)",
            feasibility = "مدعوم 100% ورسمي (Official Android API)",
            description = """
يراقب تطبيقنا دورة حياة MediaProjection عبر Callback.
عندما يقوم Messenger بسرقة الالتقاط، يتم تنبيه المستخدم وعرض حالة التعليق المؤقت (Paused due to Messenger).
بمجرد انتهاء مكالمة Messenger أو إيقاف مشاركة الشاشة فيه، يوفر تطبيقنا إعادة ارتباط فورية بلمسة واحدة (One-Tap Resume) دون الحاجة لإعادة تكوين الاتصال بالتلفزيون.
            """.trimIndent(),
            isRecommended = true
        ),
        SupportedSolution(
            id = "tv_relay",
            title = "الحل 2: مسار تحويل التلفزيون (TV-Side Screen Relay)",
            feasibility = "مدعوم تقنياً عبر الشبكة المحلية",
            description = """
يتم بث شاشة الهاتف إلى التلفزيون عبر تطبيقنا أولاً (MediaProjection واحد على الهاتف).
إذا كان الغرض مشاركة ما يراه مستخدم التلفزيون في مكالمة Messenger، يتم فتح Messenger على جهاز لوحي أو كمبيوتر أو استخدام كاميرا المكالمة الموجهة للشاشة، مما يحرر هاتف المستخدم من صراع الجلسات.
            """.trimIndent(),
            isRecommended = false
        ),
        SupportedSolution(
            id = "dual_app_warning",
            title = "الحل 3: الإشعار الصريح والشفاف للمستخدم (Zero-Hallucination)",
            feasibility = "مطلوب لتجربة استخدام احترافية وموثوقة",
            description = """
إعلام المستخدم مسبقاً بأن نظام Android يمنع التطبيقات الأمنية ومكالمات الفيديو من التقاط الشاشة في نفس الوقت مع تطبيقات خارجية، وتقديم مؤشرات مرئية دقيقة فور حدوث تداخل بين التطبيقين.
            """.trimIndent(),
            isRecommended = true
        )
    )
}

data class ArchitecturalFact(
    val title: String,
    val codeReference: String,
    val explanation: String
)

data class SupportedSolution(
    val id: String,
    val title: String,
    val feasibility: String,
    val description: String,
    val isRecommended: Boolean
)
