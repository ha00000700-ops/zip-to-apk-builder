package com.example.architecture

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.model.XiaomiGuideItem

object XiaomiCompatibilityGuide {

    fun isXiaomiDevice(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase()
        val brand = Build.BRAND.lowercase()
        return manufacturer.contains("xiaomi") || brand.contains("xiaomi") ||
                brand.contains("redmi") || brand.contains("poco")
    }

    val GUIDE_ITEMS = listOf(
        XiaomiGuideItem(
            stepNumber = 1,
            title = "تعطيل موفر البطارية الصارم (No Restrictions)",
            path = "الإعدادات > التطبيقات > إدارة التطبيقات > CastDirect TV > موفر البطارية > اختر 'لا توجد قيود'",
            whyNeeded = "يقوم نظام MIUI/HyperOS بإيقاف بث الشبكة تلقائياً بعد دقائق إذا لم يتم اختيار 'لا توجد قيود'."
        ),
        XiaomiGuideItem(
            stepNumber = 2,
            title = "تفعيل التشغيل التلقائي (Autostart)",
            path = "الإعدادات > التطبيقات > الأذونات > التشغيل التلقائي > تفعيل CastDirect TV",
            whyNeeded = "يضمن بقاء خدمة البث حية عند التبديل السريع بين مكالمة Messenger والتطبيق."
        ),
        XiaomiGuideItem(
            stepNumber = 3,
            title = "النوافذ المنبثقة أثناء التشغيل في الخلفية",
            path = "إدارة التطبيقات > CastDirect TV > أذونات أخرى > عرض النوافذ المنبثقة أثناء العمل في الخلفية",
            whyNeeded = "يسمح للنظام بعرض إشعار موافقة Android عند استئناف البث بلمسة واحدة."
        ),
        XiaomiGuideItem(
            stepNumber = 4,
            title = "قفل التطبيق في قائمة التطبيقات الحديثة (Lock in Recents)",
            path = "افتح قائمة التطبيقات الأخيرة > اضغط مطولاً على CastDirect TV > اضغط أيقونة القفل 🔒",
            whyNeeded = "يمنع منظف ذاكرة Xiaomi (MIUI RAM Cleaner) من إغلاق خادم البث أثناء المحادثة."
        )
    )

    fun openAppDetailsSettings(context: Context) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {}
    }
}
