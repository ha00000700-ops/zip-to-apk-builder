package com.example.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.io.ByteArrayOutputStream

object StandbyFrameGenerator {

    private var cachedStandbyJpeg: ByteArray? = null

    fun generatePausedFrame(width: Int = 1280, height: Int = 720, reason: String = "تم إيقاف الالتقاط مؤقتاً بواسطة Messenger"): ByteArray {
        val cached = cachedStandbyJpeg
        if (cached != null) return cached

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply {
            color = Color.parseColor("#090E17")
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle tech grid lines
        val linePaint = Paint().apply {
            color = Color.parseColor("#1B283D")
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        for (x in 0 until width step 120) {
            canvas.drawLine(x.toFloat(), 0f, x.toFloat(), height.toFloat(), linePaint)
        }
        for (y in 0 until height step 120) {
            canvas.drawLine(0f, y.toFloat(), width.toFloat(), y.toFloat(), linePaint)
        }

        // Center Warning Card
        val cardRect = RectF(
            width * 0.15f,
            height * 0.25f,
            width * 0.85f,
            height * 0.75f
        )
        val cardPaint = Paint().apply {
            color = Color.parseColor("#111A29")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(cardRect, 24f, 24f, cardPaint)

        val borderPaint = Paint().apply {
            color = Color.parseColor("#FFB300") // Amber
            strokeWidth = 4f
            style = Paint.Style.STROKE
        }
        canvas.drawRoundRect(cardRect, 24f, 24f, borderPaint)

        // Amber Pulsing Status Dot
        val dotPaint = Paint().apply {
            color = Color.parseColor("#FFB300")
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(width * 0.5f, height * 0.38f, 18f, dotPaint)

        // Main Title Text
        val titlePaint = Paint().apply {
            color = Color.parseColor("#F0F4F8")
            textSize = 34f
            textAlign = Paint.Align.CENTER
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("CastDirect TV - البث معلّق مؤقتاً", width * 0.5f, height * 0.48f, titlePaint)

        // Subtitle / Reason Text
        val subPaint = Paint().apply {
            color = Color.parseColor("#FFD54F")
            textSize = 24f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText(reason, width * 0.5f, height * 0.56f, subPaint)

        // Guidance Text
        val guidePaint = Paint().apply {
            color = Color.parseColor("#94A3B8")
            textSize = 20f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        canvas.drawText("الاتصال بالتلفزيون نشط ومستمر - اضغط 'استئناف البث' على الهاتف للعودة فوراً", width * 0.5f, height * 0.64f, guidePaint)

        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        bitmap.recycle()

        val jpeg = stream.toByteArray()
        cachedStandbyJpeg = jpeg
        return jpeg
    }
}
