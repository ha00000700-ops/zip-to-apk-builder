import urllib.request
import urllib.error
import json
import os

API_KEY = "AIzaSyDZjOA5F2tQLMH-ZOBTR_GHRhHVyQkVLd0"
SIGNUP_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={API_KEY}"
SIGNIN_URL = f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={API_KEY}"
EDGE_URL = "https://mgpzpdbvfrbwousswphg.supabase.co/functions/v1/upload-provider-image"

EMAIL = "testedge@khedmati.dz"
PASSWORD = "password123"

print("1. Authenticating with Firebase...")
payload = json.dumps({"email": EMAIL, "password": PASSWORD, "returnSecureToken": True}).encode("utf-8")
req = urllib.request.Request(SIGNUP_URL, data=payload, headers={"Content-Type": "application/json"}, method="POST")

id_token = None
try:
    with urllib.request.urlopen(req) as resp:
        data = json.loads(resp.read().decode())
        id_token = data.get("idToken")
        print("   Signed up new user successfully.")
except urllib.error.HTTPError as e:
    resp_body = e.read().decode()
    if "EMAIL_EXISTS" in resp_body:
        req = urllib.request.Request(SIGNIN_URL, data=payload, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req) as resp2:
                data = json.loads(resp2.read().decode())
                id_token = data.get("idToken")
                print("   Signed in existing user successfully.")
        except Exception as e2:
            print("   Sign in failed:", e2)
    else:
        print("   Sign up failed:", resp_body)

if not id_token:
    print("FAILED TO GET FIREBASE TOKEN")
    exit(1)

print("   Firebase Token obtained.")

print("\n2. Calling Supabase Edge Function...")
boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW"
body = (
    f"--{boundary}\r\n"
    f'Content-Disposition: form-data; name="file"; filename="test.jpg"\r\n'
    f"Content-Type: image/jpeg\r\n\r\n"
).encode('utf-8') + b'\xff\xd8\xff\xe0\x00\x10JFIF' + b'\r\n' + f"--{boundary}--\r\n".encode('utf-8')

headers = {
    "Authorization": f"Bearer {id_token}",
    "Content-Type": f"multipart/form-data; boundary={boundary}",
    "Accept": "application/json"
}

req_upload = urllib.request.Request(EDGE_URL, data=body, headers=headers, method="POST")
try:
    with urllib.request.urlopen(req_upload) as resp:
        print(f"   Upload Status: {resp.status}")
        resp_data = json.loads(resp.read().decode())
        print(f"   Upload Response: {json.dumps(resp_data, indent=2)}")
        
        public_url = resp_data.get("url")
        
        print("\n3. Testing Public URL...")
        print(f"   Fetching: {public_url}")
        req_get = urllib.request.Request(public_url, method="GET")
        try:
            with urllib.request.urlopen(req_get) as resp_get:
                print(f"   GET Status: {resp_get.status}")
                print(f"   Content-Type: {resp_get.headers.get('Content-Type')}")
                print("   SUCCESS! Image is publicly accessible.")
        except urllib.error.HTTPError as e:
            print(f"   GET Failed: {e.code} - {e.read().decode()}")
except urllib.error.HTTPError as e:
    print(f"   Upload Failed: HTTP {e.code}")
    print(f"   Error details: {e.read().decode()}")
