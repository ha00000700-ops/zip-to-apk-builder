    fun sendVoiceMessage(
        conversationId: String,
        audioUrl: String,
        duration: Long,
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        val activeCtx = appContextRef
        if (senderId.isNullOrBlank() || activeCtx == null) {
            onResult(false, "يجب تسجيل الدخول وتوفر السياق لأداء هذا الإجراء")
            return
        }

        viewModelScope.launch {
            val uploadResult = authRepository.uploadChatMedia(activeCtx, audioUrl, "audio", conversationId)
            if (uploadResult is com.example.data.repository.AuthResult.Error) {
                onResult(false, uploadResult.messageAr)
                return@launch
            } else if (uploadResult !is com.example.data.repository.AuthResult.Success) {
                onResult(false, "حدث خطأ أثناء رفع الرسالة الصوتية")
                return@launch
            }
            val uploadedUrl = uploadResult.data

            val result = authRepository.sendVoiceMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                audioUrl = uploadedUrl,
                duration = duration
            )
            when (result) {
                is com.example.data.repository.AuthResult.Success -> onResult(true, null)
                is com.example.data.repository.AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة الصوتية")
            }
        }
    }

    fun sendMediaMessage(
        conversationId: String,
        mediaUrl: String,
        type: String,
        duration: Long = 0L,
        caption: String = "",
        receiverId: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = authRepository.currentUserId
        val activeCtx = appContextRef
        if (senderId.isNullOrBlank() || activeCtx == null) {
            onResult(false, "يجب تسجيل الدخول وتوفر السياق لأداء هذا الإجراء")
            return
        }

        viewModelScope.launch {
            val uploadResult = authRepository.uploadChatMedia(activeCtx, mediaUrl, type, conversationId)
            if (uploadResult is com.example.data.repository.AuthResult.Error) {
                onResult(false, uploadResult.messageAr)
                return@launch
            } else if (uploadResult !is com.example.data.repository.AuthResult.Success) {
                onResult(false, "حدث خطأ أثناء رفع الوسائط")
                return@launch
            }
            val uploadedUrl = uploadResult.data

            val result = authRepository.sendMediaMessage(
                conversationId = conversationId,
                senderId = senderId,
                receiverId = receiverId,
                mediaUrl = uploadedUrl,
                type = type,
                duration = duration,
                caption = caption
            )
            when (result) {
                is com.example.data.repository.AuthResult.Success -> onResult(true, null)
                is com.example.data.repository.AuthResult.Error -> onResult(false, result.messageAr)
                else -> onResult(false, "حدث خطأ غير متوقع عند إرسال الرسالة")
            }
        }
    }
