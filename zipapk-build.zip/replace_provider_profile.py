import re

with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'r') as f:
    content = f.read()

# Add portfolio section
target_services = """                            val customServicesState by authViewModel.customServicesState.collectAsState()
                            if (customServicesState is AuthResult.Success) {"""

replacement_services = """                            // Portfolio / Work Photos
                            if (provider.portfolioImageUrls.isNotEmpty()) {
                                InfoCard(
                                    title = "الأعمال السابقة",
                                    icon = Icons.Default.PhotoLibrary,
                                    content = {
                                        androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                                            columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(3),
                                            modifier = Modifier.height(120.dp).fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            items(provider.portfolioImageUrls.size) { index ->
                                                val url = provider.portfolioImageUrls[index]
                                                Surface(
                                                    modifier = Modifier.aspectRatio(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = BackgroundLight
                                                ) {
                                                    AsyncImage(
                                                        model = url,
                                                        contentDescription = "عمل سابق",
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                            }
                                        }
                                    }
                                )
                            }
                            
                            val customServicesState by authViewModel.customServicesState.collectAsState()
                            if (customServicesState is AuthResult.Success) {"""

content = content.replace(target_services, replacement_services)

# Add Cover Image (Box around Avatar)
target_header = """                        // Premium Header
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Avatar
                            Surface(
                                modifier = Modifier.size(120.dp),"""

replacement_header = """                        // Premium Header
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .padding(bottom = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Cover & Avatar
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                // Cover Photo
                                val coverUrl = provider.portfolioImageUrls.firstOrNull()
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(140.dp)
                                        .align(Alignment.TopCenter),
                                    color = BluePrimary.copy(alpha = 0.2f)
                                ) {
                                    if (!coverUrl.isNullOrBlank()) {
                                        AsyncImage(
                                            model = coverUrl,
                                            contentDescription = "Cover",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize(),
                                            alpha = 0.8f
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier.fillMaxSize().background(
                                                brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                                                    colors = listOf(BluePrimary.copy(alpha = 0.4f), Color.Transparent)
                                                )
                                            )
                                        )
                                    }
                                }

                                // Avatar
                                Surface(
                                    modifier = Modifier.size(120.dp).offset(y = 20.dp),"""

content = content.replace(target_header, replacement_header)

with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'w') as f:
    f.write(content)
