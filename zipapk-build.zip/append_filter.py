with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

filter_dialog = """
    // Filter Bottom Sheet
    if (showFilterDialog) {
        ModalBottomSheet(
            onDismissRequest = { showFilterDialog = false },
            containerColor = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Text(
                    text = "تصفية الحرفيين",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = BlueDark
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "الأقسام",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlueDark
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ProfessionData.categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategoryIndex == cat.id,
                            onClick = { selectedCategoryIndex = if (selectedCategoryIndex == cat.id) null else cat.id },
                            label = { Text(cat.nameAr) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Button(
                    onClick = { showFilterDialog = false },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("تطبيق التصفية")
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}"""

content = content.rsplit("}", 1)[0] + filter_dialog

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
