suspend fun uploadChatMedia(
    context: android.content.Context,
    uriString: String,
    mediaType: String,
    conversationId: String
): com.example.data.repository.AuthResult<String> {
    return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val uri = android.net.Uri.parse(uriString)
            val bytes = if (mediaType == "image") {
                compressImageToByteArray(context, uri)
            } else {
                if (uriString.startsWith("file://") || uriString.startsWith("/")) {
                    val file = java.io.File(uriString.removePrefix("file://"))
                    if (file.exists()) file.readBytes() else null
                } else {
                    context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                }
            }
            
            if (bytes == null) {
                return@withContext com.example.data.repository.AuthResult.Error("تعذر قراءة الملف")
            }

            val token = auth?.currentUser?.getIdToken(true)?.await()?.token
                ?: return@withContext com.example.data.repository.AuthResult.Error("تعذر الحصول على رمز المصادقة")
            
            val supabaseUrl = com.example.data.remote.SupabaseConfig.SUPABASE_URL
            val url = "$supabaseUrl/functions/v1/upload-chat-media"
            
            val mime = when(mediaType) {
                "image" -> "image/jpeg"
                "video" -> "video/mp4"
                "audio" -> "audio/mp4"
                else -> "application/octet-stream"
            }
            
            val ext = when(mediaType) {
                "image" -> "jpg"
                "video" -> "mp4"
                "audio" -> "m4a"
                else -> "bin"
            }

            val requestBody = okhttp3.RequestBody.Companion.toRequestBody(bytes, okhttp3.MediaType.Companion.toMediaTypeOrNull(mime))
            val multipartBody = okhttp3.MultipartBody.Builder()
                .setType(okhttp3.MultipartBody.FORM)
                .addFormDataPart("file", "media.$ext", requestBody)
                .addFormDataPart("mediaType", mediaType)
                .addFormDataPart("conversationId", conversationId)
                .build()

            val request = okhttp3.Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post(multipartBody)
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val responseBodyString = response.body?.string()
                if (!response.isSuccessful) {
                    android.util.Log.e(tag, "Upload failed: ${response.code} - $responseBodyString")
                    return@withContext com.example.data.repository.AuthResult.Error("تعذر رفع الملف: ${response.code}")
                }
                val jsonObject = org.json.JSONObject(responseBodyString ?: "{}")
                if (jsonObject.optBoolean("success")) {
                    val returnedUrl = jsonObject.optString("url")
                    if (returnedUrl.isNotBlank()) {
                        return@withContext com.example.data.repository.AuthResult.Success(returnedUrl)
                    }
                }
                return@withContext com.example.data.repository.AuthResult.Error("فشل في معالجة استجابة الخادم")
            }
        } catch (e: Exception) {
            android.util.Log.e(tag, "Exception during chat media upload", e)
            com.example.data.repository.AuthResult.Error("حدث خطأ أثناء رفع الملف")
        }
    }
}
