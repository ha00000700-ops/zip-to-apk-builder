with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'r') as f:
    content = f.read()

# Remove duplicate is AuthResult.Error block near the end of when
duplicate_block = """                is AuthResult.Error -> {   
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {   
                        Text(text = state.messageAr, color = Color.Red)   
                    }   
                }"""

# Find and clean up the duplicate is AuthResult.Error -> { ... } at the end
import re
content = re.sub(r'is AuthResult\.Error -> \{\s*Box\(modifier = Modifier\.fillMaxSize\(\), contentAlignment = Alignment\.Center\) \{\s*Text\(text = state\.messageAr, color = Color\.Red\)\s*\}\s*\}', '', content)

# But keep the first one by putting it back inside the when block if missing, or let's inspect where it was
