# Ultra-Modern Redesign: Couples Weather (طقس القلوب)

Complete ground-up redesign of the application into an ultra-modern, elegant couples' weather platform featuring immersive automated weather atmospheres, intelligent weather-reactive romantic message popups, interactive virtual heartbeat telemetry, and contextual couple outfit/activity advice.

## User Review & Critical Decisions

> [!IMPORTANT]
> The redesign removes all manual simulator toggles from the primary interface and makes all visual weather phenomena (clouds, rainfall, snow, sun, stars, storm) and romantic phrases **100% automated** based on live telemetry from each city.

- **Visual Style**: Ultra-modern frosted glassmorphic UI with floating layered cards, soft ambient glow, dynamic gradient depth, and fluent Material 3 motions.
- **Atmosphere Automation**: The background canvas dynamically and seamlessly adapts to the live weather conditions without requiring manual user input.
- **Smart Weather Love Popups**: Love messages and Algerian humorous expressions will automatically pop up and adapt to the current atmospheric state (rainy greetings for rain, sunny warmth for clear days, cozy night quotes after sunset).
- **Innovative Couple Telemetry**: Includes an interactive "Heartbeat Touch" (لمسة القلوب), comparative dual-hourly forecast, geographic distance counter, and smart outfit/date recommendations tailored to both cities.

---

## 1. Overview & Core Concept

**طقس القلوب** is an intimate, elegant Android weather experience connecting lovers across two cities (e.g., Algiers and Oran, or anywhere in the world). The redesign modernizes the interface to match high-end 2026 Android application standards: full-bleed edge-to-edge layouts, real-time procedural weather rendering (drifting multi-layered clouds, directional rain with ground ripples, sinusoidal fluttering snow, pulsing golden sun, starry night sky with moon and shooting stars), and automated emotional connection features.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Immersive Home Experience**:
   - App opens into a dynamic, full-bleed animated sky reflecting the actual weather.
   - An automated romantic greeting banner slides down smoothly from the top, presenting a contextual love whisper tailored to the current weather condition (e.g. rain in her city, sun in his).
   - The couple's circular avatars hover with an animated beating pulse ring and temperature difference indicator.
   - Tapping the center heart triggers the **"لمسة القلوب" (Virtual Heartbeat)** animation with glowing particle ripples traveling between the two lovers.
2. **Unified Dual-City Glassmorphic Telemetry**:
   - Redesigned dual-card comparative dashboard with frosted glass blur, temperature curves, apparent feel, wind vector, humidity, and atmospheric mood score.
   - Contextual Couple Advisor: "نصيحة الطقس لك ولحبيبتك" recommending activities (cozy call, outdoor walk, umbrella reminder).
3. **Hourly & 7-Day Synchronized Forecast**:
   - Dual-track hourly timeline showing what both lovers will experience throughout the day.
4. **Automated Love Messages & Algerian Wit**:
   - Intelligent generator categorizing quotes by weather, morning, night, and humorous Algerian Derja sayings.
   - 1-tap WhatsApp/SMS share and custom love note diary.
5. **Special Dates & Milestones**:
   - Clean countdown cards for anniversaries and birthdays with remaining days badge.

### Visual Identity & Theme Tokens

- **Aesthetic**: Modern Glassmorphic / Romantic Luxury.
- **Dominant Colors**:
  - Primary: Rose Quartz & Ruby Glow (`#F43F5E`, `#FB7185`, `#E11D48`)
  - Accent: Warm Sunset Coral & Amber (`#FB923C`, `#F59E0B`)
  - Glass Surface: Semi-transparent frosted white/slate (`rgba(255, 255, 255, 0.82)`)
  - Night Tone: Deep Midnight Sapphire (`#0F172A`, `#1E1B4B`)
- **Typography**: Clean high-contrast typography scaled for Arabic RTL layout with bold temperature numerals.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: 100% Automated Weather Reactions vs Manual Simulator**
  - *Chosen Approach*: The background and quotes will automatically detect the actual weather code (`WMO 0..99`) and time of day (`is_day`) from Open-Meteo. Manual simulator chips are removed from the home screen to give a clean, authentic experience.
  - *Why*: The user specifically requested: *"اجعل تأثيرات الجو تأتي بشكل تلقائي حسب الجو وليس يدوية وايضا اجعل العبارات منبثقة بشكل تلقائي حسب الجو"*.
- **Decision 2: High-Performance Canvas Animation Engine**
  - *Chosen Approach*: Hardware-accelerated Jetpack Compose `Canvas` with continuous time-loop interpolation for clouds, rain ripples, snowflakes, rotating sunrays, and starry night skies.
  - *Why*: Fluid 60fps animations with minimal memory footprint and zero external video assets.
- **Decision 3: Intelligent Contextual Romantic Quotes Engine**
  - *Chosen Approach*: Dynamic quote selection keyed by `WeatherConditionType` (Rain, Sun, Clouds, Night, Cold, Heat) mixed with authentic Algerian colloquial gems and classic Arabic poetry.

---

## 4. Technical Architecture & System Layout

```
┌─────────────────────────────────────────────────────────────┐
│                       MainActivity                          │
│  - Edge-to-Edge Scaffold, WindowInsets, RTL Provider        │
│  - Modern M3 Floating Navigation Bar                        │
└──────────────────────────────┬──────────────────────────────┘
                               │
                ┌──────────────┴──────────────┐
                ▼                             ▼
   ┌───────────────────────────┐ ┌───────────────────────────┐
   │ CoupleWeatherViewModel    │ │ DynamicWeatherBackground  │
   │ - Live Weather Flow       │ │ - Automated Canvas Engine │
   │ - Weather-Reactive Quotes │ │   (Clouds, Rain, Snow,    │
   │ - Heartbeat Animation     │ │    Sun, Stars, Mist)      │
   │ - Couple Preferences      │ └───────────────────────────┘
   └────────────┬──────────────┘
                │
                ├───────────────────────────────────────────┐
                ▼                                           ▼
┌───────────────────────────────┐           ┌───────────────────────────────┐
│ ModernHomeScreen              │           │ ModernLoveMessagesScreen      │
│ - Automated Weather Popups    │           │ - Categorized Quotes Vault    │
│ - Virtual Heartbeat Ripple    │           │ - Weather-Reactive Messages   │
│ - Dual Glassmorphic Cards     │           │ - Custom Notes Keeper         │
│ - Contextual Couple Advice    │           └───────────────────────────────┘
│ - Comparative Hourly Track    │
└───────────────────────────────┘
```

### Proposed Changes Across Modules

1. **`app/src/main/java/com/example/ui/components/DynamicWeatherBackground.kt`**:
   - Refactor canvas to render realistic layered clouds, falling rain with ground splash ripples, fluttering snowflakes, radiant sunrays, and twinkling stars automatically triggered by live weather condition.
2. **`app/src/main/java/com/example/ui/components/ModernWeatherPopup.kt`**:
   - Create an automated floating banner / popup card that detects weather changes and displays animated romantic quotes for the couple.
3. **`app/src/main/java/com/example/ui/components/CoupleHeader.kt`**:
   - Redesign with circular glowing avatars, interactive "لمسة القلوب" tap trigger that sends animated heartwaves between them, and geographic distance banner.
4. **`app/src/main/java/com/example/ui/components/WeatherCard.kt`**:
   - Redesign into a modern sleek glassmorphic comparison view with atmospheric comfort index, outfit advice, and synchronized metrics.
5. **`app/src/main/java/com/example/ui/screens/HomeScreen.kt`**:
   - Complete redesign integrating the automated background, popup whisper, couple heartbeat, and advice card.
6. **`app/src/main/java/com/example/data/model/LoveMessages.kt`**:
   - Expand weather-specific quotes catalog (rainy, cold, sunny, cloudy, stormy, night) in sweet Algerian Derja and modern romantic Arabic.

---

## Verification Plan

### Automated Build & Unit Tests
- Execute `compile_applet` to ensure pristine compilation.
- Run `gradle :app:testDebugUnitTest` to verify all Robolectric tests, string resources, and calculation models pass without regressions.

### Visual & Interactive Review
- Verify automatic switching of background visuals and popups across weather conditions.
- Test circular avatars, heartbeat touch animation, and city weather comparison.
