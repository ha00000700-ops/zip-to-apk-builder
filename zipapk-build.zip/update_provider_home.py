import re

with open('app/src/main/java/com/example/ui/screens/home/ProviderHomeScreen.kt', 'r') as f:
    content = f.read()

target_statcard_def = """@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {"""

replacement_statcard_def = """@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Surface(
        modifier = modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
    ) {"""

content = content.replace(target_statcard_def, replacement_statcard_def)

target_stats_section = """                    // Stats Section
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            StatCard(
                                title = "الطلبات",
                                value = "12",
                                icon = Icons.Default.WorkHistory,
                                color = BluePrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "التقييم",
                                value = "4.9",
                                icon = Icons.Default.Star,
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "الخبرة",
                                value = "${providerProfile?.experienceYears ?: 0}+",
                                icon = Icons.Default.CheckCircle,
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }"""

replacement_stats_section = """                    // Stats Section
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            StatCard(
                                title = "الطلبات",
                                value = "الطلبات", // Just a label or keep value if known
                                icon = Icons.Default.WorkHistory,
                                color = BluePrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { currentTab = 1 }
                            )
                            StatCard(
                                title = "التقييم",
                                value = "تقييمات",
                                icon = Icons.Default.Star,
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                            StatCard(
                                title = "الخبرة",
                                value = "${providerProfile?.experienceYears ?: 0}+",
                                icon = Icons.Default.CheckCircle,
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                        }
                    }"""

content = content.replace(target_stats_section, replacement_stats_section)

with open('app/src/main/java/com/example/ui/screens/home/ProviderHomeScreen.kt', 'w') as f:
    f.write(content)
