import urllib.request
import urllib.error
import json
import uuid

def test():
    print("To test the Edge Function after deployment:")
    print("1. Get a valid Firebase ID token (e.g., from Android logcat or Firebase Auth REST API)")
    print("2. Run a cURL command similar to this:")
    print("")
    print('curl -X POST https://<your-supabase-project>.supabase.co/functions/v1/upload-chat-media \\')
    print('  -H "Authorization: Bearer YOUR_FIREBASE_TOKEN" \\')
    print('  -F "file=@/path/to/test.jpg" \\')
    print('  -F "mediaType=image" \\')
    print('  -F "conversationId=conv_12345"')
    print("")
    print("Expected response (HTTP 200):")
    print('{ "success": true, "url": "https://...", "path": "chat_media/...", "mediaType": "image" }')

if __name__ == "__main__":
    test()
