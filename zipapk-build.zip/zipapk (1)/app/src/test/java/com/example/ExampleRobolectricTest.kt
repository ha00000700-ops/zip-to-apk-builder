package com.example

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ProjectType
import com.example.data.zip.ZipInspector
import com.example.viewmodel.InspectionUiState
import com.example.viewmodel.MainViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    private fun createSampleAndroidZip(file: File, appName: String = "TestAndroidApp", packageName: String = "com.example.testapp"): File {
        ZipOutputStream(FileOutputStream(file)).use { zos ->
            // settings.gradle.kts
            zos.putNextEntry(ZipEntry("settings.gradle.kts"))
            zos.write("rootProject.name = \"$appName\"\ninclude(\":app\")\n".toByteArray())
            zos.closeEntry()

            // build.gradle.kts
            zos.putNextEntry(ZipEntry("build.gradle.kts"))
            zos.write("// Root build gradle\n".toByteArray())
            zos.closeEntry()

            // app/build.gradle.kts
            zos.putNextEntry(ZipEntry("app/build.gradle.kts"))
            val appGradle = """
                plugins {
                    id("com.android.application")
                }
                android {
                    namespace = "$packageName"
                    defaultConfig {
                        applicationId = "$packageName"
                        versionCode = 2
                        versionName = "2.1.0"
                    }
                }
            """.trimIndent()
            zos.write(appGradle.toByteArray())
            zos.closeEntry()

            // app/src/main/AndroidManifest.xml
            zos.putNextEntry(ZipEntry("app/src/main/AndroidManifest.xml"))
            val manifest = """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android"
                    package="$packageName">
                    <application
                        android:label="$appName"
                        android:theme="@android:style/Theme.Material">
                        <activity android:name=".MainActivity" android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent()
            zos.write(manifest.toByteArray())
            zos.closeEntry()

            // app/src/main/java/com/example/testapp/MainActivity.kt
            zos.putNextEntry(ZipEntry("app/src/main/java/com/example/testapp/MainActivity.kt"))
            zos.write("package $packageName\nclass MainActivity\n".toByteArray())
            zos.closeEntry()
        }
        return file
    }

    @Test
    fun testAppLabelStringResource() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ZIPAPK", appName)
    }

    @Test
    fun testZipInspectorDetectsAndroidProjectDirectly() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val tempZip = File(context.cacheDir, "test_android_sample.zip")
            createSampleAndroidZip(tempZip, "MySampleProject", "com.sample.demoapp")

            val inspector = ZipInspector(context)
            val result = inspector.inspectZipUri(Uri.fromFile(tempZip))

            // 1. Verify project was recognized as Android
            assertTrue("Project should be valid", result.isValid)
            assertEquals("ProjectType must be ANDROID", ProjectType.ANDROID, result.projectType)
            assertEquals("Project name extracted correctly", "MySampleProject", result.detectedProjectName)
            assertEquals("Package name extracted correctly", "com.sample.demoapp", result.detectedPackageName)
            assertEquals("Version code extracted correctly", 2, result.detectedVersionCode)
            assertEquals("Version name extracted correctly", "2.1.0", result.detectedVersionName)
            assertTrue("Has Gradle detected", result.hasGradle)
            assertTrue("Has Manifest detected", result.hasManifest)
            assertTrue("Has Src detected", result.hasSrcDir)

            tempZip.delete()
        }
    }

    @Test
    fun testHappyPath_SelectZip_Inspect_NavigateToConfig() {
        val activity = composeTestRule.activity
        val tempZip = File(activity.cacheDir, "sample_cuj_project.zip")
        createSampleAndroidZip(tempZip, "WeatherPro", "com.weather.pro")

        val viewModel = activity.viewModel

        // 1. Select ZIP & Inspect
        composeTestRule.runOnUiThread {
            viewModel.onFileSelected(Uri.fromFile(tempZip), "sample_cuj_project.zip")
            viewModel.inspectSelectedFile()
        }

        var attempts = 0
        while (viewModel.inspectionState.value !is InspectionUiState.Success && attempts < 50) {
            Thread.sleep(50)
            org.robolectric.shadows.ShadowLooper.idleMainLooper()
            attempts++
        }

        val inspectionState = viewModel.inspectionState.value
        assertTrue("Inspection must be Success", inspectionState is InspectionUiState.Success)
        val successState = inspectionState as InspectionUiState.Success
        assertEquals(ProjectType.ANDROID, successState.result.projectType)
        assertEquals("WeatherPro", successState.result.detectedProjectName)
        assertEquals("com.weather.pro", successState.result.detectedPackageName)

        // Verify ApkBuildConfig was auto-populated
        assertEquals("WeatherPro", viewModel.apkConfig.value.appName)
        assertEquals("com.weather.pro", viewModel.apkConfig.value.packageName)
        assertEquals("2.1.0", viewModel.apkConfig.value.versionName)
        assertEquals(2, viewModel.apkConfig.value.versionCode)

        composeTestRule.waitForIdle()

        // 2. Verify Android Project Card is displayed on Home Screen
        composeTestRule.onNodeWithTag("android_project_card").assertExists()
        composeTestRule.onNodeWithText("مشروع Android صالح").assertExists()
        composeTestRule.onNodeWithText("WeatherPro").assertExists()

        // 3. Click "إعداد وإنشاء APK" button
        composeTestRule.onNodeWithTag("create_apk_button").performScrollTo().assertIsDisplayed().performClick()
        composeTestRule.waitForIdle()

        // 4. Verify APK Config Screen is displayed
        composeTestRule.onNodeWithTag("config_header_card").assertExists()
        composeTestRule.onNodeWithText("إعدادات حزمة APK").assertExists()
        composeTestRule.onNodeWithTag("app_name_input").assertExists()
        composeTestRule.onNodeWithTag("package_name_input").assertExists()
        composeTestRule.onNodeWithTag("version_name_input").assertExists()
        composeTestRule.onNodeWithTag("version_code_input").assertExists()

        tempZip.delete()
    }
}


