package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "build_history")
data class BuildHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val jobId: String,
    val projectName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Int,
    val fileSizeFormatted: String,
    val status: String, // queued, running, success, failed, cancelled
    val stage: String?,
    val message: String?,
    val downloadUrl: String?,
    val apkAvailable: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Long = 0
)
