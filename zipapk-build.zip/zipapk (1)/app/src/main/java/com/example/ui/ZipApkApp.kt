package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AppBottomNavigationBar
import com.example.ui.components.AppTopBar
import com.example.ui.components.NavigationTab
import com.example.ui.screens.BuildProgressScreen
import com.example.ui.screens.BuildResultScreen
import com.example.ui.screens.ConfigScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.ZipApkTheme
import com.example.viewmodel.BuildUiState
import com.example.viewmodel.InspectionUiState
import com.example.viewmodel.MainViewModel

enum class HomeSubScreen {
    MAIN_PICKER,
    CONFIG,
    BUILD_PROGRESS,
    BUILD_RESULT
}

@Composable
fun ZipApkApp(viewModel: MainViewModel) {
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val serverUrl by viewModel.serverUrl.collectAsStateWithLifecycle()
    val historyList by viewModel.historyList.collectAsStateWithLifecycle()

    val selectedUri by viewModel.selectedUri.collectAsStateWithLifecycle()
    val selectedFileName by viewModel.selectedFileName.collectAsStateWithLifecycle()
    val inspectionState by viewModel.inspectionState.collectAsStateWithLifecycle()
    val apkConfig by viewModel.apkConfig.collectAsStateWithLifecycle()
    val buildState by viewModel.buildState.collectAsStateWithLifecycle()

    val isTestingServer by viewModel.isTestingServer.collectAsStateWithLifecycle()
    val serverTestMessage by viewModel.serverTestMessage.collectAsStateWithLifecycle()

    var currentTab by remember { mutableStateOf(NavigationTab.HOME) }
    var homeSubScreen by remember { mutableStateOf(HomeSubScreen.MAIN_PICKER) }

    val snackbarHostState = remember { SnackbarHostState() }

    // Listen for UI events
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // React to build state changes
    LaunchedEffect(buildState) {
        when (buildState) {
            is BuildUiState.InProgress -> {
                currentTab = NavigationTab.HOME
                homeSubScreen = HomeSubScreen.BUILD_PROGRESS
            }
            is BuildUiState.Success, is BuildUiState.Failed, is BuildUiState.Cancelled -> {
                if (homeSubScreen == HomeSubScreen.BUILD_PROGRESS) {
                    homeSubScreen = HomeSubScreen.BUILD_RESULT
                }
            }
            BuildUiState.Idle -> {
                // Keep current sub screen unless explicitly reset
            }
        }
    }

    val layoutDirection = if (language == "ar") LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        ZipApkTheme(themeMode = themeMode) {
            val topBarTitle = when (currentTab) {
                NavigationTab.HOME -> when (homeSubScreen) {
                    HomeSubScreen.MAIN_PICKER -> "ZIPAPK"
                    HomeSubScreen.CONFIG -> "إعداد APK"
                    HomeSubScreen.BUILD_PROGRESS -> "متابعة البناء"
                    HomeSubScreen.BUILD_RESULT -> "نتيجة البناء"
                }
                NavigationTab.HISTORY -> "سجل العمليات"
                NavigationTab.SETTINGS -> "الإعدادات"
            }

            val canNavigateBack = currentTab == NavigationTab.HOME && homeSubScreen != HomeSubScreen.MAIN_PICKER

            Scaffold(
                topBar = {
                    AppTopBar(
                        title = topBarTitle,
                        canNavigateBack = canNavigateBack,
                        onNavigateBack = {
                            when (homeSubScreen) {
                                HomeSubScreen.CONFIG -> homeSubScreen = HomeSubScreen.MAIN_PICKER
                                HomeSubScreen.BUILD_PROGRESS -> {
                                    // Minimize to picker without cancelling
                                    homeSubScreen = HomeSubScreen.MAIN_PICKER
                                }
                                HomeSubScreen.BUILD_RESULT -> {
                                    homeSubScreen = HomeSubScreen.MAIN_PICKER
                                    viewModel.resetBuildState()
                                }
                                HomeSubScreen.MAIN_PICKER -> {}
                            }
                        },
                        serverConnected = serverUrl.isNotBlank(),
                        onServerPillClick = {
                            currentTab = NavigationTab.SETTINGS
                        }
                    )
                },
                bottomBar = {
                    AppBottomNavigationBar(
                        currentTab = currentTab,
                        onTabSelected = { tab ->
                            currentTab = tab
                        }
                    )
                },
                snackbarHost = { SnackbarHost(snackbarHostState) }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = Pair(currentTab, homeSubScreen),
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tab_navigation"
                    ) { (tab, subScreen) ->
                        when (tab) {
                            NavigationTab.HOME -> {
                                when (subScreen) {
                                    HomeSubScreen.MAIN_PICKER -> {
                                        HomeScreen(
                                            selectedUri = selectedUri,
                                            selectedFileName = selectedFileName,
                                            inspectionState = inspectionState,
                                            serverUrl = serverUrl,
                                            onFileSelected = { uri ->
                                                viewModel.onFileSelected(uri)
                                            },
                                            onInspectClicked = {
                                                viewModel.inspectSelectedFile()
                                            },
                                            onResetInspection = {
                                                viewModel.resetInspection()
                                            },
                                            onNavigateToConfig = {
                                                homeSubScreen = HomeSubScreen.CONFIG
                                            },
                                            onNavigateToSettings = {
                                                currentTab = NavigationTab.SETTINGS
                                            }
                                        )
                                    }

                                    HomeSubScreen.CONFIG -> {
                                        val successResult = (inspectionState as? InspectionUiState.Success)?.result
                                        ConfigScreen(
                                            inspectionResult = successResult,
                                            initialConfig = apkConfig,
                                            serverUrl = serverUrl,
                                            onSaveAndStartBuild = { updatedConfig ->
                                                viewModel.updateApkConfig(
                                                    appName = updatedConfig.appName,
                                                    packageName = updatedConfig.packageName,
                                                    versionName = updatedConfig.versionName,
                                                    versionCode = updatedConfig.versionCode,
                                                    isFullscreen = updatedConfig.isFullscreen,
                                                    enableInternet = updatedConfig.enableInternet
                                                )
                                                viewModel.startBuild {
                                                    homeSubScreen = HomeSubScreen.BUILD_PROGRESS
                                                }
                                            },
                                            onNavigateToSettings = {
                                                currentTab = NavigationTab.SETTINGS
                                            }
                                        )
                                    }

                                    HomeSubScreen.BUILD_PROGRESS -> {
                                        BuildProgressScreen(
                                            buildState = buildState,
                                            config = apkConfig,
                                            onCancelBuild = {
                                                viewModel.cancelCurrentBuild()
                                                homeSubScreen = HomeSubScreen.BUILD_RESULT
                                            },
                                            onNavigateBack = {
                                                homeSubScreen = HomeSubScreen.MAIN_PICKER
                                            }
                                        )
                                    }

                                    HomeSubScreen.BUILD_RESULT -> {
                                        BuildResultScreen(
                                            buildState = buildState,
                                            config = apkConfig,
                                            onStartNewBuild = {
                                                viewModel.resetBuildState()
                                                viewModel.resetInspection()
                                                homeSubScreen = HomeSubScreen.MAIN_PICKER
                                            },
                                            onRetry = {
                                                viewModel.startBuild {
                                                    homeSubScreen = HomeSubScreen.BUILD_PROGRESS
                                                }
                                            }
                                        )
                                    }
                                }
                            }

                            NavigationTab.HISTORY -> {
                                HistoryScreen(
                                    historyList = historyList,
                                    onDeleteItem = { id ->
                                        viewModel.deleteHistoryItem(id)
                                    },
                                    onClearAll = {
                                        viewModel.clearAllHistory()
                                    }
                                )
                            }

                            NavigationTab.SETTINGS -> {
                                SettingsScreen(
                                    serverUrl = serverUrl,
                                    themeMode = themeMode,
                                    language = language,
                                    isTestingServer = isTestingServer,
                                    serverTestMessage = serverTestMessage,
                                    onSaveServerUrl = { url ->
                                        viewModel.setServerUrl(url)
                                    },
                                    onTestServer = { url ->
                                        viewModel.testServerConnection(url)
                                    },
                                    onSetThemeMode = { mode ->
                                        viewModel.setThemeMode(mode)
                                    },
                                    onSetLanguage = { lang ->
                                        viewModel.setLanguage(lang)
                                    },
                                    onClearAllHistory = {
                                        viewModel.clearAllHistory()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
