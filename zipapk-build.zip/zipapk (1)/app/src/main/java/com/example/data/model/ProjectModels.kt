package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class ProjectType {
    ANDROID,
    WEB_PWA,
    INVALID
}

data class ProjectInspectionResult(
    val projectType: ProjectType,
    val isValid: Boolean,
    val fileName: String,
    val fileSizeBytes: Long,
    val fileSizeFormatted: String,
    val detectedProjectName: String?,
    val detectedPackageName: String?,
    val detectedVersionName: String?,
    val detectedVersionCode: Int?,
    val detectedIconBytes: ByteArray? = null,
    val discoveredFiles: List<String> = emptyList(),
    val totalFilesCount: Int = 0,
    val hasGradle: Boolean = false,
    val hasManifest: Boolean = false,
    val hasSrcDir: Boolean = false,
    val detectedModules: List<String> = emptyList(),
    val rejectionReason: String? = null,
    val tempZipPath: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as ProjectInspectionResult

        if (projectType != other.projectType) return false
        if (isValid != other.isValid) return false
        if (fileName != other.fileName) return false
        if (fileSizeBytes != other.fileSizeBytes) return false
        if (detectedProjectName != other.detectedProjectName) return false
        if (detectedPackageName != other.detectedPackageName) return false
        if (detectedIconBytes != null) {
            if (other.detectedIconBytes == null) return false
            if (!detectedIconBytes.contentEquals(other.detectedIconBytes)) return false
        } else if (other.detectedIconBytes != null) return false

        return true
    }

    override fun hashCode(): Int {
        var result = projectType.hashCode()
        result = 31 * result + isValid.hashCode()
        result = 31 * result + fileName.hashCode()
        result = 31 * result + fileSizeBytes.hashCode()
        result = 31 * result + (detectedIconBytes?.contentHashCode() ?: 0)
        return result
    }
}

@JsonClass(generateAdapter = true)
data class ApkBuildConfig(
    @Json(name = "appName") val appName: String,
    @Json(name = "packageName") val packageName: String,
    @Json(name = "versionName") val versionName: String = "1.0.0",
    @Json(name = "versionCode") val versionCode: Int = 1,
    @Json(name = "isFullscreen") val isFullscreen: Boolean = false,
    @Json(name = "enableInternet") val enableInternet: Boolean = true
)

@JsonClass(generateAdapter = true)
data class BuildJobResponse(
    @Json(name = "jobId") val jobId: String,
    @Json(name = "status") val status: String
)

@JsonClass(generateAdapter = true)
data class BuildStatusResponse(
    @Json(name = "jobId") val jobId: String,
    @Json(name = "status") val status: String, // queued | running | success | failed | cancelled
    @Json(name = "progress") val progress: Int = 0,
    @Json(name = "stage") val stage: String? = null,
    @Json(name = "message") val message: String? = null,
    @Json(name = "apkAvailable") val apkAvailable: Boolean = false,
    @Json(name = "downloadUrl") val downloadUrl: String? = null,
    @Json(name = "logs") val logs: String? = null
)
