package com.example.data.repository

import com.example.data.local.BuildHistoryDao
import com.example.data.local.BuildHistoryEntity
import com.example.data.model.ApkBuildConfig
import com.example.data.model.BuildStatusResponse
import com.example.data.network.BuildApiClient
import com.example.data.preferences.AppSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

class BuildRepository(
    private val buildApiClient: BuildApiClient,
    private val buildHistoryDao: BuildHistoryDao,
    private val appSettingsRepository: AppSettingsRepository
) {

    val historyFlow: Flow<List<BuildHistoryEntity>> =
        buildHistoryDao.getAllHistory()

    fun startBuildProcess(
        zipFile: File,
        config: ApkBuildConfig,
        fileSizeFormatted: String
    ): Flow<BuildStatusResponse> = flow {

        val serverUrl = appSettingsRepository.serverUrlFlow.first()

        if (serverUrl.isBlank()) {
            throw IllegalStateException(
                "خدمة إنشاء APK غير متصلة حاليًا. يرجى ضبط عنوان Build Server في الإعدادات."
            )
        }

        /*
         * المرحلة 1
         */
        emit(
            BuildStatusResponse(
                jobId = "",
                status = "queued",
                progress = 5,
                stage = "في انتظار البناء",
                message = "جاري تجهيز طلب بناء APK...",
                apkAvailable = false,
                downloadUrl = null
            )
        )

        /*
         * المرحلة 2
         */
        emit(
            BuildStatusResponse(
                jobId = "",
                status = "uploading",
                progress = 15,
                stage = "رفع المشروع",
                message = "جارٍ رفع ملف المشروع إلى خادم البناء...",
                apkAvailable = false,
                downloadUrl = null
            )
        )

        /*
         * إرسال الطلب مرة واحدة فقط
         */
        val submitResult =
            buildApiClient.submitBuildJob(
                serverUrl,
                zipFile,
                config
            )

        if (submitResult.isFailure) {

            val error = submitResult.exceptionOrNull()

            val failureMessage =
                error?.localizedMessage
                    ?: "فشل إرسال المشروع إلى خادم البناء."

            buildHistoryDao.insert(
                BuildHistoryEntity(
                    jobId = "failed_${System.currentTimeMillis()}",
                    projectName = config.appName,
                    packageName = config.packageName,
                    versionName = config.versionName,
                    versionCode = config.versionCode,
                    fileSizeFormatted = fileSizeFormatted,
                    status = "failed",
                    stage = "رفع المشروع",
                    message = failureMessage,
                    downloadUrl = null,
                    apkAvailable = false,
                    timestamp = System.currentTimeMillis()
                )
            )

            emit(
                BuildStatusResponse(
                    jobId = "",
                    status = "failed",
                    progress = 0,
                    stage = "رفع المشروع",
                    message = failureMessage,
                    apkAvailable = false,
                    downloadUrl = null,
                    logs = error?.stackTraceToString()
                )
            )

            return@flow
        }

        val job = submitResult.getOrThrow()
        val jobId = job.jobId

        /*
         * تسجيل المهمة في قاعدة البيانات
         */
        val historyId = buildHistoryDao.insert(
            BuildHistoryEntity(
                jobId = jobId,
                projectName = config.appName,
                packageName = config.packageName,
                versionName = config.versionName,
                versionCode = config.versionCode,
                fileSizeFormatted = fileSizeFormatted,
                status = "queued",
                stage = "في انتظار البناء",
                message = "تم إرسال المشروع بنجاح.",
                downloadUrl = null,
                apkAvailable = false,
                timestamp = System.currentTimeMillis()
            )
        )

        /*
         * المرحلة 1 مؤكدة
         */
        emit(
            BuildStatusResponse(
                jobId = jobId,
                status = "queued",
                progress = 10,
                stage = "في انتظار البناء",
                message = "تم استلام المشروع، في انتظار بدء عملية البناء...",
                apkAvailable = false,
                downloadUrl = null
            )
        )

        val startTime = System.currentTimeMillis()

        var consecutiveErrors = 0

        /*
         * متابعة نفس jobId فقط
         */
        while (true) {

            delay(3000)

            val statusResult =
                buildApiClient.getBuildStatus(
                    serverUrl,
                    jobId
                )

            if (statusResult.isFailure) {

                consecutiveErrors++

                if (consecutiveErrors >= 8) {

                    val message =
                        "تعذر الاتصال بخادم البناء بعد عدة محاولات."

                    emit(
                        BuildStatusResponse(
                            jobId = jobId,
                            status = "failed",
                            progress = 0,
                            stage = "رفع المشروع",
                            message = message,
                            apkAvailable = false,
                            downloadUrl = null
                        )
                    )

                    break
                }

                continue
            }

            consecutiveErrors = 0

            val serverStatus =
                statusResult.getOrThrow()

            /*
             * تحويل حالة السيرفر إلى المراحل الستة
             */
            val normalizedStatus =
                serverStatus.status.lowercase()

            val serverStage =
                serverStatus.stage ?: ""

            val stageInfo =
                when {

                    normalizedStatus == "queued" ||
                    serverStage.contains("انتظار") -> {

                        StageInfo(
                            stage = 1,
                            name = "في انتظار البناء",
                            progress = 10
                        )
                    }

                    serverStage.contains("رفع") ||
                    serverStage.contains("upload", true) -> {

                        StageInfo(
                            stage = 2,
                            name = "رفع المشروع",
                            progress = 25
                        )
                    }

                    serverStage.contains("تحضير") ||
                    serverStage.contains("android", true) ||
                    serverStage.contains("wrapper", true) -> {

                        StageInfo(
                            stage = 3,
                            name = "تحضير Android",
                            progress = 40
                        )
                    }

                    serverStage.contains("Gradle", true) -> {

                        StageInfo(
                            stage = 4,
                            name = "تشغيل Gradle",
                            progress = 60
                        )
                    }

                    serverStage.contains("APK", true) ||
                    serverStage.contains("بناء") -> {

                        StageInfo(
                            stage = 5,
                            name = "بناء APK",
                            progress = 85
                        )
                    }

                    normalizedStatus == "completed" ||
                    normalizedStatus == "success" -> {

                        StageInfo(
                            stage = 6,
                            name = "اكتمل",
                            progress = 100
                        )
                    }

                    normalizedStatus == "failed" -> {

                        StageInfo(
                            stage = 5,
                            name = "بناء APK",
                            progress = 0
                        )
                    }

                    normalizedStatus == "cancelled" -> {

                        StageInfo(
                            stage = 6,
                            name = "ملغي",
                            progress = 0
                        )
                    }

                    else -> {

                        StageInfo(
                            stage = 3,
                            name = "تحضير Android",
                            progress = 40
                        )
                    }
                }

            /*
             * السيرفر قد يرجع artifactUrl
             * أو downloadUrl
             */
            val downloadUrl =
                serverStatus.downloadUrl

            val finalStatus =
                when {
                    normalizedStatus == "completed" ->
                        "success"

                    normalizedStatus == "success" ->
                        "success"

                    normalizedStatus == "failed" ->
                        "failed"

                    normalizedStatus == "cancelled" ->
                        "cancelled"

                    else ->
                        "running"
                }

            val finalProgress =
                if (finalStatus == "success") {
                    100
                } else {
                    stageInfo.progress
                }

            val finalStage =
                if (finalStatus == "success") {
                    "اكتمل"
                } else {
                    stageInfo.name
                }

            val finalMessage =
                if (finalStatus == "success") {
                    "تم بناء APK بنجاح. أصبح الملف جاهزًا."
                } else {
                    serverStatus.message
                        ?: "جاري تنفيذ عملية البناء..."
                }

            val status =
                BuildStatusResponse(
                    jobId = jobId,
                    status = finalStatus,
                    progress = finalProgress,
                    stage = finalStage,
                    message = finalMessage,
                    apkAvailable =
                        finalStatus == "success" &&
                        !downloadUrl.isNullOrBlank(),
                    downloadUrl = downloadUrl,
                    logs = serverStatus.logs
                )

            emit(status)

            /*
             * تحديث السجل
             */
            val elapsedSeconds =
                (System.currentTimeMillis() - startTime) / 1000

            buildHistoryDao.update(
                BuildHistoryEntity(
                    id = historyId,
                    jobId = jobId,
                    projectName = config.appName,
                    packageName = config.packageName,
                    versionName = config.versionName,
                    versionCode = config.versionCode,
                    fileSizeFormatted = fileSizeFormatted,
                    status = finalStatus,
                    stage = finalStage,
                    message = finalMessage,
                    downloadUrl = downloadUrl,
                    apkAvailable =
                        status.apkAvailable,
                    timestamp = startTime,
                    durationSeconds = elapsedSeconds
                )
            )

            /*
             * انتهاء العملية
             */
            if (
                finalStatus == "success" ||
                finalStatus == "failed" ||
                finalStatus == "cancelled"
            ) {
                break
            }
        }

    }.flowOn(Dispatchers.IO)

    suspend fun cancelBuild(
        jobId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {

        val serverUrl =
            appSettingsRepository.serverUrlFlow.first()

        if (
            serverUrl.isBlank() ||
            jobId.isBlank()
        ) {
            return@withContext Result.failure(
                IllegalArgumentException(
                    "معرف البناء أو عنوان الخادم غير صالح."
                )
            )
        }

        val result =
            buildApiClient.cancelBuildJob(
                serverUrl,
                jobId
            )

        val record =
            buildHistoryDao.getByJobId(jobId)

        if (record != null) {

            buildHistoryDao.update(
                record.copy(
                    status = "cancelled",
                    stage = "ملغي",
                    message =
                        "تم إلغاء عملية البناء بواسطة المستخدم"
                )
            )
        }

        result
    }

    suspend fun deleteHistoryItem(
        id: Long
    ) = withContext(Dispatchers.IO) {

        buildHistoryDao.deleteById(id)
    }

    suspend fun clearAllHistory() =
        withContext(Dispatchers.IO) {

            buildHistoryDao.clearAll()
        }

    private data class StageInfo(
        val stage: Int,
        val name: String,
        val progress: Int
    )
}
