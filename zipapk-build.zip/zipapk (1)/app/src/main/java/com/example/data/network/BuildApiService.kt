package com.example.data.network

import com.example.data.model.BuildJobResponse
import com.example.data.model.BuildStatusResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path

interface BuildApiService {

    @Multipart
    @POST("api/build")
    suspend fun startBuild(
        @Part zip: MultipartBody.Part,
        @Part("config") config: RequestBody
    ): Response<BuildJobResponse>

    @GET("api/build/{jobId}")
    suspend fun getBuildStatus(
        @Path("jobId") jobId: String
    ): Response<BuildStatusResponse>

    @DELETE("api/build/{jobId}")
    suspend fun cancelBuild(
        @Path("jobId") jobId: String
    ): Response<Unit>

    @GET("api/health")
    suspend fun checkHealth(): Response<Map<String, Any>>
}
