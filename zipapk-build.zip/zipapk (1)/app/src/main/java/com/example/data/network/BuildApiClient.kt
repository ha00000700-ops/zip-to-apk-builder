package com.example.data.network

import com.example.data.model.ApkBuildConfig
import com.example.data.model.BuildJobResponse
import com.example.data.model.BuildStatusResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class BuildApiClient {

    private val moshi: Moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS) // Generous write timeout for ZIP file uploads
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private var currentBaseUrl: String? = null
    private var cachedService: BuildApiService? = null

    private fun getService(baseUrl: String): BuildApiService {
        val sanitizedUrl = formatUrl(baseUrl)
        if (cachedService != null && currentBaseUrl == sanitizedUrl) {
            return cachedService!!
        }

        val retrofit = Retrofit.Builder()
            .baseUrl(sanitizedUrl)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

        val service = retrofit.create(BuildApiService::class.java)
        cachedService = service
        currentBaseUrl = sanitizedUrl
        return service
    }

    private fun formatUrl(url: String): String {
        var clean = url.trim()
        if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
            clean = "http://$clean"
        }
        if (!clean.endsWith("/")) {
            clean = "$clean/"
        }
        return clean
    }

    suspend fun testConnection(baseUrl: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("عنوان الخادم غير محدد."))
        }
        try {
            val service = getService(baseUrl)
            val response = service.checkHealth()
            if (response.isSuccessful) {
                Result.success(true)
            } else {
                // If health is 404 but server responds, server is at least reachable
                Result.success(true)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitBuildJob(
        baseUrl: String,
        zipFile: File,
        config: ApkBuildConfig
    ): Result<BuildJobResponse> = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(IllegalStateException("عنوان Build Server غير مضبوط. يرجى ضبطه من الإعدادات."))
        }
        if (!zipFile.exists() || zipFile.length() == 0L) {
            return@withContext Result.failure(IllegalArgumentException("ملف ZIP غير موجود أو فارغ."))
        }

        try {
            val service = getService(baseUrl)

            // Prepare multipart file
            val requestFile = zipFile.asRequestBody("application/zip".toMediaTypeOrNull())
            val zipPart = MultipartBody.Part.createFormData("zip", zipFile.name, requestFile)

            // Prepare config JSON
            val configAdapter = moshi.adapter(ApkBuildConfig::class.java)
            val configJson = configAdapter.toJson(config)
            val configBody = configJson.toRequestBody("application/json".toMediaTypeOrNull())

            val response = service.startBuild(zipPart, configBody)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                Result.failure(
                    Exception(
                        "فشل إرسال طلب البناء إلى الخادم (رمز الخطأ: ${response.code()})${
                            if (errorBody.isNotBlank()) ": $errorBody" else ""
                        }"
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getBuildStatus(
        baseUrl: String,
        jobId: String
    ): Result<BuildStatusResponse> = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(IllegalStateException("عنوان الخادم غير مضبوط."))
        }
        try {
            val service = getService(baseUrl)
            val response = service.getBuildStatus(jobId)
            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                val errorBody = response.errorBody()?.string() ?: ""
                Result.failure(
                    Exception(
                        "تعذر جلب حالة البناء (رمز الخطأ: ${response.code()})${
                            if (errorBody.isNotBlank()) ": $errorBody" else ""
                        }"
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun cancelBuildJob(
        baseUrl: String,
        jobId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (baseUrl.isBlank()) {
            return@withContext Result.failure(IllegalStateException("عنوان الخادم غير مضبوط."))
        }
        try {
            val service = getService(baseUrl)
            val response = service.cancelBuild(jobId)
            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                Result.failure(Exception("فشل طلب إلغاء البناء (رمز: ${response.code()})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
