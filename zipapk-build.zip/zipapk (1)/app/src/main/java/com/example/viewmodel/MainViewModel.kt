package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BuildHistoryEntity
import com.example.data.model.ApkBuildConfig
import com.example.data.model.ProjectInspectionResult
import com.example.data.model.ProjectType
import com.example.data.model.BuildStatusResponse
import com.example.data.network.BuildApiClient
import com.example.data.preferences.AppSettingsRepository
import com.example.data.repository.BuildRepository
import com.example.data.zip.ZipInspector
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed interface InspectionUiState {
    data object Idle : InspectionUiState
    data class Inspecting(val message: String = "جارٍ فحص محتويات ملف ZIP...") : InspectionUiState
    data class Success(val result: ProjectInspectionResult) : InspectionUiState
    data class Error(val message: String) : InspectionUiState
}

sealed interface BuildUiState {
    data object Idle : BuildUiState
    data class InProgress(val status: BuildStatusResponse) : BuildUiState
    data class Success(val status: BuildStatusResponse) : BuildUiState
    data class Failed(val message: String, val logs: String? = null) : BuildUiState
    data object Cancelled : BuildUiState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val zipInspector = ZipInspector(application)
    private val appSettingsRepository = AppSettingsRepository(application)
    private val buildApiClient = BuildApiClient()
    private val database = AppDatabase.getInstance(application)
    private val buildRepository = BuildRepository(
        buildApiClient = buildApiClient,
        buildHistoryDao = database.buildHistoryDao(),
        appSettingsRepository = appSettingsRepository
    )

    // Flows from Settings
    val serverUrl: StateFlow<String> = appSettingsRepository.serverUrlFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val themeMode: StateFlow<String> = appSettingsRepository.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "SYSTEM")

    val language: StateFlow<String> = appSettingsRepository.languageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ar")

    val historyList: StateFlow<List<BuildHistoryEntity>> = buildRepository.historyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Inspection state
    private val _selectedUri = MutableStateFlow<Uri?>(null)
    val selectedUri: StateFlow<Uri?> = _selectedUri.asStateFlow()

    private val _selectedFileName = MutableStateFlow<String?>(null)
    val selectedFileName: StateFlow<String?> = _selectedFileName.asStateFlow()

    private val _inspectionState = MutableStateFlow<InspectionUiState>(InspectionUiState.Idle)
    val inspectionState: StateFlow<InspectionUiState> = _inspectionState.asStateFlow()

    // Config state
    private val _apkConfig = MutableStateFlow(
        ApkBuildConfig(
            appName = "My App",
            packageName = "com.example.myapp",
            versionName = "1.0.0",
            versionCode = 1,
            isFullscreen = false,
            enableInternet = true
        )
    )
    val apkConfig: StateFlow<ApkBuildConfig> = _apkConfig.asStateFlow()

    // Build state
    private val _buildState = MutableStateFlow<BuildUiState>(BuildUiState.Idle)
    val buildState: StateFlow<BuildUiState> = _buildState.asStateFlow()

    private var currentBuildJobId: String? = null
    private var buildJobCorout: Job? = null

    // Server test state
    private val _isTestingServer = MutableStateFlow(false)
    val isTestingServer: StateFlow<Boolean> = _isTestingServer.asStateFlow()

    private val _serverTestMessage = MutableStateFlow<String?>(null)
    val serverTestMessage: StateFlow<String?> = _serverTestMessage.asStateFlow()

    // One-time UI events
    private val _uiEvents = MutableSharedFlow<String>()
    val uiEvents: SharedFlow<String> = _uiEvents.asSharedFlow()

    fun onFileSelected(uri: Uri, fileName: String? = null) {
        _selectedUri.value = uri
        _selectedFileName.value = fileName ?: uri.lastPathSegment ?: "project.zip"
        _inspectionState.value = InspectionUiState.Idle
    }

    fun inspectSelectedFile() {
        val uri = _selectedUri.value ?: return
        viewModelScope.launch {
            _inspectionState.value = InspectionUiState.Inspecting()
            try {
                val result = zipInspector.inspectZipUri(uri)
                if (result.isValid && result.projectType == ProjectType.ANDROID) {
                    _inspectionState.value = InspectionUiState.Success(result)

                    // Auto-fill configuration
                    _apkConfig.value = ApkBuildConfig(
                        appName = result.detectedProjectName ?: "Android App",
                        packageName = result.detectedPackageName ?: "com.example.app",
                        versionName = result.detectedVersionName ?: "1.0.0",
                        versionCode = result.detectedVersionCode ?: 1,
                        isFullscreen = false,
                        enableInternet = true
                    )
                } else if (result.projectType == ProjectType.WEB_PWA) {
                    _inspectionState.value = InspectionUiState.Success(result)
                } else {
                    _inspectionState.value = InspectionUiState.Error(
                        result.rejectionReason ?: "الملف غير صالح لمشروع Android."
                    )
                }
            } catch (e: Exception) {
                _inspectionState.value = InspectionUiState.Error(
                    "حدث خطأ أثناء فحص ملف ZIP: ${e.localizedMessage ?: "خطأ غير متوقع"}"
                )
            }
        }
    }

    fun updateApkConfig(
        appName: String,
        packageName: String,
        versionName: String,
        versionCode: Int,
        isFullscreen: Boolean,
        enableInternet: Boolean
    ) {
        _apkConfig.value = ApkBuildConfig(
            appName = appName.trim(),
            packageName = packageName.trim(),
            versionName = versionName.trim().ifBlank { "1.0.0" },
            versionCode = if (versionCode <= 0) 1 else versionCode,
            isFullscreen = isFullscreen,
            enableInternet = enableInternet
        )
    }

    fun startBuild(onStarted: () -> Unit) {
        // Prevent concurrent or rapid multiple clicks
        if (_buildState.value is BuildUiState.InProgress) return

        val state = _inspectionState.value
        if (state !is InspectionUiState.Success || !state.result.isValid) {
            viewModelScope.launch {
                _uiEvents.emit("يرجى فحص مشروع Android صالح أولاً قبل إنشاء APK.")
            }
            return
        }

        val tempPath = state.result.tempZipPath
        if (tempPath == null || !File(tempPath).exists()) {
            viewModelScope.launch {
                _uiEvents.emit("ملف ZIP المؤقت غير متوفر. يرجى إعادة اختيار الملف وفحصه.")
            }
            return
        }

        val zipFile = File(tempPath)
        val config = _apkConfig.value
        val fileSizeFormatted = state.result.fileSizeFormatted

        buildJobCorout?.cancel()
        onStarted()

        buildJobCorout = viewModelScope.launch {
            buildRepository.startBuildProcess(zipFile, config, fileSizeFormatted)
                .catch { exception ->
                    _buildState.value = BuildUiState.Failed(
                        message = exception.localizedMessage ?: "فشل في التواصل مع خادم البناء",
                        logs = exception.stackTraceToString()
                    )
                }
                .collect { status ->
                    currentBuildJobId = status.jobId.ifBlank { currentBuildJobId }
                    when {
                        status.status.equals("success", ignoreCase = true) -> {
                            _buildState.value = BuildUiState.Success(status)
                        }
                        status.status.equals("failed", ignoreCase = true) -> {
                            _buildState.value = BuildUiState.Failed(
                                message = status.message ?: "فشلت عملية البناء في خادم البناء",
                                logs = status.logs
                            )
                        }
                        status.status.equals("cancelled", ignoreCase = true) -> {
                            _buildState.value = BuildUiState.Cancelled
                        }
                        else -> {
                            _buildState.value = BuildUiState.InProgress(status)
                        }
                    }
                }
        }
    }

    fun cancelCurrentBuild() {
        val jobId = currentBuildJobId
        viewModelScope.launch {
            buildJobCorout?.cancel()
            if (!jobId.isNullOrBlank()) {
                buildRepository.cancelBuild(jobId)
            }
            _buildState.value = BuildUiState.Cancelled
            _uiEvents.emit("تم إلغاء عملية البناء.")
        }
    }

    fun resetBuildState() {
        _buildState.value = BuildUiState.Idle
        currentBuildJobId = null
    }

    fun resetInspection() {
        _selectedUri.value = null
        _selectedFileName.value = null
        _inspectionState.value = InspectionUiState.Idle
    }

    fun setServerUrl(url: String) {
        viewModelScope.launch {
            appSettingsRepository.setServerUrl(url)
            _serverTestMessage.value = null
        }
    }

    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            appSettingsRepository.setThemeMode(mode)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            appSettingsRepository.setLanguage(lang)
        }
    }

    fun testServerConnection(url: String) {
        if (url.isBlank()) {
            _serverTestMessage.value = "يرجى كتابة عنوان الخادم أولاً."
            return
        }
        viewModelScope.launch {
            _isTestingServer.value = true
            _serverTestMessage.value = "جارٍ فحص الاتصال بالخادم..."
            val result = buildApiClient.testConnection(url)
            _isTestingServer.value = false
            if (result.isSuccess) {
                _serverTestMessage.value = "✅ الاتصال بالخادم ناجح ومتاح!"
            } else {
                val err = result.exceptionOrNull()?.localizedMessage ?: "تعذر الوصول إلى الخادم"
                _serverTestMessage.value = "❌ فشل الاتصال: $err"
            }
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            buildRepository.deleteHistoryItem(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            buildRepository.clearAllHistory()
            _uiEvents.emit("تم مسح سجل العمليات بنجاح.")
        }
    }
}
