package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.RoseError
import com.example.ui.theme.TechCyan

val BUILD_STAGES = listOf(
    "في انتظار البناء",
    "رفع المشروع",
    "تحضير Android",
    "تشغيل Gradle",
    "بناء APK",
    "اكتمل"
)

fun getStageIcon(stageIndex: Int): ImageVector {
    return when (stageIndex) {
        0 -> Icons.Default.Schedule
        1 -> Icons.Default.CloudUpload
        2 -> Icons.Default.Android
        3 -> Icons.Default.Code
        4 -> Icons.Default.Sync
        else -> Icons.Default.CheckCircle
    }
}

fun mapStageNameToIndex(stageName: String?): Int {
    if (stageName == null) return 0
    val lower = stageName.lowercase()
    return when {
        lower.contains("اكتمل") || lower.contains("success") || lower.contains("complete") -> 5
        lower.contains("apk") || lower.contains("بناء") && !lower.contains("انتظار") -> 4
        lower.contains("gradle") || lower.contains("تشغيل") -> 3
        lower.contains("تحضير") || lower.contains("prepare") || lower.contains("android") -> 2
        lower.contains("رفع") || lower.contains("upload") -> 1
        else -> 0
    }
}

@Composable
fun StatusPill(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (status.lowercase()) {
        "success" -> Triple(EmeraldGreen.copy(alpha = 0.15f), EmeraldGreen, "اكتمل بنجاح")
        "running" -> Triple(CyberBlue.copy(alpha = 0.15f), CyberBlue, "قيد البناء")
        "queued" -> Triple(AmberWarning.copy(alpha = 0.15f), AmberWarning, "في قائمة الانتظار")
        "failed" -> Triple(RoseError.copy(alpha = 0.15f), RoseError, "فشل البناء")
        "cancelled" -> Triple(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.15f), MaterialTheme.colorScheme.onSurfaceVariant, "ملغي")
        else -> Triple(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary, status)
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = textColor,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun BuildStageStepRow(
    stageIndex: Int,
    currentActiveIndex: Int,
    isFailed: Boolean = false,
    stageTitle: String
) {
    val isCompleted = stageIndex < currentActiveIndex || (currentActiveIndex == 5 && stageIndex == 5)
    val isCurrent = stageIndex == currentActiveIndex && !isCompleted && !isFailed

    val infiniteTransition = rememberInfiniteTransition(label = "rotation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "stage_spin"
    )

    val stepColor by animateColorAsState(
        targetValue = when {
            isFailed && stageIndex == currentActiveIndex -> RoseError
            isCompleted -> EmeraldGreen
            isCurrent -> CyberBlue
            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        },
        label = "stepColor"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Step circle icon
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    if (isCompleted || isCurrent) stepColor.copy(alpha = 0.15f)
                    else MaterialTheme.colorScheme.surfaceVariant
                )
                .border(
                    width = 2.dp,
                    color = stepColor,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isCompleted) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = EmeraldGreen,
                    modifier = Modifier.size(18.dp)
                )
            } else if (isCurrent) {
                Icon(
                    imageVector = getStageIcon(stageIndex),
                    contentDescription = null,
                    tint = CyberBlue,
                    modifier = Modifier
                        .size(18.dp)
                        .rotate(if (stageIndex == 1 || stageIndex == 4) rotation else 0f)
                )
            } else {
                Text(
                    text = "${stageIndex + 1}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stageTitle,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isCurrent || isCompleted) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    isCompleted -> EmeraldGreen
                    isCurrent -> MaterialTheme.colorScheme.onSurface
                    isFailed && stageIndex == currentActiveIndex -> RoseError
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
            if (isCurrent) {
                Text(
                    text = "جارٍ العمل الآن...",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberBlue
                )
            }
        }

        if (isCurrent) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = CyberBlue
            )
        }
    }
}
