package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Tech Palette
val CyberBlue = Color(0xFF2563EB)
val CyberBlueDark = Color(0xFF1D4ED8)
val CyberBlueLight = Color(0xFF60A5FA)

val TechCyan = Color(0xFF06B6D4)
val TechCyanLight = Color(0xFF22D3EE)

val EmeraldGreen = Color(0xFF10B981)
val AmberWarning = Color(0xFFF59E0B)
val RoseError = Color(0xFFEF4444)

// Dark Palette
val DarkBg = Color(0xFF0B1120)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)

// Light Palette
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F5F9)
val LightBorder = Color(0xFFE2E8F0)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF64748B)
