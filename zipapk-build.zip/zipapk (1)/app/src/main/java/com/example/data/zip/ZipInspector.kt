package com.example.data.zip

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.data.model.ProjectInspectionResult
import com.example.data.model.ProjectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.regex.Pattern
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ZipInspector(private val context: Context) {

    companion object {
        const val MAX_ZIP_SIZE_BYTES = 25L * 1024L * 1024L // 25 MB
    }

    suspend fun inspectZipUri(uri: Uri): ProjectInspectionResult = withContext(Dispatchers.IO) {
        val contentResolver = context.contentResolver
        var fileName = "project.zip"
        var fileSize = 0L

        // 1. Query file metadata
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex != -1) {
                        fileName = cursor.getString(nameIndex) ?: fileName
                    }
                    if (sizeIndex != -1) {
                        fileSize = cursor.getLong(sizeIndex)
                    }
                }
            }
        } catch (_: Exception) {
            // fallback
        }

        // 2. Validate ZIP extension
        if (!fileName.lowercase(Locale.ROOT).endsWith(".zip")) {
            return@withContext ProjectInspectionResult(
                projectType = ProjectType.INVALID,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = null,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                rejectionReason = "الملف المختار ليس بصيغة ZIP صالحة."
            )
        }

        // 3. Copy to temporary file in cache and validate stream size
        val tempZipFile = File(context.cacheDir, "current_project_${System.currentTimeMillis()}.zip")
        // Clean old temp files first
        cleanOldTempFiles()

        var actualCopiedBytes = 0L
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempZipFile).use { output ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        actualCopiedBytes += read
                        if (actualCopiedBytes > MAX_ZIP_SIZE_BYTES) {
                            tempZipFile.delete()
                            return@withContext ProjectInspectionResult(
                                projectType = ProjectType.INVALID,
                                isValid = false,
                                fileName = fileName,
                                fileSizeBytes = actualCopiedBytes,
                                fileSizeFormatted = formatFileSize(actualCopiedBytes),
                                detectedProjectName = null,
                                detectedPackageName = null,
                                detectedVersionName = null,
                                detectedVersionCode = null,
                                rejectionReason = "حجم الملف يتجاوز الحد الأقصى المسموح به (25 ميجابايت). الحجم الفعلي: ${formatFileSize(actualCopiedBytes)}"
                            )
                        }
                        output.write(buffer, 0, read)
                    }
                }
            } ?: run {
                return@withContext ProjectInspectionResult(
                    projectType = ProjectType.INVALID,
                    isValid = false,
                    fileName = fileName,
                    fileSizeBytes = 0L,
                    fileSizeFormatted = "0 بايت",
                    detectedProjectName = null,
                    detectedPackageName = null,
                    detectedVersionName = null,
                    detectedVersionCode = null,
                    rejectionReason = "تعذر فتح وقراءة الملف المختار من الذاكرة."
                )
            }
        } catch (e: Exception) {
            tempZipFile.delete()
            return@withContext ProjectInspectionResult(
                projectType = ProjectType.INVALID,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = actualCopiedBytes,
                fileSizeFormatted = formatFileSize(actualCopiedBytes),
                detectedProjectName = null,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                rejectionReason = "حدث خطأ أثناء قراءة ملف ZIP: ${e.localizedMessage ?: "خطأ غير معروف"}"
            )
        }

        if (fileSize == 0L) {
            fileSize = actualCopiedBytes
        }

        // 4. Scan ZIP contents and inspect structure
        return@withContext parseZipContents(tempZipFile, fileName, fileSize)
    }

    private fun parseZipContents(zipFile: File, fileName: String, fileSize: Long): ProjectInspectionResult {
        val discoveredFiles = mutableListOf<String>()
        var totalEntries = 0

        var hasSettingsGradle = false
        var hasBuildGradle = false
        var hasGradlew = false
        var hasManifest = false
        var hasSrc = false

        var hasWebIndex = false
        var hasWebManifest = false
        var hasPackageJson = false

        val detectedModules = mutableSetOf<String>()
        var detectedProjectName: String? = null
        var detectedPackageName: String? = null
        var detectedVersionName: String? = null
        var detectedVersionCode: Int? = null
        var detectedIconBytes: ByteArray? = null

        // Collect file content buffers for key files to parse
        var manifestContent: String? = null
        var stringsXmlContent: String? = null
        var settingsGradleContent: String? = null
        var rootBuildGradleContent: String? = null
        var appBuildGradleContent: String? = null

        try {
            zipFile.inputStream().use { fileInput ->
                ZipInputStream(fileInput).use { zipInput ->
                    var entry: ZipEntry? = zipInput.nextEntry
                    while (entry != null) {
                        totalEntries++
                        val name = entry.name.replace('\\', '/')
                        val normalized = name.lowercase(Locale.ROOT)

                        // Check Android indicators
                        if (normalized.endsWith("settings.gradle") || normalized.endsWith("settings.gradle.kts")) {
                            hasSettingsGradle = true
                            discoveredFiles.add(name)
                            if (settingsGradleContent == null) {
                                settingsGradleContent = readEntryString(zipInput)
                            }
                        } else if (normalized.endsWith("build.gradle") || normalized.endsWith("build.gradle.kts")) {
                            hasBuildGradle = true
                            discoveredFiles.add(name)
                            if (normalized.contains("app/") && appBuildGradleContent == null) {
                                appBuildGradleContent = readEntryString(zipInput)
                            } else if (rootBuildGradleContent == null) {
                                rootBuildGradleContent = readEntryString(zipInput)
                            }
                        } else if (normalized.endsWith("gradlew") || normalized.endsWith("gradlew.bat")) {
                            hasGradlew = true
                            discoveredFiles.add(name)
                        } else if (normalized.endsWith("androidmanifest.xml")) {
                            hasManifest = true
                            discoveredFiles.add(name)
                            if (manifestContent == null) {
                                manifestContent = readEntryString(zipInput)
                            }
                        } else if (normalized.contains("/src/") || normalized.startsWith("src/") || normalized.contains("app/src")) {
                            hasSrc = true
                            if (discoveredFiles.size < 30 && (normalized.endsWith(".kt") || normalized.endsWith(".java") || normalized.endsWith(".xml"))) {
                                discoveredFiles.add(name)
                            }
                        }

                        // Check Web/PWA indicators
                        if (normalized.endsWith("index.html")) {
                            hasWebIndex = true
                            discoveredFiles.add(name)
                        } else if (normalized.endsWith("manifest.json") || normalized.endsWith("manifest.webmanifest")) {
                            hasWebManifest = true
                            discoveredFiles.add(name)
                        } else if (normalized.endsWith("package.json")) {
                            hasPackageJson = true
                            discoveredFiles.add(name)
                        }

                        // Try finding icon
                        if (detectedIconBytes == null && (normalized.contains("ic_launcher") || normalized.contains("app_icon") || normalized.contains("logo")) &&
                            (normalized.endsWith(".png") || normalized.endsWith(".webp") || normalized.endsWith(".jpg") || normalized.endsWith(".jpeg"))
                        ) {
                            detectedIconBytes = readEntryBytes(zipInput)
                        }

                        // Module detection (e.g. app, core, feature)
                        val segments = name.split('/')
                        if (segments.size > 1 && (segments[0] == "app" || (segments.size > 2 && segments[1] == "src"))) {
                            detectedModules.add(":${segments[0]}")
                        }

                        zipInput.closeEntry()
                        entry = zipInput.nextEntry
                    }
                }
            }
        } catch (e: Exception) {
            return ProjectInspectionResult(
                projectType = ProjectType.INVALID,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = null,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                rejectionReason = "الملف تالف أو غير قابل للاستخراج: ${e.localizedMessage ?: "خطأ في بنية ZIP"}",
                tempZipPath = zipFile.absolutePath
            )
        }

        if (totalEntries == 0) {
            return ProjectInspectionResult(
                projectType = ProjectType.INVALID,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = null,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                rejectionReason = "ملف ZIP فارغ ولا يحتوي على أي ملفات أو مجلدات.",
                tempZipPath = zipFile.absolutePath
            )
        }

        // Check if Android
        val isAndroid = hasSettingsGradle || hasBuildGradle || hasGradlew || hasManifest || hasSrc

        // Extract metadata from gradle / manifest
        if (settingsGradleContent != null) {
            val rootProjectRegex = Pattern.compile("rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']")
            val matcher = rootProjectRegex.matcher(settingsGradleContent)
            if (matcher.find()) {
                detectedProjectName = matcher.group(1)
            }
        }

        val combinedGradle = (appBuildGradleContent ?: "") + "\n" + (rootBuildGradleContent ?: "")
        if (combinedGradle.isNotBlank()) {
            val appIdRegex = Pattern.compile("(?:applicationId|namespace)\\s*=?\\s*[\"']([a-zA-Z0-9_.]+)[\"']")
            val mAppId = appIdRegex.matcher(combinedGradle)
            if (mAppId.find()) {
                detectedPackageName = mAppId.group(1)
            }

            val vNameRegex = Pattern.compile("versionName\\s*=?\\s*[\"']([^\"']+)[\"']")
            val mVName = vNameRegex.matcher(combinedGradle)
            if (mVName.find()) {
                detectedVersionName = mVName.group(1)
            }

            val vCodeRegex = Pattern.compile("versionCode\\s*=?\\s*(\\d+)")
            val mVCode = vCodeRegex.matcher(combinedGradle)
            if (mVCode.find()) {
                detectedVersionCode = mVCode.group(1)?.toIntOrNull()
            }
        }

        if (manifestContent != null) {
            if (detectedPackageName == null) {
                val pkgRegex = Pattern.compile("package\\s*=\\s*[\"']([a-zA-Z0-9_.]+)[\"']")
                val mPkg = pkgRegex.matcher(manifestContent)
                if (mPkg.find()) {
                    detectedPackageName = mPkg.group(1)
                }
            }

            if (detectedProjectName == null) {
                val labelRegex = Pattern.compile("android:label\\s*=\\s*[\"']([^\"@]+)[\"']")
                val mLabel = labelRegex.matcher(manifestContent)
                if (mLabel.find()) {
                    detectedProjectName = mLabel.group(1)
                }
            }
        }

        if (detectedProjectName.isNullOrBlank()) {
            // Derive from zip file name
            detectedProjectName = fileName.removeSuffix(".zip").removeSuffix(".ZIP")
                .replace('_', ' ')
                .replace('-', ' ')
                .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
        }

        if (detectedPackageName.isNullOrBlank()) {
            val cleanSlug = fileName.removeSuffix(".zip").lowercase(Locale.ROOT)
                .replace(Regex("[^a-z0-9]"), "")
                .take(15)
                .ifEmpty { "app" }
            detectedPackageName = "com.example.$cleanSlug"
        }

        if (detectedVersionName.isNullOrBlank()) {
            detectedVersionName = "1.0.0"
        }
        if (detectedVersionCode == null || detectedVersionCode == 0) {
            detectedVersionCode = 1
        }

        if (detectedModules.isEmpty()) {
            detectedModules.add(":app")
        }

        return if (isAndroid) {
            ProjectInspectionResult(
                projectType = ProjectType.ANDROID,
                isValid = true,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = detectedProjectName,
                detectedPackageName = detectedPackageName,
                detectedVersionName = detectedVersionName,
                detectedVersionCode = detectedVersionCode,
                detectedIconBytes = detectedIconBytes,
                discoveredFiles = discoveredFiles.distinct().take(20),
                totalFilesCount = totalEntries,
                hasGradle = hasSettingsGradle || hasBuildGradle || hasGradlew,
                hasManifest = hasManifest,
                hasSrcDir = hasSrc,
                detectedModules = detectedModules.toList(),
                rejectionReason = null,
                tempZipPath = zipFile.absolutePath
            )
        } else if (hasWebIndex || hasWebManifest || hasPackageJson) {
            ProjectInspectionResult(
                projectType = ProjectType.WEB_PWA,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = detectedProjectName,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                discoveredFiles = discoveredFiles.distinct().take(15),
                totalFilesCount = totalEntries,
                rejectionReason = "تم اكتشاف مشروع ويب / تطبيق PWA (يحتوي على index.html أو package.json). يتطلب التطبيق مشروع Android أصلي يحتوي على ملفات Gradle أو AndroidManifest.",
                tempZipPath = zipFile.absolutePath
            )
        } else {
            ProjectInspectionResult(
                projectType = ProjectType.INVALID,
                isValid = false,
                fileName = fileName,
                fileSizeBytes = fileSize,
                fileSizeFormatted = formatFileSize(fileSize),
                detectedProjectName = null,
                detectedPackageName = null,
                detectedVersionName = null,
                detectedVersionCode = null,
                discoveredFiles = discoveredFiles.distinct().take(10),
                totalFilesCount = totalEntries,
                rejectionReason = "لم يتم العثور على أي ملفات تدل على مشروع Android (مثل settings.gradle أو build.gradle أو AndroidManifest.xml أو مجلد app/src).",
                tempZipPath = zipFile.absolutePath
            )
        }
    }

    private fun readEntryString(input: InputStream): String {
        val baos = ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        var read: Int
        var totalRead = 0
        // Read at most 64KB per file to protect memory
        while (input.read(buffer).also { read = it } != -1) {
            baos.write(buffer, 0, read)
            totalRead += read
            if (totalRead > 65536) break
        }
        return baos.toString("UTF-8")
    }

    private fun readEntryBytes(input: InputStream): ByteArray {
        val baos = ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        var read: Int
        var totalRead = 0
        // Read at most 512KB for icon
        while (input.read(buffer).also { read = it } != -1) {
            baos.write(buffer, 0, read)
            totalRead += read
            if (totalRead > 524288) break
        }
        return baos.toByteArray()
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 بايت"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        return when {
            mb >= 1.0 -> String.format(Locale.US, "%.2f ميجابايت", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.1f كيلوبايت", kb)
            else -> "$bytes بايت"
        }
    }

    private fun cleanOldTempFiles() {
        try {
            val cacheDir = context.cacheDir
            cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("current_project_") && file.name.endsWith(".zip")) {
                    val age = System.currentTimeMillis() - file.lastModified()
                    if (age > 10 * 60 * 1000) { // older than 10 mins
                        file.delete()
                    }
                }
            }
        } catch (_: Exception) {}
    }
}
