import re

with open("app/src/main/java/com/example/ui/viewmodel/AuthViewModel.kt", "r", encoding="utf-8") as f:
    content = f.read()

with open("patch_auth_viewmodel.kt", "r", encoding="utf-8") as f:
    patch = f.read()

# Replace from fun sendVoiceMessage to the end of sendMediaMessage
pattern = re.compile(r'    fun sendVoiceMessage\(.*?(?=    fun markMessagesAsRead\()', re.DOTALL)
new_content = pattern.sub(patch + '\n', content)

with open("app/src/main/java/com/example/ui/viewmodel/AuthViewModel.kt", "w", encoding="utf-8") as f:
    f.write(new_content)

print("Replaced!")
