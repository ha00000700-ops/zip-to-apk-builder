sed -i 's/var searchQuery by remember { mutableStateOf("") }/val searchQuery by authViewModel.searchQuery.collectAsStateWithLifecycle()/g' app/src/main/java/com/example/ui/screens/home/CustomerHomeScreen.kt
sed -i 's/searchQuery = it/authViewModel.updateSearchQuery(it)/g' app/src/main/java/com/example/ui/screens/home/CustomerHomeScreen.kt
