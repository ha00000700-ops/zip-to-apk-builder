# Khedmati DZ — Chargily Pay Integration & Deployment Guide

## Overview
This architecture integrates **Chargily Pay v2** into Khedmati DZ to support electronic payments via **EDAHABIA** (Algerie Poste) and **CIB** (Algerian Bank Cards).

---

## Security Principles Implemented
1. **Zero Secret Keys on Mobile App**: `CHARGILY_SECRET_KEY` is kept exclusively on the secure server / Firebase Cloud Functions environment.
2. **Server-Side Verification**: The mobile client **NEVER** marks an order as `SUCCESSFUL` directly. Payment state transitions to `SUCCESSFUL` occur **ONLY** when Chargily Pay sends a cryptographically signed webhook to the backend server.
3. **Sandbox & Test Mode Ready**: Configured for Chargily Pay Test Mode API (`https://pay.chargily.net/test/api/v2`).

---

## 1. Firebase Cloud Functions Deployment

### Prerequisites
- Firebase CLI installed (`npm install -g firebase-tools`)
- Firebase project initialized (`firebase init functions`)

### Step 1: Set Chargily Pay Secret Key
Run in your Firebase project terminal:
```bash
firebase functions:secrets:set CHARGILY_SECRET_KEY="secret_test_your_chargily_secret_key"
```

### Step 2: Deploy Cloud Functions
```bash
cd functions
npm install
firebase deploy --only functions
```

### Deployed Endpoints
1. `https://us-central1-<your-project-id>.cloudfunctions.net/chargilyCheckout`
2. `https://us-central1-<your-project-id>.cloudfunctions.net/chargilyWebhook`

---

## 2. Chargily Pay Dashboard Setup

1. Log in to [Chargily Pay Dashboard](https://pay.chargily.net/).
2. Switch to **Test Mode**.
3. Go to **Developers > API Keys** to copy your `CHARGILY_PUBLIC_KEY` and `CHARGILY_SECRET_KEY`.
4. Go to **Developers > Webhooks** and add your Webhook URL:
   `https://us-central1-<your-project-id>.cloudfunctions.net/chargilyWebhook`
5. Enable events: `checkout.paid`, `checkout.failed`, `checkout.canceled`.

---

## 3. Recommended Firestore Security Rules

To enforce that client devices cannot forge payment statuses, add these rules to `firestore.rules`:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    match /serviceRequests/{requestId} {
      // Allow read/write for authenticated users involved in the request
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      
      // Prevent client from setting status to SUCCESSFUL manually
      allow update: if request.auth != null 
        && (!request.resource.data.diff(resource.data).affectedKeys().hasAny(['paymentInfo'])
            || request.resource.data.paymentInfo.status != 'SUCCESSFUL'
            || resource.data.paymentInfo.status == 'SUCCESSFUL');
    }
  }
}
```

---

## 4. Test Mode Testing Instructions

Use the following test credentials in Chargily Pay Sandbox mode:

- **EDAHABIA Test Card Number**: `0079999900000000000`
- **EDAHABIA Test CVC**: `123`
- **EDAHABIA Test Expiry**: Any future date (e.g., `12/28`)
- **CIB Test Card Number**: `1111222233334444`
- **CIB Test CVC**: `123`
- **CIB Test Expiry**: Any future date (e.g., `12/28`)
