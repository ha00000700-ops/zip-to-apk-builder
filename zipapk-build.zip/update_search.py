import re

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

# We need to add showFilterDialog state
content = content.replace(
    'var selectedCategoryIndex by remember { mutableStateOf<String?>(null) }',
    'var selectedCategoryIndex by remember { mutableStateOf<String?>(null) }\n    var showFilterDialog by remember { mutableStateOf(false) }\n    var showAllCategories by remember { mutableStateOf(false) }\n    var isSearchFocused by remember { mutableStateOf(false) }'
)

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
