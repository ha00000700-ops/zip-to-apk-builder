/**
 * Khedmati DZ — Chargily Pay v2 Firebase Cloud Functions Backend
 * Secure Server-side Integration Layer for Chargily Pay (EDAHABIA & CIB)
 */

const functions = require("firebase-functions");
const admin = require("firebase-admin");
const crypto = require("crypto");
const axios = require("axios");

admin.initializeApp();
const db = admin.firestore();

// Chargily Pay v2 Base Endpoints
const CHARGILY_TEST_API_BASE = "https://pay.chargily.net/test/api/v2";
const CHARGILY_PROD_API_BASE = "https://pay.chargily.net/api/v2";

// Centralized 3-Tier Subscription Plans Configuration
const SUBSCRIPTION_PLANS = {
  BASIC: {
    planId: "BASIC",
    priceDzd: 500, // 500 DZD / Month
    currency: "DZD",
    durationDays: 30, // 1 Month
    displayNameAr: "الخطة الأساسية (Basic)",
    tierLevel: 1
  },
  STANDARD: {
    planId: "STANDARD",
    priceDzd: 1000, // 1000 DZD / Month
    currency: "DZD",
    durationDays: 30, // 1 Month
    displayNameAr: "الخطة القياسية (Standard)",
    tierLevel: 2
  },
  PREMIUM: {
    planId: "PREMIUM",
    priceDzd: 1500, // 1500 DZD / Month
    currency: "DZD",
    durationDays: 30, // 1 Month
    displayNameAr: "الخطة المميزة (Premium ⭐)",
    tierLevel: 3
  }
};

// Promotional Advertisement Boost Packages (Completely separate from subscriptions)
const AD_BOOST_PACKAGES = {
  BOOST_BASIC: {
    packageId: "BOOST_BASIC",
    priceDzd: 100, // 100 DZD
    durationDays: 3, // 3 Days
    priorityLevel: 1,
    displayNameAr: "ترويج أساسي (Boost Basic)"
  },
  BOOST_STANDARD: {
    packageId: "BOOST_STANDARD",
    priceDzd: 250, // 250 DZD
    durationDays: 7, // 7 Days
    priorityLevel: 2,
    displayNameAr: "ترويج متقدم (Boost Standard)"
  },
  BOOST_PREMIUM: {
    packageId: "BOOST_PREMIUM",
    priceDzd: 500, // 500 DZD
    durationDays: 30, // 30 Days
    priorityLevel: 3,
    displayNameAr: "ترويج شامل مميز (Boost Premium ⭐)"
  }
};

function resolveAdBoostPackage(packageCode) {
  if (!packageCode) return AD_BOOST_PACKAGES.BOOST_BASIC;
  const upper = String(packageCode).trim().toUpperCase();
  if (upper === "BOOST_BASIC" || upper === "BASIC") return AD_BOOST_PACKAGES.BOOST_BASIC;
  if (upper === "BOOST_STANDARD" || upper === "STANDARD") return AD_BOOST_PACKAGES.BOOST_STANDARD;
  if (upper === "BOOST_PREMIUM" || upper === "PREMIUM") return AD_BOOST_PACKAGES.BOOST_PREMIUM;
  return AD_BOOST_PACKAGES.BOOST_BASIC;
}

function resolveSubscriptionPlan(planCode) {
  if (!planCode) return SUBSCRIPTION_PLANS.PREMIUM;
  const upper = String(planCode).trim().toUpperCase();
  if (upper === "BASIC") return SUBSCRIPTION_PLANS.BASIC;
  if (upper === "STANDARD") return SUBSCRIPTION_PLANS.STANDARD;
  if (upper === "PREMIUM" || upper === "PRO") return SUBSCRIPTION_PLANS.PREMIUM;
  return SUBSCRIPTION_PLANS.PREMIUM;
}

/**
 * Safely retrieve the Chargily Secret Key from server environment without requiring Secret Manager API.
 * Priority:
 *  1. process.env.CHARGILY_SECRET_KEY (from functions/.env or Cloud Functions env vars)
 *  2. functions.config().chargily.secret_key (from firebase functions:config:set chargily.secret_key="...")
 *  3. functions.config().chargily.secret
 */
function getChargilySecretKey() {
  if (process.env.CHARGILY_SECRET_KEY && process.env.CHARGILY_SECRET_KEY.trim().length > 0) {
    return process.env.CHARGILY_SECRET_KEY.trim();
  }
  try {
    const config = functions.config ? functions.config() : null;
    if (config && config.chargily) {
      if (config.chargily.secret_key && config.chargily.secret_key.trim().length > 0) {
        return config.chargily.secret_key.trim();
      }
      if (config.chargily.secret && config.chargily.secret.trim().length > 0) {
        return config.chargily.secret.trim();
      }
    }
  } catch (e) {
    // ignore
  }
  return "";
}

/**
 * Determine Chargily mode (defaults to true / test mode unless explicitly set to 'production')
 */
function isTestMode() {
  const envMode = process.env.CHARGILY_MODE;
  if (envMode) {
    return envMode.trim().toLowerCase() !== "production";
  }
  try {
    const config = functions.config ? functions.config() : null;
    if (config && config.chargily && config.chargily.mode) {
      return config.chargily.mode.trim().toLowerCase() !== "production";
    }
  } catch (e) {
    // ignore
  }
  return true; // Default to TEST mode safely
}

/**
 * 1. HTTPS Function: Create Chargily Pay Checkout Session (for Service Requests)
 * Called by Android App to initiate payment securely without holding secret keys.
 */
exports.chargilyCheckout = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.status(204).send("");
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const { requestId, paymentMethod, customerName } = req.body;

    if (!requestId || !paymentMethod) {
      return res.status(400).json({ error: "Invalid request parameters: requestId and paymentMethod are required." });
    }

    // 1. Authenticate Request
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: Missing Authorization Header" });
    }
    const idToken = authHeader.split("Bearer ")[1];
    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (authErr) {
      console.error("Token verification failed:", authErr);
      return res.status(401).json({ error: "Unauthorized: Token verification failed" });
    }
    const authenticatedUid = decodedToken.uid;

    // 2. Fetch service request from Firestore (Amount Security)
    const requestDoc = await db.collection("serviceRequests").doc(requestId).get();
    if (!requestDoc.exists) {
      return res.status(404).json({ error: "Service request not found in Firestore." });
    }
    const requestData = requestDoc.data();

    // 3. Verify ownership (Amount Security)
    if (requestData.customerId !== authenticatedUid) {
      return res.status(403).json({ error: "Forbidden: You are not authorized to pay for this request." });
    }

    // 4. Read authoritative agreed price (Amount Security)
    const amountDzd = requestData.proposedPriceDzd;
    if (!amountDzd || amountDzd <= 0) {
      return res.status(400).json({ error: "This service request does not have an agreed proposed price yet." });
    }

    const secretKey = getChargilySecretKey();
    if (!secretKey) {
      return res.status(500).json({ error: "Chargily Secret Key is not configured on the server." });
    }

    const isTest = isTestMode();
    const apiBaseUrl = isTest ? CHARGILY_TEST_API_BASE : CHARGILY_PROD_API_BASE;

    // Call Chargily Pay v2 Checkouts API
    const response = await axios.post(
      `${apiBaseUrl}/checkouts`,
      {
        amount: Number(amountDzd),
        currency: "dzd",
        payment_method: paymentMethod === "CIB" ? "cib" : "edahabia",
        success_url: `https://khedmatidz.app/payment/success?request_id=${requestId}`,
        failure_url: `https://khedmatidz.app/payment/failure?request_id=${requestId}`,
        webhook_endpoint: `https://${process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT}.cloudfunctions.net/chargilyWebhook`,
        metadata: {
          type: "SERVICE_PAYMENT",
          requestId: requestId,
          customerId: authenticatedUid,
          customerName: customerName || requestData.customerName || ""
        }
      },
      {
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json"
        }
      }
    );

    const checkoutData = response.data;

    // Update Firestore service request payment state to PENDING
    await db.collection("serviceRequests").doc(requestId).update({
      "paymentInfo.status": "PENDING",
      "paymentInfo.method": paymentMethod,
      "paymentInfo.amountDzd": Number(amountDzd),
      "paymentInfo.checkoutId": checkoutData.id,
      "paymentInfo.checkoutUrl": checkoutData.checkout_url,
      "paymentInfo.createdAt": Date.now(),
      updatedAt: Date.now()
    });

    return res.status(200).json({
      checkoutId: checkoutData.id,
      checkoutUrl: checkoutData.checkout_url
    });
  } catch (error) {
    console.error("Chargily Checkout Error:", error.response ? error.response.data : error.message);
    return res.status(500).json({
      error: "Failed to create Chargily Pay checkout session",
      details: error.response ? error.response.data : error.message
    });
  }
});

/**
 * 2. HTTPS Function: Create Chargily Pay Subscription Session (for Khedmati Pro)
 * Called by Android App to initiate Khedmati Pro subscription securely.
 */
exports.chargilyProCheckout = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.status(204).send("");
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const { paymentMethod, planId } = req.body;

    if (!paymentMethod) {
      return res.status(400).json({ error: "Invalid request parameters: paymentMethod is required." });
    }

    const selectedPlan = resolveSubscriptionPlan(planId);

    // 1. Authenticate Request
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: Missing Authorization Header" });
    }
    const idToken = authHeader.split("Bearer ")[1];
    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (authErr) {
      console.error("Token verification failed:", authErr);
      return res.status(401).json({ error: "Unauthorized: Token verification failed" });
    }
    const authenticatedUid = decodedToken.uid;

    // 2. Read user profile and verify role is PROVIDER (Only providers can subscribe to Pro)
    const userDoc = await db.collection("users").doc(authenticatedUid).get();
    if (!userDoc.exists) {
      return res.status(404).json({ error: "User profile not found." });
    }
    const userData = userDoc.data();
    if (userData.role !== "PROVIDER") {
      return res.status(403).json({ error: "Forbidden: Only service providers can subscribe to Khedmati Pro." });
    }

    // 3. Read authoritative subscription price for selected plan (Pricing Security)
    const amountDzd = selectedPlan.priceDzd;

    const secretKey = getChargilySecretKey();
    if (!secretKey) {
      return res.status(500).json({ error: "Chargily Secret Key is not configured on the server." });
    }

    const isTest = isTestMode();
    const apiBaseUrl = isTest ? CHARGILY_TEST_API_BASE : CHARGILY_PROD_API_BASE;

    // Call Chargily Pay v2 Checkouts API
    const response = await axios.post(
      `${apiBaseUrl}/checkouts`,
      {
        amount: Number(amountDzd),
        currency: "dzd",
        payment_method: paymentMethod === "CIB" ? "cib" : "edahabia",
        success_url: `https://khedmatidz.app/pro/success?user_id=${authenticatedUid}&plan=${selectedPlan.planId}`,
        failure_url: `https://khedmatidz.app/pro/failure?user_id=${authenticatedUid}&plan=${selectedPlan.planId}`,
        webhook_endpoint: `https://${process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT}.cloudfunctions.net/chargilyWebhook`,
        metadata: {
          type: "SUBSCRIPTION",
          userId: authenticatedUid,
          planId: selectedPlan.planId,
          amount: String(amountDzd)
        }
      },
      {
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json"
        }
      }
    );

    const checkoutData = response.data;

    const pendingSubscription = {
      plan: selectedPlan.planId,
      status: "PENDING",
      checkoutId: checkoutData.id,
      checkoutUrl: checkoutData.checkout_url,
      amount: Number(amountDzd),
      currency: "DZD",
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    // Update Firestore User Profile with PENDING subscription status
    await db.collection("users").doc(authenticatedUid).update({
      subscription: pendingSubscription,
      updatedAt: Date.now()
    });

    // Write to root secure subscriptions collection
    await db.collection("subscriptions").doc(authenticatedUid).set({
      userId: authenticatedUid,
      ...pendingSubscription
    });

    return res.status(200).json({
      checkoutId: checkoutData.id,
      checkoutUrl: checkoutData.checkout_url
    });
  } catch (error) {
    console.error("Chargily Pro Checkout Error:", error.response ? error.response.data : error.message);
    return res.status(500).json({
      error: "Failed to initiate Khedmati Pro subscription checkout",
      details: error.response ? error.response.data : error.message
    });
  }
});

/**
 * 3. HTTPS Function: Create Chargily Pay Ad Boost Session (for Promoted Advertisements)
 * Called by Android App to initiate payment for an advertisement boost securely.
 */
exports.chargilyAdCheckout = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    return res.status(204).send("");
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    const { paymentMethod, adId } = req.body;

    if (!paymentMethod || !adId) {
      return res.status(400).json({ error: "Invalid request parameters: paymentMethod and adId are required." });
    }

    // 1. Authenticate Request
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Unauthorized: Missing Authorization Header" });
    }
    const idToken = authHeader.split("Bearer ")[1];
    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (authErr) {
      console.error("Token verification failed:", authErr);
      return res.status(401).json({ error: "Unauthorized: Token verification failed" });
    }
    const authenticatedUid = decodedToken.uid;

    // 2. Fetch Ad document from Firestore to verify ownership and package details
    const adDocRef = db.collection("promotedAds").doc(adId);
    const adDoc = await adDocRef.get();
    if (!adDoc.exists) {
      return res.status(404).json({ error: "Promotional advertisement not found in Firestore." });
    }
    const adData = adDoc.data();

    // Verify ownership
    if (adData.providerId !== authenticatedUid) {
      return res.status(403).json({ error: "Forbidden: You do not own this promotional advertisement." });
    }

    const boostPkg = resolveAdBoostPackage(adData.packageId);
    const amountDzd = boostPkg.priceDzd;

    const secretKey = getChargilySecretKey();
    if (!secretKey) {
      return res.status(500).json({ error: "Chargily Secret Key is not configured on the server." });
    }

    const isTest = isTestMode();
    const apiBaseUrl = isTest ? CHARGILY_TEST_API_BASE : CHARGILY_PROD_API_BASE;

    // Call Chargily Pay v2 Checkouts API
    const response = await axios.post(
      `${apiBaseUrl}/checkouts`,
      {
        amount: Number(amountDzd),
        currency: "dzd",
        payment_method: paymentMethod === "CIB" ? "cib" : "edahabia",
        success_url: `https://khedmatidz.app/ad/success?ad_id=${adId}`,
        failure_url: `https://khedmatidz.app/ad/failure?ad_id=${adId}`,
        webhook_endpoint: `https://${process.env.GCP_PROJECT || process.env.GCLOUD_PROJECT}.cloudfunctions.net/chargilyWebhook`,
        metadata: {
          type: "PROMOTED_AD",
          adId: adId,
          providerId: authenticatedUid,
          packageId: boostPkg.packageId,
          amount: String(amountDzd)
        }
      },
      {
        headers: {
          Authorization: `Bearer ${secretKey}`,
          "Content-Type": "application/json"
        }
      }
    );

    const checkoutData = response.data;

    // Update Ad document in Firestore with pending payment and checkout details
    await adDocRef.update({
      status: "PENDING_VERIFICATION",
      paymentStatus: "PENDING",
      checkoutId: checkoutData.id,
      checkoutUrl: checkoutData.checkout_url,
      paymentMethod: paymentMethod,
      priceDzd: amountDzd,
      priorityLevel: boostPkg.priorityLevel,
      durationDays: boostPkg.durationDays,
      updatedAt: Date.now()
    });

    return res.status(200).json({
      checkoutId: checkoutData.id,
      checkoutUrl: checkoutData.checkout_url,
      amountDzd: amountDzd
    });
  } catch (error) {
    console.error("Chargily Ad Checkout Error:", error.response ? error.response.data : error.message);
    return res.status(500).json({
      error: "Failed to initiate promotional advertisement checkout",
      details: error.response ? error.response.data : error.message
    });
  }
});

/**
 * 4. HTTPS Webhook Handler: Chargily Pay Event Listener
 * Receives signed webhooks from Chargily Pay when payment succeeds or fails.
 */
exports.chargilyWebhook = functions.https.onRequest(async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).send("Method Not Allowed");
  }

  const signature = req.headers["signature"];
  const secretKey = getChargilySecretKey();

  if (!secretKey) {
    console.error("Missing CHARGILY_SECRET_KEY on the server.");
    return res.status(500).send("Server Configuration Error");
  }

  if (!signature) {
    console.warn("Missing Signature Header");
    return res.status(400).send("Bad Request: Missing Signature");
  }

  // 1. Verify Webhook Signature using raw body buffer to ensure byte-perfect alignment
  const computedSignature = crypto
    .createHmac("sha256", secretKey)
    .update(req.rawBody)
    .digest("hex");

  if (computedSignature !== signature) {
    console.warn("Invalid Chargily Webhook Signature");
    return res.status(403).send("Signature Verification Failed");
  }

  // 2. Parse JSON only AFTER signature verification has succeeded
  let event;
  try {
    event = JSON.parse(req.rawBody.toString("utf8"));
  } catch (err) {
    console.error("Failed to parse JSON body after verification:", err);
    return res.status(400).send("Malformed JSON Payload");
  }

  const eventType = event.type;
  const checkoutObj = event.data;

  if (!checkoutObj || !checkoutObj.metadata) {
    return res.status(200).send("No metadata found in event");
  }

  // Route webhook handling depending on the payment type
  const isSubscription = checkoutObj.metadata.type === "SUBSCRIPTION";

  if (isSubscription) {
    const userId = checkoutObj.metadata.userId;
    const planId = checkoutObj.metadata.planId || "PREMIUM";
    const selectedPlan = resolveSubscriptionPlan(planId);

    if (!userId) {
      return res.status(400).send("Missing userId in subscription metadata");
    }

    const userDocRef = db.collection("users").doc(userId);
    const subDocRef = db.collection("subscriptions").doc(userId);
    const spDocRef = db.collection("serviceProviders").doc(userId);

    try {
      const userDoc = await userDocRef.get();
      if (!userDoc.exists) {
        console.warn(`User ${userId} not found for subscription update.`);
        return res.status(404).send("User Not Found");
      }
      const userData = userDoc.data();
      const currentSubStatus = userData.subscription ? userData.subscription.status : "FREE";

      // Idempotency: skip if already marked as ACTIVE
      if (currentSubStatus === "ACTIVE" && userData.subscription.paymentId === checkoutObj.id) {
        console.log(`Subscription already verified as ACTIVE for user ${userId}. Skipping.`);
        return res.status(200).send("Webhook Processed (Already Active / Idempotency)");
      }

      if (eventType === "checkout.paid") {
        // Verify payment amount matches authoritative subscription plan price
        const expectedPrice = selectedPlan.priceDzd;
        const paidPrice = Number(checkoutObj.amount);
        if (paidPrice !== expectedPrice) {
          console.warn(`Security Warning: Subscription price mismatch. Expected ${expectedPrice}, paid ${paidPrice}`);
          return res.status(400).send("Price Mismatch");
        }

        // Verify checkout ID matches pending checkout ID
        const pendingCheckoutId = userData.subscription ? userData.subscription.checkoutId : null;
        if (pendingCheckoutId && pendingCheckoutId !== checkoutObj.id) {
          console.warn(`Security Warning: Subscription Checkout ID mismatch. Expected ${pendingCheckoutId}, got ${checkoutObj.id}`);
          return res.status(400).send("Checkout ID Mismatch");
        }

        const now = Date.now();
        const durationMs = selectedPlan.durationDays * 24 * 60 * 60 * 1000;
        const expirationDate = now + durationMs;

        const activeSubscription = {
          plan: selectedPlan.planId,
          status: "ACTIVE",
          startDate: now,
          endDate: expirationDate,
          paymentId: checkoutObj.id,
          checkoutId: checkoutObj.id,
          amount: expectedPrice,
          currency: "DZD",
          createdAt: userData.subscription ? userData.subscription.createdAt : now,
          updatedAt: now
        };

        // Update User Profile with ACTIVE subscription
        await userDocRef.update({
          subscription: activeSubscription,
          updatedAt: now
        });

        // Update secure root collection
        await subDocRef.set({
          userId: userId,
          ...activeSubscription
        });

        // Sync to serviceProviders collection if provider document exists
        const spDoc = await spDocRef.get();
        if (spDoc.exists) {
          await spDocRef.update({
            subscriptionPlan: selectedPlan.planId,
            subscriptionStatus: "ACTIVE",
            updatedAt: now
          });
        }

        console.log(`Khedmati subscription (${selectedPlan.planId}) activated successfully for user ${userId}`);
      } else if (eventType === "checkout.failed") {
        await userDocRef.update({
          "subscription.status": "PAYMENT_FAILED",
          "subscription.updatedAt": Date.now(),
          updatedAt: Date.now()
        });
        await subDocRef.update({
          status: "PAYMENT_FAILED",
          updatedAt: Date.now()
        });
        const spDoc = await spDocRef.get();
        if (spDoc.exists) {
          await spDocRef.update({
            subscriptionStatus: "PAYMENT_FAILED",
            updatedAt: Date.now()
          });
        }
        console.log(`Khedmati subscription payment FAILED for user ${userId}`);
      } else if (eventType === "checkout.canceled") {
        await userDocRef.update({
          "subscription.status": "CANCELLED",
          "subscription.updatedAt": Date.now(),
          updatedAt: Date.now()
        });
        await subDocRef.update({
          status: "CANCELLED",
          updatedAt: Date.now()
        });
        const spDoc = await spDocRef.get();
        if (spDoc.exists) {
          await spDocRef.update({
            subscriptionStatus: "CANCELLED",
            updatedAt: Date.now()
          });
        }
        console.log(`Khedmati subscription payment CANCELLED for user ${userId}`);
      }

      return res.status(200).send("Webhook Processed Successfully");
    } catch (err) {
      console.error("Firestore Subscription Webhook Update Error:", err);
      return res.status(500).send("Error updating Firestore subscription record");
    }

  } else if (checkoutObj.metadata.type === "PROMOTED_AD") {
    // Handle Promotional Advertisement Boost Payment
    const adId = checkoutObj.metadata.adId;
    const providerId = checkoutObj.metadata.providerId;
    const packageId = checkoutObj.metadata.packageId || "BOOST_BASIC";
    const boostPkg = resolveAdBoostPackage(packageId);

    if (!adId) {
      return res.status(400).send("Missing adId in PROMOTED_AD metadata");
    }

    const adDocRef = db.collection("promotedAds").doc(adId);

    try {
      const adDoc = await adDocRef.get();
      if (!adDoc.exists) {
        console.warn(`Promoted ad ${adId} not found in Firestore.`);
        return res.status(404).send("Promoted Ad Not Found");
      }
      const adData = adDoc.data();
      const currentStatus = adData.status || "PENDING_PAYMENT";

      // Idempotency: skip if already active with matching payment ID
      if (currentStatus === "ACTIVE" && adData.checkoutId === checkoutObj.id) {
        console.log(`Ad ${adId} already marked as ACTIVE. Skipping.`);
        return res.status(200).send("Webhook Processed (Already Active / Idempotency)");
      }

      if (eventType === "checkout.paid") {
        // Authoritative price check
        const expectedPrice = boostPkg.priceDzd;
        const paidPrice = Number(checkoutObj.amount);
        if (paidPrice !== expectedPrice) {
          console.warn(`Security Warning: Ad price mismatch. Expected ${expectedPrice}, paid ${paidPrice}`);
          return res.status(400).send("Price Mismatch");
        }

        const now = Date.now();
        const durationMs = boostPkg.durationDays * 24 * 60 * 60 * 1000;
        const expirationDate = now + durationMs;

        await adDocRef.update({
          status: "ACTIVE",
          paymentStatus: "SUCCESSFUL",
          startDate: now,
          endDate: expirationDate,
          priceDzd: expectedPrice,
          durationDays: boostPkg.durationDays,
          priorityLevel: boostPkg.priorityLevel,
          updatedAt: now
        });

        console.log(`Promoted Ad ${adId} activated successfully for provider ${providerId} for ${boostPkg.durationDays} days`);
      } else if (eventType === "checkout.failed") {
        await adDocRef.update({
          status: "PENDING_PAYMENT",
          paymentStatus: "FAILED",
          updatedAt: Date.now()
        });
        console.log(`Promoted Ad ${adId} payment FAILED`);
      } else if (eventType === "checkout.canceled") {
        await adDocRef.update({
          status: "CANCELLED",
          paymentStatus: "CANCELLED",
          updatedAt: Date.now()
        });
        console.log(`Promoted Ad ${adId} payment CANCELLED`);
      }

      return res.status(200).send("Webhook Processed Successfully");
    } catch (err) {
      console.error("Firestore Promoted Ad Webhook Update Error:", err);
      return res.status(500).send("Error updating Firestore Promoted Ad record");
    }

  } else {
    // Handle standard Service Request payment
    const requestId = checkoutObj.metadata.requestId;
    if (!requestId) {
      return res.status(200).send("No metadata requestId found");
    }

    const docRef = db.collection("serviceRequests").doc(requestId);

    try {
      const requestDoc = await docRef.get();
      if (!requestDoc.exists) {
        console.warn(`Request ${requestId} not found in Firestore.`);
        return res.status(404).send("Service Request Not Found");
      }
      const requestData = requestDoc.data();
      const currentPaymentStatus = requestData.paymentInfo ? requestData.paymentInfo.status : "UNPAID";

      // If already marked SUCCESSFUL, do not overwrite (Idempotency)
      if (currentPaymentStatus === "SUCCESSFUL") {
        console.log(`Payment already verified as SUCCESSFUL for request ${requestId}. Skipping.`);
        return res.status(200).send("Webhook Processed (Already Successful / Idempotency)");
      }

      if (eventType === "checkout.paid") {
        const pendingCheckoutId = requestData.paymentInfo ? requestData.paymentInfo.checkoutId : null;
        if (pendingCheckoutId && pendingCheckoutId !== checkoutObj.id) {
          console.warn(`Security Warning: Checkout ID mismatch. Expected ${pendingCheckoutId}, got ${checkoutObj.id}`);
          return res.status(400).send("Checkout ID Mismatch");
        }

        const agreedPrice = requestData.proposedPriceDzd;
        const paidAmount = Number(checkoutObj.amount);
        if (paidAmount !== Number(agreedPrice)) {
          console.warn(`Security Warning: Amount mismatch. Expected ${agreedPrice}, paid ${paidAmount}`);
          return res.status(400).send("Payment Amount Mismatch");
        }

        await docRef.update({
          "paymentInfo.status": "SUCCESSFUL",
          "paymentInfo.chargilyPaymentId": checkoutObj.id,
          "paymentInfo.receiptUrl": checkoutObj.receipt_url || null,
          "paymentInfo.paidAt": Date.now(),
          updatedAt: Date.now()
        });
        console.log(`Payment SUCCESSFUL for request ${requestId}`);
      } else if (eventType === "checkout.failed") {
        await docRef.update({
          "paymentInfo.status": "FAILED",
          "paymentInfo.failureReason": checkoutObj.failure_message || "فشلت عملية الدفع",
          updatedAt: Date.now()
        });
        console.log(`Payment FAILED for request ${requestId}`);
      } else if (eventType === "checkout.canceled") {
        await docRef.update({
          "paymentInfo.status": "CANCELLED",
          "paymentInfo.failureReason": "تم إلغاء العملية",
          updatedAt: Date.now()
        });
        console.log(`Payment CANCELLED for request ${requestId}`);
      }

      return res.status(200).send("Webhook Processed Successfully");
    } catch (err) {
      console.error("Firestore Webhook Update Error:", err);
      return res.status(500).send("Error updating Firestore payment record");
    }
  }
});
