with open("app/src/main/java/com/example/data/repository/AuthRepository.kt", "r", encoding="utf-8") as f:
    lines = f.readlines()

new_lines = []
in_upload_chat = False
upload_chat_lines = []

for line in lines:
    if line.startswith("suspend fun uploadChatMedia("):
        in_upload_chat = True
        upload_chat_lines.append(line)
        continue
    
    if in_upload_chat:
        upload_chat_lines.append(line)
        if line.strip() == "}" and len(upload_chat_lines) > 50:
            in_upload_chat = False
        continue
    
    new_lines.append(line)

# find where to insert: before "private suspend fun uploadImageToStorage"
insert_idx = -1
for i, line in enumerate(new_lines):
    if "private suspend fun uploadImageToStorage" in line:
        insert_idx = i
        break

if insert_idx != -1:
    new_lines = new_lines[:insert_idx] + upload_chat_lines + new_lines[insert_idx:]

with open("app/src/main/java/com/example/data/repository/AuthRepository.kt", "w", encoding="utf-8") as f:
    f.writelines(new_lines)

print("Fixed!")
