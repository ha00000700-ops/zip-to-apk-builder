import java.net.URL
import java.net.URLEncoder
import java.net.HttpURLConnection
import org.json.JSONArray

fun main() {
    val query = "ورقلة"
    val encodedQuery = URLEncoder.encode(query, "UTF-8")
    val url = URL("https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&limit=5&accept-language=ar,en")
    val connection = url.openConnection() as HttpURLConnection
    connection.requestMethod = "GET"
    connection.setRequestProperty("User-Agent", "WathakkirApp/1.0")
    
    val response = connection.inputStream.bufferedReader().use { it.readText() }
    println(response)
}
