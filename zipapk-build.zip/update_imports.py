with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

imports_to_add = """
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.rememberModalBottomSheetState
"""

content = content.replace('import androidx.compose.runtime.*', 'import androidx.compose.runtime.*\n' + imports_to_add)
content = content.replace('@Composable', '@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)\n@Composable')

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
