with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for line in lines:
    if line.strip() in ['import androidx.compose.foundation.lazy.grid.LazyVerticalGrid', 'import androidx.compose.foundation.lazy.grid.GridCells']:
        if not any(line.strip() in nl for nl in new_lines):
            new_lines.append(line)
    else:
        new_lines.append(line)

with open('app/src/main/java/com/example/ui/screens/profile/ProviderProfileScreen.kt', 'w') as f:
    f.writelines(new_lines)
