with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'header: (@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)\n@Composable () -> Unit)? = null',
    'header: (@Composable () -> Unit)? = null'
)

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
