import re

with open('app/src/main/java/com/example/ui/screens/profile/ProfileScreen.kt', 'r') as f:
    content = f.read()

target = """                        Icon(
                            imageVector = if (isProvider) Icons.Default.Handyman else Icons.Default.Person,
                            contentDescription = null,
                            tint = BluePrimary,
                            modifier = Modifier.size(54.dp)
                        )"""

replacement = """                        val imgUrl = if (isProvider) providerProfile?.effectiveAvatarUrl() else currentUser?.avatarUrl
                        if (!imgUrl.isNullOrBlank()) {
                            coil.compose.AsyncImage(
                                model = imgUrl,
                                contentDescription = null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(
                                imageVector = if (isProvider) Icons.Default.Handyman else Icons.Default.Person,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(54.dp)
                            )
                        }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/profile/ProfileScreen.kt', 'w') as f:
    f.write(content)
