import requests
import json
import time

supabase_url = "https://mgpzpdbvfrbwousswphg.supabase.co"
supabase_key = "sb_publishable_eYsl7Db8u1n8xbjr-iBuFw_plhTyfo9"
bucket_name = "khedmati"

# Dummy file data
dummy_data = b"test_data"

print("--- Testing Supabase Storage Upload ---")

# 1. Test upload with anon key (Bearer $supabase_key)
upload_url = f"{supabase_url}/storage/v1/object/{bucket_name}/providers/test_dummy_user/test.jpg"
headers_anon = {
    "apikey": supabase_key,
    "Authorization": f"Bearer {supabase_key}",
    "x-upsert": "true",
    "Content-Type": "image/jpeg"
}

try:
    r_anon = requests.post(upload_url, headers=headers_anon, data=dummy_data)
    print(f"Anon Upload HTTP Status: {r_anon.status_code}")
    print(f"Anon Upload Response: {r_anon.text}")
except Exception as e:
    print(f"Anon Upload Exception: {e}")

# 2. Test upload with an invalid/expired/fake Firebase JWT
# Let's see if we get 401 (Invalid JWT) or 400 (RLS violation)
fake_firebase_jwt = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjEifQ.eyJzdWIiOiJ0ZXN0X3VzZXIiLCJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vZmFrZSIsImF1ZCI6ImZha2UiLCJleHAiOjE3MDAwMDAwMDB9.fake_signature"
headers_fake = {
    "apikey": supabase_key,
    "Authorization": f"Bearer {fake_firebase_jwt}",
    "x-upsert": "true",
    "Content-Type": "image/jpeg"
}

try:
    r_fake = requests.post(upload_url, headers=headers_fake, data=dummy_data)
    print(f"Fake JWT Upload HTTP Status: {r_fake.status_code}")
    print(f"Fake JWT Upload Response: {r_fake.text}")
except Exception as e:
    print(f"Fake JWT Upload Exception: {e}")
