    private suspend fun uploadImageToStorage(context: android.content.Context, path: String, uriString: String): String {
        if (uriString.isBlank()) return ""
        if (uriString.startsWith("http://") || uriString.startsWith("https://")) {
            if (!uriString.contains("/storage/v1/object/") && !uriString.contains("/functions/v1/")) {
                return uriString
            }
            val extracted = com.example.data.remote.SupabaseConfig.extractObjectPath(uriString)
            if (extracted != null) {
                return extracted
            }
        }

        val supabaseUrl = com.example.data.remote.SupabaseConfig.SUPABASE_URL
        val cleanPath = path.removePrefix("/")
        val uri = android.net.Uri.parse(uriString)
        val imageBytes = compressImageToByteArray(context, uri) ?: run {
            Log.e(tag, "Could not compress image for Edge Function upload")
            return cleanPath
        }

        Log.d(tag, "Lifecycle Trace - MIME type: image/jpeg, Byte size: ${imageBytes.size}, Original intended path: $cleanPath")

        return kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val token = auth?.currentUser?.getIdToken(true)?.kotlinx.coroutines.tasks.await()?.token
                if (token == null) {
                    Log.e(tag, "Failed to get Firebase token for upload")
                    return@withContext cleanPath
                }

                val url = "$supabaseUrl/functions/v1/upload-provider-image"
                val requestBody = imageBytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
                val multipartBody = okhttp3.MultipartBody.Builder()
                    .setType(okhttp3.MultipartBody.FORM)
                    .addFormDataPart("file", "image.jpg", requestBody)
                    .build()

                val request = okhttp3.Request.Builder()
                    .url(url)
                    .addHeader("Authorization", "Bearer $token")
                    .post(multipartBody)
                    .build()

                okHttpClient.newCall(request).execute().use { response ->
                    val responseBodyString = response.body?.string()
                    Log.d(tag, "Lifecycle Trace - Upload HTTP status: ${response.code}")
                    if (!response.isSuccessful) {
                        Log.e(tag, "Edge Function upload failed: ${response.code} - $responseBodyString")
                        return@withContext cleanPath
                    }

                    Log.d(tag, "Successfully uploaded via Edge Function: $responseBodyString")
                    try {
                        val jsonObject = org.json.JSONObject(responseBodyString ?: "{}")
                        if (jsonObject.optBoolean("success")) {
                            val returnedUrl = jsonObject.optString("url")
                            if (returnedUrl.isNotBlank()) {
                                return@withContext returnedUrl
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(tag, "Failed to parse Edge Function response", e)
                    }
                    cleanPath
                }
            } catch (e: Exception) {
                Log.e(tag, "Exception during Edge Function upload", e)
                cleanPath
            }
        }
    }
