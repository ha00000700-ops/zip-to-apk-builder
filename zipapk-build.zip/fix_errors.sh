sed -i 's/authViewModel.updateSearchQuery(it)/authViewModel.updateSearchQuery(it)/g' app/src/main/java/com/example/ui/screens/home/CustomerHomeScreen.kt
sed -i 's/val searchQuery by authViewModel.searchQuery.collectAsStateWithLifecycle()/val searchQuery by authViewModel.searchQuery.collectAsState()/g' app/src/main/java/com/example/ui/screens/home/CustomerHomeScreen.kt
