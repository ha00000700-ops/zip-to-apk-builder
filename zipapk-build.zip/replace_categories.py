import re

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'r') as f:
    content = f.read()

target = """        // Categories (Circular Icons)
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الأقسام",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    Text(
                        text = "عرض الكل",
                        style = MaterialTheme.typography.labelLarge,
                        color = BluePrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { /* TODO */ }
                    )
                }

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    items(ProfessionData.categories, key = { it.id }) { cat ->
                        val isSelected = selectedCategoryIndex == cat.id
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { selectedCategoryIndex = if (isSelected) null else cat.id }
                        ) {
                            Surface(
                                modifier = Modifier.size(64.dp),
                                shape = CircleShape,
                                color = if (isSelected) BluePrimary else BackgroundLight,
                                border = if (isSelected) null else BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = when(cat.id) {
                                            "home" -> Icons.Default.HomeRepairService
                                            "tech" -> Icons.Default.Computer
                                            "car" -> Icons.Default.DirectionsCar
                                            "build" -> Icons.Default.Construction
                                            else -> Icons.Default.Category
                                        },
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else BlueDark,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = cat.nameAr,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                color = if (isSelected) BluePrimary else TextSecondaryLight
                            )
                        }
                    }
                }
            }
        }"""

replacement = """        // Categories (Circular Icons)
        item {
            Column(modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الأقسام",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = BlueDark
                    )
                    Text(
                        text = if (showAllCategories) "عرض أقل" else "عرض الكل",
                        style = MaterialTheme.typography.labelLarge,
                        color = BluePrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { showAllCategories = !showAllCategories }
                    )
                }

                if (showAllCategories) {
                    FlowRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        ProfessionData.categories.forEach { cat ->
                            val isSelected = selectedCategoryIndex == cat.id
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { selectedCategoryIndex = if (isSelected) null else cat.id }
                                    .width(80.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(64.dp),
                                    shape = CircleShape,
                                    color = if (isSelected) BluePrimary else BackgroundLight,
                                    border = if (isSelected) null else BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Category,
                                            contentDescription = null,
                                            tint = if (isSelected) Color.White else BlueDark,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = cat.nameAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    color = if (isSelected) BluePrimary else TextSecondaryLight,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                } else {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        items(ProfessionData.categories, key = { it.id }) { cat ->
                            val isSelected = selectedCategoryIndex == cat.id
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .clickable { selectedCategoryIndex = if (isSelected) null else cat.id }
                                    .width(80.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.size(64.dp),
                                    shape = CircleShape,
                                    color = if (isSelected) BluePrimary else BackgroundLight,
                                    border = if (isSelected) null else BorderStroke(1.dp, OutlineLight.copy(alpha = 0.5f))
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Category,
                                            contentDescription = null,
                                            tint = if (isSelected) Color.White else BlueDark,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = cat.nameAr,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                                    color = if (isSelected) BluePrimary else TextSecondaryLight,
                                    textAlign = TextAlign.Center,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }"""

if target in content:
    content = content.replace(target, replacement)
else:
    print("Could not find categories target")

with open('app/src/main/java/com/example/ui/screens/home/MarketplaceTab.kt', 'w') as f:
    f.write(content)
