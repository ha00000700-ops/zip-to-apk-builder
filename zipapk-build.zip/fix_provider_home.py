import re

with open('app/src/main/java/com/example/ui/screens/home/ProviderHomeScreen.kt', 'r') as f:
    content = f.read()

target = """                    // Stats Section
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            StatCard(
                                title = "الطلبات",
                                value = "الطلبات", // Just a label or keep value if known
                                icon = Icons.Default.WorkHistory,
                                color = BluePrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { currentTab = 1 }
                            )
                            StatCard(
                                title = "التقييم",
                                value = "تقييمات",
                                icon = Icons.Default.Star,
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                            StatCard(
                                title = "الخبرة",
                                value = "${providerProfile?.experienceYears ?: 0}+",
                                icon = Icons.Default.CheckCircle,
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                        }
                    }"""

replacement = """                    // Stats Section
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            StatCard(
                                title = "الطلبات",
                                value = "${providerProfile?.completedJobsCount ?: 0}",
                                icon = Icons.Default.WorkHistory,
                                color = BluePrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { currentTab = 1 }
                            )
                            StatCard(
                                title = "التقييم",
                                value = if (providerProfile?.rating == 0.0) "-" else String.format("%.1f", providerProfile?.rating ?: 0.0),
                                icon = Icons.Default.Star,
                                color = AmberPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                            StatCard(
                                title = "الخبرة",
                                value = "${providerProfile?.experienceYears ?: 0}+",
                                icon = Icons.Default.CheckCircle,
                                color = EmeraldPrimary,
                                modifier = Modifier.weight(1f),
                                onClick = { onNavigateToProfile() }
                            )
                        }
                    }"""

content = content.replace(target, replacement)

with open('app/src/main/java/com/example/ui/screens/home/ProviderHomeScreen.kt', 'w') as f:
    f.write(content)
