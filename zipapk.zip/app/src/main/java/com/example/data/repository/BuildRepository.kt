package com.example.data.repository

import com.example.data.local.BuildHistoryDao
import com.example.data.local.BuildHistoryEntity
import com.example.data.model.ApkBuildConfig
import com.example.data.model.BuildStatusResponse
import com.example.data.network.BuildApiClient
import com.example.data.preferences.AppSettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File

class BuildRepository(
    private val buildApiClient: BuildApiClient,
    private val buildHistoryDao: BuildHistoryDao,
    private val appSettingsRepository: AppSettingsRepository
) {

    val historyFlow: Flow<List<BuildHistoryEntity>> = buildHistoryDao.getAllHistory()

    fun startBuildProcess(
        zipFile: File,
        config: ApkBuildConfig,
        fileSizeFormatted: String
    ): Flow<BuildStatusResponse> = flow {
        val serverUrl = appSettingsRepository.serverUrlFlow.first()
        if (serverUrl.isBlank()) {
            throw IllegalStateException("خدمة إنشاء APK غير متصلة حاليًا. يرجى ضبط عنوان Build Server في الإعدادات.")
        }

        // 1. Initial State: Uploading
        emit(
            BuildStatusResponse(
                jobId = "",
                status = "running",
                progress = 10,
                stage = "رفع المشروع",
                message = "جارٍ رفع ملف المشروع (${zipFile.name}) إلى خادم البناء...",
                apkAvailable = false,
                downloadUrl = null
            )
        )

        // 2. Submit build job
        val submitResult = buildApiClient.submitBuildJob(serverUrl, zipFile, config)
        if (submitResult.isFailure) {
            val error = submitResult.exceptionOrNull()
            val failureMessage = error?.localizedMessage ?: "فشل في رفع المشروع إلى خادم البناء"
            
            // Record failure in history
            buildHistoryDao.insert(
                BuildHistoryEntity(
                    jobId = "failed_${System.currentTimeMillis()}",
                    projectName = config.appName,
                    packageName = config.packageName,
                    versionName = config.versionName,
                    versionCode = config.versionCode,
                    fileSizeFormatted = fileSizeFormatted,
                    status = "failed",
                    stage = "رفع المشروع",
                    message = failureMessage,
                    downloadUrl = null,
                    apkAvailable = false,
                    timestamp = System.currentTimeMillis()
                )
            )

            emit(
                BuildStatusResponse(
                    jobId = "",
                    status = "failed",
                    progress = 0,
                    stage = "رفع المشروع",
                    message = failureMessage,
                    apkAvailable = false,
                    downloadUrl = null,
                    logs = error?.stackTraceToString()
                )
            )
            return@flow
        }

        val job = submitResult.getOrThrow()
        val jobId = job.jobId

        // Insert initial history record
        val historyId = buildHistoryDao.insert(
            BuildHistoryEntity(
                jobId = jobId,
                projectName = config.appName,
                packageName = config.packageName,
                versionName = config.versionName,
                versionCode = config.versionCode,
                fileSizeFormatted = fileSizeFormatted,
                status = "queued",
                stage = "في انتظار البناء",
                message = "تم استلام المشروع في قائمة الانتظار",
                downloadUrl = null,
                apkAvailable = false,
                timestamp = System.currentTimeMillis()
            )
        )

        emit(
            BuildStatusResponse(
                jobId = jobId,
                status = "queued",
                progress = 15,
                stage = "في انتظار البناء",
                message = "تم إرسال المشروع بنجاح، في انتظار بدء البناء...",
                apkAvailable = false,
                downloadUrl = null
            )
        )

        val startTime = System.currentTimeMillis()
        var isCompleted = false
        var consecutiveErrors = 0

        // Polling loop (every 3 seconds)
        while (!isCompleted) {
            delay(3000)

            val statusResult = buildApiClient.getBuildStatus(serverUrl, jobId)
            if (statusResult.isSuccess) {
                consecutiveErrors = 0
                val status = statusResult.getOrThrow()
                emit(status)

                val elapsedSeconds = (System.currentTimeMillis() - startTime) / 1000

                // Update history record
                buildHistoryDao.update(
                    BuildHistoryEntity(
                        id = historyId,
                        jobId = jobId,
                        projectName = config.appName,
                        packageName = config.packageName,
                        versionName = config.versionName,
                        versionCode = config.versionCode,
                        fileSizeFormatted = fileSizeFormatted,
                        status = status.status,
                        stage = status.stage,
                        message = status.message,
                        downloadUrl = status.downloadUrl,
                        apkAvailable = status.apkAvailable,
                        timestamp = startTime,
                        durationSeconds = elapsedSeconds
                    )
                )

                if (status.status.equals("success", ignoreCase = true) ||
                    status.status.equals("failed", ignoreCase = true) ||
                    status.status.equals("cancelled", ignoreCase = true)
                ) {
                    isCompleted = true
                }
            } else {
                consecutiveErrors++
                if (consecutiveErrors >= 5) {
                    val errMsg = "انقطع الاتصال بخادم البناء بعد عدة محاولات."
                    emit(
                        BuildStatusResponse(
                            jobId = jobId,
                            status = "failed",
                            progress = 0,
                            stage = "خطأ في الاتصال",
                            message = errMsg,
                            apkAvailable = false,
                            downloadUrl = null
                        )
                    )
                    isCompleted = true
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    suspend fun cancelBuild(jobId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val serverUrl = appSettingsRepository.serverUrlFlow.first()
        if (serverUrl.isBlank() || jobId.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("معرف البناء أو عنوان الخادم غير صالح."))
        }
        val result = buildApiClient.cancelBuildJob(serverUrl, jobId)
        // update local db
        val record = buildHistoryDao.getByJobId(jobId)
        if (record != null) {
            buildHistoryDao.update(record.copy(status = "cancelled", stage = "ملغي", message = "تم إلغاء عملية البناء بواسطة المستخدم"))
        }
        result
    }

    suspend fun deleteHistoryItem(id: Long) = withContext(Dispatchers.IO) {
        buildHistoryDao.deleteById(id)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        buildHistoryDao.clearAll()
    }
}
